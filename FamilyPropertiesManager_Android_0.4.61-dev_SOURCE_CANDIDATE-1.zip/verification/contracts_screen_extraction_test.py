from pathlib import Path
root = Path(__file__).resolve().parents[1]
main = (root / "app/src/main/java/com/example/rentals/MainActivity.kt").read_text(encoding="utf-8")
feature = (root / "app/src/main/java/com/example/rentals/features/contracts/ContractsArchiveScreen.kt").read_text(encoding="utf-8")
assert "import com.example.rentals.features.contracts.ContractsArchiveScreen" in main
assert "Tab.Contracts->ContractsArchiveScreen(activity,contractRepository,units)" in main
assert "fun ContractsArchiveScreen(activity:FragmentActivity,repository:ContractRepository,units:List<UnitRecord>)" in feature
assert "private fun ContractsArchiveScreen" not in main
for token in ("GetContractArchive(repository)", "SaveContract(repository)", "DeleteContract(repository)", "AddContractAttachment(repository)", "RemoveContractAttachment(repository)", "fun beginRenewal(id:Long)"):
    assert token in feature, token
assert "editingLeaseId=0L" in feature
assert "تجديد مستقل للعقد السابق رقم ${previous.id}" in feature
assert "ActivityResultContracts.OpenDocument()" in feature
file_manager = (root / "app/src/main/java/com/example/rentals/files/AttachmentFileManager.kt").read_text(encoding="utf-8")
assert "Intent.ACTION_VIEW" in file_manager
assert "AttachmentFileManager(activity)" in feature
print("PASS: contracts screen delegates archive and write operations through repository/use cases; renewals and document archive remain available.")
