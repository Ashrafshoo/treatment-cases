import 'dart:convert';
import 'package:sqflite_sqlcipher/sqflite.dart';
import '../../../core/database/app_database.dart';
import '../../auth/data/app_session.dart';

class ExpensesRepository {
  Future<Database> get _db async => AppDatabase.instance.database;
  String _id() => DateTime.now().microsecondsSinceEpoch.toString();

  Future<List<Map<String, Object?>>> all() async => (await _db).query(
    'expenses', where: 'archived_at IS NULL', orderBy: 'expense_date DESC, created_at DESC');

  Future<void> save({String? id, required String name, required int amountMinor, required DateTime date, String? notes}) async {
    AppSession.instance.requireAdmin();
    if (name.trim().isEmpty || amountMinor < 0) throw ArgumentError('بيانات المصروف غير صحيحة');
    final db = await _db;
    await db.transaction((tx) async {
      final isNew = id == null;
      final recordId = id ?? _id();
      final before = isNew ? <Map<String,Object?>>[] : await tx.query('expenses', where: 'id=?', whereArgs: [recordId], limit: 1);
      final values = <String,Object?>{'name': name.trim(), 'amount_minor': amountMinor, 'expense_date': _date(date), 'notes': notes, 'updated_at': DateTime.now().toIso8601String(), 'modified_unreviewed':1};
      if (isNew) { values['id'] = recordId; await tx.insert('expenses', values); }
      else { await tx.update('expenses', values, where: 'id=?', whereArgs: [recordId]); }
      await tx.insert('audit_log', {'id': _id(), 'user_id': AppSession.instance.userId, 'entity_type': 'expense', 'entity_id': recordId, 'action': isNew ? 'create' : 'update', 'before_json': isNew ? null : jsonEncode(before.first), 'after_json': jsonEncode(values)});
    });
  }

  Future<void> archive(String id) async {
    AppSession.instance.requireAdmin();
    final db = await _db;
    await db.transaction((tx) async {
      final rows = await tx.query('expenses', where: 'id=?', whereArgs: [id], limit: 1);
      if (rows.isEmpty) return;
      final now = DateTime.now().toIso8601String();
      await tx.update('expenses', {'archived_at': now, 'updated_at': now}, where: 'id=?', whereArgs: [id]);
      await tx.insert('audit_log', {'id': _id(), 'user_id': AppSession.instance.userId, 'entity_type': 'expense', 'entity_id': id, 'action': 'archive', 'before_json': jsonEncode(rows.first), 'after_json': jsonEncode({'archived_at': now})});
    });
  }

  Future<Map<String,int>> totals() async {
    final db = await _db;
    final rows = await db.rawQuery("SELECT COALESCE(SUM(amount_minor),0) AS total, COUNT(*) AS count FROM expenses WHERE archived_at IS NULL");
    return {'total': (rows.first['total'] as num).toInt(), 'count': (rows.first['count'] as num).toInt()};
  }

  static String _date(DateTime d) => '${d.year.toString().padLeft(4,'0')}-${d.month.toString().padLeft(2,'0')}-${d.day.toString().padLeft(2,'0')}';
}
