from pathlib import Path
root=Path(__file__).resolve().parents[1]
local=(root/"android/app/src/main/java/com/treatmentcases/app/LocalDb.kt").read_text(encoding="utf-8")
ui=(root/"android/app/src/main/java/com/treatmentcases/app/MainActivity.kt").read_text(encoding="utf-8")
seed=(root/"android/app/src/main/assets/medicines_seed.json").read_text(encoding="utf-8")
checks={
 "database migration for name history":"medicine_name_history" in local and "if(oldVersion<4)" in local,
 "atomic correction transaction":"approveMedicineNameCorrection" in local and "d.beginTransaction()" in local and "d.setTransactionSuccessful()" in local,
 "case records relinked":"UPDATE cases SET medicine=? WHERE medicine=? COLLATE NOCASE" in local,
 "old name retained as alias":"put(\"aliases\",aliasList.joinToString" in local,
 "affected record count captured":"affected_cases" in local and "SELECT COUNT(*) FROM cases WHERE medicine" in local,
 "correction action accessible from medicine details":"تصحيح واعتماد الاسم" in ui,
 "explicit same-product confirmation":"أؤكد أن الاسم الجديد يخص المستحضر نفسه" in ui,
 "correction history in audit report":"medicineNameHistoryReport" in ui,
 "approved Baritava canonical entry":"\"name\": \"BARITAVA\"" in seed,
 "approved Recormon canonical entry":"\"name\": \"RECORMON\"" in seed,
}
for label,ok in checks.items(): print(("PASS" if ok else "FAIL")+": "+label)
if not all(checks.values()): raise SystemExit(1)
