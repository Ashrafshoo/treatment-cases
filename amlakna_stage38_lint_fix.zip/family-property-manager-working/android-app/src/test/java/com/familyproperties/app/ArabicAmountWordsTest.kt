package com.familyproperties.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.assertThrows
import org.junit.Test

class ArabicAmountWordsTest {
    @Test fun convertsZero() {
        assertEquals("صفر", ArabicAmountWords.convert(0))
    }

    @Test fun convertsTensAndHundreds() {
        assertEquals("واحد وعشرون", ArabicAmountWords.convert(21))
        assertEquals("مائتان وخمسة وثلاثون", ArabicAmountWords.convert(235))
    }

    @Test fun convertsThousandsAndMillions() {
        assertEquals("ألفان", ArabicAmountWords.convert(2_000))
        assertEquals("ثلاثة آلاف", ArabicAmountWords.convert(3_000))
        assertTrue(ArabicAmountWords.convert(1_250_000).contains("مليون"))
    }

    @Test fun convertsEgpAndPiastresForReceipt() {
        assertEquals("مائة وخمسة وعشرون جنيهاً مصرياً فقط لا غير", ArabicAmountWords.forEgpMinorUnits(12_500))
        assertTrue(ArabicAmountWords.forEgpMinorUnits(12_550).contains("وخمسون قرشاً"))
    }

    @Test fun negativeAmountsAreRejected() {
        assertThrows(IllegalArgumentException::class.java) { ArabicAmountWords.forEgpMinorUnits(-1) }
    }
}
