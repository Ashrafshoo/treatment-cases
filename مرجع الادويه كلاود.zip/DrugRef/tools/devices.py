"""كشف الأجهزة التعويضية والمستلزمات الطبية. الاسم الأجنبي هو المرجع (إن وُجد) وإلا الاسم العربي."""
import re

def _n(s: str) -> str:
    s = (s or "").lower()
    s = re.sub("[\u064B-\u065F\u0670\u0640]", "", s)
    s = re.sub("[أإآٱ]", "ا", s).replace("ى", "ي").replace("ة", "ه")
    return re.sub(r"\s+", " ", s).strip()

BODY = r"(?:thumb|wrist|elbow|knee|ankle|back|lumbar|lumbo\w*|shoulder|neck|hand|foot|waist|calf|arch|groin|chest|abdominal|pelvic|hip|finger|cervical|clavicle|rib|tennis|patella\w*)"

# (نوع الجهاز، النمط) — بالترتيب: الأول المطابق يفوز
RULES = [
    ("كرسي متحرك", r"كرسي متحرك|كرسي كهربائي|كراسي متحركه|wheel ?chair|commode|كرسي حمام"),
    ("عكاز", r"عكاز|عكازات|كراتش|\bcrutch|\bwalking (stick|cane)"),
    ("مشاية", r"مشايه|مشايات|\bwalker\b|\bwalking frame|\brollator"),
    ("طرف صناعي", r"طرف صناعي|اطراف صناعيه|جهاز تعويضي|prosthe|artificial (limb|leg|arm)|\bstump\b"),
    ("جبيرة", r"جبيره|جباير|\bsplint|plaster of paris"),
    ("رقبة طبية", r"رقبه طبيه|\bcervical (collar|brace)|\b(hard|soft|rigid|neck) collar|\bneck (support|brace)"),
    ("جهاز تنفس", r"\bcpap\b|\bbpap\b|\bventilator|جهاز تنفس|oxygen concentrator|منظم اكسجين|oxygen (regulator|mask)"),
    ("جهاز تقويم (شلل)", r"جهاز شلل|\bkafo\b"),
    ("جهاز طبي", r"\bnebuli[sz]er\b(?!.*\b(sol|solution|amp|ampoules?|ml)\b)|جهاز نيبوليزر|جهاز قياس|جهاز ضغط|ضغط دم|digital blood|blood pressure|\bglucometer|\bthermometer|ترمومتر|\bstethoscope|سماعه طبيه|\bpulse oximeter|\bnebuli[sz]er set"),
    ("جورب ضاغط", r"شراب طبي|شراب دوالي|stocking|\bstoking|\bcompression (sock|stock)|varicose (sock|stock)"),
    ("نعل طبي", r"حذاء اير كاست|air ?cast|cast shoe|insole|نعل طبي|نعال طبيه|حذاء طبي|orthotic|arch support|orthopedic (shoe|insole)"),
    ("حزام طبي", r"\bحزام|corset|lumbosacral|\bbelt\b|\babdominal binder|\bposture"),
    ("دعامة / رباط", rf"\b{BODY} (support|brace|sleeve|guard|strap|ranger|splint)|\b(support|brace|sleeve) {BODY}|\bbrace\b|\bsling\b|حامل ذراع|رباط ضاغط|دعامه|دعامات|كاحل|ركبه|معصم|كوع تنس|\bknee\b|\bankle\b|\bwrist\b|\belbow\b|\bsupport (bandage|wrap)|\bsupport\b(?=\s*(?:size|small|medium|large|xl|[sml]\b|محلي|مصري))"),
    ("سماعة / سمع", r"سماعه اذن|hearing aid"),
    ("مستلزمات طبية", r"\bgauze\b|شاش|بلاستر طبي|\bsteripad|alcohol (swab|pad)|حفاضه|حفاض|\bdiaper|\bgloves?\b|جوانتي|قفاز|\bface mask\b|كمامه|\blancets?\b|test strips?|شرائط (قياس|سكر)|\bcatheter\b|قسطره|\bcannula\b|كانيولا|urine bag|كيس بول|\bbandage\b|ضماد|\b(surgical|kinesio\w*|sports|medical) tape\b|\bswab pad|\bneedles+\b|\bdisposable mask|\bsurgical mask|\bn95|\bheat pads?\b|antiulcer pad|hemorrhoid cushion|\bbed ?sore|air (mattress|cushion)"),
]
COMPILED = [(t, re.compile(p)) for t, p in RULES]

# علامات الدواء: وجودها في الاسم تُبطل كونه جهازًا
DRUG = re.compile(r"\b\d+(?:\.\d+)?\s*(mg|mcg|ug|iu|gm|g)\b|\b(tab|tabs|cap|caps|amp|amps|vial|vials|syrup|susp|sol|solution|cream|gel|oint|drops|supp|sachet|inj)\b|مجم|اقراص|كبسول|امبول|فيال|\bprefilled\b|\bزنك\b|\bvitamin|\bprogram\b|\bseasonal\b|\bimmune\b")

def detect(name_en: str, name_ar: str):
    """يعيد نوع الجهاز أو None. المرجع الاسم الأجنبي إن وُجد."""
    anchor = _n(name_en) if (name_en or "").strip() else _n(name_ar)
    if not anchor:
        return None
    # «شراب طبي» جورب لا دواء: نستثنيه من علامات الدواء
    probe = anchor.replace("شراب طبي", "جورب").replace("شراب دوالي", "جورب")
    if re.search(r"\bsyringe\b|سرنجه", anchor):
        rest = re.sub(r"\(?\s*\d+\s*(cm3|cc|ml|سم)\s*\)?", "", anchor)
        if not re.search(r"\d|prefilled|\bpre\b|disp|vaccin|dose|جرعه", rest):
            return "مستلزمات طبية"
        return None
    for typ, rx in COMPILED:
        if rx.search(anchor):
            if typ in ("حزام طبي",) and re.search(r"\bحزام\b", anchor) and not DRUG.search(probe):
                return typ
            if typ in ("دعامة / رباط", "نعل طبي"):
                probe = re.sub(r"\bgel\b", " ", probe)
            if DRUG.search(probe):
                return None
            return typ
    return None


PROSTHETIC = {"كرسي متحرك", "عكاز", "مشاية", "طرف صناعي", "جبيرة", "رقبة طبية", "جورب ضاغط", "نعل طبي",
              "حزام طبي", "دعامة / رباط", "جهاز تقويم (شلل)", "سماعة / سمع"}

def device_class(device_type: str) -> str:
    """تصنيف علاجي للجهاز: تعويضي/تقويمي أم جهاز ومستلزم طبي."""
    dt = (device_type or "").strip()
    if dt in PROSTHETIC or re.search(r"عكاز|حزام|دعام|كراتش|walker|splint|brace|sling|stocking|insole|support|collar|corset|lumbar|cervical|بتر|طرف", dt, re.I):
        return "أجهزة تعويضية"
    return "أجهزة ومستلزمات طبية"

FORM_FROM_EN = [("TAB", "أقراص"), ("CAP", "كبسولات"), ("AMP", "أمبول"), ("VIAL", "فيال"), ("SYRUP", "شراب"),
                ("SUSP", "معلق"), ("CREAM", "كريم"), ("GEL", "جل"), ("OINT", "مرهم"), ("DROPS", "قطرة"),
                ("SUPP", "تحاميل"), ("SACHET", "أكياس"), ("SPRAY", "بخاخ"), ("SOL", "محلول"), ("POWDER", "مسحوق")]
