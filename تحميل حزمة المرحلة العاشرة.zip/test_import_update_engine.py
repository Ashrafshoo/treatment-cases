import tempfile, shutil, unittest
from pathlib import Path
from openpyxl import Workbook
from import_update_engine import migrate, preview_personnel, preview_cases, approve, connect
from test_fixtures import create_test_db
class EngineTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(); self.db=create_test_db(Path(self.tmp.name)/'test.db'); migrate(self.db)
 def tearDown(self): self.tmp.cleanup()
 def book(self,headers,rows,name):
  p=Path(self.tmp.name)/name; w=Workbook(); s=w.active; s.title='بيانات العاملين' if 'الوظيفة' in headers else 'الحالات الحرجة'; s.append(headers)
  for r in rows:s.append(r)
  w.save(p); return p
 def test_personnel_preview_then_approve(self):
  p=self.book(['رقم الأداء','الاســـم','الوظيفة','المنطقة','الإدارة','المحمول','المحمول2','الرقم القومى','النوع'],[['999991','اختبار جديد','فني','القاهرة','إدارة أ','','','30001011234567','ذكر']], 'p.xlsx')
  b,s=preview_personnel(self.db,p); self.assertEqual(s['new'],1)
  c=connect(self.db); self.assertIsNone(c.execute('select 1 from Personnel where performance_number=?',('999991',)).fetchone()); c.close()
  approve(self.db,b,'tester'); c=connect(self.db); self.assertIsNotNone(c.execute('select 1 from Personnel where performance_number=?',('999991',)).fetchone()); c.close()
 def test_case_partial_add(self):
  perf=connect(self.db).execute('select performance_number from Personnel limit 1').fetchone()[0]
  p=self.book(['رقم الأداء','العلاج','التركيز','مدة الصرف','الجرعة','الحالة المرضية','تاريخ الموافقة','ملاحظات'],[[perf,'دواء اختبار إضافي','10 mg','شهر','مرة يومياً','اختبار','2026-01-01','']], 'c.xlsx')
  b,s=preview_cases(self.db,p,'PARTIAL_UPDATE'); self.assertEqual(s['new'],1); approve(self.db,b,'tester')
  c=connect(self.db); self.assertEqual(c.execute("select count(*) from Treatments where medicine_name_raw='دواء اختبار إضافي' and status='ACTIVE'").fetchone()[0],1); c.close()

 def test_partial_update_never_archives(self):
  c=connect(self.db); t=c.execute("select medicine_name_raw from Treatments where status='ACTIVE' limit 1").fetchone(); perf=c.execute("select b.performance_number from Treatments t join Beneficiaries b using(beneficiary_id) where t.status='ACTIVE' limit 1").fetchone()[0]; med=t[0]; c.close()
  p=self.book(['رقم الأداء','العلاج','التركيز','مدة الصرف','الجرعة','الحالة المرضية','تاريخ الموافقة','ملاحظات'],[[perf,'علاج إضافي تجريبي','5 mg','','','','','']], 'partial.xlsx')
  b,s=preview_cases(self.db,p,'PARTIAL_UPDATE'); self.assertEqual(s['archive_candidates'],0); approve(self.db,b,'tester')
  c=connect(self.db); self.assertGreater(c.execute("select count(*) from Treatments where status='ACTIVE'").fetchone()[0],0); c.close()
 def test_full_snapshot_proposes_archive_without_applying(self):
  c=connect(self.db); t=c.execute("select t.medicine_name_raw,t.strength_raw,b.performance_number from Treatments t join Beneficiaries b using(beneficiary_id) where t.status='ACTIVE' limit 1").fetchone(); c.close()
  # Empty snapshot explicitly declares the complete set to be empty; only proposes archival.
  p=self.book(['رقم الأداء','العلاج','التركيز','مدة الصرف','الجرعة','الحالة المرضية','تاريخ الموافقة','ملاحظات'],[], 'snapshot.xlsx')
  b,s=preview_cases(self.db,p,'FULL_SNAPSHOT'); self.assertGreater(s['archive_candidates'],0)
  c=connect(self.db); self.assertGreater(c.execute("select count(*) from Treatments where status='ACTIVE'").fetchone()[0],0); c.close()
  approve(self.db,b,'tester',include_archive=True); c=connect(self.db); self.assertEqual(c.execute("select count(*) from Treatments where status='ACTIVE'").fetchone()[0],0); self.assertGreater(c.execute("select count(*) from Treatments where status='STOPPED'").fetchone()[0],0); c.close()

if __name__=='__main__': unittest.main()
