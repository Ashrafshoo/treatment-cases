# عقد خادم المزامنة – 2.7.1-dev

هذه المرحلة تضيف ناقل HTTPS صادراً من التطبيق. لا تتضمن هذه الحزمة خادماً مستضافاً أو حساباً سحابياً أو مفاتيح اتصال؛ لذلك لا تعمل المزامنة الحية قبل تجهيز الخادم وإصدار رمز لكل جهاز.

## المسار
`POST /v1/sync/push`

## ترويسات الطلب
- `Authorization: Bearer <device-token>`
- `Content-Type: application/json; charset=utf-8`
- `Accept: application/json`

## جسم الطلب
```json
{
  "protocol_version": 1,
  "device_id": "stable-device-uuid",
  "events": [
    {
      "event_id": "unique-event-uuid",
      "source_device_id": "stable-device-uuid",
      "entity_type": "case|employee|medicine|strength",
      "entity_id": "stable-entity-uuid",
      "operation": "upsert|delete",
      "base_version": 0,
      "new_version": 1,
      "payload": {}
    }
  ]
}
```

## الاستجابة المطلوبة
HTTP 200 مع JSON:
```json
{
  "accepted_event_ids": ["unique-event-uuid"],
  "message": "accepted"
}
```

على الخادم تنفيذ الآتي قبل إقرار الحدث:
1. التحقق من صلاحية الرمز وربطه بالمستخدم والجهاز والصلاحيات.
2. فرض عزل بيانات كل جهة/حساب؛ لا يجوز قبول `device_id` كهوية موثوقة وحدها.
3. تنفيذ idempotency باستخدام `event_id`؛ تكرار الحدث نفسه لا ينشئ تغييراً مكرراً.
4. التحقق من تسلسل الإصدارات وعدم الكتابة فوق إصدار أحدث.
5. حفظ سجل التعارضات وإرجاع الأحداث المقبولة فقط في `accepted_event_ids`.
6. عدم إرسال ACK قبل حفظ الحدث بشكل دائم في معاملة قاعدة بيانات.

## ضوابط التطبيق
- لا يقبل التطبيق عناوين HTTP غير المشفرة.
- يخزن رمز الاتصال مشفراً باستخدام مفتاح AES-GCM في Android Keystore.
- لا يعلّم التطبيق الحدث بأنه مرسل إلا إذا أعاد الخادم معرفه ضمن قائمة القبول.
- الأحداث غير المؤكدة تبقى قابلة لإعادة المحاولة.
- هذه المرحلة Push فقط؛ استقبال تغييرات الأجهزة الأخرى، ومراجعة التعارضات، وإدارة المستخدمين والأدوار على الخادم تأتي في مرحلة لاحقة.
