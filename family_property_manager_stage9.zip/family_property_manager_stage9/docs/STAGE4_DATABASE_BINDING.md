# Stage 4 — Local database binding

## Implemented in source
- Added `sqflite`, `path`, and `path_provider` dependencies.
- Added the initial SQL schema as a bundled Flutter asset and a versioned local database at the app documents directory.
- Enabled SQLite foreign-key enforcement on connection.
- Added stage-3 indexes and immutable approved-receipt triggers during database creation/upgrades.
- Added repository operations for property, unit, and tenant listing, create, update, and soft archive.
- Added audit-log entries for create/update/archive operations.
- Added a working Arabic records screen with tabs, add/edit dialogs, tenant assignment to a unit, and soft archive confirmation.
- Dashboard counters read live counts from SQLite and refresh after returning from the records screen.

## Verification performed
- Python SQLite binding test: 4/4 passed.
- Existing stage-3 schema test: 4/4 passed.
- Existing legacy smoke test: passed (its printed table count is from an older 19-table expectation and should not be used as the current table count).
- Current schema contains 20 business tables plus `schema_migrations`; `PRAGMA foreign_key_check` returns no rows.
- CRUD relation test verified a unit joins to its property and current tenant.
- Approved receipt update guard verified.

## Not yet complete
- Flutter/Dart SDK is not available in the build environment, so `flutter pub get`, `flutter analyze`, `flutter test`, Android compilation, and APK generation have not been run.
- Login remains a development entry point; authentication, password hashing, roles, and biometric unlock are not active.
- SQLCipher encryption and Android Keystore key management are not active. Do not put real family data into this build yet.
- Lease, rent, payment, receipt generation/printing, expenses, documents, Excel import/export, sync, notifications, and backup screens/services remain future implementation stages.
