-- A unit may have only one active/open-ended lease at a time.
CREATE TRIGGER IF NOT EXISTS one_active_lease_per_unit_insert
BEFORE INSERT ON leases
WHEN NEW.status IN ('active','ending_soon','open_ended') AND NEW.archived_at IS NULL
BEGIN
  SELECT CASE WHEN EXISTS (
    SELECT 1 FROM leases l
    WHERE l.unit_id = NEW.unit_id
      AND l.archived_at IS NULL
      AND l.status IN ('active','ending_soon','open_ended')
      AND COALESCE(l.manual_end_date,l.calculated_end_date,'9999-12-31') >= NEW.start_date
      AND COALESCE(NEW.manual_end_date,NEW.calculated_end_date,'9999-12-31') >= l.start_date
  ) THEN RAISE(ABORT,'unit_already_has_overlapping_active_lease') END;
END;

CREATE TRIGGER IF NOT EXISTS one_active_lease_per_unit_update
BEFORE UPDATE OF unit_id,start_date,calculated_end_date,manual_end_date,status,archived_at ON leases
WHEN NEW.status IN ('active','ending_soon','open_ended') AND NEW.archived_at IS NULL
BEGIN
  SELECT CASE WHEN EXISTS (
    SELECT 1 FROM leases l
    WHERE l.unit_id = NEW.unit_id
      AND l.id <> OLD.id
      AND l.archived_at IS NULL
      AND l.status IN ('active','ending_soon','open_ended')
      AND COALESCE(l.manual_end_date,l.calculated_end_date,'9999-12-31') >= NEW.start_date
      AND COALESCE(NEW.manual_end_date,NEW.calculated_end_date,'9999-12-31') >= l.start_date
  ) THEN RAISE(ABORT,'unit_already_has_overlapping_active_lease') END;
END;

INSERT OR IGNORE INTO schema_migrations(version,name)
VALUES (6,'stage18_active_lease_overlap_constraints');
