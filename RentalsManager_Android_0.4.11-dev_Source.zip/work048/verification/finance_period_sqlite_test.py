import sqlite3, tempfile, os
# Simulate a version-10 database with historical batches (period unknown).
c=sqlite3.connect(':memory:')
c.execute('PRAGMA foreign_keys=ON')
c.executescript('''
CREATE TABLE collection_batches(id INTEGER PRIMARY KEY AUTOINCREMENT,collector TEXT,received_date TEXT,amount REAL,method TEXT,expenses REAL DEFAULT 0,handed_over REAL DEFAULT 0,remaining REAL DEFAULT 0,notes TEXT);
CREATE TABLE collector_receivables(id INTEGER PRIMARY KEY AUTOINCREMENT,collector TEXT NOT NULL,period TEXT,collected_date TEXT,amount REAL NOT NULL,handed_over REAL DEFAULT 0,balance REAL NOT NULL,notes TEXT);
CREATE TABLE heir_payouts(id INTEGER PRIMARY KEY AUTOINCREMENT,heir_id INTEGER,amount REAL,pay_date TEXT,method TEXT,period TEXT,notes TEXT);
CREATE TABLE expenses(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,amount REAL,expense_date TEXT,category TEXT,recurring INTEGER DEFAULT 0,allocation_json TEXT,attachment_uri TEXT,notes TEXT);
INSERT INTO collection_batches(collector,received_date,amount,method,expenses,handed_over,remaining,notes) VALUES('محصل قديم','2026-08-01',500,'نقدي',0,0,500,'legacy');
INSERT INTO expenses(title,amount,expense_date,category,notes) VALUES('مصروف قديم',75,'2026-08-02','عام','legacy');
''')
# Migration 10 -> 11
c.execute('ALTER TABLE collection_batches ADD COLUMN period TEXT')
c.execute('CREATE INDEX IF NOT EXISTS idx_collection_batches_period ON collection_batches(period,collector)')
c.execute('ALTER TABLE expenses ADD COLUMN period TEXT')
c.execute('CREATE INDEX IF NOT EXISTS idx_expenses_period ON expenses(period)')
assert c.execute('SELECT period,remaining FROM collection_batches WHERE id=1').fetchone()==(None,500)
assert c.execute('SELECT period,amount FROM expenses WHERE id=1').fetchone()==(None,75)
# New receivables for two distinct months
c.executemany('INSERT INTO collector_receivables(collector,period,collected_date,amount,handed_over,balance,notes) VALUES(?,?,?,?,0,?,?)',[
 ('محصل أ','2026-10','2026-10-30',1000,1000,'oct'),('محصل أ','2026-11','2026-11-30',2000,2000,'nov')])
c.commit()
# A November handover cannot draw October funds
rows=c.execute('SELECT id,balance FROM collector_receivables WHERE collector=? AND period=? AND balance>0 ORDER BY id',('محصل أ','2026-11')).fetchall()
held=sum(x[1] for x in rows)
assert held==2000
assert held < 2100  # 1000 in October is deliberately not counted
# Successful November handover
c.execute('BEGIN')
rows=c.execute('SELECT id,balance FROM collector_receivables WHERE collector=? AND period=? AND balance>0 ORDER BY id',('محصل أ','2026-11')).fetchall()
remaining=1500
for rid,balance in rows:
    take=min(balance,remaining)
    c.execute('UPDATE collector_receivables SET handed_over=handed_over+?,balance=balance-? WHERE id=?',(take,take,rid)); remaining-=take
c.execute('INSERT INTO collection_batches(collector,received_date,period,amount,method,expenses,handed_over,remaining,notes) VALUES(?,?,?,?,?,?,?,?,?)',('محصل أ','2026-11-30','2026-11',1500,'تحويل',100,0,1400,'nov batch'))
c.commit()
# Only November funds are available for November payout; legacy and October are excluded.
avail_nov=c.execute('SELECT COALESCE(SUM(remaining),0) FROM collection_batches WHERE period=?',('2026-11',)).fetchone()[0]
assert avail_nov==1400, avail_nov
avail_oct=c.execute('SELECT COALESCE(SUM(remaining),0) FROM collection_batches WHERE period=?',('2026-10',)).fetchone()[0]
assert avail_oct==0
legacy=c.execute('SELECT COALESCE(SUM(remaining),0) FROM collection_batches WHERE period IS NULL').fetchone()[0]
assert legacy==500
# Allocate 1200 to November, not to legacy or other periods.
c.execute('BEGIN')
left=1200
for bid,balance in c.execute('SELECT id,remaining FROM collection_batches WHERE period=? AND remaining>0 ORDER BY id',('2026-11',)).fetchall():
    take=min(balance,left)
    c.execute('UPDATE collection_batches SET remaining=remaining-?,handed_over=handed_over+? WHERE id=?',(take,take,bid));left-=take
c.execute('INSERT INTO heir_payouts(heir_id,amount,pay_date,method,period) VALUES(1,1200,\'2026-11-30\',\'تحويل\',\'2026-11\')')
c.commit()
assert c.execute('SELECT remaining FROM collection_batches WHERE period=\'2026-11\'').fetchone()[0]==200
assert c.execute('SELECT remaining FROM collection_batches WHERE period IS NULL').fetchone()[0]==500
assert c.execute('SELECT balance FROM collector_receivables WHERE period=\'2026-10\'').fetchone()[0]==1000
assert c.execute('SELECT balance FROM collector_receivables WHERE period=\'2026-11\'').fetchone()[0]==500
# Period tagging on newly created direct expenses; legacy remains unassigned.
c.execute("INSERT INTO expenses(title,amount,expense_date,period,category,notes) VALUES('مصروف نوفمبر',25,'2026-11-30','2026-11','عام','test')")
assert c.execute("SELECT SUM(amount) FROM expenses WHERE period='2026-11'").fetchone()[0]==25
assert c.execute("SELECT SUM(amount) FROM expenses WHERE period IS NULL").fetchone()[0]==75
print('PASS: migration preserves legacy NULL periods for batches and expenses')
print('PASS: collector handover is constrained by collector + period')
print('PASS: payout is constrained by selected period')
print('PASS: legacy and other-month balances remain untouched')
print('PASS: balances remain internally consistent')
print('PASS: new direct expenses retain their selected month without relabeling legacy expenses')
