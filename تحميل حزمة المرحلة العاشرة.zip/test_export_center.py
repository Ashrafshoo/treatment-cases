import tempfile, unittest, sqlite3
from pathlib import Path
from export_center import export_excel, export_profile_excel, beneficiary_profile
import management, shutil
from openpyxl import load_workbook
from test_fixtures import create_test_db

class ExportTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(); self.db=create_test_db(Path(self.tmp.name)/'base.db'); management.initialize(self.db)
 def tearDown(self): self.tmp.cleanup()
 def test_all_export_counts(self):
  with tempfile.TemporaryDirectory() as d:
   r=export_excel(self.db,Path(d)/'all.xlsx')
   self.assertEqual(r['rows'],2); self.assertEqual(r['people'],1)
   self.assertTrue(Path(r['file']).exists())
 def test_filter_any_selected_medicine(self):
  with tempfile.TemporaryDirectory() as d:
   c=sqlite3.connect(self.db); meds=[x[0] for x in c.execute('select distinct medicine_name_raw from Treatment_Entries where medicine_name_raw is not null limit 2')]; c.close()
   r=export_excel(self.db,Path(d)/'filtered.xlsx',medicines=meds)
   self.assertGreater(r['rows'],0); self.assertLessEqual(r['rows'],2)
 def test_profile_privacy_and_treatments(self):
  c=sqlite3.connect(self.db); pn=c.execute('select performance_number from Personnel limit 1').fetchone()[0]; c.close()
  p=beneficiary_profile(self.db,pn); self.assertIsNotNone(p)
  self.assertNotIn('national_id',p['person']); self.assertIn('current_treatments',p)
  with tempfile.TemporaryDirectory() as d:
   r=export_profile_excel(self.db,pn,Path(d)/'profile.xlsx'); self.assertTrue(Path(r['file']).exists())
 def test_alias_export_filters_by_canonical_name_without_overwriting_raw(self):
  with tempfile.TemporaryDirectory() as d:
   db=Path(d)/'db.sqlite'; create_test_db(db); management.initialize(db)
   c=sqlite3.connect(db); raw=c.execute('SELECT TRIM(medicine_name_raw) FROM Treatment_Entries WHERE medicine_name_raw IS NOT NULL LIMIT 1').fetchone()[0]; c.close()
   mid=management.save_medicine(db,'اسم موحد تجريبي','','','','','tester')
   management.save_medicine_alias(db,raw,mid,'tester')
   out=Path(d)/'alias.xlsx'; result=export_excel(db,out,medicines=['اسم موحد تجريبي'])
   self.assertGreater(result['rows'],0)
   w=load_workbook(out,read_only=True,data_only=True); rows=list(w.active.values); w.close()
   headers=rows[0]; raw_i=headers.index('اسم العلاج كما ورد'); canonical_i=headers.index('اسم العلاج المعتمد')
   self.assertEqual(rows[1][raw_i],raw); self.assertEqual(rows[1][canonical_i],'اسم موحد تجريبي')

 def test_unknown_profile(self):
  self.assertIsNone(beneficiary_profile(self.db,'__not_a_real_number__'))
if __name__=='__main__': unittest.main()
