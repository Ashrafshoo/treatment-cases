import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';
import 'package:archive/archive.dart';
import 'package:cryptography/cryptography.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite_sqlcipher/sqflite.dart';
import '../../../core/database/app_database.dart';
import '../../auth/data/app_session.dart';

class BackupRepository {
  static const _magic = 'FPMBK01\n';
  final _pbkdf2 = Pbkdf2(macAlgorithm: Hmac.sha256(), iterations: 210000, bits: 256);
  final _aes = AesGcm.with256bits();

  Future<File> createEncryptedBackup(String password, String confirm) async {
    AppSession.instance.requireAdmin();
    if (password.length < 10 || password != confirm) {
      throw ArgumentError('أدخل كلمة مرور للنسخة الاحتياطية من 10 أحرف على الأقل وتأكد من تطابقها');
    }
    final db = await AppDatabase.instance.database;
    final checkpoint = await db.rawQuery('PRAGMA wal_checkpoint(FULL)');
    if (checkpoint.isNotEmpty) {
      final state = checkpoint.first;
      final busy = (state['busy'] as num?)?.toInt() ?? 0;
      final logFrames = (state['log'] as num?)?.toInt() ?? -1;
      final copiedFrames = (state['checkpointed'] as num?)?.toInt() ?? -1;
      if (busy != 0 || (logFrames >= 0 && copiedFrames >= 0 && copiedFrames < logFrames)) {
        throw StateError('قاعدة البيانات مشغولة ولم يكتمل ترحيل سجل WAL؛ أعد المحاولة بعد إغلاق العمليات الأخرى');
      }
    }
    final dbPath = await AppDatabase.instance.databasePath;
    await AppDatabase.instance.close();
    final documents = await getApplicationDocumentsDirectory();
    final archive = Archive();
    final databaseBytes = await File(dbPath).readAsBytes();
    await AppDatabase.instance.database;
    archive.addFile(ArchiveFile('family_properties.db', databaseBytes.length, databaseBytes));
    final databaseKey = await AppDatabase.instance.readEncryptionKey();
    if (databaseKey == null || databaseKey.isEmpty) {
      throw StateError('مفتاح تشفير قاعدة البيانات غير متاح؛ أُوقف إنشاء النسخة لحماية البيانات');
    }
    final keyBytes = utf8.encode(databaseKey);
    archive.addFile(ArchiveFile('database_key.txt', keyBytes.length, keyBytes));
    final archiveFolder = Directory(p.join(documents.path, 'property_archive'));
    if (await archiveFolder.exists()) {
      await for (final entity in archiveFolder.list(recursive: true, followLinks: false)) {
        if (entity is File) {
          final relative = p.relative(entity.path, from: documents.path).replaceAll('\\', '/');
          final content = await entity.readAsBytes();
          archive.addFile(ArchiveFile(relative, content.length, content));
        }
      }
    }
    final zipped = ZipEncoder().encode(archive);
    if (zipped == null) throw StateError('تعذر ضغط بيانات النسخة الاحتياطية');

    final random = Random.secure();
    final salt = List<int>.generate(16, (_) => random.nextInt(256));
    final nonce = List<int>.generate(12, (_) => random.nextInt(256));
    final key = await _pbkdf2.deriveKey(secretKey: SecretKey(utf8.encode(password)), nonce: salt);
    final box = await _aes.encrypt(zipped, secretKey: key, nonce: nonce, aad: Uint8List.fromList(_magic.codeUnits));
    final bytes = Uint8List.fromList([..._magic.codeUnits, ...salt, ...nonce, ...box.mac.bytes, ...box.cipherText]);
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/family_properties_${DateTime.now().millisecondsSinceEpoch}.fpmbak');
    await file.writeAsBytes(bytes, flush: true);
    return file;
  }

  Future<void> restoreEncryptedBackup(String password) async {
    AppSession.instance.requireAdmin();
    final picked = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['fpmbak'], withData: true);
    if (picked == null || picked.files.isEmpty) return;
    final selected = picked.files.single;
    final bytes = selected.bytes ?? (selected.path == null ? null : await File(selected.path!).readAsBytes());
    if (bytes == null || bytes.length < 52 || String.fromCharCodes(bytes.take(_magic.length)) != _magic) {
      throw FormatException('ملف النسخة الاحتياطية غير معروف أو تالف');
    }
    final offset = _magic.length;
    final salt = bytes.sublist(offset, offset + 16);
    final nonce = bytes.sublist(offset + 16, offset + 28);
    final mac = Mac(bytes.sublist(offset + 28, offset + 44));
    final cipher = bytes.sublist(offset + 44);
    final key = await _pbkdf2.deriveKey(secretKey: SecretKey(utf8.encode(password)), nonce: salt);
    final zipped = await _aes.decrypt(SecretBox(cipher, nonce: nonce, mac: mac), secretKey: key, aad: Uint8List.fromList(_magic.codeUnits));
    final archive = ZipDecoder().decodeBytes(zipped);
    final databaseEntries = archive.files.where((f) => f.name == 'family_properties.db' && f.isFile).toList();
    if (databaseEntries.isEmpty) throw FormatException('النسخة لا تحتوي على قاعدة البيانات');
    final databaseEntry = databaseEntries.first;
    final databaseBytes = databaseEntry.content as List<int>;
    final keyEntries = archive.files.where((f) => f.name == 'database_key.txt' && f.isFile).toList();
    final importedDatabaseKey = keyEntries.isEmpty
        ? null
        : utf8.decode(keyEntries.first.content as List<int>, allowMalformed: false);
    final currentDatabaseKey = await AppDatabase.instance.readEncryptionKey();
    final documents = await getApplicationDocumentsDirectory();
    final dbPath = await AppDatabase.instance.databasePath;
    final validationFile = File('${(await getTemporaryDirectory()).path}/restore_validation_${DateTime.now().microsecondsSinceEpoch}.db');
    await validationFile.writeAsBytes(databaseBytes, flush: true);
    if (importedDatabaseKey != null) {
      Database? validationDb;
      try {
        validationDb = await openDatabase(validationFile.path, password: importedDatabaseKey, singleInstance: false);
        final check = await validationDb.rawQuery('PRAGMA quick_check');
        final foreign = await validationDb.rawQuery('PRAGMA foreign_key_check');
        if (check.isEmpty || check.first.values.first != 'ok' || foreign.isNotEmpty) {
          throw FormatException('قاعدة البيانات المشفرة داخل النسخة غير سليمة');
        }
      } finally {
        await validationDb?.close();
        if (await validationFile.exists()) await validationFile.delete();
      }
    } else {
      const sqliteHeader = 'SQLite format 3\u0000';
      if (databaseBytes.length < sqliteHeader.length || String.fromCharCodes(databaseBytes.take(sqliteHeader.length)) != sqliteHeader) {
        if (await validationFile.exists()) await validationFile.delete();
        throw FormatException('النسخة القديمة لا تحتوي على مفتاح التشفير ولا يمكن التحقق من قاعدة البيانات');
      }
      if (await validationFile.exists()) await validationFile.delete();
    }

    final liveDb = await AppDatabase.instance.database;
    final localDeviceSettings = await liveDb.query('app_settings', where: 'scope=?', whereArgs: ['device']);
    final checkpoint = await liveDb.rawQuery('PRAGMA wal_checkpoint(FULL)');
    if (checkpoint.isNotEmpty) {
      final state = checkpoint.first;
      final busy = (state['busy'] as num?)?.toInt() ?? 0;
      final logFrames = (state['log'] as num?)?.toInt() ?? -1;
      final copiedFrames = (state['checkpointed'] as num?)?.toInt() ?? -1;
      if (busy != 0 || (logFrames >= 0 && copiedFrames >= 0 && copiedFrames < logFrames)) {
        throw StateError('قاعدة البيانات مشغولة ولم يكتمل ترحيل سجل WAL؛ أعد المحاولة لاحقاً');
      }
    }
    await AppDatabase.instance.close();
    final target = File(dbPath);
    final safetyDb = File('$dbPath.before_restore');
    final walFile = File('$dbPath-wal');
    final shmFile = File('$dbPath-shm');
    final archiveFolder = Directory(p.join(documents.path, 'property_archive'));
    final safetyArchive = Directory(p.join(documents.path, 'property_archive.before_restore'));
    if (await target.exists()) await target.copy(safetyDb.path);
    if (await safetyArchive.exists()) await safetyArchive.delete(recursive: true);
    if (await archiveFolder.exists()) await _copyDirectory(archiveFolder, safetyArchive);

    try {
      if (await walFile.exists()) await walFile.delete();
      if (await shmFile.exists()) await shmFile.delete();
      if (importedDatabaseKey != null) {
        await AppDatabase.instance.writeEncryptionKey(importedDatabaseKey);
      }
      await target.writeAsBytes(databaseBytes, flush: true);
      if (await archiveFolder.exists()) await archiveFolder.delete(recursive: true);
      await archiveFolder.create(recursive: true);
      for (final entry in archive.files.where((f) => f.isFile && f.name.startsWith('property_archive/'))) {
        final normalized = p.normalize(entry.name);
        if (p.isAbsolute(normalized) || normalized.split('/').contains('..')) throw FormatException('مسار ملف غير آمن داخل النسخة');
        final destination = File(p.join(documents.path, normalized));
        await destination.parent.create(recursive: true);
        await destination.writeAsBytes(entry.content as List<int>, flush: true);
      }
      final db = await AppDatabase.instance.database;
      final integrity = await db.rawQuery('PRAGMA quick_check');
      final foreign = await db.rawQuery('PRAGMA foreign_key_check');
      if (integrity.isEmpty || integrity.first.values.first != 'ok' || foreign.isNotEmpty) {
        throw StateError('فشل فحص سلامة قاعدة البيانات بعد الاستعادة');
      }
      // Device-specific appearance settings must remain local when a family
      // backup is restored onto another phone.
      await db.transaction((tx) async {
        await tx.delete('app_settings', where: 'scope=?', whereArgs: ['device']);
        for (final setting in localDeviceSettings) {
          await tx.insert('app_settings', setting, conflictAlgorithm: ConflictAlgorithm.replace);
        }
      });
      if (await safetyDb.exists()) await safetyDb.delete();
      if (await safetyArchive.exists()) await safetyArchive.delete(recursive: true);
    } catch (_) {
      await AppDatabase.instance.close();
      if (currentDatabaseKey != null) {
        await AppDatabase.instance.writeEncryptionKey(currentDatabaseKey);
      }
      if (await walFile.exists()) await walFile.delete();
      if (await shmFile.exists()) await shmFile.delete();
      if (await safetyDb.exists()) await safetyDb.copy(dbPath);
      if (await archiveFolder.exists()) await archiveFolder.delete(recursive: true);
      if (await safetyArchive.exists()) await _copyDirectory(safetyArchive, archiveFolder);
      await AppDatabase.instance.database;
      rethrow;
    }
  }

  Future<void> _copyDirectory(Directory source, Directory target) async {
    await target.create(recursive: true);
    await for (final entity in source.list(recursive: true, followLinks: false)) {
      final relative = p.relative(entity.path, from: source.path);
      final destination = p.join(target.path, relative);
      if (entity is Directory) {
        await Directory(destination).create(recursive: true);
      } else if (entity is File) {
        await File(destination).parent.create(recursive: true);
        await entity.copy(destination);
      }
    }
  }
}
