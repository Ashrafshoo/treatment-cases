from pathlib import Path
root = Path(__file__).resolve().parents[1]
finance = (root / "app/src/main/java/com/example/rentals/features/finance/FinanceScreen.kt").read_text()
components = (root / "app/src/main/java/com/example/rentals/ui/components/PropertyComponents.kt").read_text()
reviewed_importer = (root / "app/src/main/java/com/example/rentals/io/ReviewedRentalsWorkbookImporter.kt").read_text()
checks = {
    "FinanceScreen imports Modifier": "import androidx.compose.ui.Modifier" in finance,
    "FinanceScreen imports Icons receiver": "import androidx.compose.material.icons.Icons" in finance,
    "FinanceScreen imports AccountBalanceWallet extension": "import androidx.compose.material.icons.filled.AccountBalanceWallet" in finance,
    "material icons extended dependency exists": 'implementation("androidx.compose.material:material-icons-extended")' in (root / "app/build.gradle.kts").read_text(),
    "PropertyComponents imports KeyboardOptions from foundation.text": "import androidx.compose.foundation.text.KeyboardOptions" in components,
    "PropertyComponents no longer imports KeyboardOptions from ui.text.input": "import androidx.compose.ui.text.input.KeyboardOptions" not in components,
    "Reviewed Q022 importer imports ByteArrayOutputStream": "import java.io.ByteArrayOutputStream" in reviewed_importer,
    "Reviewed Q022 importer uses explicit mutable-list add calls": "rows.add(emptyList())" in reviewed_importer and "rows.add(if (row.isEmpty())" in reviewed_importer,
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
assert all(checks.values())
