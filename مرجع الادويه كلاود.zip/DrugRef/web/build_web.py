#!/usr/bin/env python3
"""يولّد نسخة ويب (PWA) تعمل بلا إنترنت من قاعدة التطبيق:
    python3 web/build_web.py app/src/main/assets/drugs.db web/dist
تحذير خصوصية: الصفحة الناتجة تحوي كل البيانات. لا تنشرها علنًا إن كانت سرّية.
"""
import base64, gzip, json, os, shutil, sqlite3, sys

db, out = sys.argv[1], sys.argv[2]
here = os.path.dirname(os.path.abspath(__file__))
c = sqlite3.connect(db)
items = [list(r) for r in c.execute(
    "select code,name_en,name_ar,concentration,dosage_form,therapeutic_class,is_device,device_type,status,decision,"
    "family,variant,removal_reason,name_src,class_src,dev_src,flag from items order by code")]
links = [list(r) for r in c.execute("select code,related,kind from links")]
raw = json.dumps({"i": items, "l": links}, ensure_ascii=False, separators=(",", ":")).encode()
z = base64.b64encode(gzip.compress(raw, 9)).decode()
os.makedirs(out, exist_ok=True)
tpl = open(os.path.join(here, "template.html"), encoding="utf-8").read()
open(os.path.join(out, "index.html"), "w", encoding="utf-8").write(tpl.replace("__DATA__", z))
for f in ("manifest.webmanifest", "sw.js", "icon.svg"):
    shutil.copy(os.path.join(here, f), out)
print(f"OK -> {out}/index.html ({len(z)/1e6:.2f} MB بيانات مضغوطة)")
