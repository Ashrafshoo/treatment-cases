# حالة خط البناء — أملاك العائلة 0.4.39-dev

- الإصدار الحالي: 0.4.39-dev / versionCode 64.
- التطبيق Android Native: Kotlin + Jetpack Compose + SQLite.
- applicationId: `com.example.rentals`.
- GitHub Actions يحتوي مرحلتين: اختبارات المصدر ثم Android `assembleDebug` باستخدام JDK 17 وGradle 8.9 وAndroid SDK 35.
- تم تحديث اسم artifact ليطابق 0.4.39-dev.
- لا يوجد Gradle executable أو Android SDK في بيئة المراجعة المحلية؛ لذلك لم ينفذ Gradle Sync أو assembleDebug ولم ينتج APK.
- نجاح اختبارات Python المصدرية لا يعادل ترجمة Kotlin/Compose ولا اختبار التشغيل على هاتف.
- لم يتم تشغيل GitHub Actions من هذه البيئة ولم يتم اختبار طابعة أو استعادة على هاتف فعلي.

- تم إصلاح استيرادات Kotlin التي فشلت في آخر تشغيل سابق، وإضافة مسار Q022؛ يلزم رفع المصدر المصحح لتشغيل Workflow جديد وإثبات الترجمة.
- اجتازت 40 سكربت تحقق مصدري في الإصدار 0.4.39-dev عند تشغيلها على ثلاث دفعات.
- Workflow المستودع الحالي يبحث عن ملف ZIP واحد فقط في جذر المستودع؛ عند التحديث استبدل الأرشيف القديم بالجديد ولا تترك نسختين ZIP معًا.
