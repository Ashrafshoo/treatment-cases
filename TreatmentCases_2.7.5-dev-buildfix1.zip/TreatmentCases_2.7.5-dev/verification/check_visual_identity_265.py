#!/usr/bin/env python3
from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'android/app/src/main/java/com/treatmentcases/app/MainActivity.kt').read_text(encoding='utf-8')
g=(root/'android/app/build.gradle').read_text(encoding='utf-8')
asset=root/'android/app/src/main/res/drawable-nodpi/medical_hero.png'
checks={
 'isolated preview application id': "applicationId 'com.treatmentcases.app.preview275'" in g,
 '2.7.3 development version': "versionName '2.7.5-dev'" in g and 'versionCode 31' in g,
 'custom medical hero image included': asset.exists() and asset.stat().st_size>20000,
 'hero image displayed in dashboard': 'painterResource(id=R.drawable.medical_hero)' in s,
 'persistent Arabic-English preference': 'getString("ui_language","ar")' in s and 'putString("ui_language"' in s,
 'one-tap language switch in top bar': 'Text(if(isEnglish)"عربي" else "EN"' in s,
 'English layout direction': 'LayoutDirection.Ltr' in s,
 'Arabic layout direction': 'LayoutDirection.Rtl' in s,
 'bilingual bottom navigation': 'appLabel("الرئيسية","Home",isEnglish)' in s,
 'bilingual dashboard title': 'appLabel("لوحة المتابعة","Dashboard",isEnglish)' in s,
 'bilingual settings language control': 'App Language' in s,
 'bilingual login screen': 'Sign in with your account' in s and 'Create the administrator password' in s,
 'bilingual records page': 'Records & Search' in s and 'Add Beneficiary' in s,
 'bilingual medicine and reports pages': 'Medicine Catalog' in s and 'Medicine Reports Center' in s,
 'vector medical brand mark': (root/'android/app/src/main/res/drawable/ic_medical_brand.xml').exists(),
 'localized launcher app names': (root/'android/app/src/main/res/values-en/strings.xml').exists() and '@string/app_name' in (root/'android/app/src/main/AndroidManifest.xml').read_text(encoding='utf-8'),
 'animated statistic cards': 'AnimatedContent(targetState=value' in s and 'fontSize=24.sp' in s,
 'animated dashboard interactions': 'animateFloatAsState' in s and 'shortcutPress' in s,
 'gradient hero overlay': 'Brush.horizontalGradient' in s and 'DashboardHero' in s,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+': '+name)
assert all(checks.values())
print(f'PASS: {len(checks)} visual identity assertions')
