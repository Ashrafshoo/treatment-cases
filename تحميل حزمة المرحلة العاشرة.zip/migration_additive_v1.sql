PRAGMA foreign_keys = ON;

-- Migration is additive: existing tables and rows are retained unchanged.
CREATE TABLE IF NOT EXISTS Personnel (
  personnel_id INTEGER PRIMARY KEY AUTOINCREMENT,
  performance_number TEXT NOT NULL UNIQUE,
  full_name TEXT,
  job_title TEXT,
  region TEXT,
  department TEXT,
  mobile1 TEXT,
  mobile2 TEXT,
  national_id TEXT,
  gender TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  source_batch_id INTEGER
);

CREATE TABLE IF NOT EXISTS Personnel_Import_Staging (
  staging_id INTEGER PRIMARY KEY AUTOINCREMENT,
  batch_id INTEGER NOT NULL,
  row_number INTEGER NOT NULL,
  performance_number TEXT,
  full_name TEXT, job_title TEXT, region TEXT, department TEXT,
  mobile1 TEXT, mobile2 TEXT, national_id TEXT, gender TEXT,
  validation_status TEXT NOT NULL DEFAULT 'PENDING',
  validation_message TEXT,
  row_json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS Treatment_History (
  history_id INTEGER PRIMARY KEY AUTOINCREMENT,
  beneficiary_id INTEGER NOT NULL,
  treatment_order INTEGER,
  medicine_name_raw TEXT,
  strength_raw TEXT,
  dispensing_duration TEXT,
  dosage_text TEXT,
  medical_condition TEXT,
  approval_date TEXT,
  treatment_status TEXT NOT NULL DEFAULT 'ACTIVE',
  status_note TEXT,
  started_or_imported_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  stopped_at TEXT,
  source_batch_id INTEGER,
  source_row_json TEXT,
  FOREIGN KEY(beneficiary_id) REFERENCES Beneficiaries(beneficiary_id)
);

CREATE TABLE IF NOT EXISTS Case_Import_Staging (
  staging_id INTEGER PRIMARY KEY AUTOINCREMENT,
  batch_id INTEGER NOT NULL,
  row_number INTEGER NOT NULL,
  performance_number TEXT,
  medicine_name_raw TEXT,
  strength_raw TEXT,
  dispensing_duration TEXT,
  dosage_text TEXT,
  medical_condition TEXT,
  approval_date TEXT,
  notes TEXT,
  validation_status TEXT NOT NULL DEFAULT 'PENDING',
  validation_message TEXT,
  row_json TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS Import_Batches_Ext (
  batch_id INTEGER PRIMARY KEY AUTOINCREMENT,
  batch_type TEXT NOT NULL CHECK(batch_type IN ('PERSONNEL','CRITICAL_CASES')),
  source_file TEXT NOT NULL,
  import_mode TEXT NOT NULL CHECK(import_mode IN ('FULL_SNAPSHOT','PARTIAL_UPDATE')),
  imported_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  submitted_by TEXT,
  preview_status TEXT NOT NULL DEFAULT 'PREVIEW',
  approval_status TEXT NOT NULL DEFAULT 'PENDING',
  approved_by TEXT,
  approved_at TEXT,
  summary_json TEXT
);

CREATE TABLE IF NOT EXISTS Import_Change_Proposals (
  proposal_id INTEGER PRIMARY KEY AUTOINCREMENT,
  batch_id INTEGER NOT NULL,
  entity_type TEXT NOT NULL,
  entity_key TEXT NOT NULL,
  change_type TEXT NOT NULL,
  field_name TEXT,
  old_value TEXT,
  new_value TEXT,
  impact_note TEXT,
  decision TEXT NOT NULL DEFAULT 'PENDING',
  decided_by TEXT,
  decided_at TEXT,
  FOREIGN KEY(batch_id) REFERENCES Import_Batches_Ext(batch_id)
);

CREATE TABLE IF NOT EXISTS Data_Audit_Log (
  audit_id INTEGER PRIMARY KEY AUTOINCREMENT,
  batch_id INTEGER,
  entity_type TEXT NOT NULL,
  entity_key TEXT NOT NULL,
  action TEXT NOT NULL,
  before_json TEXT,
  after_json TEXT,
  actor TEXT,
  action_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_personnel_performance ON Personnel(performance_number);
CREATE INDEX IF NOT EXISTS idx_case_staging_perf ON Case_Import_Staging(performance_number);
CREATE INDEX IF NOT EXISTS idx_history_beneficiary_status ON Treatment_History(beneficiary_id,treatment_status);
CREATE INDEX IF NOT EXISTS idx_proposals_batch ON Import_Change_Proposals(batch_id);


-- Initial safe seed: populate the new personnel master from existing beneficiary rows.
-- Only fields already present in the old database are copied; unknown fields remain NULL.
INSERT OR IGNORE INTO Personnel
(performance_number, full_name, region, department, source_batch_id)
SELECT performance_number, full_name, region, department, source_batch_id
FROM Beneficiaries
WHERE performance_number IS NOT NULL AND TRIM(performance_number) <> '';

-- A view for active treatment history; application writes remain transaction-controlled.
CREATE VIEW IF NOT EXISTS Active_Treatment_History AS
SELECT * FROM Treatment_History WHERE treatment_status='ACTIVE';
