from pathlib import Path
from PIL import Image

root = Path(__file__).resolve().parents[1]
source = root / 'app/assets/branding/app_icon.png'
res = root / 'app/android/app/src/main/res'
if not source.exists() or not res.exists():
    raise SystemExit('Branding source or generated Android res folder is missing')
for density, size in {'mdpi':48,'hdpi':72,'xhdpi':96,'xxhdpi':144,'xxxhdpi':192}.items():
    folder = res / f'mipmap-{density}'
    folder.mkdir(parents=True, exist_ok=True)
    Image.open(source).convert('RGBA').resize((size,size), Image.Resampling.LANCZOS).save(folder/'ic_launcher.png')
manifest = root / 'app/android/app/src/main/AndroidManifest.xml'
text = manifest.read_text()
text = text.replace('android:icon="@mipmap/ic_launcher"', 'android:icon="@mipmap/ic_launcher"')
if 'android:icon=' not in text:
    text = text.replace('<application', '<application android:icon="@mipmap/ic_launcher"', 1)
manifest.write_text(text)
print('Applied family navy/gold launcher icon.')
