import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'core/theme/app_theme.dart';
import 'core/theme/app_preferences.dart';
import 'features/auth/presentation/login_screen.dart';

class FamilyPropertyApp extends StatefulWidget {
  const FamilyPropertyApp({super.key});
  @override State<FamilyPropertyApp> createState()=>_FamilyPropertyAppState();
}
class _FamilyPropertyAppState extends State<FamilyPropertyApp> {
  final preferences=AppPreferences.instance;
  @override void initState(){super.initState();preferences.load();}
  ThemeData _apply(ThemeData base){
    return base.copyWith(
      colorScheme:base.colorScheme.copyWith(primary:base.brightness==Brightness.dark?preferences.accentColor:AppTheme.navy,secondary:preferences.accentColor),
      textTheme:base.textTheme.apply(fontSizeFactor:preferences.fontScale),
    );
  }
  @override Widget build(BuildContext context)=>AnimatedBuilder(animation:preferences,builder:(context,_)=>MaterialApp(
    title:'إدارة أملاك العائلة',debugShowCheckedModeBanner:false,
    theme:_apply(AppTheme.light),darkTheme:_apply(AppTheme.dark),themeMode:preferences.themeMode,
    locale:const Locale('ar'),supportedLocales:const [Locale('ar'),Locale('en')],
    localizationsDelegates:const [GlobalMaterialLocalizations.delegate,GlobalWidgetsLocalizations.delegate,GlobalCupertinoLocalizations.delegate],
    home:const Directionality(textDirection:TextDirection.rtl,child:LoginScreen()),
  ));
}
