
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS schema_migrations (
  version INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE owners (
  id TEXT PRIMARY KEY,
  full_name TEXT NOT NULL,
  phone TEXT,
  notes TEXT,
  modified_unreviewed INTEGER NOT NULL DEFAULT 0 CHECK (modified_unreviewed IN (0,1)),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  archived_at TEXT
);

CREATE TABLE property_groups (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  archived_at TEXT
);

CREATE TABLE properties (
  id TEXT PRIMARY KEY,
  group_id TEXT REFERENCES property_groups(id) ON DELETE RESTRICT,
  name TEXT NOT NULL,
  address_text TEXT,
  city TEXT,
  district TEXT,
  property_type TEXT,
  notes TEXT,
  review_status TEXT NOT NULL DEFAULT 'needs_review'
    CHECK (review_status IN ('sound','needs_review','incorrect')),
  modified_unreviewed INTEGER NOT NULL DEFAULT 0 CHECK (modified_unreviewed IN (0,1)),
  is_highlighted INTEGER NOT NULL DEFAULT 0 CHECK (is_highlighted IN (0,1)),
  source_status TEXT NOT NULL DEFAULT 'manual'
    CHECK (source_status IN ('excel','receipt','manual','mixed')),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  archived_at TEXT
);

CREATE TABLE ownership_shares (
  id TEXT PRIMARY KEY,
  property_id TEXT NOT NULL REFERENCES properties(id) ON DELETE RESTRICT,
  owner_id TEXT NOT NULL REFERENCES owners(id) ON DELETE RESTRICT,
  share_percent REAL NOT NULL CHECK (share_percent > 0 AND share_percent <= 100),
  valid_from TEXT,
  valid_to TEXT,
  notes TEXT,
  modified_unreviewed INTEGER NOT NULL DEFAULT 0 CHECK (modified_unreviewed IN (0,1)),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CHECK (valid_to IS NULL OR valid_from IS NULL OR valid_to >= valid_from)
);

CREATE TABLE units (
  id TEXT PRIMARY KEY,
  property_id TEXT NOT NULL REFERENCES properties(id) ON DELETE RESTRICT,
  unit_number TEXT,
  floor_label TEXT,
  unit_type TEXT,
  area REAL,
  occupancy_status TEXT NOT NULL DEFAULT 'unknown'
    CHECK (occupancy_status IN ('occupied','vacant','closed','unknown')),
  address_details TEXT,
  current_tenant_id TEXT REFERENCES tenants(id) ON DELETE SET NULL,
  old_law_164_2025 INTEGER NOT NULL DEFAULT 0 CHECK (old_law_164_2025 IN (0,1)),
  review_status TEXT NOT NULL DEFAULT 'needs_review'
    CHECK (review_status IN ('sound','needs_review','incorrect')),
  modified_unreviewed INTEGER NOT NULL DEFAULT 0 CHECK (modified_unreviewed IN (0,1)),
  source_status TEXT NOT NULL DEFAULT 'manual'
    CHECK (source_status IN ('excel','receipt','manual','mixed')),
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  archived_at TEXT
);

CREATE TABLE tenants (
  id TEXT PRIMARY KEY,
  full_name TEXT NOT NULL,
  phone TEXT,
  national_id_last4 TEXT,
  notes TEXT,
  modified_unreviewed INTEGER NOT NULL DEFAULT 0 CHECK (modified_unreviewed IN (0,1)),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  archived_at TEXT
);

CREATE TABLE leases (
  id TEXT PRIMARY KEY,
  unit_id TEXT NOT NULL REFERENCES units(id) ON DELETE RESTRICT,
  tenant_id TEXT NOT NULL REFERENCES tenants(id) ON DELETE RESTRICT,
  start_date TEXT NOT NULL,
  duration_value INTEGER,
  duration_unit TEXT CHECK (duration_unit IN ('days','months','years')),
  calculated_end_date TEXT,
  manual_end_date TEXT,
  end_date_override_reason TEXT,
  initial_rent_minor INTEGER,
  currency_code TEXT NOT NULL DEFAULT 'EGP',
  annual_increase_percent REAL CHECK (annual_increase_percent IS NULL OR annual_increase_percent >= 0),
  increase_rule TEXT NOT NULL DEFAULT 'anniversary'
    CHECK (increase_rule IN ('anniversary','fixed_month_day','manual_dates','none')),
  increase_month INTEGER CHECK (increase_month IS NULL OR increase_month BETWEEN 1 AND 12),
  increase_day INTEGER CHECK (increase_day IS NULL OR increase_day BETWEEN 1 AND 31),
  law_164_2025_applies INTEGER NOT NULL DEFAULT 0 CHECK (law_164_2025_applies IN (0,1)),
  status TEXT NOT NULL DEFAULT 'active'
    CHECK (status IN ('active','ending_soon','ended','renewed','terminated','suspended','open_ended')),
  notes TEXT,
  modified_unreviewed INTEGER NOT NULL DEFAULT 0 CHECK (modified_unreviewed IN (0,1)),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  archived_at TEXT,
  CHECK ((duration_value IS NULL AND duration_unit IS NULL) OR
         (duration_value > 0 AND duration_unit IS NOT NULL))
);

CREATE TABLE rent_increases (
  id TEXT PRIMARY KEY,
  lease_id TEXT NOT NULL REFERENCES leases(id) ON DELETE RESTRICT,
  effective_date TEXT NOT NULL,
  percentage REAL CHECK (percentage IS NULL OR percentage >= 0),
  previous_rent_minor INTEGER,
  new_rent_minor INTEGER,
  calculation_method TEXT NOT NULL DEFAULT 'percentage'
    CHECK (calculation_method IN ('percentage','fixed_amount','manual')),
  status TEXT NOT NULL DEFAULT 'proposed'
    CHECK (status IN ('proposed','approved','applied','cancelled')),
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE rent_history (
  id TEXT PRIMARY KEY,
  lease_id TEXT NOT NULL REFERENCES leases(id) ON DELETE RESTRICT,
  amount_minor INTEGER NOT NULL,
  currency_code TEXT NOT NULL DEFAULT 'EGP',
  valid_from TEXT NOT NULL,
  valid_to TEXT,
  source_type TEXT NOT NULL DEFAULT 'manual'
    CHECK (source_type IN ('manual','increase','receipt_candidate','import')),
  source_id TEXT,
  approval_status TEXT NOT NULL DEFAULT 'approved'
    CHECK (approval_status IN ('approved','under_review','rejected')),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CHECK (valid_to IS NULL OR valid_to >= valid_from)
);

CREATE TABLE payments (
  id TEXT PRIMARY KEY,
  lease_id TEXT NOT NULL REFERENCES leases(id) ON DELETE RESTRICT,
  paid_at TEXT NOT NULL,
  amount_minor INTEGER NOT NULL CHECK (amount_minor >= 0),
  currency_code TEXT NOT NULL DEFAULT 'EGP',
  period_start TEXT,
  period_end TEXT,
  payment_method TEXT,
  reference_text TEXT,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE receipts (
  id TEXT PRIMARY KEY,
  payment_id TEXT REFERENCES payments(id) ON DELETE RESTRICT,
  lease_id TEXT REFERENCES leases(id) ON DELETE RESTRICT,
  receipt_number TEXT NOT NULL,
  issued_at TEXT NOT NULL,
  landlord_snapshot TEXT,
  tenant_snapshot TEXT,
  property_snapshot TEXT,
  unit_snapshot TEXT,
  amount_minor INTEGER NOT NULL CHECK (amount_minor >= 0),
  amount_words_snapshot TEXT,
  currency_code TEXT NOT NULL DEFAULT 'EGP',
  period_snapshot TEXT,
  payment_method_snapshot TEXT,
  remaining_minor INTEGER,
  law_164_2025_snapshot INTEGER NOT NULL DEFAULT 0 CHECK (law_164_2025_snapshot IN (0,1)),
  approved INTEGER NOT NULL DEFAULT 0 CHECK (approved IN (0,1)),
  pdf_relative_path TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(receipt_number)
);

CREATE TABLE expenses (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  amount_minor INTEGER NOT NULL CHECK (amount_minor >= 0),
  currency_code TEXT NOT NULL DEFAULT 'EGP',
  expense_date TEXT NOT NULL,
  notes TEXT,
  modified_unreviewed INTEGER NOT NULL DEFAULT 0 CHECK (modified_unreviewed IN (0,1)),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  archived_at TEXT
);

CREATE TABLE documents (
  id TEXT PRIMARY KEY,
  entity_type TEXT NOT NULL CHECK (entity_type IN ('property','unit','tenant','lease','receipt','owner')),
  entity_id TEXT NOT NULL,
  document_type TEXT,
  title TEXT NOT NULL,
  relative_path TEXT NOT NULL,
  mime_type TEXT,
  source_type TEXT CHECK (source_type IN ('excel','receipt','manual','scan','other')),
  notes TEXT,
  version_group_id TEXT,
  version_number INTEGER NOT NULL DEFAULT 1 CHECK (version_number >= 1),
  supersedes_document_id TEXT REFERENCES documents(id) ON DELETE RESTRICT,
  document_date TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  archived_at TEXT
);
CREATE INDEX idx_documents_entity_versions ON documents(entity_type, entity_id, version_group_id, version_number);

CREATE TABLE review_items (
  id TEXT PRIMARY KEY,
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  field_name TEXT,
  original_value TEXT,
  proposed_value TEXT,
  source_document_id TEXT REFERENCES documents(id) ON DELETE RESTRICT,
  source_description TEXT,
  confidence REAL CHECK (confidence IS NULL OR confidence BETWEEN 0 AND 1),
  status TEXT NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending','approved','rejected','deferred')),
  reviewed_by TEXT,
  reviewed_at TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE users (
  id TEXT PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  display_name TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('administrator','family_viewer')),
  password_hash TEXT,
  is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1)),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE devices (
  id TEXT PRIMARY KEY,
  device_label TEXT NOT NULL,
  platform TEXT NOT NULL DEFAULT 'android',
  registered_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_sync_at TEXT,
  is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1))
);

CREATE TABLE sync_operations (
  id TEXT PRIMARY KEY,
  device_id TEXT NOT NULL REFERENCES devices(id) ON DELETE RESTRICT,
  operation_type TEXT NOT NULL CHECK (operation_type IN ('export','import')),
  package_id TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  completed_at TEXT,
  status TEXT NOT NULL DEFAULT 'prepared'
    CHECK (status IN ('prepared','previewed','applied','conflict','failed','cancelled')),
  summary_json TEXT,
  UNIQUE(device_id, package_id)
);

CREATE TABLE audit_log (
  id TEXT PRIMARY KEY,
  user_id TEXT REFERENCES users(id) ON DELETE RESTRICT,
  device_id TEXT REFERENCES devices(id) ON DELETE RESTRICT,
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  action TEXT NOT NULL CHECK (action IN ('create','update','archive','restore','approve','reject','import')),
  before_json TEXT,
  after_json TEXT,
  occurred_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE notifications (
  id TEXT PRIMARY KEY,
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  notification_type TEXT NOT NULL
    CHECK (notification_type IN ('lease_end','rent_increase','review_due','custom')),
  due_at TEXT NOT NULL,
  remind_days_before INTEGER NOT NULL DEFAULT 30 CHECK (remind_days_before >= 0),
  status TEXT NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending','shown','dismissed','completed','cancelled')),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE app_settings (
  setting_key TEXT PRIMARY KEY,
  setting_value TEXT NOT NULL,
  scope TEXT NOT NULL DEFAULT 'device'
    CHECK (scope IN ('device','user')),
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_properties_group ON properties(group_id);
CREATE INDEX idx_units_property ON units(property_id);
CREATE INDEX idx_units_tenant ON units(current_tenant_id);
CREATE INDEX idx_leases_unit ON leases(unit_id);
CREATE INDEX idx_leases_tenant ON leases(tenant_id);
CREATE INDEX idx_leases_end ON leases(manual_end_date, calculated_end_date);
CREATE INDEX idx_increases_date ON rent_increases(effective_date, status);
CREATE INDEX idx_payments_lease_date ON payments(lease_id, paid_at);
CREATE INDEX idx_receipts_lease ON receipts(lease_id);
CREATE INDEX idx_review_status ON review_items(status, created_at);
CREATE INDEX idx_audit_entity ON audit_log(entity_type, entity_id, occurred_at);
CREATE INDEX idx_notifications_due ON notifications(status, due_at);

INSERT OR IGNORE INTO schema_migrations(version, name)
VALUES (1, 'initial_property_management_schema');

-- Stage 9 reporting and scheduling indexes
CREATE INDEX IF NOT EXISTS idx_payments_paid_at ON payments(paid_at);
CREATE INDEX IF NOT EXISTS idx_expenses_month ON expenses(expense_date, archived_at);
CREATE INDEX IF NOT EXISTS idx_increases_lease_date ON rent_increases(lease_id, effective_date, status);
CREATE INDEX IF NOT EXISTS idx_notifications_entity_due ON notifications(entity_type, entity_id, due_at, status);
CREATE INDEX IF NOT EXISTS idx_receipts_issued_at ON receipts(issued_at);
INSERT OR IGNORE INTO schema_migrations(version, name) VALUES (3, 'reports_schedules_and_exchange_indexes');

-- Stage 10 modified-record flags
INSERT OR IGNORE INTO schema_migrations(version, name) VALUES (4, 'modified_flags_for_all_editable_records');
