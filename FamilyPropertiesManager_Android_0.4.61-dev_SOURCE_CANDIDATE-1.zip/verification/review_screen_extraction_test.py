from pathlib import Path
root = Path(__file__).resolve().parents[1]
main = (root / "app/src/main/java/com/example/rentals/MainActivity.kt").read_text(encoding="utf-8")
feature = (root / "app/src/main/java/com/example/rentals/features/review/ReviewScreen.kt").read_text(encoding="utf-8")
assert "import com.example.rentals.features.review.ReviewScreen" in main
assert "Tab.Review->ReviewScreen(db,units)" in main
assert "@Composable fun ReviewScreen(db:RentalsDb,units:List<UnitRecord>)" in feature
assert "@Composable private fun ReviewScreen" not in main
for token in ("db.reviewFlags()", "db.legacyImportCounts()", "LegacyUnitReviewAnalyzer.analyze", "LegacyReceiptMatchAnalyzer.analyze", "db.updateLegacyImportReview", "db.archiveApprovedLegacyContracts()", "db.linkLegacyContractToUnit", "db.unlinkLegacyContractFromUnit", "db.migrateUniquelyMatchedLegacyUnitsToReview()", "db.migrateApprovedLegacyUnitsToReview()"):
    assert token in feature, token
assert "غياب الإيصال لا يعني وحده توقف الدفع" in feature
assert "لم تُنشأ حركة مالية أو عقد تشغيلي" in feature
print("PASS: review center extracted with matching, audit, archive/link and conservative migration workflows preserved.")
