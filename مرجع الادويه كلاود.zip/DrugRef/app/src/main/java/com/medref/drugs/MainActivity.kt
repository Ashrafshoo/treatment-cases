package com.medref.drugs

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognizerIntent
import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import java.util.concurrent.Executors

class MainActivity : BaseActivity() {

    private companion object {
        const val PAGE = 60
    }

    private lateinit var db: Db
    private lateinit var adapter: ItemAdapter
    private lateinit var famAdapter: FamilyAdapter
    private lateinit var list: RecyclerView
    private lateinit var searchBox: TextInputEditText
    private lateinit var countText: TextView
    private lateinit var groupChip: Chip
    private lateinit var bulkBar: View
    private lateinit var bulkCount: TextView
    private lateinit var backCallback: OnBackPressedCallback

    private val io = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private val items = ArrayList<Item>()
    private val fams = ArrayList<Family>()
    private val selected = LinkedHashSet<Int>()

    private var scope = Scope.CURATED
    private var status: String? = null
    private var query = ""
    private var grouped = false
    private var total = 0
    private var hasMore = false
    private var loading = false
    private var gen = 0
    private var searchJob: Runnable? = null

    private val openDetail = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == RESULT_OK) load(true)
    }

    private val voice = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val txt = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (r.resultCode == RESULT_OK && txt != null) searchBox.setText(txt)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        db = Db.get(this)
        scope = try { Scope.valueOf(Prefs.startScope) } catch (e: Exception) { Scope.CURATED }
        grouped = Prefs.groupMode

        countText = findViewById(R.id.countText)
        bulkBar = findViewById(R.id.bulkBar)
        bulkCount = findViewById(R.id.bulkCount)
        searchBox = findViewById(R.id.search)
        groupChip = findViewById(R.id.groupChip)

        val toolbar = findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.toolbar)
        toolbar.inflateMenu(R.menu.main_menu)
        toolbar.setOnMenuItemClickListener { onMenu(it.itemId) }

        adapter = ItemAdapter(items, selected, { onTap(it) }, { onLongTap(it) })
        famAdapter = FamilyAdapter(fams) { f ->
            startActivity(
                Intent(this, FamilyActivity::class.java)
                    .putExtra("family", f.name).putExtra("scope", scope.name)
            )
        }
        list = findViewById(R.id.list)
        val lm = LinearLayoutManager(this)
        list.layoutManager = lm
        list.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) {
                val n = if (isGrouped()) fams.size else items.size
                if (hasMore && !loading && lm.findLastVisibleItemPosition() >= n - 8) load(false)
            }
        })

        searchBox.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                searchJob?.let { handler.removeCallbacks(it) }
                val job = Runnable { query = s?.toString() ?: ""; load(true) }
                searchJob = job
                handler.postDelayed(job, 250)
            }
        })

        findViewById<MaterialButton>(R.id.btnMic).setOnClickListener { startVoice() }

        groupChip.isChecked = grouped
        groupChip.setOnClickListener {
            grouped = groupChip.isChecked
            Prefs.groupMode = grouped
            clearSelection()
            load(true)
        }

        buildScopeChips()
        buildStatusChips()
        Thread { Backup.auto(applicationContext) }.start()

        findViewById<MaterialButton>(R.id.btnToDevice).setOnClickListener { confirmMove(true) }
        findViewById<MaterialButton>(R.id.btnToDrug).setOnClickListener { confirmMove(false) }
        findViewById<MaterialButton>(R.id.btnClear).setOnClickListener { clearSelection() }

        backCallback = object : OnBackPressedCallback(false) {
            override fun handleOnBackPressed() = clearSelection()
        }
        onBackPressedDispatcher.addCallback(this, backCallback)

        finishUi()
        load(true)
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    /** اختصارات الأيقونة + استقبال نص من تطبيقات أخرى (مشاركة أو تحديد نص ← «بحث في مرجع الأدوية»). */
    private fun handleIntent(i: Intent) {
        when (i.getStringExtra("shortcut")) {
            "review" -> Review.pick(this)
            "progress" -> startActivity(Intent(this, ProgressActivity::class.java))
            "voice" -> startVoice()
        }
        i.removeExtra("shortcut")
        val shared = when (i.action) {
            Intent.ACTION_SEND -> i.getStringExtra(Intent.EXTRA_TEXT)
            Intent.ACTION_PROCESS_TEXT -> i.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)?.toString()
            else -> null
        }
        if (!shared.isNullOrBlank()) {
            searchBox.setText(shared.trim().take(80))
            i.action = Intent.ACTION_MAIN
        }
    }

    /** وضع «بالدواء» لا ينطبق على «الأصلية» لأنها نسخة ثابتة بلا عائلات. */
    private fun isGrouped() = grouped && scope != Scope.ORIGINAL

    /** بعد استيراد أو استعادة نسخة: القاعدة قد تكون أُعيد فتحها. */
    override fun onDataChanged() {
        db = Db.get(this)
        clearSelection()
        load(true)
    }

    private fun startVoice() {
        Lock.pause()
        try {
            voice.launch(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-EG")
                    .putExtra(RecognizerIntent.EXTRA_PROMPT, "انطق اسم الدواء")
            )
        } catch (e: Exception) {
            Toast.makeText(this, "لا يتوفر تعرّف على الصوت في هذا الجهاز", Toast.LENGTH_LONG).show()
        }
    }

    // ---------- الشرائح ----------
    private fun chip(group: ChipGroup, text: String, checked: Boolean, onSelect: () -> Unit) {
        val c = layoutInflater.inflate(R.layout.chip_filter, group, false) as Chip
        c.id = View.generateViewId()
        c.text = text
        c.isChecked = checked
        c.setOnClickListener { onSelect() }
        group.addView(c)
    }

    private fun buildScopeChips() {
        val g = findViewById<ChipGroup>(R.id.scopeChips)
        g.removeAllViews()
        Scope.values().forEach { s ->
            chip(g, s.label, s == scope) { scope = s; clearSelection(); load(true) }
        }
    }

    private val statusKeys = listOf(
        "" to "كل الحالات", "auto_ar" to "اسم عربي مقترح", "auto_cls" to "تصنيف مقترح", "auto_dev" to "جهاز مقترح",
        "similar" to "متشابه / تكرار تقريبي", "flag" to "تعارض الاسمين",
        "ok" to "سليم", "duplicate" to "مكرر", "missing_name" to "اسم أجنبي ناقص", "device" to "جهاز تعويضي"
    )

    private fun buildStatusChips() {
        val g = findViewById<ChipGroup>(R.id.statusChips)
        g.removeAllViews()
        for ((k, label) in statusKeys) {
            val txt = if (label.isNotEmpty() && k in Labels.status && k != "similar") (Labels.status[k] ?: label) else label
            chip(g, txt, (status ?: "") == k) { status = if (k.isEmpty()) null else k; load(true) }
        }
    }

    // ---------- التحميل ----------
    private fun load(reset: Boolean) {
        val grp = isGrouped()
        if (reset) {
            gen++
            items.clear()
            fams.clear()
            list.adapter = if (grp) famAdapter else adapter
            hasMore = false
            if (grp) famAdapter.notifyDataSetChanged() else adapter.notifyDataSetChanged()
        }
        val g = gen
        val offset = if (grp) fams.size else items.size
        val s = scope
        val q = query
        val st = status
        val d = db
        loading = true
        io.execute {
            var page: List<Item> = emptyList()
            var fpage: List<Family> = emptyList()
            try {
                if (grp) fpage = d.families(s, q, st, PAGE, offset) else page = d.search(s, q, st, PAGE, offset)
            } catch (e: Exception) { /* قاعدة أُغلقت أثناء الاستعادة: نتجاهل */ }
            var cnt = -1
            var note = ""
            if (reset) {
                cnt = try {
                    if (grp) d.countFamilies(s, q, st) else d.count(s, q, st)
                } catch (e: Exception) { 0 }
                // كود غير موجود في الشيت المصدَّر؟
                val n = q.trim().toIntOrNull()
                if (!grp && d.loose) note += " — نتائج تقريبية (تسامح إملائي)"
                if (n != null) {
                    val missing = try { d.isMissingCode(n) } catch (e: Exception) { false }
                    if (missing) note = " — الكود $n غير موجود في الشيت المصدَّر (من الأكواد الناقصة)"
                }
            }
            runOnUiThread {
                if (g != gen) return@runOnUiThread
                if (grp) {
                    val start = fams.size
                    fams.addAll(fpage)
                    famAdapter.notifyItemRangeInserted(start, fpage.size)
                    hasMore = fpage.size == PAGE
                } else {
                    val start = items.size
                    items.addAll(page)
                    adapter.notifyItemRangeInserted(start, page.size)
                    hasMore = page.size == PAGE
                }
                if (cnt >= 0) total = cnt
                loading = false
                val shown = if (grp) fams.size else items.size
                val unit = if (grp) "دواء" else "صنف"
                if (reset) countText.tag = note
                countText.text = "${s.label}: $total $unit" +
                    (if (shown < total) " (معروض $shown)" else "") + ((countText.tag as? String) ?: "")
            }
        }
    }

    // ---------- التحديد والنقل ----------
    private fun onTap(item: Item) {
        if (selected.isNotEmpty()) toggle(item) else
            openDetail.launch(Intent(this, DetailActivity::class.java).putExtra("code", item.code))
    }

    private fun onLongTap(item: Item) = toggle(item)

    private fun toggle(item: Item) {
        if (Prefs.haptic) window.decorView.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        if (!selected.add(item.code)) selected.remove(item.code)
        refreshBulk()
        adapter.notifyDataSetChanged()
    }

    private fun clearSelection() {
        selected.clear()
        refreshBulk()
        adapter.notifyDataSetChanged()
    }

    private fun refreshBulk() {
        bulkBar.visibility = if (selected.isEmpty()) View.GONE else View.VISIBLE
        bulkCount.text = "تم تحديد ${selected.size} صنفًا"
        backCallback.isEnabled = selected.isNotEmpty()
    }

    private fun confirmMove(toDevice: Boolean) {
        val target = if (toDevice) "الأجهزة التعويضية" else "قسم الأدوية"
        MaterialAlertDialogBuilder(this)
            .setTitle("نقل ${selected.size} صنفًا")
            .setMessage("سيتم النقل إلى «$target» وتسجيل العملية في سجل كل صنف (ويمكن التراجع عنها). الأكواد لا تتغير ولا تُحذف.")
            .setPositiveButton("نقل") { _, _ ->
                val codes = selected.toList()
                io.execute {
                    val n = db.moveItems(codes, toDevice)
                    runOnUiThread {
                        Toast.makeText(this, "تم نقل $n صنفًا", Toast.LENGTH_SHORT).show()
                        clearSelection()
                        load(true)
                    }
                }
            }
            .setNegativeButton("إلغاء", null)
            .showStyled()
    }

    // ---------- القائمة العلوية ----------
    // ---------- العروض المحفوظة ----------
    private fun viewsMenu() {
        val saved = Prefs.views.toList().sorted()
        val labels = (listOf("＋ حفظ العرض الحالي…") + saved.map { it.substringBefore('|') }).toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle("العروض المحفوظة")
            .setItems(labels) { _, i ->
                if (i == 0) saveView() else applyView(saved[i - 1])
            }
            .setNeutralButton("حذف…") { _, _ -> deleteViewMenu(saved) }
            .setNegativeButton("إغلاق", null)
            .showStyled()
    }

    private fun saveView() {
        val e = android.widget.EditText(this).apply { hint = "اسم العرض (مثل: كل الأجهزة المقترحة)" }
        val box = android.widget.LinearLayout(this).apply {
            setPadding(60, 20, 60, 0)
            addView(e, android.widget.LinearLayout.LayoutParams(-1, -2))
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("حفظ العرض الحالي")
            .setMessage("القسم: ${scope.label} • الحالة: ${statusKeys.firstOrNull { it.first == (status ?: "") }?.second ?: ""} • البحث: ${query.ifBlank { "—" }}")
            .setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                val name = e.text.toString().trim().replace("|", " ")
                if (name.isNotEmpty()) {
                    Prefs.views = Prefs.views + "$name|${scope.name}|${status ?: ""}|$query"
                    Toast.makeText(this, "تم حفظ العرض", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("إلغاء", null)
            .showStyled()
    }

    private fun applyView(v: String) {
        val p = v.split("|")
        scope = try { Scope.valueOf(p.getOrElse(1) { "CURATED" }) } catch (e: Exception) { Scope.CURATED }
        status = p.getOrElse(2) { "" }.ifEmpty { null }
        query = p.getOrElse(3) { "" }
        clearSelection()
        buildScopeChips()
        buildStatusChips()
        finishUi()
        searchBox.setText(query) // يستدعي load بعد التأخير القصير
        load(true)
    }

    private fun deleteViewMenu(saved: List<String>) {
        if (saved.isEmpty()) return
        MaterialAlertDialogBuilder(this)
            .setTitle("حذف عرض")
            .setItems(saved.map { it.substringBefore('|') }.toTypedArray()) { _, i -> Prefs.views = Prefs.views - saved[i] }
            .setNegativeButton("إلغاء", null)
            .showStyled()
    }

    // ---------- إجراءات على كل النتائج الحالية ----------
    private fun batchMenu() {
        val ops = arrayOf(
            "إضافة وسم", "تغيير التصنيف العلاجي", "تغيير القرار", "نقل إلى الأجهزة", "نقل إلى الأدوية",
            "إضافة للمفضلة", "بحث واستبدال في الاسم العربي"
        )
        MaterialAlertDialogBuilder(this)
            .setTitle("على كل نتائج: ${scope.label}" + if (query.isNotBlank()) " • «$query»" else "")
            .setItems(ops) { _, i ->
                io.execute {
                    val codes = db.search(scope, query, status, Int.MAX_VALUE, 0).map { it.code }
                    runOnUiThread { batchAsk(i, codes) }
                }
            }
            .setNegativeButton("إلغاء", null)
            .showStyled()
    }

    private fun askText(title: String, hint: String, hint2: String? = null, ok: (String, String) -> Unit) {
        val a = android.widget.EditText(this).apply { this.hint = hint }
        val b = android.widget.EditText(this).apply { this.hint = hint2 ?: "" }
        val box = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(60, 20, 60, 0)
            addView(a, android.widget.LinearLayout.LayoutParams(-1, -2))
            if (hint2 != null) addView(b, android.widget.LinearLayout.LayoutParams(-1, -2))
        }
        MaterialAlertDialogBuilder(this).setTitle(title).setView(box)
            .setPositiveButton("متابعة") { _, _ -> ok(a.text.toString(), b.text.toString()) }
            .setNegativeButton("إلغاء", null).showStyled()
    }

    private fun batchAsk(op: Int, codes: List<Int>) {
        if (codes.isEmpty()) { Toast.makeText(this, "لا نتائج", Toast.LENGTH_SHORT).show(); return }
        val n = codes.size
        fun confirm(what: String, run: () -> Int) {
            MaterialAlertDialogBuilder(this)
                .setTitle("تأكيد")
                .setMessage("$what\nسيُطبَّق على $n صنفًا، ويُسجَّل في سجل كل صنف (ويمكن التراجع عن كل تعديل).")
                .setPositiveButton("تطبيق") { _, _ ->
                    io.execute {
                        val changed = run()
                        runOnUiThread {
                            Toast.makeText(this, "تغيّر $changed صنفًا", Toast.LENGTH_SHORT).show()
                            load(true)
                        }
                    }
                }
                .setNegativeButton("إلغاء", null).showStyled()
        }
        when (op) {
            0 -> askText("وسم للنتائج", "الوسم") { t, _ -> if (t.isNotBlank()) confirm("وسم «${t.trim()}»") { db.applyToCodes(codes, "tag", t.trim()) } }
            1 -> {
                val cls = db.classes().toTypedArray()
                MaterialAlertDialogBuilder(this).setTitle("التصنيف العلاجي")
                    .setItems(cls) { _, i -> confirm("التصنيف: ${cls[i]}") { db.applyToCodes(codes, "class", cls[i]) } }
                    .setNegativeButton("إلغاء", null).showStyled()
            }
            2 -> {
                val keys = Labels.decision.keys.toList()
                MaterialAlertDialogBuilder(this).setTitle("القرار")
                    .setItems(keys.map { Labels.decision[it] ?: it }.toTypedArray()) { _, i ->
                        confirm("القرار: ${Labels.decision[keys[i]]}") { db.applyToCodes(codes, "decision", keys[i]) }
                    }
                    .setNegativeButton("إلغاء", null).showStyled()
            }
            3 -> confirm("نقل إلى الأجهزة التعويضية") { db.applyToCodes(codes, "device", "") }
            4 -> confirm("نقل إلى قسم الأدوية") { db.applyToCodes(codes, "drug", "") }
            5 -> confirm("إضافة للمفضلة") { db.applyToCodes(codes, "fav", "1") }
            else -> askText("بحث واستبدال", "ابحث عن (في الاسم العربي)", "استبدله بـ") { f, r ->
                if (f.isNotEmpty()) confirm("استبدال «$f» بـ «$r»") { db.findReplaceAr(codes, f, r) }
            }
        }
    }

    private fun onMenu(id: Int): Boolean {
        when (id) {
            R.id.m_review -> Review.pick(this)
            R.id.m_batch -> batchMenu()
            R.id.m_views -> viewsMenu()
            R.id.m_progress -> startActivity(Intent(this, ProgressActivity::class.java))
            R.id.m_data -> DataTools.showMenu(this)
            R.id.m_settings -> startActivity(Intent(this, SettingsActivity::class.java))
            R.id.m_share_apk -> try {
                Share.apk(this)
            } catch (e: Exception) {
                Toast.makeText(this, "تعذر تجهيز الملف: ${e.message}", Toast.LENGTH_LONG).show()
            }
            else -> return false
        }
        return true
    }
}

class FamilyAdapter(
    private val fams: List<Family>,
    private val onClick: (Family) -> Unit
) : RecyclerView.Adapter<FamilyAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val card = v as MaterialCardView
        val name: TextView = v.findViewById(R.id.famName)
        val meta: TextView = v.findViewById(R.id.famMeta)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_family, parent, false))

    override fun getItemCount() = fams.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val f = fams[position]
        h.name.text = f.name
        h.meta.text = "${f.count} تركيز/عبوة" + if (f.cls.isNotBlank()) " • ${f.cls}" else ""
        Ui.styleCard(h.card)
        h.card.setOnClickListener { _ -> onClick(f) }
        Ui.style(h.itemView)
    }
}

class ItemAdapter(
    private val items: List<Item>,
    private val selected: Set<Int>,
    private val onClick: (Item) -> Unit,
    private val onLong: (Item) -> Unit
) : RecyclerView.Adapter<ItemAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val card = v as MaterialCardView
        val main: TextView = v.findViewById(R.id.nameMain)
        val sub: TextView = v.findViewById(R.id.nameSub)
        val meta: TextView = v.findViewById(R.id.meta)
        val reason: TextView = v.findViewById(R.id.reason)
        val check: TextView = v.findViewById(R.id.check)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_row, parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val item = items[position]

        // الكود ملتصق بالاسم الأجنبي دائمًا؛ الإعداد يغيّر فقط أيّ السطرين يأتي أولًا.
        val star = if (item.fav) "★ " else ""
        val codeEn = if (item.nameEn.isNotBlank()) "${item.code} · ${item.nameEn}" else "${item.code} · — بدون اسم أجنبي —"
        val ar = item.nameAr.ifBlank { "— بدون اسم عربي —" }
        if (Prefs.nameOrder == "ar") {
            h.main.text = star + ar
            h.sub.text = codeEn
        } else {
            h.main.text = star + codeEn
            h.sub.text = ar
        }

        val parts = ArrayList<String>()
        parts += Labels.status[item.status] ?: item.status
        if (Labels.isAuto(item.nameSrc)) parts += "اسم عربي مقترح"
        if (Labels.isAutoClass(item.classSrc)) parts += "تصنيف مقترح"
        if (item.devSrc == "auto") parts += "جهاز مقترح"
        if (item.flag == "mismatch") parts += "تعارض اسمين"
        if (item.decision != "pending" && item.decision != "keep") parts += Labels.decision[item.decision] ?: item.decision
        if (item.concentration.isNotBlank()) parts += item.concentration
        if (item.therapeuticClass.isNotBlank() && item.therapeuticClass != "غير محدد") parts += item.therapeuticClass
        if (item.tag.isNotBlank()) parts += "#${item.tag}"
        h.meta.text = parts.joinToString(" • ")
        h.meta.visibility = if (Prefs.compact) View.GONE else View.VISIBLE

        h.reason.text = item.removalReason
        h.reason.visibility = if (item.removalReason.isBlank()) View.GONE else View.VISIBLE

        Ui.styleCard(h.card)
        val sel = selected.contains(item.code)
        h.check.visibility = if (sel) View.VISIBLE else View.GONE
        if (sel) {
            h.card.strokeWidth = (2 * h.card.resources.displayMetrics.density).toInt()
            h.card.strokeColor = Ui.primary(h.card.context)
        }

        h.card.setOnClickListener { _ -> onClick(item) }
        h.card.setOnLongClickListener { _ -> onLong(item); true }
        Ui.style(h.itemView)
    }
}
