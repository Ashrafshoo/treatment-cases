from pathlib import Path
root=Path(__file__).resolve().parents[1]
db=(root/'app/src/main/java/com/example/rentals/data/RentalsDb.kt').read_text()
ui=(root/'app/src/main/java/com/example/rentals/MainActivity.kt').read_text()
checks={
 'database schema v13':'rentals_local.db", null, 13' in db,
 'unit has stable property and tenant links':'property_id INTEGER,tenant_id INTEGER' in db,
 'existing entities are backfilled':'UPDATE units SET property_id=' in db and 'UPDATE units SET tenant_id=' in db,
 'lease tenant mapping uses historical snapshot':'TRIM(COALESCE(leases.tenant_name_snapshot' in db,
 'entity read and write APIs exist':all(x in db for x in ['fun properties():','fun tenants():','fun saveProperty(','fun saveTenant(']),
 'linked entities cannot be deleted': 'لا يمكن حذف عقار مرتبط بوحدات' in db and 'لا يمكن حذف مستأجر مرتبط بوحدة أو عقد' in db,
 'new unit save links canonical entities':'put("property_id",propertyId)' in db and 'put("tenant_id",tenantId)' in db,
 'new lease links current tenant':'if(id<=0){if(tenantId==null)putNull("tenant_id")else put("tenant_id",tenantId)}' in db,
 'entity management is reachable from app navigation':'Tab.Entities->EntityManagementScreen(db)' in ui,
 'tenant rename routed through safe unit workflow':'غيّر المستأجر من بطاقة الوحدة' in db,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+': '+name)
assert all(checks.values())
