import 'package:flutter/material.dart';
import '../data/expenses_repository.dart';
import '../../auth/data/app_session.dart';
import '../../records/data/records_repository.dart';

class ExpensesScreen extends StatefulWidget {
  const ExpensesScreen({super.key});
  @override
  State<ExpensesScreen> createState() => _ExpensesScreenState();
}

class _ExpensesScreenState extends State<ExpensesScreen> {
  final _repo = ExpensesRepository();
  final _recordsRepo = RecordsRepository();
  late Future<List<Map<String,Object?>>> _rows;
  late Future<Map<String,int>> _totals;
  @override
  void initState() { super.initState(); _refresh(); }
  void _refresh() { _rows = _repo.all(); _totals = _repo.totals(); }

  Future<void> _edit([Map<String,Object?>? row]) async {
    final saved = await showModalBottomSheet<bool>(context: context, isScrollControlled: true, useSafeArea: true, builder: (_) => _ExpenseForm(repository: _repo, record: row));
    if (saved == true && mounted) setState(_refresh);
  }

  Future<void> _archive(Map<String,Object?> row) async {
    final yes = await showDialog<bool>(context: context, builder: (context) => AlertDialog(title: const Text('حذف المصروف'), content: Text('سيتم إخفاء المصروف "${row['name']}" مع الاحتفاظ بسجله. هل تريد المتابعة؟'), actions: [TextButton(onPressed: () => Navigator.pop(context,false), child: const Text('إلغاء')), FilledButton(onPressed: () => Navigator.pop(context,true), child: const Text('تأكيد'))]));
    if (yes == true) { await _repo.archive(row['id'] as String); if (mounted) setState(_refresh); }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('المصروفات العامة')),
    floatingActionButton: AppSession.instance.isAdmin ? FloatingActionButton.extended(onPressed:()=>_edit(),icon:const Icon(Icons.add),label:const Text('إضافة مصروف')) : null,
    body: Column(children: [
      FutureBuilder<Map<String,int>>(future: _totals, builder: (context,s) { final d=s.data ?? {}; return Card(margin: const EdgeInsets.all(16), child: ListTile(leading: const Icon(Icons.account_balance_wallet_outlined), title: Text('إجمالي المصروفات: ${((d['total'] ?? 0)/100).toStringAsFixed(2)} جنيه'), subtitle: Text('عدد المصروفات: ${d['count'] ?? 0}'))); }),
      Expanded(child: FutureBuilder<List<Map<String,Object?>>>(future: _rows, builder: (context,s) {
        if (s.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
        if (s.hasError) return Center(child: Text('تعذر تحميل المصروفات: ${s.error}'));
        final rows=s.data ?? []; if (rows.isEmpty) return const Center(child: Text('لا توجد مصروفات مسجلة'));
        return ListView.separated(padding: const EdgeInsets.fromLTRB(16,0,16,90), itemCount: rows.length, separatorBuilder: (_,__)=>const SizedBox(height:8), itemBuilder: (context,i) { final r=rows[i]; return Card(child: ListTile(tileColor:(r['modified_unreviewed'] as num?)?.toInt()==1?Theme.of(context).colorScheme.tertiaryContainer.withOpacity(0.35):null,title: Text(r['name'] as String), subtitle: Text('${r['expense_date']} • ${r['notes'] ?? ''}'), trailing: Row(mainAxisSize:MainAxisSize.min,children:[Text('${((r['amount_minor'] as num)/100).toStringAsFixed(2)} ج'),if(AppSession.instance.isAdmin)PopupMenuButton<String>(onSelected:(v){if(v=='edit')_edit(r);if(v=='archive')_archive(r);if(v=='clear')_clearModified(r);},itemBuilder:(_)=>[const PopupMenuItem(value:'edit',child:Text('تعديل')),const PopupMenuItem(value:'archive',child:Text('أرشفة')),if((r['modified_unreviewed'] as num?)?.toInt()==1)const PopupMenuItem(value:'clear',child:Text('إزالة علامة التعديل بعد المراجعة'))])]))); });
      }))
    ]),
  );
}

class _ExpenseForm extends StatefulWidget {
  const _ExpenseForm({required this.repository, this.record});
  final ExpensesRepository repository;
  final Map<String,Object?>? record;
  @override
  State<_ExpenseForm> createState() => _ExpenseFormState();
}
class _ExpenseFormState extends State<_ExpenseForm> {
  final _form=GlobalKey<FormState>(); late final TextEditingController _name; late final TextEditingController _amount; late final TextEditingController _notes; late DateTime _date; bool _saving=false;
  @override
  void initState() { super.initState(); final r=widget.record; _name=TextEditingController(text:r?['name'] as String? ?? ''); _amount=TextEditingController(text:r==null?'':((r['amount_minor'] as num)/100).toStringAsFixed(2)); _notes=TextEditingController(text:r?['notes'] as String? ?? ''); _date=r==null?DateTime.now():DateTime.parse(r['expense_date'] as String); }
  @override
  void dispose(){_name.dispose();_amount.dispose();_notes.dispose();super.dispose();}
  Future<void> _save() async { if(!_form.currentState!.validate()) return; setState(()=>_saving=true); try { await widget.repository.save(id:widget.record?['id'] as String?,name:_name.text,amountMinor:(double.parse(_amount.text)*100).round(),date:_date,notes:_notes.text); if(mounted) Navigator.pop(context,true); } catch(e) { if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تعذر الحفظ: $e'))); } finally {if(mounted)setState(()=>_saving=false);} }
  @override
  Widget build(BuildContext context)=>Padding(padding:EdgeInsets.fromLTRB(18,18,18,MediaQuery.of(context).viewInsets.bottom+18),child:Form(key:_form,child:ListView(shrinkWrap:true,children:[Text(widget.record==null?'إضافة مصروف':'تعديل مصروف',style:Theme.of(context).textTheme.titleLarge),const SizedBox(height:14),TextFormField(controller:_name,decoration:const InputDecoration(labelText:'اسم المصروف'),validator:(v)=>v==null||v.trim().isEmpty?'أدخل اسم المصروف':null),TextFormField(controller:_amount,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'القيمة بالجنيه'),validator:(v)=>double.tryParse(v??'')==null||double.parse(v!)<0?'أدخل قيمة صحيحة':null),ListTile(contentPadding:EdgeInsets.zero,title:const Text('التاريخ'),subtitle:Text('${_date.year}-${_date.month.toString().padLeft(2,'0')}-${_date.day.toString().padLeft(2,'0')}'),trailing:IconButton(onPressed:()async{final d=await showDatePicker(context:context,initialDate:_date,firstDate:DateTime(2000),lastDate:DateTime(2100));if(d!=null)setState(()=>_date=d);},icon:const Icon(Icons.calendar_month))),TextField(controller:_notes,maxLines:3,decoration:const InputDecoration(labelText:'ملاحظات / الغرض من المصروف')),const SizedBox(height:16),FilledButton(onPressed:_saving?null:_save,child:Text(_saving?'جارٍ الحفظ…':'حفظ'))])));
}
