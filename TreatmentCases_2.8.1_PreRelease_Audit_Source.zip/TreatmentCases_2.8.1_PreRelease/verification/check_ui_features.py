from pathlib import Path
src = Path("android/app/src/main/java/com/treatmentcases/app/MainActivity.kt").read_text()
checks = {
    "dropdown font family": "PreferenceDropdown(appLabel(\"نوع الخط\",\"Font Family\",isEnglish)" in src,
    "eight palette options": all(f'"{x}" to' in src for x in ["blue","green","purple","teal","indigo","rose","amber","slate"]),
    "ten font choices": all(f'"{x}" to' in src for x in ["sans","naskh","serif","mono","cursive","condensed","rounded","light","medium","black"]),
    "five full theme presets": all(f'"{x}" to' in src for x in ["clinic","forest","lavender","midnight","graphite"]),
    "spacing slider 50-140 percent": "valueRange=50f..140f" in src and "spacing_percent" in src,
    "font scale range 60-140": "valueRange=0.6f..1.4f" in src,
    "font family applied inside MaterialTheme": src.index("MaterialTheme(typography=") < src.index("LocalTextStyle provides"),
    "global bold typography switch": "bold_text" in src and "fontWeight=weight" in src,
    "medicine detail editor": "MedicineDetailsDialog" in src and "دواعي الاستعمال الموثقة" in src,
    "patient record includes medicine info": "دواعي الاستعمال المسجلة" in src and "التصنيف الطبي" in src,
    "factory reset options": all(x in src for x in ["مسح جميع سجلات الحالات فقط", "مسح دليل العاملين فقط", "إعادة ضبط بيانات البرنامج بالكامل"]),
    "reset password and phrase guard": "auth.verify(resetPassword)" in src and "resetPhrase.trim()==requiredPhrase" in src,
    "distinct backgrounds": all(f'"{x}" to' in src for x in ["white","sky","mint","lavender","cream","rose","slate","aqua"]),
    "factory reset database transaction": "fun factoryResetData()" in Path("android/app/src/main/java/com/treatmentcases/app/LocalDb.kt").read_text(),
    "medicine clinical fields migrated": all(x in Path("android/app/src/main/java/com/treatmentcases/app/LocalDb.kt").read_text() for x in ["indications","critical_classification","target_conditions","source_reference","aliases"]),
    "fuzzy medicine typo blocks import": "medicineNameReviewIssues(rows)" in Path("android/app/src/main/java/com/treatmentcases/app/LocalDb.kt").read_text(),
    "verified aliases migrate without duplicates": "reconcileVerifiedMedicineAliases()" in Path("android/app/src/main/java/com/treatmentcases/app/LocalDb.kt").read_text() and all(x in Path("android/app/src/main/assets/medicines_seed.json").read_text() for x in ["CINRYSE","Xelganz","X-GEVA"]),
    "medicine clinical details included in backup": "critical_classification" in Path("android/app/src/main/java/com/treatmentcases/app/EncryptedBackup.kt").read_text(),
    "seed includes verified indications and references": all(x in Path("android/app/src/main/assets/medicines_seed.json").read_text() for x in ["الوقاية الروتينية من نوبات الوذمة", "الأحداث المرتبطة بالهيكل العظمي", "التهاب المفاصل الروماتويدي"]),
    "seed dictionary deduplicated": len({__import__("re").sub(r"[\s\W_]+", "", r["name"].strip().casefold()) for r in __import__("json").loads(Path("android/app/src/main/assets/medicines_seed.json").read_text())}) == len(__import__("json").loads(Path("android/app/src/main/assets/medicines_seed.json").read_text())),
    "visible reports tab": '"التقارير"' in src and "تصدير PDF" in src and "تصدير Excel" in src,
    "single/multiple/all report selection": "اختيار الكل" in src and "selectedReportMeds" in src,
    "biometric prompt": "BiometricPrompt" in src and "BIOMETRIC_STRONG" in src,
    "fingerprint login entry": "الدخول بالبصمة" in src,
}
for label, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + label)
if not all(checks.values()): raise SystemExit(1)
# 2.4.9 medicine catalog quality and maintenance controls
root = Path(".")
catalog = (root / "android/app/src/main/assets/medicines_seed.json").read_text(encoding="utf-8")
local_db = (root / "android/app/src/main/java/com/treatmentcases/app/LocalDb.kt").read_text(encoding="utf-8")
main_ui = (root / "android/app/src/main/java/com/treatmentcases/app/MainActivity.kt").read_text(encoding="utf-8")
assert catalog.count('"indications"') >= 109, "verified medical indication fields should be populated for 109 catalog entries"
assert "refreshVerifiedMedicineMetadataFromSeed" in local_db, "existing installs should safely receive newly verified medicine metadata"
assert "reconcileStrengthDuplicates" in local_db, "strengths should be deduplicated on startup"
assert "medicineCatalogReviewReport" in local_db and "تقرير المراجعة" in main_ui, "medicine audit report should be available in the app"
assert "removeStrength" in local_db and "renameStrength" in local_db, "strength CRUD should include delete and rename"
assert "aliasItems" in main_ui and "تعديل الاسم البديل" in main_ui and "حذف الاسم البديل" in main_ui, "medicine aliases should be manageable in the details screen"
assert "CINRYSE" in local_db and "Xelganz" in local_db and "X-GEVA" in local_db, "verified medicine name corrections should be migrated"
print("PASS: 2.4.9 catalog coverage and maintenance controls")
