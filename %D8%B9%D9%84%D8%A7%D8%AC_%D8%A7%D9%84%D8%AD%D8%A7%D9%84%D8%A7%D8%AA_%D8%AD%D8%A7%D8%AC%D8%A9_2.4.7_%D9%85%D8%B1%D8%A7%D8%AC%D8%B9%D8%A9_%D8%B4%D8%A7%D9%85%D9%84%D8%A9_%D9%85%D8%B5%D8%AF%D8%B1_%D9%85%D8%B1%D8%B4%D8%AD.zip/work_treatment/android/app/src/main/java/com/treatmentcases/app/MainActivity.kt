package com.treatmentcases.app

import android.app.Activity
import android.graphics.Paint
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.fragment.app.FragmentActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontFamily
import android.graphics.Typeface
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.*

private val Navy=Color(0xFF0759C7);private val Teal=Color(0xFF20A447);private val Bg=Color(0xFFF3F7FF)
private val fontOptions = listOf(
    "sans" to "عربي واضح (افتراضي)", "naskh" to "نسخي عربي", "serif" to "سيريـف",
    "mono" to "ثابت", "cursive" to "مائل", "condensed" to "مضغوط",
    "rounded" to "مستدير", "light" to "خفيف", "medium" to "متوسط", "black" to "عريض جداً"
)
private val paletteOptions = listOf(
    "blue" to "أزرق طبي", "green" to "أخضر هادئ", "purple" to "بنفسجي",
    "teal" to "تركواز", "indigo" to "نيلي", "rose" to "وردي هادئ",
    "amber" to "ذهبي", "slate" to "رمادي أزرق"
)
private val backgroundOptions = listOf(
    "white" to "أبيض نقي", "sky" to "أزرق سماوي واضح", "mint" to "أخضر نعناعي",
    "lavender" to "بنفسجي فاتح", "cream" to "كريمي دافئ", "rose" to "وردي فاتح",
    "slate" to "رمادي مزرق", "aqua" to "فيروزي فاتح"
)
private fun appTypeface(choice:String): Typeface = Typeface.create(when(choice){
    "naskh","serif"->"serif"; "mono"->"monospace"; "cursive"->"casual";
    "condensed"->"sans-serif-condensed"; "rounded"->"sans-serif-rounded";
    "light"->"sans-serif-light"; "medium"->"sans-serif-medium"; "black"->"sans-serif-black"; else->"sans-serif"
}, Typeface.NORMAL)
private fun appTypography(family:FontFamily):Typography {
    val t=Typography()
    return t.copy(
        displayLarge=t.displayLarge.copy(fontFamily=family),displayMedium=t.displayMedium.copy(fontFamily=family),displaySmall=t.displaySmall.copy(fontFamily=family),
        headlineLarge=t.headlineLarge.copy(fontFamily=family),headlineMedium=t.headlineMedium.copy(fontFamily=family),headlineSmall=t.headlineSmall.copy(fontFamily=family),
        titleLarge=t.titleLarge.copy(fontFamily=family),titleMedium=t.titleMedium.copy(fontFamily=family),titleSmall=t.titleSmall.copy(fontFamily=family),
        bodyLarge=t.bodyLarge.copy(fontFamily=family),bodyMedium=t.bodyMedium.copy(fontFamily=family),bodySmall=t.bodySmall.copy(fontFamily=family),
        labelLarge=t.labelLarge.copy(fontFamily=family),labelMedium=t.labelMedium.copy(fontFamily=family),labelSmall=t.labelSmall.copy(fontFamily=family)
    )
}
private fun accentColor(choice:String)=when(choice){
    "green"->Color(0xFF087F6A); "purple"->Color(0xFF6941A5); "teal"->Color(0xFF007C91);
    "indigo"->Color(0xFF3949AB); "rose"->Color(0xFFAD496B); "amber"->Color(0xFF9A6500);
    "slate"->Color(0xFF455A64); else->Navy
}
private fun appBackground(choice:String)=when(choice){
    "sky"->Color(0xFFE1F0FF); "mint"->Color(0xFFDFF3E8); "lavender"->Color(0xFFECE4F7);
    "cream"->Color(0xFFFFF0D6); "rose"->Color(0xFFFBE1E8); "slate"->Color(0xFFE0E8F0);
    "aqua"->Color(0xFFD8F1F0); else->Color.White
}
@Composable private fun PreferenceDropdown(label:String, selected:String, options:List<Pair<String,String>>, onSelected:(String)->Unit){
    var expanded by remember { mutableStateOf(false) }
    Column(verticalArrangement=Arrangement.spacedBy(3.dp)) {
        Text(label,fontWeight=FontWeight.SemiBold)
        Box(Modifier.fillMaxWidth()) {
            OutlinedButton(onClick={expanded=true},modifier=Modifier.fillMaxWidth(),contentPadding=PaddingValues(horizontal=12.dp,vertical=8.dp)) {
                Text(options.firstOrNull{it.first==selected}?.second ?: options.first().second,Modifier.weight(1f))
                Icon(Icons.Default.ArrowDropDown,null)
            }
            DropdownMenu(expanded=expanded,onDismissRequest={expanded=false},modifier=Modifier.fillMaxWidth(.88f)) {
                options.forEach { option -> DropdownMenuItem(text={Text(option.second)},onClick={onSelected(option.first);expanded=false}) }
            }
        }
    }
}

private const val MAX_BACKUP_BYTES = 64L * 1024L * 1024L
private fun readBackupBytes(context: android.content.Context, uri: Uri): ByteArray {
    val out = java.io.ByteArrayOutputStream()
    context.contentResolver.openInputStream(uri)?.use { input ->
        val buffer = ByteArray(8192)
        var total = 0L
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            total += count
            require(total <= MAX_BACKUP_BYTES) { "حجم ملف النسخة أكبر من الحد المسموح (64 ميجابايت)" }
            out.write(buffer, 0, count)
        }
    } ?: error("تعذر فتح ملف النسخة الاحتياطية")
    return out.toByteArray()
}
private fun promptFingerprint(activity:FragmentActivity,title:String,onSuccess:()->Unit,onError:(String)->Unit){
    val manager=BiometricManager.from(activity)
    val availability=manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG)
    if(availability!=BiometricManager.BIOMETRIC_SUCCESS){onError(when(availability){BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE->"هذا الهاتف لا يحتوي على مستشعر بصمة متوافق";BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE->"مستشعر البصمة غير متاح حالياً";BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED->"لا توجد بصمة مسجلة في إعدادات الهاتف";else->"المصادقة بالبصمة غير متاحة على هذا الهاتف"});return}
    val prompt=BiometricPrompt(activity,ContextCompat.getMainExecutor(activity),object:BiometricPrompt.AuthenticationCallback(){
        override fun onAuthenticationSucceeded(result:BiometricPrompt.AuthenticationResult){super.onAuthenticationSucceeded(result);onSuccess()}
        override fun onAuthenticationError(errorCode:Int,errString:CharSequence){super.onAuthenticationError(errorCode,errString);onError(errString.toString())}
        override fun onAuthenticationFailed(){super.onAuthenticationFailed();onError("لم يتم التعرف على البصمة؛ حاول مرة أخرى")}
    })
    val info=BiometricPrompt.PromptInfo.Builder().setTitle(title).setSubtitle("تحقق من هويتك للمتابعة").setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG).setNegativeButtonText("إلغاء").build()
    prompt.authenticate(info)
}

class MainActivity:FragmentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){
  super.onCreate(savedInstanceState)
  val db=LocalDb(this);val auth=AuthManager(this)
  val prefs=getSharedPreferences("app_preferences",MODE_PRIVATE)
  setContent {
   var darkTheme by remember{mutableStateOf(prefs.getBoolean("dark_theme",false))}
   var fontScale by remember{mutableFloatStateOf(prefs.getFloat("font_scale",1f).coerceIn(0.4f,1.4f))}
   var fontChoice by remember{mutableStateOf(prefs.getString("font_family","sans")?:"sans")}
   var paletteChoice by remember{mutableStateOf(prefs.getString("palette","blue")?:"blue")}
   var backgroundChoice by remember{mutableStateOf(prefs.getString("background","white")?:"white")}
   var fingerprintEnabled by remember{mutableStateOf(prefs.getBoolean("fingerprint_enabled",false))}
   val family=FontFamily(appTypeface(fontChoice))
   val primary=accentColor(paletteChoice)
   val secondary=when(paletteChoice){
    "green"->Color(0xFF42A58D);"purple"->Color(0xFF9B7BD0);"teal"->Color(0xFF42B8C3)
    "rose"->Color(0xFFD68AA2);"indigo"->Color(0xFF7986CB);"amber"->Color(0xFFD4A64A)
    "slate"->Color(0xFF78909C);else->Teal
   }
   val density=LocalDensity.current
   val lightBg=appBackground(backgroundChoice)
   CompositionLocalProvider(LocalDensity provides androidx.compose.ui.unit.Density(density.density,fontScale)) {
    MaterialTheme(typography=appTypography(family),colorScheme=if(darkTheme) darkColorScheme(primary=primary,secondary=secondary,background=Color(0xFF101820),surface=Color(0xFF1B2732)) else lightColorScheme(primary=primary,secondary=secondary,background=lightBg,surface=Color.White)) {
     // Apply the selected typeface AFTER MaterialTheme, otherwise MaterialTheme's typography overrides it.
     CompositionLocalProvider(androidx.compose.material3.LocalTextStyle provides androidx.compose.material3.LocalTextStyle.current.merge(TextStyle(fontFamily=family))) {
      AppGate(db,auth,darkTheme,
       {darkTheme=it;prefs.edit().putBoolean("dark_theme",it).apply()},
       {fontScale=it;prefs.edit().putFloat("font_scale",it).apply()},
       {fontChoice=it;prefs.edit().putString("font_family",it).apply()},
       {paletteChoice=it;prefs.edit().putString("palette",it).apply()},
       backgroundChoice,{backgroundChoice=it;prefs.edit().putString("background",it).apply()},
       fingerprintEnabled,{fingerprintEnabled=it;prefs.edit().putBoolean("fingerprint_enabled",it).apply()})
     }
    }
   }
  }
 }
}
@Composable fun AppGate(db:LocalDb,auth:AuthManager,darkTheme:Boolean,onDarkThemeChange:(Boolean)->Unit,onFontScaleChange:(Float)->Unit,onFontChoiceChange:(String)->Unit,onPaletteChange:(String)->Unit,backgroundChoice:String,onBackgroundChange:(String)->Unit,fingerprintEnabled:Boolean,onFingerprintEnabledChange:(Boolean)->Unit){val gateContext=LocalContext.current;var unlocked by remember{mutableStateOf(false)};var configured by remember{mutableStateOf(auth.isConfigured())};var password by remember{mutableStateOf("")};var confirm by remember{mutableStateOf("")};var error by remember{mutableStateOf("")}
 if(unlocked) App(db,auth,darkTheme,onDarkThemeChange,onFontScaleChange,onFontChoiceChange,onPaletteChange,backgroundChoice,onBackgroundChange,fingerprintEnabled,onFingerprintEnabledChange) else Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(24.dp),verticalArrangement=Arrangement.Center,horizontalAlignment=Alignment.CenterHorizontally){Icon(Icons.Default.HealthAndSafety,null,tint=MaterialTheme.colorScheme.primary,modifier=Modifier.size(72.dp));Text("علاج الحالات حاجة",fontSize=25.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary);Text(if(configured)"تسجيل دخول المدير" else "إنشاء كلمة مرور المدير لأول استخدام",color=Color.Gray);OutlinedTextField(password,{password=it},Modifier.fillMaxWidth(),label={Text("كلمة المرور")},singleLine=true,visualTransformation=PasswordVisualTransformation());if(!configured)OutlinedTextField(confirm,{confirm=it},Modifier.fillMaxWidth(),label={Text("تأكيد كلمة المرور")},singleLine=true,visualTransformation=PasswordVisualTransformation());if(error.isNotBlank())Text(error,color=Color.Red);Button(onClick={if(configured){if(auth.verify(password)){unlocked=true;error=""}else error="كلمة المرور غير صحيحة"}else if(password!=confirm)error="كلمتا المرور غير متطابقتين" else if(auth.createAdmin(password)){configured=true;unlocked=true;error=""}else error="استخدم كلمة مرور لا تقل عن 8 أحرف أو أرقام"},Modifier.fillMaxWidth()){Text(if(configured)"دخول" else "إنشاء حساب المدير")};if(configured&&fingerprintEnabled)OutlinedButton(onClick={promptFingerprint(gateContext as FragmentActivity,"الدخول بالبصمة",{unlocked=true;error=""},{error=it})},Modifier.fillMaxWidth()){Icon(Icons.Default.Fingerprint,null);Text("الدخول بالبصمة")};Text("الحماية محلية على هذا الهاتف؛ احتفظ بكلمة المرور في مكان آمن.",fontSize=12.sp,color=Color.Gray)}
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun App(db:LocalDb,auth:AuthManager,darkTheme:Boolean,onDarkThemeChange:(Boolean)->Unit,onFontScaleChange:(Float)->Unit,onFontChoiceChange:(String)->Unit,onPaletteChange:(String)->Unit,backgroundChoice:String,onBackgroundChange:(String)->Unit,fingerprintEnabled:Boolean,onFingerprintEnabledChange:(Boolean)->Unit){val ctx=LocalContext.current;var fontScale by remember{mutableFloatStateOf(ctx.getSharedPreferences("app_preferences",0).getFloat("font_scale",1f))};var fontChoice by remember{mutableStateOf(ctx.getSharedPreferences("app_preferences",0).getString("font_family","sans")?:"sans")};var paletteChoice by remember{mutableStateOf(ctx.getSharedPreferences("app_preferences",0).getString("palette","blue")?:"blue")};var backgroundChoiceLocal by remember{mutableStateOf(backgroundChoice)};var spacingLevel by remember{mutableFloatStateOf(ctx.getSharedPreferences("app_preferences",0).getFloat("spacing_level",if(ctx.getSharedPreferences("app_preferences",0).getBoolean("compact_spacing",true))15f else 60f).coerceIn(0f,100f))};var changePasswordDialog by remember{mutableStateOf(false)};var resetMode by remember{mutableStateOf("")};var resetPhrase by remember{mutableStateOf("")};var resetPassword by remember{mutableStateOf("")};var currentPassword by remember{mutableStateOf("")};var newPassword by remember{mutableStateOf("")};var confirmPassword by remember{mutableStateOf("")};var settingsMessage by remember{mutableStateOf("")};var tick by remember{mutableIntStateOf(0)};var page by remember{mutableStateOf("الرئيسية")};var pageBeforeRecords by remember{mutableStateOf("الرئيسية")};var query by remember{mutableStateOf("")};var filter by remember{mutableStateOf("")};var edit by remember{mutableStateOf<CaseRecord?>(null)};var form by remember{mutableStateOf(false)};var msg by remember{mutableStateOf("")};var previewRows by remember{mutableStateOf<List<CaseRecord>?>(null)};var showMedicineAdd by remember{mutableStateOf(false)};var newMedicine by remember{mutableStateOf("")};var newStrengths by remember{mutableStateOf("")};var backupDialog by remember{mutableStateOf("")};var backupPassword by remember{mutableStateOf("")};var restoreBytes by remember{mutableStateOf<ByteArray?>(null)};var restorePreview by remember{mutableStateOf<BackupBundle?>(null)};var exportBackupBytes by remember{mutableStateOf<ByteArray?>(null)};var employeeQuery by remember{mutableStateOf("")};var employeePlan by remember{mutableStateOf<EmployeeImportPlan?>(null)};var employeeEdit by remember{mutableStateOf<EmployeeRecord?>(null)};var showEmployeeForm by remember{mutableStateOf(false)};var reportDialog by remember{mutableStateOf(false)};var selectedReportMeds by remember{mutableStateOf<Set<String>>(emptySet())};var pendingReportRows by remember{mutableStateOf<List<CaseRecord>>(emptyList())};var pendingReportTitle by remember{mutableStateOf("تقرير الحالات الحرجة")}
 val meds=remember(tick){db.medicines()};val counts=remember(tick){db.counts()};val reportMeds=remember(meds,counts){meds.filter{(counts[it]?:0)>0}};val alerts=remember(tick){db.alerts()};val results=remember(tick,query,filter){db.search(query,filter)};val employeeResults=remember(tick,employeeQuery){db.employees(employeeQuery)}
 LaunchedEffect(reportMeds){selectedReportMeds=selectedReportMeds.intersect(reportMeds.toSet())}
 val import=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){u->if(u!=null)try{val rows=Xlsx.read(ctx.contentResolver,u);previewRows=rows;msg="تمت قراءة ${rows.size} صفًا. راجعها قبل الاعتماد."}catch(e:Exception){msg="تعذر الاستيراد: ${e.message}"}}
 val caseTemplate=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")){u->if(u!=null)try{Xlsx.writeTemplate(ctx.contentResolver,u);msg="تم إنشاء نموذج الحالات الحرجة الفارغ. املأه ثم أعد استيراده."}catch(e:Exception){msg="تعذر إنشاء النموذج: ${e.message}"}}
 val export=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")){u->if(u!=null)try{val rows=pendingReportRows;Xlsx.write(rows,ctx.contentResolver,u);msg="تم تصدير ${rows.size} سجل إلى Excel"}catch(e:Exception){msg="خطأ التصدير: ${e.message}"}}
 val employeeImport=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){u->if(u!=null)try{val rows=EmployeeXlsx.read(ctx.contentResolver,u);employeePlan=db.planEmployeeImport(rows);msg="تم فحص ${rows.size} صفاً. راجع تقرير دليل العاملين قبل الاعتماد."}catch(e:Exception){msg="تعذر قراءة قالب دليل العاملين: ${e.message}"}}
 val employeeTemplate=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")){u->if(u!=null)try{EmployeeXlsx.writeTemplate(ctx.contentResolver,u);msg="تم إنشاء قالب دليل العاملين الفارغ"}catch(e:Exception){msg="تعذر إنشاء القالب: ${e.message}"}}
 val employeeExport=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")){u->if(u!=null)try{EmployeeXlsx.writeDirectory(ctx.contentResolver,u,db.employees());msg="تم تصدير دليل العاملين"}catch(e:Exception){msg="تعذر تصدير الدليل: ${e.message}"}}
 val backupSave=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")){u->if(u!=null&&exportBackupBytes!=null)try{ctx.contentResolver.openOutputStream(u)?.use{it.write(exportBackupBytes!!)};msg="تم حفظ النسخة الاحتياطية المشفرة"}catch(e:Exception){msg="تعذر حفظ النسخة: ${e.message}"};exportBackupBytes=null}
 val backupOpen=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){u->if(u!=null)try{restoreBytes=readBackupBytes(ctx,u);backupDialog="restore"}catch(e:Exception){msg="تعذر قراءة النسخة: ${e.message}"}}
 val pdf=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")){u->if(u!=null)try{val rows=pendingReportRows;pdfReport(ctx as Activity,u,rows,pendingReportTitle);msg="تم إنشاء PDF يضم ${rows.size} سجل"}catch(e:Exception){msg="تعذر إنشاء PDF: ${e.message}"}}
 BackHandler(enabled=page!="الرئيسية"||form||reportDialog||backupDialog.isNotBlank()||restorePreview!=null||previewRows!=null||showMedicineAdd||showEmployeeForm||changePasswordDialog){when{changePasswordDialog->{changePasswordDialog=false;currentPassword="";newPassword="";confirmPassword=""};showMedicineAdd->showMedicineAdd=false;showEmployeeForm->showEmployeeForm=false;previewRows!=null->previewRows=null;restorePreview!=null->restorePreview=null;backupDialog.isNotBlank()->{backupDialog="";backupPassword=""};reportDialog->reportDialog=false;form->form=false;page=="السجلات"->{filter="";page=pageBeforeRecords};page=="العاملون"->page="الإعدادات";page!="الرئيسية"->page="الرئيسية"}}
 Scaffold(topBar={TopAppBar(title={Column{Text("علاج الحالات حاجة",fontWeight=FontWeight.Bold);Text("قاعدة بيانات محلية • دون إنترنت",fontSize=11.sp,color=Color.Gray)}},actions={IconButton(onClick={page="الإعدادات"}){Icon(Icons.Default.Settings,null)}})},bottomBar={NavigationBar{listOf("الرئيسية","السجلات","الأدوية","التقارير","الإعدادات").forEach{p->NavigationBarItem(selected=page==p,onClick={page=p;filter="";query=""},icon={Icon(when(p){"الرئيسية"->Icons.Default.Home;"السجلات"->Icons.Default.People;"الأدوية"->Icons.Default.Medication;"التقارير"->Icons.Default.Assessment;else->Icons.Default.Settings},null)},label={Text(p)})}}}){pad->Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(pad).padding((4f + spacingLevel * 0.08f).dp)){
 if(msg.isNotBlank()){Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Color(0xFFDDF1EA))){Row(Modifier.padding(9.dp),verticalAlignment=Alignment.CenterVertically){Text(msg,Modifier.weight(1f));TextButton(onClick={msg=""}){Text("إغلاق")}}}}
 when(page){"الرئيسية"->{Text("لوحة المتابعة",fontSize=23.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Stat("إجمالي السجلات",db.count().toString(),Modifier.weight(1f));Stat("الأدوية",meds.size.toString(),Modifier.weight(1f))};Spacer(Modifier.height(10.dp));Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){Column(Modifier.padding(12.dp)){Text("مراجعة جودة البيانات • ${alerts.size} تنبيه",fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary);if(alerts.isEmpty())Text("لا توجد تنبيهات أساسية",color=MaterialTheme.colorScheme.secondary) else alerts.forEach{Text("• $it",fontSize=12.sp,color=Color(0xFF9A5A12))}}};Spacer(Modifier.height(12.dp));Text("الأدوية المسجلة",fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary);LazyColumn(verticalArrangement=Arrangement.spacedBy((2f + spacingLevel * 0.06f).dp)){items(meds){m->Card(Modifier.fillMaxWidth().clickable{pageBeforeRecords="الرئيسية";filter=m;page="السجلات"},colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Text(m,Modifier.weight(1f),fontWeight=FontWeight.SemiBold,color=MaterialTheme.colorScheme.primary);Text((counts[m]?:0).toString(),fontSize=22.sp,color=MaterialTheme.colorScheme.secondary,fontWeight=FontWeight.Bold)}}}};if(meds.isEmpty())Text("أضف سجلًا جديدًا أو استورد ملف Excel من الإعدادات.",color=Color.Gray)}
 "السجلات"->{Text("السجلات والبحث",fontSize=22.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary);OutlinedTextField(query,{query=it},Modifier.fillMaxWidth(),label={Text("الاسم أو رقم الأداء أو الدواء")},singleLine=true,leadingIcon={Icon(Icons.Default.Search,null)});if(filter.isNotBlank())TextButton(onClick={filter=""}){Text("إلغاء فلتر $filter")};Text("عدد النتائج: ${results.size}",color=MaterialTheme.colorScheme.secondary);LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy((2f + spacingLevel * 0.06f).dp)){items(results){r->RecordCard(r,{edit=r;form=true},{db.delete(r.id);db.log("حذف",r.performanceNo);tick++})}};Button(onClick={edit=null;form=true},Modifier.fillMaxWidth()){Icon(Icons.Default.Add,null);Text("إضافة مستفيد")}}
 "العاملون"->{
  Row(verticalAlignment=Alignment.CenterVertically){Text("دليل العاملين بالشركة",Modifier.weight(1f),fontSize=22.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary);IconButton(onClick={page="الإعدادات"}){Icon(Icons.Default.ArrowBack,null,tint=MaterialTheme.colorScheme.primary)};IconButton(onClick={employeeEdit=null;showEmployeeForm=true}){Icon(Icons.Default.PersonAdd,null,tint=MaterialTheme.colorScheme.secondary)}}
  Text("قاعدة مستقلة لجميع العاملين، سواء كانوا يتلقون علاجاً أم لا.",color=Color.Gray,fontSize=12.sp)
  Row(horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically){Stat("إجمالي العاملين",db.employeeCount().toString(),Modifier.weight(1f));Stat("نتائج البحث",employeeResults.size.toString(),Modifier.weight(1f))}
  OutlinedTextField(employeeQuery,{employeeQuery=it},Modifier.fillMaxWidth(),label={Text("بحث برقم الأداء أو الاسم")},singleLine=true)
  Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){Button(onClick={employeeTemplate.launch("قالب_دليل_العاملين_فارغ.xlsx")},modifier=Modifier.weight(1f)){Text("قالب فارغ")};OutlinedButton(onClick={employeeImport.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))},modifier=Modifier.weight(1f)){Text("استيراد")}}
  OutlinedButton(onClick={employeeExport.launch("دليل_العاملين.xlsx")},Modifier.fillMaxWidth()){Text("تصدير الدليل الحالي")}
  LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(6.dp)){items(employeeResults){e->Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){Column(Modifier.padding(10.dp)){Row(verticalAlignment=Alignment.CenterVertically){Text(e.name,Modifier.weight(1f),fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary);IconButton(onClick={employeeEdit=e;showEmployeeForm=true}){Icon(Icons.Default.Edit,null,tint=MaterialTheme.colorScheme.secondary)}};Text("رقم الأداء: ${e.performanceNo} • ${e.job}",fontSize=12.sp,color=MaterialTheme.colorScheme.secondary);Text("${e.entity} • ${e.department}",fontSize=12.sp);Text("${e.gender} • ${e.age?.let{"العمر $it سنة"}?:"العمر غير متاح"}",fontSize=12.sp);if(e.serviceStatus.isNotBlank())Text(e.serviceStatus,color=Color(0xFF9A5A12),fontWeight=FontWeight.Bold)}}}}
 }
 "الأدوية"->{
  Row(verticalAlignment=Alignment.CenterVertically){Text("قاموس الأدوية",Modifier.weight(1f),fontSize=22.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary);IconButton(onClick={showMedicineAdd=true}){Icon(Icons.Default.AddCircle,null,tint=MaterialTheme.colorScheme.secondary)}}
  Text("الأدوية المسجلة في السجلات أو المضافة حديثًا",color=Color.Gray)
  LazyColumn{items(meds){m->
   val strengthSummary=db.strengthsForMedicine(m).joinToString("، ").ifBlank { "غير محددة" }
   ListItem(headlineContent={Text(m)},supportingContent={Text("${counts[m]?:0} مستفيد • العيارات: $strengthSummary")},leadingContent={Icon(Icons.Default.Medication,null,tint=MaterialTheme.colorScheme.secondary)},modifier=Modifier.clickable{pageBeforeRecords="الأدوية";filter=m;page="السجلات"})
  }}
 }
 "التقارير"->{
  Text("مركز تقارير الأدوية",fontSize=22.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary)
  Text("اختر دواءً واحداً أو عدة أدوية أو جميع الأدوية، ثم صدّر القائمة نفسها إلى PDF أو Excel.",fontSize=12.sp,color=Color.Gray)
  Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) { OutlinedButton(onClick={selectedReportMeds=reportMeds.toSet()}){Text("اختيار الكل")}; TextButton(onClick={selectedReportMeds=emptySet()}){Text("مسح الاختيار")} }
  Text("المحدد: ${selectedReportMeds.size} من ${reportMeds.size}",color=MaterialTheme.colorScheme.primary,fontWeight=FontWeight.Bold)
  LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy((2f + spacingLevel * 0.05f).dp)) { items(reportMeds) { medicine -> Row(Modifier.fillMaxWidth().clickable{selectedReportMeds=if(medicine in selectedReportMeds)selectedReportMeds-medicine else selectedReportMeds+medicine}.padding(vertical=(1f + spacingLevel * 0.04f).dp),verticalAlignment=Alignment.CenterVertically){Checkbox(checked=medicine in selectedReportMeds,onCheckedChange={checked->selectedReportMeds=if(checked)selectedReportMeds+medicine else selectedReportMeds-medicine});Column(Modifier.weight(1f)){Text(medicine,fontWeight=FontWeight.SemiBold);Text("${counts[medicine]?:0} سجل",fontSize=11.sp,color=Color.Gray)}} } }
  Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxWidth()) {
   Button(enabled=selectedReportMeds.isNotEmpty(),onClick={pendingReportRows=db.all().filter{it.medicine in selectedReportMeds};pendingReportTitle=if(selectedReportMeds.size==reportMeds.size)"تقرير جميع الأدوية" else "تقرير الأدوية المختارة";pdf.launch("تقرير_الأدوية_المختارة.pdf")},modifier=Modifier.weight(1f)){Icon(Icons.Default.PictureAsPdf,null);Text("تصدير PDF")}
   OutlinedButton(enabled=selectedReportMeds.isNotEmpty(),onClick={pendingReportRows=db.all().filter{it.medicine in selectedReportMeds};pendingReportTitle=if(selectedReportMeds.size==reportMeds.size)"تقرير جميع الأدوية" else "تقرير الأدوية المختارة";export.launch("تقرير_الأدوية_المختارة.xlsx")},modifier=Modifier.weight(1f)){Icon(Icons.Default.TableView,null);Text("تصدير Excel")}
  }
  if(reportMeds.isEmpty())Text("لا توجد أدوية لها سجلات حالياً.",color=Color.Gray)
 }
 "الإعدادات"->{
  Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)) {
   Text("الإعدادات العامة",fontSize=22.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary)
   Text("خصص شكل التطبيق وطريقة عرضه وحماية الدخول.",color=Color.Gray,fontSize=12.sp)
   Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)) {
    Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy((3f + spacingLevel * 0.06f).dp)) {
     Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("النمط الليلي",fontWeight=FontWeight.SemiBold);Text(if(darkTheme)"مفعّل" else "الوضع النهاري",fontSize=12.sp,color=Color.Gray)};Switch(checked=darkTheme,onCheckedChange=onDarkThemeChange)}
     Divider()
     Text("حجم الخط",fontWeight=FontWeight.SemiBold);Text("${(fontScale*100).toInt()}%",color=MaterialTheme.colorScheme.secondary)
     Text("من 40% (أصغر) إلى 140% (أكبر) — الحجم المعتاد 100%",fontSize=11.sp,color=Color.Gray)
     Slider(value=fontScale,onValueChange={fontScale=it;onFontScaleChange(it)},valueRange=0.4f..1.4f,steps=19)
     PreferenceDropdown("نوع الخط",fontChoice,fontOptions){fontChoice=it;onFontChoiceChange(it)}
     PreferenceDropdown("لون التصميم الرئيسي",paletteChoice,paletteOptions){paletteChoice=it;onPaletteChange(it)}
     PreferenceDropdown("لون خلفية التطبيق",backgroundChoiceLocal,backgroundOptions){backgroundChoiceLocal=it;onBackgroundChange(it)}
     Text("كثافة المسافات بين العناصر",fontWeight=FontWeight.SemiBold)
     Text("${spacingLevel.toInt()}% — ${if(spacingLevel<25f)"مضغوطة جداً" else if(spacingLevel<60f)"مضغوطة" else "مريحة"}",fontSize=12.sp,color=MaterialTheme.colorScheme.secondary)
     Slider(value=spacingLevel,onValueChange={spacingLevel=it;ctx.getSharedPreferences("app_preferences",0).edit().putFloat("spacing_level",it).apply()},valueRange=0f..100f,steps=9)
     Text("حرّك المؤشر إلى اليسار لتقليل الفراغات، وإلى اليمين لزيادة المسافات. أحجام أزرار اللمس لا تقل عن الحد الآمن.",fontSize=11.sp,color=Color.Gray)
     Divider();Text("الأمان",fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary)
     OutlinedButton(onClick={settingsMessage="";changePasswordDialog=true},Modifier.fillMaxWidth()){Icon(Icons.Default.Lock,null);Text("تغيير كلمة مرور المدير")}
     Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("تفعيل الدخول بالبصمة",fontWeight=FontWeight.SemiBold);Text(if(fingerprintEnabled)"مفعّل — سيظهر خيار البصمة عند فتح التطبيق" else "غير مفعّل",fontSize=11.sp,color=Color.Gray)};Switch(checked=fingerprintEnabled,onCheckedChange={enable->if(!enable){onFingerprintEnabledChange(false);settingsMessage="تم إيقاف الدخول بالبصمة"}else{promptFingerprint(ctx as FragmentActivity,"تفعيل الدخول بالبصمة",{onFingerprintEnabledChange(true);settingsMessage="تم تفعيل البصمة بنجاح"},{settingsMessage=it})}})}
     if(settingsMessage.isNotBlank())Text(settingsMessage,color=MaterialTheme.colorScheme.secondary)
    }
   }
   Text("الاستيراد والتصدير",fontSize=20.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary)
   Text("تُحفظ البيانات داخل الهاتف ولا تُرسل إلى أي خادم.",color=Color.Gray,fontSize=12.sp)
   OutlinedButton(onClick={page="العاملون"},Modifier.fillMaxWidth()){Icon(Icons.Default.Badge,null);Text("إدارة دليل العاملين")}
   Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxWidth()) {
    Button(onClick={caseTemplate.launch("نموذج_الحالات_الحرجة_فارغ.xlsx")},Modifier.weight(1f)){Icon(Icons.Default.FileDownload,null);Text("نموذج فارغ")}
    OutlinedButton(onClick={import.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))},Modifier.weight(1f)){Icon(Icons.Default.FileOpen,null);Text("استيراد النموذج")}
   }
   OutlinedButton(onClick={pendingReportRows=db.all();pendingReportTitle="تقرير كل الحالات الحرجة";export.launch("تصدير_كل_الحالات_الحرجة.xlsx")},Modifier.fillMaxWidth()){Icon(Icons.Default.FileDownload,null);Text("تصدير كل الحالات إلى Excel")}
   Button(onClick={selectedReportMeds=reportMeds.toSet();page="التقارير"},Modifier.fillMaxWidth(),enabled=reportMeds.isNotEmpty()){Icon(Icons.Default.Assessment,null);Text("فتح مركز تقارير الأدوية")}
   OutlinedButton(onClick={backupDialog="export";backupPassword=""},Modifier.fillMaxWidth()){Icon(Icons.Default.Lock,null);Text("إنشاء نسخة احتياطية مشفرة")}
   OutlinedButton(onClick={backupOpen.launch(arrayOf("application/octet-stream","application/x-tcbak","*/*"))},Modifier.fillMaxWidth()){Icon(Icons.Default.Restore,null);Text("استعادة نسخة احتياطية")}
   Divider(Modifier.padding(vertical=8.dp))
   Text("إدارة ومسح البيانات",fontSize=20.sp,fontWeight=FontWeight.Bold,color=Color(0xFFB3261E))
   Text("يمكنك مسح الحالات وحدها أو دليل العاملين وحده أو إعادة بناء قاعدة البيانات بالكامل. أنشئ نسخة احتياطية مشفرة أولاً إذا كانت البيانات مهمة.",fontSize=12.sp,color=Color.Gray)
   OutlinedButton(onClick={resetMode="cases";resetPhrase="";resetPassword=""},Modifier.fillMaxWidth()){Icon(Icons.Default.Delete,null);Text("مسح جميع سجلات الحالات فقط")}
   OutlinedButton(onClick={resetMode="employees";resetPhrase="";resetPassword=""},Modifier.fillMaxWidth()){Icon(Icons.Default.People,null);Text("مسح دليل العاملين فقط")}
   Button(onClick={resetMode="all";resetPhrase="";resetPassword=""},Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFFB3261E))){Icon(Icons.Default.Warning,null);Text("إعادة ضبط بيانات البرنامج بالكامل")}
   Divider(Modifier.padding(vertical=8.dp))
   Text("ملاحظات الأمان",fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary)
   Text("• لا توجد صلاحية إنترنت في التطبيق.\n• قاعدة البيانات مستقلة لكل هاتف.\n• استيراد الحالات يتم من نموذج Excel الصادر من التطبيق.\n• لا ترفع بيانات شخصية أو صحية إلى GitHub.\n• النسخ الاحتياطية مشفرة والاستعادة دمجية ولا تحذف البيانات الحالية.",color=Color.Gray,fontSize=12.sp)
  }
 }
 }} }
 if(form)EditDialog(edit,meds,{db.findEmployee(it)},{db.strengthsForMedicine(it)},{form=false},{r->db.save(r);db.upsertMedicine(r.medicine);if(r.strength.isNotBlank())db.addStrength(r.medicine,r.strength);db.log(if(r.id>0)"تعديل" else "إضافة",r.performanceNo);tick++;form=false})
 if(previewRows!=null){val rows=previewRows!!;val duplicates=db.duplicateCount(rows);val issues=db.caseImportIssues(rows);AlertDialog(onDismissRequest={previewRows=null},title={Text("مراجعة استيراد الحالات الحرجة")},text={Column(Modifier.heightIn(max=480.dp).verticalScroll(rememberScrollState())){Text("السجلات المقروءة: ${rows.size}");Text("سجلات مطابقة موجودة أو مكررة داخل الملف: $duplicates");Text("سجلات جديدة متوقعة: ${(rows.size-duplicates).coerceAtLeast(0)}");Text("أخطاء تمنع الاعتماد: ${issues.size}",color=if(issues.isEmpty())Teal else Color.Red);issues.take(30).forEach{Text("• $it",fontSize=12.sp,color=Color.Red)};Text("عينة من البيانات:",fontWeight=FontWeight.Bold);rows.take(5).forEach{Text("• ${it.name} | ${it.performanceNo} | ${it.medicine} | ${it.strength}",fontSize=12.sp)};Text("لن يتم اعتماد أي سجل إذا كانت هناك أخطاء إلزامية. السجلات المتطابقة بالكامل فقط ستُتجاوز؛ ويمكن للعامل نفسه الحصول على أكثر من علاج أو سجل مختلف.",fontSize=11.sp,color=Color.Gray)}},confirmButton={Button(enabled=issues.isEmpty(),onClick={try{val(a,d)=db.importRows(rows);msg="تمت إضافة $a سجل وتجاوز $d سجلاً مطابقاً بالكامل";previewRows=null;tick++}catch(e:Exception){msg="لم يتم اعتماد الاستيراد: ${e.message}"}}){Text("اعتماد الاستيراد")}},dismissButton={TextButton(onClick={previewRows=null}){Text("إلغاء")}})}
 if(showEmployeeForm)EmployeeEditDialog(employeeEdit,{showEmployeeForm=false},{r->try{db.saveEmployee(r);db.log("حفظ دليل عامل",r.performanceNo);msg="تم حفظ بيانات العامل";tick++;showEmployeeForm=false}catch(e:Exception){msg="تعذر حفظ العامل: ${e.message}"}})
 if(employeePlan!=null){val plan=employeePlan!!;AlertDialog(onDismissRequest={employeePlan=null},title={Text("تقرير مراجعة دليل العاملين")},text={Column(Modifier.heightIn(max=480.dp).verticalScroll(rememberScrollState())){Text("موظفون جدد: ${plan.inserts.size}",color=MaterialTheme.colorScheme.secondary);Text("بيانات سيتم تحديثها: ${plan.updates.size}",color=MaterialTheme.colorScheme.secondary);Text("دون تغيير: ${plan.unchanged}");Text("أخطاء تمنع الاعتماد: ${plan.issues.size}",color=if(plan.issues.isEmpty())Teal else Color.Red);plan.issues.take(30).forEach{Text("صف ${it.row} • ${it.performanceNo}: ${it.message}",fontSize=12.sp,color=Color.Red)};plan.changes.take(20).forEach{change->Text("${change.performanceNo} • ${change.name}",fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary,fontSize=12.sp);change.fields.forEach{field->Text("${field.field}: ${field.oldValue.ifBlank{"(فارغ)"}} ← ${field.newValue}",fontSize=11.sp)}};if(plan.issues.isEmpty())Text("لن تُمسح البيانات القديمة عند ترك خلية فارغة. ستتم العملية داخل معاملة واحدة، إما تكتمل كلها أو لا يُعتمد أي تغيير.",fontSize=12.sp)}} ,confirmButton={Button(enabled=plan.canCommit,onClick={try{val(a,u)=db.commitEmployeeImport(plan);msg="تم تحديث دليل العاملين: إضافة $a وتحديث $u";employeePlan=null;tick++}catch(e:Exception){msg="لم يتم اعتماد الاستيراد: ${e.message}"}}){Text("اعتماد التحديث")}},dismissButton={TextButton(onClick={employeePlan=null}){Text("إلغاء")}})}
 if(reportDialog)AlertDialog(onDismissRequest={reportDialog=false},title={Text("اختيار الأدوية للتقرير")},text={Column(Modifier.heightIn(max=520.dp)) {Text("حدد دواءً واحداً أو عدة أدوية، أو اترك الكل محدداً لإصدار تقرير شامل.",fontSize=12.sp,color=Color.Gray);Row(verticalAlignment=Alignment.CenterVertically){TextButton(onClick={selectedReportMeds=reportMeds.toSet()}){Text("تحديد الكل")};TextButton(onClick={selectedReportMeds=emptySet()}){Text("إلغاء التحديد")};Spacer(Modifier.weight(1f));Text("${selectedReportMeds.size}/${reportMeds.size}",color=MaterialTheme.colorScheme.secondary,fontWeight=FontWeight.Bold)};Column(Modifier.weight(1f,false).verticalScroll(rememberScrollState())){reportMeds.forEach{medicine->Row(Modifier.fillMaxWidth().clickable{selectedReportMeds=if(medicine in selectedReportMeds)selectedReportMeds-medicine else selectedReportMeds+medicine}.padding(vertical=3.dp),verticalAlignment=Alignment.CenterVertically){Checkbox(checked=medicine in selectedReportMeds,onCheckedChange={checked->selectedReportMeds=if(checked)selectedReportMeds+medicine else selectedReportMeds-medicine});Text("$medicine  •  ${counts[medicine]?:0} سجل",Modifier.weight(1f))}}}}},confirmButton={Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){Button(enabled=selectedReportMeds.isNotEmpty(),onClick={pendingReportRows=db.all().filter{it.medicine in selectedReportMeds};pendingReportTitle=if(selectedReportMeds.size==reportMeds.size)"تقرير جميع الأدوية" else "تقرير الأدوية المختارة";reportDialog=false;pdf.launch("تقرير_الأدوية_المختارة.pdf")}){Text("PDF")};Button(enabled=selectedReportMeds.isNotEmpty(),onClick={pendingReportRows=db.all().filter{it.medicine in selectedReportMeds};pendingReportTitle=if(selectedReportMeds.size==reportMeds.size)"تقرير جميع الأدوية" else "تقرير الأدوية المختارة";reportDialog=false;export.launch("تقرير_الأدوية_المختارة.xlsx")}){Text("Excel")}}},dismissButton={TextButton(onClick={reportDialog=false}){Text("إلغاء")}})
 if(backupDialog.isNotBlank())AlertDialog(onDismissRequest={backupDialog="";backupPassword="";restoreBytes=null},title={Text(if(backupDialog=="export")"حماية النسخة الاحتياطية" else "كلمة مرور الاستعادة")},text={Column{Text("${if(backupDialog=="export")"أنشئ كلمة مرور لحماية ملف النسخة. استخدم 8 أحرف أو أرقام على الأقل." else "أدخل كلمة المرور التي استُخدمت عند إنشاء النسخة."}");OutlinedTextField(backupPassword,{backupPassword=it},label={Text("كلمة مرور النسخة")},singleLine=true,visualTransformation=PasswordVisualTransformation())}},confirmButton={Button(onClick={try{if(backupDialog=="export"){exportBackupBytes=EncryptedBackup.encodeFull(db.all(),db.employees(),db.medicineCatalog(),db.medicineStrengths(),backupPassword);backupDialog="";backupSave.launch("نسخة_علاج_الحالات_المشفرة.tcbak")}else{restorePreview=EncryptedBackup.decodeFull(restoreBytes?:byteArrayOf(),backupPassword);backupDialog="";restoreBytes=null};backupPassword=""}catch(e:Exception){msg="تعذر تنفيذ العملية: ${e.message ?: "تحقق من كلمة المرور"}"}}){Text("متابعة")}},dismissButton={TextButton(onClick={backupDialog="";backupPassword="";restoreBytes=null}){Text("إلغاء")}})
 if(restorePreview!=null){val bundle=restorePreview!!;val caseIssues=CaseDataRules.validate(bundle.cases);val employeeIssues=db.planEmployeeImport(bundle.employees).issues;AlertDialog(onDismissRequest={restorePreview=null},title={Text("معاينة النسخة قبل الاستعادة")},text={Column(Modifier.heightIn(max=460.dp).verticalScroll(rememberScrollState())){Text("الحالات العلاجية: ${bundle.cases.size}",color=MaterialTheme.colorScheme.primary);Text("العاملون: ${bundle.employees.size}",color=MaterialTheme.colorScheme.primary);Text("الأدوية في القاموس: ${bundle.medicineDetails.size.coerceAtLeast(bundle.medicines.size)}",color=MaterialTheme.colorScheme.primary);Text("العيارات: ${bundle.strengths.size}",color=MaterialTheme.colorScheme.primary);Text("مشكلات بيانات الحالات: ${caseIssues.size}",color=if(caseIssues.isEmpty())Teal else Color.Red);Text("مشكلات بيانات العاملين: ${employeeIssues.size}",color=if(employeeIssues.isEmpty())Teal else Color.Red);(caseIssues+employeeIssues.take(10).map{"بيانات عامل: ${it.message}"}).take(15).forEach{Text("• $it",fontSize=12.sp,color=Color.Red)};Text("الاستعادة ستدمج البيانات ولن تحذف السجلات الحالية. كلمة مرور المدير وصلاحيات هذا الهاتف لن تنتقل من النسخة.",fontSize=12.sp,color=Color.Gray)}},confirmButton={Button(enabled=caseIssues.isEmpty()&&employeeIssues.isEmpty(),onClick={try{val(casesAdded,employeesAdded,employeesUpdated)=db.restoreBundle(bundle);msg="تمت الاستعادة الدمجية: حالات جديدة $casesAdded، عاملون جدد $employeesAdded، تحديث عاملين $employeesUpdated. تم دمج قاموس الأدوية والعيارات دون حذف البيانات الحالية.";tick++;restorePreview=null}catch(e:Exception){msg="لم تتم الاستعادة: ${e.message}"}}){Text("اعتماد الاستعادة")}},dismissButton={TextButton(onClick={restorePreview=null}){Text("إلغاء")}})}
 if(resetMode.isNotBlank()){
  val requiredPhrase=when(resetMode){"cases"->"مسح الحالات";"employees"->"مسح العاملين";else->"إعادة ضبط"}
  val resetTitle=when(resetMode){"cases"->"تأكيد مسح سجلات الحالات";"employees"->"تأكيد مسح دليل العاملين";else->"تأكيد إعادة ضبط بيانات البرنامج"}
  AlertDialog(onDismissRequest={resetMode="";resetPhrase="";resetPassword=""},title={Text(resetTitle)},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
   Text(when(resetMode){"cases"->"سيتم حذف جميع سجلات الحالات العلاجية فقط. سيظل دليل العاملين وقاموس الأدوية كما هما.";"employees"->"سيتم حذف جميع العاملين فقط. ستظل سجلات الحالات العلاجية كما هي.";else->"سيتم حذف جميع الحالات والعاملين والأدوية والعيارات وسجل التدقيق، ثم إعادة تحميل قاموس الأدوية الأساسي. ستظل كلمة مرور المدير وإعدادات العرض محفوظة."},color=Color(0xFFB3261E))
   Text("هذه العملية لا يمكن التراجع عنها. يفضّل إنشاء نسخة احتياطية مشفرة أولاً.",fontSize=12.sp,color=Color.Gray)
   OutlinedTextField(resetPhrase,{resetPhrase=it},Modifier.fillMaxWidth(),label={Text("اكتب للتأكيد: $requiredPhrase")},singleLine=true)
   OutlinedTextField(resetPassword,{resetPassword=it},Modifier.fillMaxWidth(),label={Text("كلمة مرور المدير الحالية")},singleLine=true,visualTransformation=PasswordVisualTransformation())
  }},confirmButton={Button(enabled=resetPhrase.trim()==requiredPhrase&&resetPassword.isNotBlank(),onClick={
   if(!auth.verify(resetPassword)){settingsMessage="كلمة مرور المدير غير صحيحة";msg=settingsMessage}
   else try{when(resetMode){"cases"->db.clearCases();"employees"->db.clearEmployees();else->db.factoryResetData()};tick++;msg=when(resetMode){"cases"->"تم مسح سجلات الحالات فقط";"employees"->"تم مسح دليل العاملين فقط";else->"تمت إعادة ضبط بيانات البرنامج وإعادة تحميل قاموس الأدوية الأساسي. كلمة مرور المدير وإعدادات العرض محفوظة."};resetMode="";resetPhrase="";resetPassword=""}catch(e:Exception){msg="تعذر تنفيذ المسح: ${e.message}"}
  }){Text("تنفيذ المسح")}},dismissButton={TextButton(onClick={resetMode="";resetPhrase="";resetPassword=""}){Text("إلغاء")}})
 }
 if(changePasswordDialog)AlertDialog(onDismissRequest={changePasswordDialog=false;currentPassword="";newPassword="";confirmPassword=""},title={Text("تغيير كلمة مرور المدير")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(currentPassword,{currentPassword=it},label={Text("كلمة المرور الحالية")},singleLine=true,visualTransformation=PasswordVisualTransformation());OutlinedTextField(newPassword,{newPassword=it},label={Text("كلمة المرور الجديدة")},singleLine=true,visualTransformation=PasswordVisualTransformation());OutlinedTextField(confirmPassword,{confirmPassword=it},label={Text("تأكيد كلمة المرور الجديدة")},singleLine=true,visualTransformation=PasswordVisualTransformation());Text("يجب ألا تقل كلمة المرور الجديدة عن 8 أحرف أو أرقام.",fontSize=11.sp,color=Color.Gray);if(settingsMessage.isNotBlank())Text(settingsMessage,color=Color.Red,fontSize=12.sp)}},confirmButton={Button(onClick={if(!auth.verify(currentPassword))settingsMessage="كلمة المرور الحالية غير صحيحة" else if(newPassword.length<8)settingsMessage="كلمة المرور الجديدة قصيرة" else if(newPassword!=confirmPassword)settingsMessage="تأكيد كلمة المرور غير مطابق" else if(auth.createAdmin(newPassword)){settingsMessage="تم تغيير كلمة المرور بنجاح";changePasswordDialog=false;currentPassword="";newPassword="";confirmPassword=""}else settingsMessage="تعذر تغيير كلمة المرور"}){Text("حفظ التغيير")}},dismissButton={TextButton(onClick={changePasswordDialog=false}){Text("إلغاء")}})
 if(showMedicineAdd)AlertDialog(onDismissRequest={showMedicineAdd=false},title={Text("إضافة دواء للقاموس")},text={Column{OutlinedTextField(newMedicine,{newMedicine=it},label={Text("اسم الدواء")});OutlinedTextField(newStrengths,{newStrengths=it},label={Text("التركيزات المتاحة")})}},confirmButton={Button(onClick={if(db.addMedicine(newMedicine,strengths=newStrengths)){msg="تمت إضافة الدواء إلى القاموس";tick++;newMedicine="";newStrengths="";showMedicineAdd=false}else msg="الاسم فارغ أو الدواء موجود بالفعل"}){Text("حفظ")}},dismissButton={TextButton(onClick={showMedicineAdd=false}){Text("إلغاء")}})
}
@Composable fun EmployeeEditDialog(old:EmployeeRecord?,close:()->Unit,save:(EmployeeRecord)->Unit){
 val fields=listOf("رقم الأداء","الاسم","الوظيفة","الجهة","الإدارة","رقم البطاقة","رقم التليفون","رقم التليفون الثاني","النوع","ملاحظات")
 val values= remember(old){mutableStateListOf(*(old?.cells()?.toTypedArray()?:Array(10){""}))}
 AlertDialog(onDismissRequest=close,title={Text(if(old==null)"إضافة عامل إلى الدليل" else "تعديل بيانات العامل")},text={Column(Modifier.heightIn(max=520.dp).verticalScroll(rememberScrollState())){fields.forEachIndexed{i,label->OutlinedTextField(values[i],{values[i]=it},Modifier.fillMaxWidth().padding(vertical=2.dp),label={Text(label)},singleLine=i!=9,enabled=(i!=0||old==null))};Text("رقم الأداء فريد ولا يقبل التكرار. رقم البطاقة إن أدخلته يجب أن يكون صحيحاً.",fontSize=11.sp,color=Color.Gray)}},confirmButton={Button(enabled=values[0].isNotBlank()&&values[1].isNotBlank(),onClick={save(EmployeeRecord(performanceNo=values[0].trim(),name=values[1],job=values[2],entity=values[3],department=values[4],nationalId=values[5],phone1=values[6],phone2=values[7],gender=values[8],notes=values[9]))}){Text("حفظ")}},dismissButton={TextButton(onClick=close){Text("إلغاء")}})
}
@Composable fun Stat(label:String,value:String,mod:Modifier){Card(mod,colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),shape=RoundedCornerShape(15.dp)){Column(Modifier.padding(15.dp)){Text(label,color=Color.Gray,fontSize=12.sp);Text(value,color=MaterialTheme.colorScheme.secondary,fontSize=27.sp,fontWeight=FontWeight.Bold)}}}
@Composable fun RecordCard(r:CaseRecord,edit:()->Unit,delete:()->Unit){var ask by remember{mutableStateOf(false)};Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){Column(Modifier.padding(11.dp)){Row(verticalAlignment=Alignment.CenterVertically){Text(r.name,Modifier.weight(1f),fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary);IconButton(onClick=edit){Icon(Icons.Default.Edit,null,tint=MaterialTheme.colorScheme.secondary)};IconButton(onClick={ask=true}){Icon(Icons.Default.Delete,null,tint=Color.Red)}};Text("رقم الأداء: ${r.performanceNo} • ${r.medicine}",color=MaterialTheme.colorScheme.secondary);Text("${r.strength} | الموافقة: ${r.approvalDate}",fontSize=12.sp,color=Color.Gray);if(r.condition.isNotBlank())Text(r.condition,fontSize=12.sp)}};if(ask)AlertDialog(onDismissRequest={ask=false},title={Text("حذف السجل؟")},confirmButton={TextButton(onClick={delete;ask=false}){Text("حذف")}},dismissButton={TextButton(onClick={ask=false}){Text("إلغاء")}})}
@Composable
fun EditDialog(
    old: CaseRecord?,
    meds: List<String>,
    lookup: (String) -> EmployeeRecord?,
    strengthOptions: (String) -> List<String>,
    close: () -> Unit,
    save: (CaseRecord) -> Unit
) {
    val labels = listOf("المنطقة", "القطاع", "الاسم", "رقم الأداء", "اسم الدواء", "التركيز/العيار", "بيان إضافي 1", "بيان إضافي 2", "مدة الصرف", "الجرعة", "الحالة المرضية", "تاريخ الموافقة", "انتهاء الموافقة")
    val values = remember(old) { mutableStateListOf(*(old?.cells()?.toTypedArray() ?: Array(13) { "" })) }
    var formError by remember(old) { mutableStateOf("") }
    var medicineMenu by remember { mutableStateOf(false) }
    var strengthMenu by remember { mutableStateOf(false) }
    val options = strengthOptions(values[4])

    AlertDialog(
        onDismissRequest = close,
        title = { Text(if (old == null) "إضافة مستفيد" else "تعديل مستفيد") },
        text = {
            Column(Modifier.heightIn(max = 530.dp).verticalScroll(rememberScrollState())) {
                labels.forEachIndexed { index, label ->
                    when (index) {
                        4 -> Box {
                            OutlinedTextField(
                                values[index], {}, Modifier.fillMaxWidth().padding(vertical = 2.dp),
                                label = { Text(label) }, readOnly = true,
                                trailingIcon = { IconButton(onClick = { medicineMenu = true }) { Icon(Icons.Default.ArrowDropDown, null) } }
                            )
                            DropdownMenu(expanded = medicineMenu, onDismissRequest = { medicineMenu = false }) {
                                meds.forEach { medicine ->
                                    DropdownMenuItem(text = { Text(medicine) }, onClick = {
                                        values[4] = medicine
                                        values[5] = ""
                                        medicineMenu = false
                                    })
                                }
                            }
                        }
                        5 -> if (options.isNotEmpty()) Box {
                            OutlinedTextField(
                                values[index], { values[index] = it }, Modifier.fillMaxWidth().padding(vertical = 2.dp),
                                label = { Text(label) },
                                trailingIcon = { IconButton(onClick = { strengthMenu = true }) { Icon(Icons.Default.ArrowDropDown, null) } }
                            )
                            DropdownMenu(expanded = strengthMenu, onDismissRequest = { strengthMenu = false }) {
                                options.forEach { strength ->
                                    DropdownMenuItem(text = { Text(strength) }, onClick = {
                                        values[5] = strength
                                        strengthMenu = false
                                    })
                                }
                            }
                        } else {
                            OutlinedTextField(values[index], { values[index] = it }, Modifier.fillMaxWidth().padding(vertical = 2.dp), label = { Text(label) })
                        }
                        else -> OutlinedTextField(
                            values[index], { values[index] = it }, Modifier.fillMaxWidth().padding(vertical = 2.dp),
                            label = { Text(label) }, singleLine = index != 10
                        )
                    }
                    if (index == 3 && values[index].isNotBlank()) {
                        val employee = lookup(values[index].trim())
                        if (employee != null) {
                            values[2] = employee.name
                            Text("تم العثور على العامل: ${employee.name} • ${employee.job} • ${employee.entity} / ${employee.department}", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                        } else {
                            Text("رقم الأداء غير موجود في دليل العاملين", fontSize = 11.sp, color = Color(0xFF9A5A12))
                        }
                    }
                }
                if (formError.isNotBlank()) Text(formError, color = Color.Red, fontSize = 12.sp)
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val record = CaseDataRules.normalizeForImport(CaseRecord.from(values.toList()).copy(id = old?.id ?: 0))
                    val issues = CaseDataRules.validate(listOf(record))
                    if (issues.isNotEmpty()) formError = issues.joinToString("\n")
                    else { formError = ""; save(record) }
                },
                enabled = values[2].isNotBlank() && values[3].isNotBlank() && values[4].isNotBlank()
            ) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = close) { Text("إلغاء") } }
    )
}

fun pdfReport(activity:Activity,uri:Uri,rows:List<CaseRecord>,reportTitle:String="تقرير السجلات"){
 val doc=PdfDocument();val width=595;val height=842;val margin=30f;val body=TextPaint(Paint.ANTI_ALIAS_FLAG).apply{textSize=10f;color=android.graphics.Color.DKGRAY};val header=TextPaint(Paint.ANTI_ALIAS_FLAG).apply{textSize=16f;color=android.graphics.Color.rgb(7,89,199);isFakeBoldText=true;textAlign=Paint.Align.RIGHT};var pageNo=1;var page=doc.startPage(PdfDocument.PageInfo.Builder(width,height,pageNo).create());var canvas=page.canvas;var y=42f
 fun heading(){canvas.drawText("علاج الحالات حاجة - $reportTitle • عدد السجلات: ${rows.size}",width-margin,y,header);y+=28;canvas.drawLine(margin,y,width-margin,y,Paint().apply{color=android.graphics.Color.LTGRAY;strokeWidth=1f});y+=16}
 fun newPage(){doc.finishPage(page);pageNo++;page=doc.startPage(PdfDocument.PageInfo.Builder(width,height,pageNo).create());canvas=page.canvas;y=42f;heading()}
 heading()
 rows.forEachIndexed{index,r->
  val line="${index+1}) الاسم: ${r.name}   |   رقم الأداء: ${r.performanceNo}\nالدواء: ${r.medicine}   |   التركيز/العيار: ${r.strength}\nالمنطقة: ${r.region}   |   القطاع: ${r.sector}\nمدة الصرف: ${r.duration}   |   الجرعة: ${r.dosage}\nالحالة المرضية: ${r.condition}\nتاريخ الموافقة: ${r.approvalDate}   |   الانتهاء: ${r.approvalExpiry}\n${listOf(r.extra1,r.extra2).filter{it.isNotBlank()}.joinToString("   |   ")}"
  val layout=StaticLayout.Builder.obtain(line,0,line.length,body,(width-(margin*2)).toInt()).setAlignment(Layout.Alignment.ALIGN_OPPOSITE).setTextDirection(TextDirectionHeuristics.RTL).setIncludePad(false).setLineSpacing(2f,1f).build()
  if(y+layout.height>height-35)newPage()
  canvas.save();canvas.translate(margin,y);layout.draw(canvas);canvas.restore();y+=layout.height+10
  canvas.drawLine(margin,y,width-margin,y,Paint().apply{color=android.graphics.Color.LTGRAY;strokeWidth=0.5f});y+=8
 }
 doc.finishPage(page);activity.contentResolver.openOutputStream(uri)?.use{doc.writeTo(it)}?:error("تعذر حفظ تقرير PDF");doc.close()
}
