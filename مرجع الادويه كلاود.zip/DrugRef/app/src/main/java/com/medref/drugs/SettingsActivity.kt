package com.medref.drugs

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.InputFilter
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.google.android.material.card.MaterialCardView
import com.google.android.material.color.DynamicColors
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import java.io.File

class SettingsActivity : BaseActivity() {

    private lateinit var root: LinearLayout
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "الإعدادات"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(6), dp(14), dp(28))
        }
        setContentView(ScrollView(this).apply { addView(root) })
        render()
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    /** أي تغيير في المظهر: نسجّل الختم ونعيد بناء هذه الشاشة، والبقية تُعاد عند الرجوع إليها. */
    private fun appearanceChanged() {
        Prefs.touch()
        recreate()
    }

    // ---------- أدوات بناء الواجهة ----------
    private fun section(title: String): LinearLayout {
        root.addView(TextView(this).apply {
            text = title
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Ui.primary(this@SettingsActivity))
            setPadding(dp(4), dp(16), dp(4), dp(6))
        })
        val card = MaterialCardView(this).apply { layoutParams = LinearLayout.LayoutParams(MATCH, WRAP) }
        Ui.styleCard(card)
        val inner = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        card.addView(inner)
        root.addView(card)
        return inner
    }

    private fun selectableBg(): Int {
        val tv = TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
        return tv.resourceId
    }

    private fun row(parent: LinearLayout, title: String, sub: String?, trailing: View? = null, onClick: (() -> Unit)? = null) {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        val tx = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
        }
        tx.addView(TextView(this).apply { text = title; textSize = 15f })
        if (!sub.isNullOrBlank()) {
            tx.addView(TextView(this).apply { text = sub; textSize = 12f; alpha = 0.7f })
        }
        r.addView(tx)
        if (trailing != null) r.addView(trailing)
        if (onClick != null) {
            r.isClickable = true
            r.setBackgroundResource(selectableBg())
            r.setOnClickListener { onClick() }
        }
        parent.addView(r)
    }

    private fun switchRow(parent: LinearLayout, title: String, sub: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
        val sw = MaterialSwitch(this).apply { isChecked = checked }
        sw.setOnCheckedChangeListener { _, v -> onChange(v) }
        row(parent, title, sub, sw) { sw.toggle() }
    }

    private fun choiceRow(
        parent: LinearLayout, title: String, options: List<Pair<String, String>>,
        current: String, onPick: (String) -> Unit
    ) {
        val label = options.firstOrNull { it.first == current }?.second ?: ""
        row(parent, title, label) {
            val idx = options.indexOfFirst { it.first == current }
            MaterialAlertDialogBuilder(this)
                .setTitle(title)
                .setSingleChoiceItems(options.map { it.second }.toTypedArray(), idx) { d, which ->
                    d.dismiss()
                    onPick(options[which].first)
                }
                .setNegativeButton("إلغاء", null)
                .showStyled()
        }
    }

    // ---------- الشاشة ----------
    private fun render() {
        root.removeAllViews()

        // ===== المظهر =====
        val ap = section("المظهر")
        choiceRow(ap, "الوضع", listOf("system" to "حسب النظام", "light" to "نهاري", "dark" to "ليلي"), Prefs.themeMode) {
            Prefs.themeMode = it
            Prefs.touch()
            androidx.appcompat.app.AppCompatDelegate.setDefaultNightMode(Prefs.nightMode())
        }
        val accLabel = if (Prefs.accent == "dynamic") "ألوان النظام" else
            (Ui.accents.firstOrNull { it.id == Prefs.accent }?.label ?: "")
        row(ap, "لون التطبيق", accLabel, colorDot()) { pickAccent() }
        choiceRow(
            ap, "خلفية التطبيق",
            listOf(
                "default" to "افتراضية", "white" to "ناصعة (أبيض / أسود)", "cream" to "كريمية",
                "gray" to "رمادية", "blue" to "زرقاء هادئة", "green" to "خضراء هادئة",
                "image" to "صورة من المعرض…"
            ),
            Prefs.background
        ) {
            if (it == "image") openImagePicker() else { Prefs.background = it; appearanceChanged() }
        }
        if (Prefs.background == "image") {
            choiceRow(
                ap, "تعتيم طبقة الصورة",
                listOf("0" to "بلا", "20" to "خفيف 20%", "35" to "متوسط 35%", "50" to "50%", "65" to "قوي 65%", "80" to "80%"),
                Prefs.bgDim.toString()
            ) { Prefs.bgDim = it.toInt(); appearanceChanged() }
            row(ap, "إزالة صورة الخلفية", null) {
                File(filesDir, "bg.jpg").delete()
                Prefs.background = "default"
                appearanceChanged()
            }
        }
        choiceRow(ap, "الخط", Ui.fontChoices(this), Prefs.font) { Prefs.font = it; appearanceChanged() }
        choiceRow(
            ap, "حجم النص",
            listOf("85" to "صغير", "100" to "عادي", "115" to "كبير", "130" to "أكبر", "150" to "ضخم"),
            Prefs.textScale.toString()
        ) { Prefs.textScale = it.toInt(); appearanceChanged() }
        choiceRow(
            ap, "نمط البطاقات",
            listOf("outlined" to "بإطار", "elevated" to "بظل", "flat" to "مسطّح"),
            Prefs.cardStyle
        ) { Prefs.cardStyle = it; appearanceChanged() }
        choiceRow(
            ap, "استدارة الزوايا",
            listOf("2" to "حادة", "12" to "متوسطة", "20" to "مستديرة", "28" to "كبسولة"),
            Prefs.cardRadius.toString()
        ) { Prefs.cardRadius = it.toInt(); appearanceChanged() }

        // ===== القائمة =====
        val ls = section("القائمة")
        choiceRow(
            ls, "ترتيب الاسمين",
            listOf("en" to "الأجنبي (مع الكود) أولًا", "ar" to "العربي أولًا"),
            Prefs.nameOrder
        ) { Prefs.nameOrder = it; Prefs.touch(); render(); finishUi() }
        row(ls, "الكود ملتصق بالاسم الأجنبي دائمًا", "يظهر الكود قبل الاسم الأجنبي مباشرة في كل مكان ولا يُفصل عنه.")
        switchRow(ls, "عرض مضغوط", "إخفاء سطر الحالة والتفاصيل تحت الاسم", Prefs.compact) { Prefs.compact = it; Prefs.touch() }
        choiceRow(
            ls, "الشاشة الافتتاحية",
            Scope.values().map { it.name to it.label },
            Prefs.startScope
        ) { Prefs.startScope = it; Prefs.touch(); render(); finishUi() }
        switchRow(ls, "اهتزاز عند التحديد", null, Prefs.haptic) { Prefs.haptic = it }

        // ===== الأمان =====
        val sc = section("الأمان")
        switchRow(sc, "قفل التطبيق برمز", "رمز من 4 إلى 8 أرقام", Lock.enabled()) { on ->
            if (on) setNewPin { render(); finishUi() }
            else verifyPin(onFail = { render(); finishUi() }) { Lock.clear(); render(); finishUi() }
        }
        if (Lock.enabled()) {
            row(sc, "تغيير الرمز", null) { verifyPin { setNewPin { render(); finishUi() } } }
            if (Lock.biometricAvailable(this)) {
                switchRow(sc, "الدخول بالبصمة / الوجه", "يبقى الرمز بديلًا دائمًا", Prefs.biometric) { Prefs.biometric = it }
            } else {
                row(sc, "الدخول بالبصمة / الوجه", "غير متاح: لم تُسجَّل بصمة على هذا الجهاز")
            }
            choiceRow(
                sc, "القفل التلقائي",
                listOf("0" to "فورًا عند الخروج", "30" to "بعد 30 ثانية", "60" to "بعد دقيقة", "300" to "بعد 5 دقائق", "900" to "بعد 15 دقيقة"),
                Prefs.lockTimeout.toString()
            ) { Prefs.lockTimeout = it.toInt(); render(); finishUi() }
        }
        switchRow(sc, "منع لقطات الشاشة", "يخفي التطبيق من لقطات الشاشة وقائمة التطبيقات الأخيرة", Prefs.secure) {
            Prefs.secure = it
            Prefs.touch()
            recreate()
        }

        // ===== البيانات =====
        val dt = section("البيانات")
        row(dt, "تصدير واستيراد", "CSV قابل للتعديل، ونسخة احتياطية كاملة") { DataTools.showMenu(this) }
        row(dt, "اعتماد كل الأسماء العربية المقترحة", "الأسماء التي أُضيفت آليًا تصبح «معتمدة»") { confirmApproveAll("names", "الأسماء العربية") }
        row(dt, "اعتماد كل التصنيفات العلاجية المقترحة", "التي جاءت من المادة الفعّالة أو أشقاء العائلة") { confirmApproveAll("class", "التصنيفات") }
        row(dt, "اعتماد كل الأجهزة المقترحة", "التي نُقلت بالبحث الشامل إلى قسم الأجهزة") { confirmApproveAll("device", "الأجهزة") }
        row(dt, "مراجعة موجّهة (الصنف التالي)", "تمرّ بالمقترحات واحدًا واحدًا") { Review.pick(this) }
        row(dt, "قواعد التصنيف (كلمة ← تصنيف)", "تضيف قواعدك وتطبّقها على غير المصنّف كاقتراحات") { showRules() }
        switchRow(dt, "نسخ احتياطي تلقائي أسبوعي", "يحتفظ بآخر 3 نسخ داخل التطبيق", Prefs.autoBackup) { Prefs.autoBackup = it }
        row(dt, "إرسال آخر نسخة تلقائية", "للحفظ خارج الهاتف") {
            val f = Backup.latest(this)
            if (f == null) toast("لا توجد نسخة تلقائية بعد") else Share.file(this, f, "application/octet-stream", "نسخة احتياطية")
        }
        row(dt, "استعادة البيانات الأصلية", "يمسح كل تعديلاتك على هذا الجهاز") { confirmReset() }

        // ===== عام =====
        val gn = section("عام")
        row(gn, "إعادة ضبط المظهر", "الألوان والخط والخلفية والقائمة") {
            MaterialAlertDialogBuilder(this)
                .setTitle("إعادة ضبط المظهر؟")
                .setPositiveButton("نعم") { _, _ -> Prefs.resetAppearance(); recreate() }
                .setNegativeButton("إلغاء", null)
                .showStyled()
        }
        row(gn, "عن التطبيق", "مرجع الأدوية — الإصدار 1.3.0 • يعمل بلا إنترنت وبياناته على جهازك فقط")

        finishUi()
    }

    private fun colorDot(): View {
        val night = Ui.isNight(this)
        val col = if (Prefs.accent == "dynamic") Ui.primary(this) else
            Ui.accents.firstOrNull { it.id == Prefs.accent }?.let { if (night) it.dark else it.light } ?: Ui.primary(this)
        return View(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(24), dp(24))
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(col) }
        }
    }

    // ---------- اللون ----------
    private fun pickAccent() {
        val night = Ui.isNight(this)
        val grid = GridLayout(this).apply {
            columnCount = 4
            setPadding(dp(12), dp(12), dp(12), dp(4))
        }
        var dialog: AlertDialog? = null
        val list = ArrayList(Ui.accents.map { Triple(it.id, it.label, if (night) it.dark else it.light) })
        if (DynamicColors.isDynamicColorAvailable()) list.add(Triple("dynamic", "ألوان النظام", 0xFF888888.toInt()))
        for ((id, label, color) in list) {
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(6), dp(6), dp(6), dp(6))
            }
            cell.addView(TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
                gravity = Gravity.CENTER
                text = if (Prefs.accent == id) "✔" else ""
                setTextColor(Color.WHITE)
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }
            })
            cell.addView(TextView(this).apply { text = label; textSize = 11f; gravity = Gravity.CENTER })
            cell.setOnClickListener {
                Prefs.accent = id
                dialog?.dismiss()
                appearanceChanged()
            }
            grid.addView(cell)
        }
        dialog = MaterialAlertDialogBuilder(this)
            .setTitle("لون التطبيق")
            .setView(grid)
            .setNegativeButton("إلغاء", null)
            .showStyled()
    }

    // ---------- صورة الخلفية ----------
    override fun onImagePicked(uri: Uri) {
        Thread {
            try {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 1600) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                if (bmp == null) {
                    runOnUiThread { toast("تعذر قراءة الصورة") }
                } else {
                    File(filesDir, "bg.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
                    runOnUiThread { Prefs.background = "image"; appearanceChanged() }
                }
            } catch (e: Exception) {
                runOnUiThread { toast("تعذر حفظ الصورة") }
            }
        }.start()
    }

    // ---------- الرمز ----------
    private fun pinField(hint: String) = EditText(this).apply {
        this.hint = hint
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        filters = arrayOf(InputFilter.LengthFilter(8))
        gravity = Gravity.CENTER
        textDirection = View.TEXT_DIRECTION_LTR
    }

    private fun setNewPin(onDone: () -> Unit) {
        val a = pinField("رمز جديد (4–8 أرقام)")
        val b = pinField("أعد كتابة الرمز")
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(8), dp(24), 0)
            addView(a)
            addView(b)
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("تعيين رمز الدخول")
            .setMessage("إن نسيت الرمز فلا استرجاع له إلا بمسح بيانات التطبيق (وتضيع تعديلاتك). صدّر نسخة احتياطية أولًا.")
            .setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                val p = a.text.toString()
                if (p.length < 4 || p != b.text.toString()) {
                    toast("الرمز قصير أو غير متطابق")
                    onDone()
                } else {
                    Lock.setPin(p)
                    Prefs.lockEnabled = true
                    Lock.unlock()
                    onDone()
                }
            }
            .setNegativeButton("إلغاء") { _, _ -> onDone() }
            .showStyled()
    }

    private fun verifyPin(onFail: () -> Unit = {}, onOk: () -> Unit) {
        val a = pinField("الرمز الحالي")
        val box = LinearLayout(this).apply {
            setPadding(dp(24), dp(8), dp(24), 0)
            addView(a, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("أدخل الرمز الحالي")
            .setView(box)
            .setPositiveButton("تأكيد") { _, _ ->
                if (Lock.verify(a.text.toString())) onOk() else { toast("رمز خاطئ"); onFail() }
            }
            .setNegativeButton("إلغاء") { _, _ -> onFail() }
            .showStyled()
    }

    // ---------- بيانات ----------
    private fun confirmApproveAll(kind: String, label: String) {
        MaterialAlertDialogBuilder(this)
            .setTitle("اعتماد كل $label المقترحة؟")
            .setMessage("تُوسم كلها «معتمدة» ويُسجَّل ذلك في سجل كل صنف. يمكنك تعديل أي منها لاحقًا، ويمكن التراجع عن التعديل الفردي.")
            .setPositiveButton("اعتماد") { _, _ ->
                val n = Db.get(this).approveAll(kind)
                Prefs.touch()
                toast("تم اعتماد $n")
            }
            .setNegativeButton("إلغاء", null)
            .showStyled()
    }

    private fun showRules() {
        val db = Db.get(this)
        val rules = db.rules()
        val labels = (listOf("＋ إضافة قاعدة") + rules.map { "«${it.keyword}» ← ${it.cls}   (اضغط للحذف)" }).toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle("قواعد التصنيف")
            .setItems(labels) { _, i ->
                if (i == 0) addRule() else { db.deleteRule(rules[i - 1].id); showRules() }
            }
            .setNeutralButton("تطبيق القواعد الآن") { _, _ ->
                val n = db.applyRules()
                Prefs.touch()
                toast("اقتُرح تصنيف لـ $n صنفًا")
            }
            .setNegativeButton("إغلاق", null)
            .showStyled()
    }

    private fun addRule() {
        val e = EditText(this).apply { hint = "الكلمة (جزء من الاسم، عربي أو إنجليزي)" }
        val box = LinearLayout(this).apply {
            setPadding(dp(24), dp(8), dp(24), 0)
            addView(e, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("قاعدة جديدة")
            .setView(box)
            .setPositiveButton("التالي: اختيار التصنيف") { _, _ ->
                val kw = e.text.toString().trim()
                val db = Db.get(this)
                val cls = db.classes().filter { it != "غير محدد" && !it.startsWith("أجهزة") }.toTypedArray()
                if (kw.isEmpty()) { showRules(); return@setPositiveButton }
                MaterialAlertDialogBuilder(this)
                    .setTitle("التصنيف لـ «$kw»")
                    .setItems(cls) { _, i -> db.addRule(kw, cls[i]); showRules() }
                    .setNegativeButton("إلغاء") { _, _ -> showRules() }
                    .showStyled()
            }
            .setNegativeButton("إلغاء") { _, _ -> showRules() }
            .showStyled()
    }

    private fun confirmReset() {
        MaterialAlertDialogBuilder(this)
            .setTitle("استعادة البيانات الأصلية؟")
            .setMessage("سيُمسح كل ما عدّلته أو علّقت عليه، وتعود القائمة كما جاءت مع التطبيق. صدّر نسخة احتياطية أولًا إن أردت الاحتفاظ بها.")
            .setPositiveButton("استعادة") { _, _ ->
                Db.reset(this)
                Db.get(this)
                Prefs.touch()
                toast("تمت الاستعادة")
            }
            .setNegativeButton("إلغاء", null)
            .showStyled()
    }
}
