package com.treatmentcases.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class LocalDb(private val appContext:Context):SQLiteOpenHelper(appContext,"treatment_cases_local.db",null,2){
 init { seedMedicineDictionary(); syncLegacyStrengths() }
 private fun seedMedicineDictionary(){
  val prefs=appContext.getSharedPreferences("local_setup",Context.MODE_PRIVATE)
  if(prefs.getBoolean("dictionary_seeded",false))return
  try{
   val json=org.json.JSONArray(appContext.assets.open("medicines_seed.json").bufferedReader(Charsets.UTF_8).use{it.readText()})
   val d=writableDatabase;d.beginTransaction()
   try{for(i in 0 until json.length()){val o=json.getJSONObject(i);val v=ContentValues().apply{put("name",o.optString("name"));put("generic_name",o.optString("generic"));put("specialty",o.optString("specialty"));put("strengths",o.optString("strengths"));put("dosage_form",o.optString("form"));put("review_status",o.optString("status"))};d.insertWithOnConflict("medicines",null,v,SQLiteDatabase.CONFLICT_IGNORE)};d.setTransactionSuccessful()}finally{d.endTransaction()}
   prefs.edit().putBoolean("dictionary_seeded",true).apply()
  }catch(_:Exception){}
 }
 override fun onCreate(db:SQLiteDatabase){
  db.execSQL("CREATE TABLE cases(id INTEGER PRIMARY KEY AUTOINCREMENT,region TEXT,sector TEXT,name TEXT NOT NULL,performance_no TEXT,medicine TEXT,strength TEXT,extra1 TEXT,extra2 TEXT,duration TEXT,dosage TEXT,condition_text TEXT,approval_date TEXT,approval_expiry TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP)")
  db.execSQL("CREATE INDEX idx_performance ON cases(performance_no)");db.execSQL("CREATE INDEX idx_medicine ON cases(medicine)")
  db.execSQL("CREATE TABLE medicines(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE COLLATE NOCASE,generic_name TEXT DEFAULT '',specialty TEXT DEFAULT '',strengths TEXT DEFAULT '',dosage_form TEXT DEFAULT '',review_status TEXT DEFAULT 'يحتاج مراجعة')")
  db.execSQL("CREATE TABLE strengths(id INTEGER PRIMARY KEY AUTOINCREMENT,medicine TEXT,strength TEXT,UNIQUE(medicine,strength))")
  db.execSQL("CREATE TABLE app_users(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT UNIQUE,password_hash TEXT,role TEXT)")
  db.execSQL("CREATE TABLE audit_log(id INTEGER PRIMARY KEY AUTOINCREMENT,action TEXT,item_key TEXT,at TEXT DEFAULT CURRENT_TIMESTAMP)")
  createEmployeeTable(db)
 }
 override fun onUpgrade(db:SQLiteDatabase,oldVersion:Int,newVersion:Int){
  if(oldVersion<2) createEmployeeTable(db)
 }
 private fun createEmployeeTable(db:SQLiteDatabase){
  db.execSQL("CREATE TABLE IF NOT EXISTS employees(id INTEGER PRIMARY KEY AUTOINCREMENT,performance_no TEXT NOT NULL UNIQUE,name TEXT NOT NULL DEFAULT '',job TEXT DEFAULT '',entity TEXT DEFAULT '',department TEXT DEFAULT '',national_id TEXT DEFAULT '',phone1 TEXT DEFAULT '',phone2 TEXT DEFAULT '',gender TEXT DEFAULT '',notes TEXT DEFAULT '',birth_date TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP)")
  db.execSQL("CREATE INDEX IF NOT EXISTS idx_employee_name ON employees(name)")
 }
 private fun android.database.Cursor.s(k:String)=getString(getColumnIndexOrThrow(k))?:""
 private fun android.database.Cursor.toRecord()=CaseRecord(getLong(getColumnIndexOrThrow("id")),s("region"),s("sector"),s("name"),s("performance_no"),s("medicine"),s("strength"),s("extra1"),s("extra2"),s("duration"),s("dosage"),s("condition_text"),s("approval_date"),s("approval_expiry"))
 fun all():List<CaseRecord>{val a= mutableListOf<CaseRecord>();readableDatabase.rawQuery("SELECT * FROM cases ORDER BY name",null).use{c->while(c.moveToNext())a+=c.toRecord()};return a}
 fun search(q:String="",med:String=""):List<CaseRecord>{val a= mutableListOf<CaseRecord>();val l="%$q%";readableDatabase.rawQuery("SELECT * FROM cases WHERE (?='' OR name LIKE ? OR performance_no LIKE ? OR medicine LIKE ?) AND (?='' OR medicine=?) ORDER BY name",arrayOf(q,l,l,l,med,med)).use{c->while(c.moveToNext())a+=c.toRecord()};return a}
 fun save(r:CaseRecord):Long{val v=ContentValues().apply{put("region",r.region);put("sector",r.sector);put("name",r.name);put("performance_no",r.performanceNo);put("medicine",r.medicine);put("strength",r.strength);put("extra1",r.extra1);put("extra2",r.extra2);put("duration",r.duration);put("dosage",r.dosage);put("condition_text",r.condition);put("approval_date",r.approvalDate);put("approval_expiry",r.approvalExpiry)};return if(r.id>0){writableDatabase.update("cases",v,"id=?",arrayOf(r.id.toString()));r.id}else writableDatabase.insertOrThrow("cases",null,v)}
 fun delete(id:Long){writableDatabase.delete("cases","id=?",arrayOf(id.toString()))}
 fun count()=readableDatabase.rawQuery("SELECT COUNT(*) FROM cases",null).use{it.moveToFirst();it.getInt(0)}
 fun counts():Map<String,Int>{val m=linkedMapOf<String,Int>();readableDatabase.rawQuery("SELECT medicine,COUNT(*) FROM cases GROUP BY medicine ORDER BY medicine",null).use{c->while(c.moveToNext())m[c.getString(0).orEmpty()]=c.getInt(1)};return m}
 fun medicines():List<String>{val m=linkedSetOf<String>();readableDatabase.rawQuery("SELECT name FROM medicines UNION SELECT DISTINCT medicine FROM cases WHERE medicine<>'' ORDER BY 1",null).use{c->while(c.moveToNext())m+=c.getString(0)};return m.toList()}
 fun medicineCatalog():List<MedicineCatalogRecord>{
  val out=mutableListOf<MedicineCatalogRecord>()
  readableDatabase.rawQuery("SELECT name,generic_name,specialty,strengths,dosage_form,review_status FROM medicines ORDER BY name",null).use{c->while(c.moveToNext())out+=MedicineCatalogRecord(c.getString(0).orEmpty(),c.getString(1).orEmpty(),c.getString(2).orEmpty(),c.getString(3).orEmpty(),c.getString(4).orEmpty(),c.getString(5).orEmpty())}
  return out
 }
 fun medicineStrengths():List<MedicineStrengthRecord>{
  val out=mutableListOf<MedicineStrengthRecord>()
  readableDatabase.rawQuery("SELECT medicine,strength FROM strengths ORDER BY medicine,strength",null).use{c->while(c.moveToNext())out+=MedicineStrengthRecord(c.getString(0).orEmpty(),c.getString(1).orEmpty())}
  return out
 }
 fun upsertMedicine(n:String){if(n.isBlank())return;val clean=n.trim().replace(Regex("\\s+")," ");val v=ContentValues().apply{put("name",clean)};writableDatabase.insertWithOnConflict("medicines",null,v,SQLiteDatabase.CONFLICT_IGNORE)}
 private fun splitStrengths(value:String):List<String> = value.split(Regex("[;؛,،|\\n]+")).map{it.trim()}.filter{it.isNotBlank() && !it.contains("يُستكمل") && !it.contains("يستكمل")}.distinctBy{it.lowercase()}
 private fun syncLegacyStrengths(){
  val d=writableDatabase
  d.beginTransaction()
  try{
   d.rawQuery("SELECT name,strengths FROM medicines",null).use{c->while(c.moveToNext()){
    val medicine=c.getString(0).orEmpty();splitStrengths(c.getString(1).orEmpty()).forEach{strength->
     val v=ContentValues().apply{put("medicine",medicine);put("strength",strength)}
     d.insertWithOnConflict("strengths",null,v,SQLiteDatabase.CONFLICT_IGNORE)
    }
   }}
   d.setTransactionSuccessful()
  }finally{d.endTransaction()}
 }
 fun strengthsForMedicine(medicine:String):List<String>{
  val out=linkedSetOf<String>()
  readableDatabase.rawQuery("SELECT strength FROM strengths WHERE medicine=? COLLATE NOCASE ORDER BY strength",arrayOf(medicine.trim())).use{c->while(c.moveToNext())out+=c.getString(0).orEmpty()}
  if(out.isEmpty())readableDatabase.rawQuery("SELECT strengths FROM medicines WHERE name=? COLLATE NOCASE LIMIT 1",arrayOf(medicine.trim())).use{c->if(c.moveToFirst())out+=splitStrengths(c.getString(0).orEmpty())}
  return out.toList()
 }
 fun addStrength(medicine:String,strength:String):Boolean{
  val med=medicine.trim();val st=strength.trim();if(med.isBlank()||st.isBlank())return false
  val d=writableDatabase;d.beginTransaction()
  try{
   upsertMedicine(med)
   val values=ContentValues().apply{put("medicine",med);put("strength",st)}
   val inserted=d.insertWithOnConflict("strengths",null,values,SQLiteDatabase.CONFLICT_IGNORE)>0
   val current=d.rawQuery("SELECT strengths FROM medicines WHERE name=? COLLATE NOCASE LIMIT 1",arrayOf(med)).use{c->if(c.moveToFirst())c.getString(0).orEmpty() else ""}
   val all=(splitStrengths(current)+st).distinctBy{it.lowercase()}
   val update=ContentValues().apply{put("strengths",all.joinToString("; "))}
   d.update("medicines",update,"name=? COLLATE NOCASE",arrayOf(med))
   d.setTransactionSuccessful();return inserted
  }finally{d.endTransaction()}
 }
 fun addMedicine(n:String,generic:String="",strengths:String="",form:String=""):Boolean {
  val clean=n.trim().replace(Regex("\\s+")," ");if(clean.isBlank())return false
  val v=ContentValues().apply{put("name",clean);put("generic_name",generic.trim());put("strengths",strengths.trim());put("dosage_form",form.trim());put("review_status","مضاف يدويًا")}
  val d=writableDatabase;d.beginTransaction()
  try{
   val inserted=d.insertWithOnConflict("medicines",null,v,SQLiteDatabase.CONFLICT_IGNORE)>0
   if(inserted)splitStrengths(strengths).forEach{st->val sv=ContentValues().apply{put("medicine",clean);put("strength",st)};d.insertWithOnConflict("strengths",null,sv,SQLiteDatabase.CONFLICT_IGNORE)}
   d.setTransactionSuccessful();return inserted
  }finally{d.endTransaction()}
 }
 private fun caseSignature(r:CaseRecord):String = CaseDataRules.signature(r)
 fun caseImportIssues(rows:List<CaseRecord>):List<String> = CaseDataRules.validate(rows)
 private fun existingCaseSignatures(d:SQLiteDatabase):MutableSet<String> {
  val signatures=mutableSetOf<String>()
  d.rawQuery("SELECT * FROM cases",null).use{c->while(c.moveToNext())signatures+=caseSignature(c.toRecord())}
  return signatures
 }
 fun duplicateCount(rows:List<CaseRecord>):Int {
  val known=existingCaseSignatures(readableDatabase)
  var duplicates=0
  rows.forEach{r->if(!known.add(caseSignature(CaseDataRules.normalizeForImport(r))))duplicates++}
  return duplicates
 }
 fun importRows(rows:List<CaseRecord>):Pair<Int,Int>{
  val issues=caseImportIssues(rows)
  require(issues.isEmpty()) { issues.take(10).joinToString("\n") }
  var added=0;var duplicates=0;val d=writableDatabase
  d.beginTransaction()
  try {
   val known=existingCaseSignatures(d)
   rows.forEach { source ->
    val r=CaseDataRules.normalizeForImport(source)
    if(!known.add(caseSignature(r))) duplicates++
    else {
     save(r.copy(id=0));upsertMedicine(r.medicine)
     if(r.strength.isNotBlank()) {
      val strengthValues=ContentValues().apply{put("medicine",r.medicine);put("strength",r.strength)}
      d.insertWithOnConflict("strengths",null,strengthValues,SQLiteDatabase.CONFLICT_IGNORE)
     }
     added++
    }
   }
   val log=ContentValues().apply{put("action","استيراد قالب الحالات الحرجة");put("item_key","إضافة $added؛ تكرارات مطابقة $duplicates")}
   d.insert("audit_log",null,log)
   d.setTransactionSuccessful()
  }finally{d.endTransaction()}
  return added to duplicates
 }
 fun employeeCount():Int=readableDatabase.rawQuery("SELECT COUNT(*) FROM employees",null).use{it.moveToFirst();it.getInt(0)}
 fun employees(q:String=""):List<EmployeeRecord>{
  val out=mutableListOf<EmployeeRecord>();val like="%$q%"
  readableDatabase.rawQuery("SELECT * FROM employees WHERE (?='' OR performance_no LIKE ? OR name LIKE ?) ORDER BY name",arrayOf(q,like,like)).use{c->while(c.moveToNext()){
   val birth=c.getString(c.getColumnIndexOrThrow("birth_date")).orEmpty();val age=employeeAge(birth)
   out+=EmployeeRecord(c.getLong(c.getColumnIndexOrThrow("id")),c.getString(c.getColumnIndexOrThrow("performance_no")),c.getString(c.getColumnIndexOrThrow("name")).orEmpty(),c.getString(c.getColumnIndexOrThrow("job")).orEmpty(),c.getString(c.getColumnIndexOrThrow("entity")).orEmpty(),c.getString(c.getColumnIndexOrThrow("department")).orEmpty(),c.getString(c.getColumnIndexOrThrow("national_id")).orEmpty(),c.getString(c.getColumnIndexOrThrow("phone1")).orEmpty(),c.getString(c.getColumnIndexOrThrow("phone2")).orEmpty(),c.getString(c.getColumnIndexOrThrow("gender")).orEmpty(),c.getString(c.getColumnIndexOrThrow("notes")).orEmpty(),birth,age,if(age!=null&&age>=60)"بلغ 60 سنة (معلومة عمرية فقط)" else "")
  }};return out
 }
 fun findEmployee(performanceNo:String):EmployeeRecord?=employees(normalizePerformanceNo(performanceNo)).firstOrNull{normalizePerformanceNo(it.performanceNo)==normalizePerformanceNo(performanceNo)}
 fun planEmployeeImport(rows:List<EmployeeRecord>):EmployeeImportPlan{
  val inserts=mutableListOf<EmployeeRecord>();val updates=mutableListOf<EmployeeRecord>();val issues=mutableListOf<EmployeeImportIssue>();val changes=mutableListOf<EmployeeImportChange>();val seen=mutableSetOf<String>();var unchanged=0
  rows.forEachIndexed{index,r->
   val key=normalizePerformanceNo(r.performanceNo);val rowNo=r.sourceRow.takeIf{it>0}?:index+5
   if(key.isBlank()){issues+=EmployeeImportIssue(rowNo,key,"رقم الأداء إلزامي");return@forEachIndexed}
   if(!seen.add(key)){issues+=EmployeeImportIssue(rowNo,r.performanceNo,"رقم الأداء مكرر داخل ملف الاستيراد");return@forEachIndexed}
   if(r.name.isBlank()&&findEmployee(key)==null){issues+=EmployeeImportIssue(rowNo,key,"اسم العامل مطلوب للسجل الجديد");return@forEachIndexed}
   if(r.nationalId.isNotBlank()&&!validNationalId(r.nationalId)){issues+=EmployeeImportIssue(rowNo,key,"رقم البطاقة يجب أن يتكون من 14 رقماً صالحاً");return@forEachIndexed}
   val derivedGender=genderFromNationalId(r.nationalId);if(r.gender.isNotBlank()&&derivedGender!=null&&normalizeGender(r.gender)!=derivedGender){issues+=EmployeeImportIssue(rowNo,key,"النوع المدخل لا يتفق مع النوع المستخرج من رقم البطاقة");return@forEachIndexed}
   val existing=findEmployee(key)
   if(existing==null) inserts+=r else {
    val merged=mergeEmployee(existing,r)
    if(merged.cells()!=existing.cells()){
     updates+=merged
     val labels=EmployeeRecord.headers
     val oldCells=existing.cells();val newCells=merged.cells()
     val fieldChanges=labels.indices.mapNotNull{i->if(oldCells[i]!=newCells[i])EmployeeFieldChange(labels[i],oldCells[i],newCells[i])else null}
     changes+=EmployeeImportChange(existing.performanceNo,existing.name,fieldChanges)
    } else unchanged++
   }
  }
  return EmployeeImportPlan(inserts,updates,unchanged,issues,changes)
 }
 fun commitEmployeeImport(plan:EmployeeImportPlan):Pair<Int,Int>{
  require(plan.canCommit){"لا يمكن اعتماد ملف يحتوي على أخطاء"}
  val d=writableDatabase;d.beginTransaction();try{
   plan.inserts.forEach{upsertEmployee(d,it,false)}
   plan.updates.forEach{upsertEmployee(d,it,true)}
   val log=ContentValues().apply{put("action","استيراد دليل العاملين");put("item_key","إضافة ${plan.inserts.size} وتحديث ${plan.updates.size}")};d.insert("audit_log",null,log)
   d.setTransactionSuccessful()
  }finally{d.endTransaction()}
  return plan.inserts.size to plan.updates.size
 }
 fun saveEmployee(r:EmployeeRecord){require(normalizePerformanceNo(r.performanceNo).isNotBlank());require(r.name.isNotBlank());require(r.nationalId.isBlank()||validNationalId(r.nationalId));val d=writableDatabase;upsertEmployee(d,r,findEmployee(r.performanceNo)!=null)}
 private fun upsertEmployee(d:SQLiteDatabase,r:EmployeeRecord,update:Boolean){
  val existing=if(update) findEmployee(r.performanceNo) else null
  val m=if(existing!=null)mergeEmployee(existing,r) else r
  val cleanNationalId=normalizeDigits(m.nationalId)
  val birth=if(cleanNationalId.isNotBlank())birthDateFromNationalId(cleanNationalId)?:"" else ""
  val inferredGender=genderFromNationalId(cleanNationalId)?:m.gender
  val v=ContentValues().apply{put("performance_no",normalizePerformanceNo(m.performanceNo));put("name",m.name);put("job",m.job);put("entity",m.entity);put("department",m.department);put("national_id",cleanNationalId);put("phone1",m.phone1);put("phone2",m.phone2);put("gender",inferredGender);put("notes",m.notes);put("birth_date",birth);put("updated_at",java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss",java.util.Locale.US).format(java.util.Date()))}
  if(existing==null)d.insertOrThrow("employees",null,v) else d.update("employees",v,"performance_no=?",arrayOf(normalizePerformanceNo(m.performanceNo)))
 }
 private fun mergeEmployee(old:EmployeeRecord,new:EmployeeRecord)=old.copy(name=new.name.ifBlank{old.name},job=new.job.ifBlank{old.job},entity=new.entity.ifBlank{old.entity},department=new.department.ifBlank{old.department},nationalId=new.nationalId.ifBlank{old.nationalId},phone1=new.phone1.ifBlank{old.phone1},phone2=new.phone2.ifBlank{old.phone2},gender=new.gender.ifBlank{old.gender},notes=new.notes.ifBlank{old.notes})
 private fun normalizePerformanceNo(value:String):String=value.trim().filterNot{it.isWhitespace()}.map{ch->when(ch){in '٠'..'٩'->'0'+(ch-'٠');in '۰'..'۹'->'0'+(ch-'۰');else->ch}}.joinToString("")
 private fun normalizeDigits(value:String):String=value.map{ch->when(ch){in '٠'..'٩'->'0'+(ch-'٠');in '۰'..'۹'->'0'+(ch-'۰');else->ch}}.joinToString("")
 private fun normalizeGender(value:String):String=when(value.trim()){"ذكر","رجل","Male","male"->"ذكر";"أنثى","انثى","امرأة","Female","female"->"أنثى";else->value.trim()}
 private fun genderFromNationalId(value:String):String?{val id=normalizeDigits(value);if(id.length!=14)return null;val serial=id[12].digitToIntOrNull()?:return null;return if(serial%2==1)"ذكر" else "أنثى"}
 private fun validNationalId(id:String):Boolean{val clean=normalizeDigits(id);if(!clean.matches(Regex("[0-9]{14}")))return false;return birthDateFromNationalId(clean)!=null}
 private fun birthDateFromNationalId(id:String):String? {
  if(id.length!=14)return null
  val century=when(id[0]){'2'->1900;'3'->2000;else->return null}
  return try{
   val year=century+id.substring(1,3).toInt();val month=id.substring(3,5).toInt();val day=id.substring(5,7).toInt()
   val cal=java.util.GregorianCalendar(year,month-1,day)
   if(cal.get(java.util.Calendar.YEAR)!=year||cal.get(java.util.Calendar.MONTH)!=month-1||cal.get(java.util.Calendar.DAY_OF_MONTH)!=day)null
   else java.text.SimpleDateFormat("yyyy-MM-dd",java.util.Locale.US).format(cal.time)
  }catch(_:Exception){null}
 }
 private fun employeeAge(birth:String):Int? {
  return try {
   val d=java.text.SimpleDateFormat("yyyy-MM-dd",java.util.Locale.US).parse(birth) ?: return null
   val born=java.util.Calendar.getInstance().apply{time=d}
   val now=java.util.Calendar.getInstance()
   var age=now.get(java.util.Calendar.YEAR)-born.get(java.util.Calendar.YEAR)
   val beforeBirthday=now.get(java.util.Calendar.MONTH)<born.get(java.util.Calendar.MONTH) ||
    (now.get(java.util.Calendar.MONTH)==born.get(java.util.Calendar.MONTH) && now.get(java.util.Calendar.DAY_OF_MONTH)<born.get(java.util.Calendar.DAY_OF_MONTH))
   if(beforeBirthday) age--
   age
  } catch(_:Exception){null}
 }


 fun restoreBundle(bundle:BackupBundle):Triple<Int,Int,Int>{
  val caseIssues=CaseDataRules.validate(bundle.cases)
  require(caseIssues.isEmpty()){"النسخة تحتوي على حالات غير صالحة؛ لم يتم اعتماد أي بيانات. أول خطأ: ${caseIssues.firstOrNull().orEmpty()}"}
  val employeePlan=planEmployeeImport(bundle.employees)
  require(employeePlan.canCommit){"النسخة تحتوي على بيانات عاملين غير صالحة؛ لم يتم استعادة أي بيانات. أول خطأ: ${employeePlan.issues.firstOrNull()?.message.orEmpty()}"}
  var casesAdded=0;var employeesAdded=0;var employeesUpdated=0;var medicinesAdded=0
  val d=writableDatabase;d.beginTransaction()
  try{
   val knownCaseSignatures=existingCaseSignatures(d)
   bundle.cases.forEach{source->
    // A worker may legitimately have multiple records for the same medicine.
    // Only an identical normalized full record is skipped.
    val r=CaseDataRules.normalizeForImport(source)
    if(knownCaseSignatures.add(caseSignature(r))){
     save(r.copy(id=0));if(r.medicine.isNotBlank())upsertMedicine(r.medicine)
     if(r.medicine.isNotBlank()&&r.strength.isNotBlank()){
      val strengthValues=ContentValues().apply{put("medicine",r.medicine);put("strength",r.strength)}
      d.insertWithOnConflict("strengths",null,strengthValues,SQLiteDatabase.CONFLICT_IGNORE)
     }
     casesAdded++
    }
   }
   employeePlan.inserts.forEach{upsertEmployee(d,it,false)}
   employeePlan.updates.forEach{upsertEmployee(d,it,true)}
   employeesAdded=employeePlan.inserts.size;employeesUpdated=employeePlan.updates.size
   bundle.medicines.forEach{n->if(n.isNotBlank()){val before=readableDatabase.rawQuery("SELECT 1 FROM medicines WHERE name=? COLLATE NOCASE LIMIT 1",arrayOf(n.trim())).use{it.moveToFirst()};upsertMedicine(n);if(!before)medicinesAdded++}}
   // Merge catalog rows without REPLACE: REPLACE deletes the old row first and
   // can discard local metadata/row identity. Incoming non-empty fields update
   // existing values; blank incoming fields never erase local information.
   bundle.medicineDetails.forEach{m->
    val name=m.name.trim().replace(Regex("\\s+")," ")
    if(name.isNotBlank()){
     val existing=d.rawQuery("SELECT generic_name,specialty,strengths,dosage_form,review_status FROM medicines WHERE name=? COLLATE NOCASE LIMIT 1",arrayOf(name)).use{c->
      if(c.moveToFirst()) listOf(0,1,2,3,4).map{c.getString(it).orEmpty()} else null
     }
     val values=ContentValues().apply{
      put("name",name)
      put("generic_name",m.genericName.ifBlank{existing?.get(0).orEmpty()})
      put("specialty",m.specialty.ifBlank{existing?.get(1).orEmpty()})
      put("strengths",m.strengths.ifBlank{existing?.get(2).orEmpty()})
      put("dosage_form",m.dosageForm.ifBlank{existing?.get(3).orEmpty()})
      put("review_status",m.reviewStatus.ifBlank{existing?.get(4).orEmpty().ifBlank{"يحتاج مراجعة"}})
     }
     if(existing==null)d.insertOrThrow("medicines",null,values)
     else d.update("medicines",values,"name=? COLLATE NOCASE",arrayOf(name))
    }
   }
   bundle.strengths.forEach{st->if(st.medicine.isNotBlank()&&st.strength.isNotBlank()){
    val values=ContentValues().apply{put("medicine",st.medicine.trim());put("strength",st.strength.trim())}
    d.insertWithOnConflict("strengths",null,values,SQLiteDatabase.CONFLICT_IGNORE)
   }}
   val log=ContentValues().apply{put("action","استعادة نسخة شاملة");put("item_key","حالات $casesAdded؛ عاملون +$employeesAdded / تحديث $employeesUpdated؛ أدوية +$medicinesAdded؛ عيارات ${bundle.strengths.size}")};d.insert("audit_log",null,log)
   d.setTransactionSuccessful()
  }finally{d.endTransaction()}
  return Triple(casesAdded,employeesAdded,employeesUpdated)
 }

 fun alerts():List<String>{
  val a=mutableListOf<String>();val d=readableDatabase
  fun n(sql:String)=d.rawQuery(sql,null).use{it.moveToFirst();it.getInt(0)}
  val missing=n("SELECT COUNT(*) FROM cases WHERE name='' OR performance_no='' OR medicine=''")
  val noApproval=n("SELECT COUNT(*) FROM cases WHERE approval_date=''")
  // Multiple medicines/treatment rows for one worker are valid; alert only when
  // one performance number is associated with more than one distinct name.
  val dup=n("SELECT COUNT(*) FROM (SELECT performance_no FROM cases WHERE trim(performance_no)<>'' GROUP BY trim(performance_no) HAVING COUNT(DISTINCT lower(trim(name)))>1)")
  val unknown=n("SELECT COUNT(*) FROM cases c LEFT JOIN medicines m ON c.medicine=m.name COLLATE NOCASE WHERE trim(c.medicine)<>'' AND m.id IS NULL")
  val expired=n("SELECT COUNT(*) FROM cases WHERE approval_expiry<>'' AND date(approval_expiry) < date('now')")
  val soon=n("SELECT COUNT(*) FROM cases WHERE approval_expiry<>'' AND date(approval_expiry) BETWEEN date('now') AND date('now','+30 day')")
  if(missing>0)a+="بيانات أساسية ناقصة في $missing سجل"
  if(noApproval>0)a+="تاريخ موافقة غير مسجل في $noApproval سجل"
  if(dup>0)a+="أرقام أداء مكررة: $dup"
  if(unknown>0)a+="أدوية غير موجودة بالقاموس: $unknown"
  if(expired>0)a+="موافقات منتهية حسب تاريخ الانتهاء: $expired"
  if(soon>0)a+="موافقات ستنتهي خلال 30 يومًا: $soon"
  return a
 }
 fun log(a:String,k:String){val v=ContentValues().apply{put("action",a);put("item_key",k)};writableDatabase.insert("audit_log",null,v)}
}
