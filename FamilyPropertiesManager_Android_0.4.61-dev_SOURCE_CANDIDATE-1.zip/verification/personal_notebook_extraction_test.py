from pathlib import Path
root = Path(__file__).resolve().parents[1]
main = (root / 'app/src/main/java/com/example/rentals/MainActivity.kt').read_text(encoding='utf-8')
feature = (root / 'app/src/main/java/com/example/rentals/features/personal/PersonalRentNotebook.kt').read_text(encoding='utf-8')
assert 'import com.example.rentals.features.personal.PersonalRentNotebook' in main
assert 'Tab.Personal->PersonalRentNotebook(db)' in main
assert 'private fun PersonalRentNotebook' not in main
assert '@Composable fun PersonalRentNotebook(db:RentalsDb)' in feature
for token in ('db.personalRows(monthId)', 'db.personalExpenses(monthId)', 'db.personalAnnualSummary(it)', 'db.copyPersonalNames(source,y,m)', 'db.savePersonalRow', 'db.addPersonalExpense', 'db.updatePersonalExpense', 'db.deletePersonalExpense'):
    assert token in feature, f'missing personal notebook behavior: {token}'
assert 'التعديلات لا تؤثر في دفتر الحركات الرئيسي' in feature
print('PASS: personal notebook extracted with independent data and retained operations')
