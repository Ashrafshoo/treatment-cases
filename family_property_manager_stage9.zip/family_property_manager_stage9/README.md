# Family Property Manager — Flutter source

Private Arabic-first family property and rent-management project. Latest source stage: **Stage 10 security implementation (source-level; runtime validation pending)**.

- Stage notes: `docs/STAGE9_COMPLETION.md`
- Latest integration audit before security additions: `docs/INTEGRATION_AUDIT_2026-11-10.md`
- Stage 10 security implementation: `docs/SECURITY_IMPLEMENTATION_STAGE10.md`
- Cloud build guide (Arabic): `docs/CLOUD_BUILD_GUIDE_AR.md`
- Codemagic workflow: `codemagic.yaml`
- Database schema: `app/assets/database/001_initial_schema.sql`

## Local build (requires Flutter SDK)

```bash
cd app
flutter create --platforms=android --org com.familyproperties .
flutter pub get
dart format lib test
flutter analyze
flutter test
flutter build apk --debug
```

The current handover environment did not have Flutter/Dart installed, so the Flutter commands and APK build have not been run. Alternatively, connect the private repository to Codemagic and run the workflow in `codemagic.yaml`.

## Privacy

The source now contains SQLCipher encryption, secure key storage, a guarded plaintext-to-encrypted migration path, and optional biometric sign-in. These additions have not yet been validated by Flutter analysis/build or on a physical Android device. Use synthetic data only until those checks and migration/restore tests pass. Encrypted manual backups include the database and archived documents. XLSX exports are plain files and must be protected by the user. Never upload family Excel files, receipts, real database files, passwords or signing keys to a public repository or cloud build service.
