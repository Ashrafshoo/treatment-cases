package com.treatmentcases.app

/** Provider-neutral envelope. It contains only one changed business row and stable sync identity. */
data class SyncEnvelope(
    val eventId: String,
    val sourceDeviceId: String,
    val entityType: String,
    val entityId: String,
    val operation: String,
    val baseVersion: Long,
    val newVersion: Long,
    val payloadJson: String
)

/** Explicit conflict result; callers must never resolve by silently overwriting a local row. */
sealed class SyncApplyDecision {
    data class Apply(val expectedLocalVersion: Long) : SyncApplyDecision()
    data class Conflict(val localVersion: Long, val remoteVersion: Long, val reason: String) : SyncApplyDecision()
    data class IgnoreDuplicate(val eventId: String) : SyncApplyDecision()
}

object SyncConflictPolicy {
    fun decide(localVersion: Long?, remoteBaseVersion: Long, remoteNewVersion: Long, eventAlreadyReceived: Boolean): SyncApplyDecision {
        if (eventAlreadyReceived) return SyncApplyDecision.IgnoreDuplicate("duplicate")
        if (remoteNewVersion <= remoteBaseVersion) return SyncApplyDecision.Conflict(localVersion ?: 0L, remoteNewVersion, "invalid remote version sequence")
        val current = localVersion ?: 0L
        return if (current == remoteBaseVersion) SyncApplyDecision.Apply(current)
        else SyncApplyDecision.Conflict(current, remoteNewVersion, "local version differs from remote base version")
    }
}
