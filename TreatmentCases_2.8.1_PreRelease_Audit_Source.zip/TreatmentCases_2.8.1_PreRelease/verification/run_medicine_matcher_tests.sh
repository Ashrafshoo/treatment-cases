#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
kotlinc "$ROOT/android/app/src/main/java/com/treatmentcases/app/MedicineNameMatcher.kt" "$ROOT/verification/MedicineNameMatcherTest.kt" -include-runtime -d "$TMP/medicine-matcher-tests.jar"
java -jar "$TMP/medicine-matcher-tests.jar"
