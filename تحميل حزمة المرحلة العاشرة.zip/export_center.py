#!/usr/bin/env python3
"""Export center and beneficiary profile service for علاج الحالات حاجة.
Read-only against the supplied SQLite database. Exports are generated separately.
"""
from __future__ import annotations
import argparse, json, sqlite3
from pathlib import Path
from datetime import datetime, date
from typing import Iterable
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.worksheet.table import Table, TableStyleInfo
from openpyxl.utils import get_column_letter

FIELDS = [
 ('performance_number','رقم الأداء'),('full_name','الاسم'),('job_title','الوظيفة'),
 ('region','المنطقة'),('department','الإدارة'),('mobile1','المحمول'),
 ('medicine_name_raw','اسم العلاج كما ورد'),('medicine_name_canonical','اسم العلاج المعتمد'),('strength_raw','التركيز'),('treatment_order','موضع العلاج'),
 ('dosage_text','الجرعة'),('dispensing_duration','مدة الصرف'),('medical_condition','الحالة المرضية'),
 ('approval_date','تاريخ الموافقة'),('record_status','حالة السجل')]

def connect(db):
    c=sqlite3.connect(str(db)); c.row_factory=sqlite3.Row; c.execute('PRAGMA query_only=ON'); return c

def _query(c, medicines=None, include_archive=False, include_mobile=False, order_by='medicine'):
    src='v_Treatment_Export'
    rows=[dict(r) for r in c.execute(f'SELECT * FROM {src}')]
    if include_archive:
        rows += [dict(r) for r in c.execute('SELECT * FROM v_Treatment_History_Export')]
    aliases={}
    try:
        aliases={str(r['raw_alias']).strip().casefold():r['medicine_name'] for r in c.execute('SELECT a.raw_alias,d.medicine_name FROM Medicine_Name_Aliases a JOIN Medicine_Dictionary d USING(medicine_id)')}
    except sqlite3.OperationalError:
        aliases={}
    for r in rows:
        raw=(r.get('medicine_name_raw') or '').strip()
        r['medicine_name_canonical']=aliases.get(raw.casefold(),raw)
    if medicines:
        wanted={m.strip().casefold() for m in medicines if m.strip()}
        rows=[r for r in rows if (r.get('medicine_name_raw') or '').strip().casefold() in wanted or (r.get('medicine_name_canonical') or '').strip().casefold() in wanted]
    if not include_mobile:
        for r in rows: r['mobile1']=''
    sort_keys={'medicine':('medicine_name_canonical','full_name'),'region':('region','full_name'),'department':('department','full_name'),'performance':('performance_number','medicine_name_raw')}
    keys=sort_keys.get(order_by,sort_keys['medicine'])
    rows.sort(key=lambda r: tuple((r.get(k) or '') for k in keys))
    return rows

def _style_sheet(ws, headers, widths):
    ws.sheet_view.rightToLeft=True; ws.freeze_panes='A2'; ws.auto_filter.ref=ws.dimensions
    for cell in ws[1]:
        cell.font=Font(name='Arial',bold=True,color='FFFFFF')
        cell.fill=PatternFill('solid',fgColor='174A5B')
        cell.alignment=Alignment(horizontal='center',vertical='center',wrap_text=True)
    ws.row_dimensions[1].height=32
    for i,w in enumerate(widths,1): ws.column_dimensions[get_column_letter(i)].width=w
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.font=Font(name='Arial',size=10,color='18313A')
            cell.alignment=Alignment(vertical='center',wrap_text=True)
            if cell.row%2==0: cell.fill=PatternFill('solid',fgColor='EEF4F5')
    ws.sheet_properties.pageSetUpPr.fitToPage=True
    ws.page_setup.orientation='landscape'; ws.page_setup.paperSize=ws.PAPERSIZE_A4
    ws.page_setup.fitToWidth=1; ws.page_setup.fitToHeight=0
    ws.print_title_rows='1:1'; ws.page_margins.left=.25; ws.page_margins.right=.25
    ws.page_margins.top=.5; ws.page_margins.bottom=.5

def export_excel(db, output, medicines=None, include_archive=False, include_mobile=False, order_by='medicine'):
    c=connect(db)
    try: rows=_query(c,medicines,include_archive,include_mobile,order_by)
    finally: c.close()
    wb=Workbook(); ws=wb.active; ws.title='كشف العلاجات'
    headers=[label for key,label in FIELDS]
    ws.append(headers)
    for r in rows:
        vals=[]
        for key,_ in FIELDS:
            v=r.get(key,'')
            if key=='treatment_order': v={1:'الأول',2:'الثاني',3:'الثالث'}.get(v,str(v or ''))
            vals.append(v if v is not None else '')
        ws.append(vals)
    _style_sheet(ws,headers,[16,30,20,18,20,16,24,16,14,28,18,26,16,18])
    if ws.max_row>1:
        tab=Table(displayName='TreatmentsExport',ref=ws.dimensions)
        tab.tableStyleInfo=TableStyleInfo(name='TableStyleMedium2',showRowStripes=True,showColumnStripes=False)
        ws.add_table(tab)
    summary=wb.create_sheet('ملخص')
    unique=len({r.get('performance_number') for r in rows})
    summary.append(['المؤشر','القيمة']); summary.append(['عدد سجلات العلاج',len(rows)]); summary.append(['عدد الأشخاص الفريدين',unique]); summary.append(['تاريخ إنشاء التقرير',datetime.now().strftime('%Y-%m-%d %H:%M')]); summary.sheet_view.rightToLeft=True
    _style_sheet(summary,['المؤشر','القيمة'],[30,28])
    output=Path(output); output.parent.mkdir(parents=True,exist_ok=True); wb.save(output)
    return {'rows':len(rows),'people':unique,'file':str(output)}

def beneficiary_profile(db, performance_number):
    c=connect(db)
    try:
        p=c.execute('SELECT * FROM Personnel WHERE performance_number=?',(str(performance_number),)).fetchone()
        b=c.execute('SELECT * FROM Beneficiaries WHERE performance_number=?',(str(performance_number),)).fetchone()
        if not p and not b: return None
        person=dict(p) if p else {}
        if b:
            for k in ('full_name','region','department','medical_condition','approval_date'):
                person.setdefault(k,b[k])
        treatments=[]
        if b:
            treatments=[dict(r) for r in c.execute('SELECT treatment_order,medicine_name_raw,strength_raw,source_field FROM Treatment_Entries WHERE beneficiary_id=? ORDER BY treatment_order',(b['beneficiary_id'],))]
            history=[dict(r) for r in c.execute('SELECT treatment_order,medicine_name_raw,strength_raw,dispensing_duration,dosage_text,medical_condition,approval_date,treatment_status,status_note,started_or_imported_at,stopped_at FROM Treatment_History WHERE beneficiary_id=? ORDER BY history_id DESC',(b['beneficiary_id'],))]
        else: history=[]
        nid=person.get('national_id')
        if nid: person['national_id_masked']='*'*max(0,len(str(nid))-4)+str(nid)[-4:]
        person.pop('national_id',None)
        dob=person.get('birth_date')
        if dob:
            try:
                born=date.fromisoformat(dob); today=date.today(); person['age_years']=today.year-born.year-((today.month,today.day)<(born.month,born.day))
            except Exception: person['age_years']=None
        return {'person':person,'current_treatments':treatments,'treatment_history':history,'privacy_note':'رقم قومي مخفي جزئياً؛ المحمول لا يظهر في التصدير العام.'}
    finally: c.close()

def export_profile_excel(db, performance_number, output):
    profile=beneficiary_profile(db,performance_number)
    if not profile: raise ValueError('لا يوجد مستفيد بهذا الرقم')
    wb=Workbook(); ws=wb.active; ws.title='الملف الشخصي'; ws.sheet_view.rightToLeft=True
    ws.append(['البيان','القيمة'])
    for k,v in profile['person'].items():
        if k in ('personnel_id','created_at','updated_at','source_batch_id','national_id_validation_status'): continue
        ws.append([k, '' if v is None else str(v)])
    _style_sheet(ws,['البيان','القيمة'],[30,48])
    tw=wb.create_sheet('العلاجات الحالية'); tw.sheet_view.rightToLeft=True
    tw.append(['موضع العلاج','اسم العلاج','التركيز','مصدر الحقل'])
    for r in profile['current_treatments']: tw.append([r['treatment_order'],r['medicine_name_raw'],r['strength_raw'],r['source_field']])
    _style_sheet(tw,['موضع العلاج','اسم العلاج','التركيز','مصدر الحقل'],[18,32,22,22])
    hw=wb.create_sheet('الأرشيف'); hw.sheet_view.rightToLeft=True
    hheaders=['موضع العلاج','اسم العلاج','التركيز','مدة الصرف','الجرعة','الحالة المرضية','تاريخ الموافقة','الحالة','ملاحظة الحالة','تاريخ الإيقاف']
    hw.append(hheaders)
    for r in profile['treatment_history']: hw.append([r.get(k,'') for k in ['treatment_order','medicine_name_raw','strength_raw','dispensing_duration','dosage_text','medical_condition','approval_date','treatment_status','status_note','stopped_at']])
    _style_sheet(hw,hheaders,[14,26,16,18,24,26,16,14,28,18])
    Path(output).parent.mkdir(parents=True,exist_ok=True); wb.save(output)
    return {'file':str(output),'current_treatments':len(profile['current_treatments']),'history':len(profile['treatment_history'])}

def export_pdf(db, output, medicines=None, include_archive=False, include_mobile=False, order_by='medicine'):
    # WeasyPrint uses the system's Arabic-capable shaping/bidi stack and Noto Arabic fonts.
    from weasyprint import HTML
    c=connect(db)
    try: rows=_query(c,medicines,include_archive,include_mobile,order_by)
    finally: c.close()
    headers=[label for _,label in FIELDS]
    def esc(v):
        import html
        return html.escape('' if v is None else str(v))
    def display_value(r,k):
        if k=='treatment_order': return {1:'الأول',2:'الثاني',3:'الثالث'}.get(r.get(k),r.get(k,''))
        return r.get(k,'')
    body=''.join('<tr>'+''.join(f'<td>{esc(display_value(r,k))}</td>' for k,_ in FIELDS)+'</tr>' for r in rows)
    html_doc=f'''<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><style>
    @page {{size:A4 landscape;margin:12mm 8mm 14mm;@bottom-right{{content:"صفحة " counter(page) " من " counter(pages);font-size:8pt}}}}
    body{{font-family:"Noto Sans Arabic",sans-serif;color:#18313a;font-size:8pt}}h1{{font-size:16pt;color:#174a5b}}.meta{{margin-bottom:8px}}table{{width:100%;border-collapse:collapse;table-layout:auto}}thead{{display:table-header-group}}th{{background:#174a5b;color:white}}th,td{{border:.4pt solid #9aafb5;padding:4px;text-align:right;vertical-align:top;overflow-wrap:anywhere}}tr:nth-child(even){{background:#eef4f5}}</style>
    <h1>كشف إدارة العلاجات</h1><div class="meta">عدد سجلات العلاج: {len(rows)} | عدد الأشخاص: {len(set(r.get('performance_number') for r in rows))} | تاريخ الطباعة: {datetime.now():%Y-%m-%d %H:%M}</div>
    <table><thead><tr>{''.join(f'<th>{esc(h)}</th>' for h in headers)}</tr></thead><tbody>{body}</tbody></table></html>'''
    Path(output).parent.mkdir(parents=True,exist_ok=True); HTML(string=html_doc).write_pdf(str(output))
    return {'rows':len(rows),'people':len(set(r.get('performance_number') for r in rows)),'file':str(output)}

def main():
    ap=argparse.ArgumentParser(description='مركز التصدير والملف الشخصي — قراءة فقط')
    ap.add_argument('--db',required=True); sub=ap.add_subparsers(dest='cmd',required=True)
    for name in ('excel','pdf'):
        p=sub.add_parser(name); p.add_argument('--out',required=True); p.add_argument('--medicine',action='append'); p.add_argument('--archive',action='store_true'); p.add_argument('--mobile',action='store_true'); p.add_argument('--sort',default='medicine',choices=['medicine','region','department','performance'])
    p=sub.add_parser('profile'); p.add_argument('--performance-number',required=True); p.add_argument('--out',required=True)
    a=ap.parse_args()
    if a.cmd=='excel': result=export_excel(a.db,a.out,a.medicine,a.archive,a.mobile,a.sort)
    elif a.cmd=='pdf': result=export_pdf(a.db,a.out,a.medicine,a.archive,a.mobile,a.sort)
    else: result=export_profile_excel(a.db,a.performance_number,a.out)
    print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__': main()
