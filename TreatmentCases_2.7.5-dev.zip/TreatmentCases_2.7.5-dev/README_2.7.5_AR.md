# علاج الحالات حاجة – 2.7.5-dev

هذه حزمة تطوير مستقلة مبنية على `2.7.4-dev`، مع تشديد حدود الصلاحيات في عمليات الاستيراد والاستعادة وقاموس الأدوية.

## فتح المشروع
افتح مجلد `android` في Android Studio بعد تثبيت Android SDK. يحدد ملف `.github/workflows/android-apk.yml` إعداد بناء APK باستخدام Gradle 8.9 وAndroid SDK 35.

## الفحوص
من مجلد المشروع شغّل:
```bash
python verification/check_user_access_274.py
for f in verification/check_*.py; do python "$f" || exit 1; done
for f in verification/run_*.sh; do bash "$f" || exit 1; done
```

## تنبيه مهم
هذه نسخة تطوير واختبار وليست إصداراً إنتاجياً. لم يُبنَ APK في بيئة التجهيز الحالية لعدم توفر Gradle وAndroid SDK. لم يتم اختبارها على هاتف فعلي. اختبر الترقية على نسخة منفصلة من قاعدة البيانات، واحتفظ بنسخة احتياطية مشفرة قبل أي تجربة على بيانات حقيقية.
