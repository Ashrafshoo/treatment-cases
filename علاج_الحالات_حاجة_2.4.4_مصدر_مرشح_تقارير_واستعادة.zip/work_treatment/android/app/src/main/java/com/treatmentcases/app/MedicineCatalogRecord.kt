package com.treatmentcases.app

data class MedicineCatalogRecord(
    val name: String,
    val genericName: String = "",
    val specialty: String = "",
    val strengths: String = "",
    val dosageForm: String = "",
    val reviewStatus: String = "يحتاج مراجعة"
)

data class MedicineStrengthRecord(val medicine: String, val strength: String)
