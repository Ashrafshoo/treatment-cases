# Stage 15 — Android Native migration foundation

## Completed in this stage
- Replaced the Flutter build workflow with a GitHub Actions workflow using JDK 17 and Gradle 8.9.
- Added an Android application module using Kotlin and Jetpack Compose (Arabic RTL-capable UI).
- Added the navy/gold dashboard, navigation drawer, section entry points, and animated dashboard introduction.
- Added pure Kotlin rent/collection/expense calculation functions with unit tests.
- Bundled the reviewed relational SQL schema as an Android asset and added a non-destructive SQLite installation helper.
- Added a GitHub workflow that can either build checked-in project files or extract `project-source.zip` uploaded to the repository root.

## Important not-yet-complete items
This is a migration foundation, not a feature-complete replacement for the previous Flutter prototype. The property, unit, tenant, lease, payment, receipt, reports, expenses, archive, Excel exchange, review center, role management, biometric login flow, notification scheduling, encrypted database, backup/restore and PDF printing screens/services still need to be ported and integrated. Current non-home section screens are clearly marked placeholders.

## Critical correctness/security gates
1. Implement SQLCipher-compatible SQLite and Android Keystore-backed key lifecycle before real family data is entered.
2. Replace the initial schema installer with explicit, tested versioned migrations; never destructively reset a populated database.
3. Implement date-effective rent history and approval-based increases. The current sample law-164 helper is only an isolated calculation primitive and must not be used as a production scheduler until legal/business rules and historical rent basis are confirmed.
4. Implement and test allocation of payments spanning periods before calculating monthly outstanding balances.
5. Enforce owner-share totals over overlapping effective dates at repository/database transaction level.
6. Add repositories, audit log, role enforcement and immutable approved receipt snapshots.
7. Port all existing modules and run device/emulator integration tests before calling the Android app complete.

## Stage 15 test coverage
Kotlin unit tests cover the initial pure calculation primitives only. GitHub Actions runs these tests and assembles a debug APK. No cloud run has been executed from this environment; the workflow must be run in the user's GitHub repository to verify remote build success.
