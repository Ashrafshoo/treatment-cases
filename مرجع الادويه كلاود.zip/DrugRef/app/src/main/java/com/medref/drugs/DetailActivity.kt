package com.medref.drugs

import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.color.MaterialColors
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class DetailActivity : BaseActivity() {

    private lateinit var db: Db
    private lateinit var root: LinearLayout
    private lateinit var scroll: ScrollView
    private var code = 0

    // وضع المراجعة الموجّهة
    private var queue: IntArray? = null
    private var qpos = 0
    private var qkind = ""

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun muted() = MaterialColors.getColor(this, com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFF777777.toInt())
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        queue = intent.getIntArrayExtra("queue")
        qkind = intent.getStringExtra("qkind") ?: ""
        qpos = intent.getIntExtra("qpos", 0)
        code = queue?.getOrNull(qpos) ?: intent.getIntExtra("code", 0)
        db = Db.get(this)

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(32))
        }
        scroll = ScrollView(this).apply { addView(root) }
        val outer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        outer.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        if (queue != null) outer.addView(queueBar())
        setContentView(outer)

        supportActionBar?.title = "تفاصيل الصنف"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        render()
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    override fun onDataChanged() {
        db = Db.get(this)
        render()
    }

    // ---------- شريط المراجعة الموجّهة ----------
    private lateinit var qCounter: TextView

    private fun queueBar(): View {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(MaterialColors.getColor(this@DetailActivity, com.google.android.material.R.attr.colorSurfaceVariant, 0x22808080))
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        qCounter = TextView(this).apply { textSize = 12f; setPadding(0, 0, 0, dp(4)) }
        bar.addView(qCounter)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = "‹ السابق"
            setOnClickListener { go(-1) }
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dp(6) }
        })
        row.addView(MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = "تجاوز ›"
            setOnClickListener { go(1) }
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dp(6) }
        })
        row.addView(MaterialButton(this).apply {
            text = "اعتماد وتالي ››"
            setOnClickListener {
                db.approveFor(qkind, code)
                setResult(RESULT_OK)
                go(1)
            }
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1.4f)
        })
        bar.addView(row)
        return bar
    }

    private fun go(step: Int) {
        val q = queue ?: return
        val next = qpos + step
        if (next < 0) { toast("هذا أول صنف"); return }
        if (next >= q.size) { toast("انتهت القائمة"); finish(); return }
        qpos = next
        code = q[qpos]
        render()
        scroll.scrollTo(0, 0)
    }

    // ---------- عناصر واجهة صغيرة ----------
    private fun card(): LinearLayout {
        val c = MaterialCardView(this).apply {
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(12) }
        }
        Ui.styleCard(c)
        val inner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        c.addView(inner)
        root.addView(c)
        return inner
    }

    private fun title(parent: LinearLayout, text: String) {
        parent.addView(TextView(this).apply {
            this.text = text
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, 0, 0, dp(6))
        })
    }

    private fun para(parent: LinearLayout, text: String, color: Int? = null) {
        parent.addView(TextView(this).apply {
            this.text = text
            textSize = 13f
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            if (color != null) setTextColor(color)
            setPadding(0, dp(2), 0, dp(2))
        })
    }

    private fun button(parent: LinearLayout, text: String, outlined: Boolean = false, onClick: () -> Unit) {
        val b = if (outlined) MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle)
        else MaterialButton(this)
        b.text = text
        b.setOnClickListener { onClick() }
        b.layoutParams = LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(6); marginEnd = dp(6) }
        parent.addView(b)
    }

    private fun linkRow(parent: LinearLayout, text: String, target: Int, color: Int) {
        parent.addView(TextView(this).apply {
            this.text = text
            textSize = 13f
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            setTextColor(color)
            setPadding(0, dp(6), 0, dp(6))
            setOnClickListener {
                startActivity(Intent(this@DetailActivity, DetailActivity::class.java).putExtra("code", target))
            }
        })
    }

    private fun row(parent: LinearLayout, label: String, value: String?) {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(5), 0, dp(5))
        }
        r.addView(TextView(this).apply {
            text = label
            textSize = 12f
            setTextColor(muted())
            layoutParams = LinearLayout.LayoutParams(dp(112), WRAP)
        })
        r.addView(TextView(this).apply {
            text = if (value.isNullOrBlank()) "—" else value
            textSize = 14f
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            setTextIsSelectable(true)
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
        })
        parent.addView(r)
    }

    // ---------- العرض ----------
    private fun render() {
        root.removeAllViews()
        if (queue != null) qCounter.text = "${Review.kinds[qkind] ?: ""} — ${qpos + 1} / ${queue!!.size}"
        val item = db.get(code)
        if (item == null) {
            para(card(), "لا يوجد صنف بهذا الكود.")
            finishUi()
            return
        }
        val orig = db.get(code, original = true)
        val primary = Ui.primary(this)

        // الكود ملتصق بالاسم الأجنبي في سطر واحد
        val head = card()
        head.addView(TextView(this).apply {
            text = (if (item.fav) "★ " else "") +
                (if (item.nameEn.isNotBlank()) "${item.code} · ${item.nameEn}" else "${item.code} · — بدون اسم أجنبي —")
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
            textDirection = View.TEXT_DIRECTION_LTR
            textAlignment = View.TEXT_ALIGNMENT_VIEW_START
            setTextIsSelectable(true)
        })
        head.addView(TextView(this).apply {
            text = item.nameAr.ifBlank { "— بدون اسم عربي —" }
            textSize = 15f
            alpha = 0.9f
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            setTextIsSelectable(true)
        })
        para(head, "${Labels.status[item.status] ?: item.status}   •   ${Labels.decision[item.decision] ?: item.decision}" +
            (if (item.tag.isNotBlank()) "   •   #${item.tag}" else ""))
        para(head, "الكود مرتبط باسمه الأجنبي ولا يُحذف أو يتغيّر أو يُفصل عنه.", muted())

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(8), 0, 0)
        }
        buttons.addView(MaterialButton(this).apply {
            text = "تعديل / قرار"
            setOnClickListener { showEdit(item) }
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dp(6) }
        })
        buttons.addView(MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = "تعليق"
            setOnClickListener { showComment() }
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dp(6) }
        })
        buttons.addView(MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = if (item.fav) "★ مفضلة" else "☆ مفضلة"
            setOnClickListener { db.setFav(code, !item.fav); setResult(RESULT_OK); render() }
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
        })
        head.addView(buttons)

        // ماذا حدث لهذا الصنف؟
        val why = card()
        title(why, "ماذا حدث لهذا الصنف؟")
        val explanation = when {
            item.decision == "remove" && item.status == "similar" -> "مستبعد لأنه تكرار تقريبي لصنف آخر (الاسم نفسه بكتابة مختلفة). ${item.removalReason}"
            item.decision == "remove" -> "مستبعد من القائمة المحدّثة. ${item.removalReason}"
            item.status == "duplicate" -> "صنف مكرر مُبقى (أول كود في مجموعة التكرار). الأصناف المطابقة له مستبعدة وأكوادها محفوظة."
            item.status == "similar" -> "اسمه يشبه صنفًا آخر بنفس التركيز والعبوة (فرق إملائي). لم يُحذف؛ راجع المرتبطات أدناه ثم قرّر."
            item.status == "missing_name" -> "لا يوجد اسم أجنبي لهذا الكود في القائمة الأصلية. لا يُخمَّن اسم أجنبي؛ أضفه من «تعديل» بعد التحقق وسيرتبط بالكود نهائيًا."
            item.isDevice -> "مصنّف جهازًا/مستلزمًا تعويضيًا ومنقول إلى قسم الأجهزة."
            else -> "سليم — لا ملاحظات."
        }
        para(why, explanation)
        if (item.reviewerNote.isNotBlank()) para(why, "ملاحظة المراجعة: ${item.reviewerNote}", muted())

        if (Labels.isAuto(item.nameSrc)) {
            val how = if (item.nameSrc == "auto_dict") "من قاموس مبني على أسماء الشيت نفسه" else "بنقل صوتي تقريبي من الإنجليزية"
            para(why, "الاسم العربي مقترح آليًا ($how). راجعه ثم اعتمده أو عدّله.", muted())
            button(why, "اعتماد الاسم العربي") { db.approveName(code); setResult(RESULT_OK); render() }
        }
        if (Labels.isAutoClass(item.classSrc)) {
            para(why, "التصنيف «${item.therapeuticClass}» مقترح آليًا (${Labels.classHow(item.classSrc)}). راجعه ثم اعتمده أو عدّله.", muted())
            button(why, "اعتماد التصنيف") {
                val n = db.approveClass(code)
                if (n > 0) toast("اعتُمد، وعُمّم كاقتراح على $n من أشقائه غير المصنّفين")
                setResult(RESULT_OK); render()
            }
        }
        if (item.devSrc == "auto") {
            para(why, "صُنّف جهازًا بالبحث الشامل (${item.deviceType}). اعتمده أو أعده إلى قسم الأدوية.", muted())
            button(why, "اعتماد كجهاز") { db.approveDevice(code); setResult(RESULT_OK); render() }
            button(why, "إعادته إلى الأدوية", true) { db.moveItems(listOf(code), false); setResult(RESULT_OK); render() }
        }
        if (item.flag == "fixed") {
            para(why, "الاسم العربي السابق «${orig?.nameAr ?: ""}» لم يكن يخص هذا الاسم الأجنبي (الاسم الأجنبي هو المرجع) فاستُبدل. لا شيء مفقود: السابق محفوظ هنا وفي «الأصلية» وفي السجل.", muted())
            button(why, "تم التحقق") { db.approveFor("flag", code); setResult(RESULT_OK); render() }
        }
        if (item.flag == "mismatch") {
            para(why, "قد لا يخص الاسم العربي هذا الاسم الأجنبي. راجعه: إن كان صحيحًا اضغط «الاسم صحيح»، وإلا عدّله.", muted())
            button(why, "الاسم صحيح") { db.approveFor("flag", code); setResult(RESULT_OK); render() }
        }
        if (item.status == "similar" && item.decision != "remove") {
            button(why, "ليسا نفس الدواء") { db.approveFor("similar", code); setResult(RESULT_OK); render() }
        }

        // ما ارتبط به وما حدث
        val rel = card()
        title(rel, "ما ارتبط به وما حدث")
        val links = db.linksFor(code)
        if (links.isEmpty()) para(rel, "لا توجد أصناف حُذفت أو تشابهت مع هذا الصنف.", muted())
        for (l in links) {
            val name = l.otherEn.ifBlank { l.otherAr }
            val kindLabel = Labels.kind[l.kind] ?: l.kind
            val text = when {
                l.kind == "similar" -> "≈ $kindLabel: ${l.otherCode} · $name" + (if (l.note.isNotBlank()) "  (${l.note})" else "")
                l.iAmKeeper -> "حُذف ($kindLabel) وكوده محفوظ: ${l.otherCode} · $name"
                else -> "الصحيح المُبقى ($kindLabel): ${l.otherCode} · $name"
            }
            linkRow(rel, text, l.otherCode, if (!l.iAmKeeper && l.kind != "similar") 0xFF2E7D32.toInt() else primary)
        }

        // البدائل: المادة الفعّالة والقوة نفسهما
        val alts = db.alternatives(item)
        if (alts.isNotEmpty()) {
            title(rel, "بدائل (${item.generic} ${item.strength})")
            for (a in alts) linkRow(rel, "${a.code} · ${a.nameEn.ifBlank { a.nameAr }}" + (if (a.dosageForm.isNotBlank()) "  [${a.dosageForm}]" else ""), a.code, primary)
        } else if (item.generic.isBlank() && !item.isDevice) {
            para(rel, "لا مادة فعّالة مسجّلة لهذا الصنف بعد؛ تُملأ من قاعدة الأدوية المصرية فتظهر البدائل هنا.", muted())
        }

        // تراكيز أخرى لنفس الدواء
        if (item.family.isNotBlank()) {
            val n = db.familyCount(item.family)
            if (n > 1) {
                para(rel, "الدواء «${item.family}» له $n تركيز/عبوة.", muted())
                button(rel, "عرض كل التراكيز", true) {
                    startActivity(
                        Intent(this, FamilyActivity::class.java).putExtra("family", item.family)
                            .putExtra("scope", if (item.isDevice) Scope.DEVICES.name else Scope.CURATED.name)
                    )
                }
            }
        }

        // الحقول
        val f = card()
        title(f, "البيانات")
        row(f, "الدواء (العائلة)", item.family)
        row(f, "التركيز / العبوة", item.variant)
        row(f, "المادة الفعّالة", item.generic)
        row(f, "القوة", item.strength)
        row(f, "العبوة", item.pack)
        row(f, "التركيز (عمود)", item.concentration)
        row(f, "الشكل الدوائي", item.dosageForm)
        row(f, "التصنيف العلاجي", item.therapeuticClass)
        row(f, "جهاز تعويضي", if (item.isDevice) "نعم — ${item.deviceType}" else "لا")
        row(f, "الاسم الصحيح", item.correctedName)
        row(f, "سبب الحذف", item.removalReason)
        row(f, "مجموعة المراجعة", item.reviewGroup)

        // ما اختلف عن النسخة الأصلية
        if (orig != null && (orig.nameAr != item.nameAr || orig.nameEn != item.nameEn || orig.concentration != item.concentration ||
                orig.therapeuticClass != item.therapeuticClass || orig.dosageForm != item.dosageForm)) {
            val o = card()
            title(o, "النسخة الأصلية (قبل التعديل)")
            row(o, "الاسم العربي", orig.nameAr)
            row(o, "الاسم الأجنبي", orig.nameEn)
            row(o, "التركيز", orig.concentration)
            row(o, "الشكل الدوائي", orig.dosageForm)
            row(o, "التصنيف العلاجي", orig.therapeuticClass)
        }

        // السجل مع التراجع
        val log = card()
        title(log, "سجل المراجعة")
        val acts = db.activities(code)
        if (acts.isEmpty()) para(log, "لا يوجد سجل بعد.", muted())
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
        for (a in acts) {
            val line = if (a.action == "comment") a.note
            else "${Labels.field[a.field] ?: a.field}: ${a.oldValue.ifBlank { "—" }}  ←  ${a.newValue.ifBlank { "—" }}" +
                (if (a.note.isNotBlank()) "\n${a.note}" else "")
            para(log, "${Labels.action[a.action] ?: a.action} • ${fmt.format(Date(a.ts))}", muted())
            para(log, line)
            if (Db.canUndo(a)) {
                button(log, "تراجع عن هذا التعديل", true) {
                    val msg = db.undo(a.id)
                    toast(msg ?: "تم التراجع")
                    if (msg == null) setResult(RESULT_OK)
                    render()
                }
            }
            log.addView(View(this).apply {
                setBackgroundColor(0x22808080)
                layoutParams = LinearLayout.LayoutParams(MATCH, 1).apply { topMargin = dp(6); bottomMargin = dp(6) }
            })
        }
        finishUi()
    }

    // ---------- التعديل (متاح دائمًا) ----------
    private fun showEdit(item: Item) {
        val fields = ArrayList<Pair<String, String>>()
        fields += "name_ar" to "الاسم العربي"
        // الاسم الأجنبي ملتصق بالكود: يظهر للتعديل فقط إن كان فارغًا (لإكماله).
        if (item.nameEn.isBlank()) fields += "name_en" to "الاسم الأجنبي (غير موجود — أضفه بعد التحقق)"
        fields += "concentration" to "التركيز / الحجم"
        fields += "dosage_form" to "الشكل الدوائي (اضغط للاختيار)"
        fields += "therapeutic_class" to "التصنيف العلاجي (اضغط للاختيار)"
        fields += "device_type" to "نوع الجهاز (إن وُجد)"
        fields += "corrected_name" to "الاسم الصحيح بعد المراجعة"
        fields += "removal_reason" to "سبب الحذف / ملاحظة القرار"
        fields += "tag" to "وسم (كلمة للبحث والمتابعة)"
        val values = mapOf(
            "name_ar" to item.nameAr, "name_en" to item.nameEn, "concentration" to item.concentration,
            "dosage_form" to item.dosageForm, "therapeutic_class" to item.therapeuticClass,
            "device_type" to item.deviceType, "corrected_name" to item.correctedName,
            "removal_reason" to item.removalReason, "tag" to item.tag
        )
        val form = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(8))
        }
        form.addView(TextView(this).apply {
            text = "${item.code} · ${item.nameEn.ifBlank { "—" }}"
            textDirection = View.TEXT_DIRECTION_LTR
            alpha = 0.7f
            setPadding(0, 0, 0, dp(8))
        })
        val edits = LinkedHashMap<String, EditText>()
        for ((k, label) in fields) {
            val e = EditText(this).apply {
                hint = label
                setText(values[k] ?: "")
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            }
            if (k == "therapeutic_class" || k == "dosage_form") {
                e.isFocusable = false
                e.setOnClickListener {
                    val cls = (if (k == "dosage_form") db.forms() else db.classes()).toTypedArray()
                    MaterialAlertDialogBuilder(this)
                        .setTitle(if (k == "dosage_form") "الشكل الدوائي" else "التصنيف العلاجي")
                        .setItems(cls) { _, i -> e.setText(cls[i]) }
                        .setNegativeButton("إلغاء", null)
                        .showStyled()
                }
            }
            edits[k] = e
            form.addView(e)
        }
        val keys = Labels.decision.keys.toList()
        val spinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@DetailActivity, android.R.layout.simple_spinner_dropdown_item, keys.map { Labels.decision[it] ?: it })
            setSelection(keys.indexOf(item.decision).coerceAtLeast(0))
        }
        form.addView(TextView(this).apply { text = "القرار"; setPadding(0, dp(12), 0, 0) })
        form.addView(spinner)

        MaterialAlertDialogBuilder(this)
            .setTitle("تعديل الصنف ${item.code}")
            .setView(ScrollView(this).apply { addView(form) })
            .setPositiveButton("حفظ") { _, _ ->
                val m = HashMap<String, String>()
                for ((k, e) in edits) m[k] = e.text.toString()
                m["decision"] = keys[spinner.selectedItemPosition]
                val n = db.update(item.code, m)
                if (n > 0 && m["therapeutic_class"]?.trim().orEmpty() != item.therapeuticClass) {
                    val p = db.propagateClass(item.code)
                    if (p > 0) toast("عُمّم التصنيف كاقتراح على $p من أشقائه")
                }
                if (n > 0) {
                    setResult(RESULT_OK)
                    toast("تم حفظ $n تعديل")
                }
                render()
            }
            .setNegativeButton("إلغاء", null)
            .showStyled()
    }

    private fun showComment() {
        val e = EditText(this).apply {
            hint = "اكتب تعليقك أو ملاحظة المراجعة…"
            minLines = 3
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }
        val box = LinearLayout(this).apply {
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(e, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("إضافة تعليق")
            .setView(box)
            .setPositiveButton("إضافة") { _, _ ->
                db.addComment(code, e.text.toString())
                setResult(RESULT_OK)
                render()
            }
            .setNegativeButton("إلغاء", null)
            .showStyled()
    }
}
