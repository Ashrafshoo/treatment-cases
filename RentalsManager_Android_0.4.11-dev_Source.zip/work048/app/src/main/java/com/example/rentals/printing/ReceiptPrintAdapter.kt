package com.example.rentals.printing

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import com.example.rentals.data.ReceiptRecord
import java.util.Locale

/** Prints the supplied original receipt artwork (old-law or clean/new template) on A4. */
class ReceiptPrintAdapter(
    private val context: Context,
    private val receipts: List<ReceiptRecord>,
    private val perPage: Int = 3,
    private val marginMm: Float = 5f,
    private val oldLawTemplate: Boolean = true
) : PrintDocumentAdapter() {
    private var pageCount = 0
    private val slotBitmaps = mutableMapOf<Int, android.graphics.Bitmap>()

    override fun onLayout(oldAttributes: PrintAttributes?, newAttributes: PrintAttributes,
        cancellationSignal: android.os.CancellationSignal, callback: LayoutResultCallback, extras: Bundle?) {
        pageCount = (receipts.size + perPage.coerceIn(1, 3) - 1) / perPage.coerceIn(1, 3)
        val info = PrintDocumentInfo.Builder("إيصالات الإيجار.pdf")
            .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).setPageCount(pageCount).build()
        callback.onLayoutFinished(info, true)
    }

    override fun onWrite(pages: Array<out PageRange>, destination: android.os.ParcelFileDescriptor,
        cancellationSignal: android.os.CancellationSignal, callback: WriteResultCallback) {
        val doc = PdfDocument()
        try {
            for (page in 0 until pageCount) {
                if (cancellationSignal.isCanceled) { callback.onWriteCancelled(); return }
                val info = PdfDocument.PageInfo.Builder(595, 842, page + 1).create()
                val pdfPage = doc.startPage(info)
                drawPage(pdfPage.canvas, page)
                doc.finishPage(pdfPage)
            }
            java.io.FileOutputStream(destination.fileDescriptor).use { doc.writeTo(it) }
            callback.onWriteFinished(arrayOf(PageRange(0, pageCount - 1)))
        } catch (e: Exception) {
            callback.onWriteFailed(e.message ?: "تعذر إنشاء ملف PDF")
        } finally {
            doc.close()
            slotBitmaps.values.forEach { it.recycle() }
            slotBitmaps.clear()
        }
    }

    private fun template(slot: Int): android.graphics.Bitmap {
        return slotBitmaps.getOrPut(slot) {
            val suffix = (slot + 1).coerceIn(1, 3)
            val name = "receipt_${if (oldLawTemplate) "old" else "new"}_$suffix"
            val id = context.resources.getIdentifier(name, "drawable", context.packageName)
            require(id != 0) { "قالب الإيصال غير موجود: $name" }
            BitmapFactory.decodeResource(context.resources, id)
                ?: error("تعذر تحميل قالب الإيصال: $name")
        }
    }

    private fun drawPage(canvas: Canvas, page: Int) {
        val margin = marginMm * 2.8346f
        val gap = 5f
        val count = perPage.coerceIn(1, 3)
        val cardH = (842f - 2f * margin - (count - 1) * gap) / count
        for (slot in 0 until count) {
            val index = page * count + slot
            if (index >= receipts.size) break
            val unit = receipts[index]
            val rect = RectF(margin, margin + slot * (cardH + gap), 595f - margin,
                margin + slot * (cardH + gap) + cardH)
            canvas.drawBitmap(template(slot), null, rect, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
            drawOverlay(canvas, rect, unit)
        }
    }

    /** Variable fields are drawn over the dotted blanks in the owner's original form. */
    private fun drawOverlay(c: Canvas, r: RectF, u: ReceiptRecord) {
        val ink = 0xff111111.toInt()
        val amount = u.amount?.let { String.format(Locale.US, "%.2f", it) }.orEmpty()
        // Amount box, tenant line, and property/unit lines; all other printed wording remains untouched.
        drawRtl(c, amount, r.left + r.width() * .62f, r.top + r.height() * .205f,
            r.width() * .16f, r.height() * .075f, 12f, true, ink)
        drawRtl(c, u.tenant, r.right - r.width() * .10f, r.top + r.height() * .315f,
            r.width() * .80f, r.height() * .07f, 11f, false, ink)
        drawRtl(c, "${u.property}  •  ${u.paidDate}", r.right - r.width() * .12f, r.top + r.height() * .505f,
            r.width() * .53f, r.height() * .065f, 9f, false, ink)
        val unitDescription = listOf("إيصال ${u.receiptNo}", "عن فترة ${u.period}", u.unitCode)
            .filter { it.isNotBlank() }.joinToString(" – ")
        drawRtl(c, unitDescription, r.right - r.width() * .12f, r.top + r.height() * .585f,
            r.width() * .58f, r.height() * .065f, 9f, false, ink)
    }

    private fun drawRtl(c: Canvas, text: String, right: Float, top: Float, width: Float,
        maxHeight: Float, size: Float, bold: Boolean, color: Int) {
        if (text.isBlank()) return
        val p = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            textSize = size
            typeface = Typeface.create("sans-serif", if (bold) Typeface.BOLD else Typeface.NORMAL)
        }
        val safe = text.take(100)
        val layout = StaticLayout.Builder.obtain(safe, 0, safe.length, p, width.toInt().coerceAtLeast(40))
            .setAlignment(Layout.Alignment.ALIGN_OPPOSITE)
            .setTextDirection(TextDirectionHeuristics.RTL)
            .setIncludePad(false).setMaxLines(2).build()
        c.save()
        c.translate(right - width, top)
        layout.draw(c)
        c.restore()
    }
}
