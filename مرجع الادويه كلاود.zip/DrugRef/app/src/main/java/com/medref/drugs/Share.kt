package com.medref.drugs

import android.content.ClipData
import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Share {

    private fun dir(ctx: Context) = File(ctx.cacheDir, "shared").apply { mkdirs() }

    fun file(ctx: Context, f: File, mime: String, title: String) {
        Lock.pause()
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            clipData = ClipData.newRawUri("", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(send, title))
    }

    /** يشارك ملف الـAPK الخاص بالتطبيق المثبَّت نفسه. */
    fun apk(ctx: Context) {
        val out = File(dir(ctx), "DrugRef.apk")
        File(ctx.applicationInfo.sourceDir).copyTo(out, overwrite = true)
        file(ctx, out, "application/vnd.android.package-archive", "مشاركة ملف التثبيت")
    }

    private fun esc(s: String): String =
        if (s.any { it == ',' || it == '"' || it == '\n' || it == '\r' }) "\"" + s.replace("\"", "\"\"") + "\"" else s

    private fun writeCsv(ctx: Context, name: String, header: List<String>, rows: List<List<String>>): File {
        val f = File(dir(ctx), name)
        f.bufferedWriter(Charsets.UTF_8).use { w ->
            w.write("\uFEFF") // BOM ليفتح Excel العربية صحيحة
            w.write(header.joinToString(",") + "\r\n")
            for (r in rows) w.write(r.joinToString(",") { esc(it) } + "\r\n")
        }
        return f
    }

    /** الكود والاسم الأجنبي دائمًا أول عمودين وملتصقان: هما مفتاح الاستيراد. */
    val ITEM_HEADER = listOf(
        "item_code", "name_en", "name_ar", "concentration", "dosage_form", "therapeutic_class",
        "is_device", "device_type", "status", "review_group", "decision", "removal_reason",
        "corrected_name", "reviewer_note", "name_src", "class_src", "dev_src", "flag", "fav", "tag",
        "family", "variant"
    )

    private fun rowOf(it: Item) = listOf(
        it.code.toString(), it.nameEn, it.nameAr, it.concentration, it.dosageForm, it.therapeuticClass,
        if (it.isDevice) "1" else "0", it.deviceType, it.status, it.reviewGroup, it.decision,
        it.removalReason, it.correctedName, it.reviewerNote, it.nameSrc, it.classSrc, it.devSrc, it.flag,
        if (it.fav) "1" else "0", it.tag, it.family, it.variant
    )

    fun exportItems(ctx: Context, db: Db, scope: Scope): File {
        val items = db.search(scope, "", null, Int.MAX_VALUE, 0)
        return writeCsv(ctx, "DrugRef-${scope.name.lowercase()}.csv", ITEM_HEADER, items.map { rowOf(it) })
    }

    fun exportAll(ctx: Context, db: Db): File =
        writeCsv(ctx, "DrugRef-all.csv", ITEM_HEADER, db.allCurrent().map { rowOf(it) })

    fun exportAllXlsx(ctx: Context, db: Db): File {
        val f = File(dir(ctx), "DrugRef-all.xlsx")
        Xlsx.write(f, "DrugRef", ITEM_HEADER, db.allCurrent().map { rowOf(it) })
        return f
    }

    fun exportMissing(ctx: Context, db: Db): File =
        writeCsv(ctx, "DrugRef-missing-codes.csv", listOf("missing_code"), db.missingCodes().map { listOf(it.toString()) })

    fun exportPdf(ctx: Context, db: Db): File = PdfReport.build(ctx, db)

    fun exportLog(ctx: Context, db: Db): File {
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
        val rows = db.allActivities().map {
            listOf(it[0], it[1], it[2], it[3], it[4], it[5], fmt.format(Date(it[6].toLong())))
        }
        return writeCsv(ctx, "DrugRef-log.csv", listOf("item_code", "action", "field", "old_value", "new_value", "note", "time"), rows)
    }

    /** نسخة كاملة من قاعدة البيانات (القائمة العاملة + الأصلية + السجل). */
    fun backup(ctx: Context): File {
        val stamp = SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date())
        val out = File(dir(ctx), "DrugRef-backup-$stamp.db")
        Db.dbFile(ctx).copyTo(out, overwrite = true)
        return out
    }
}
