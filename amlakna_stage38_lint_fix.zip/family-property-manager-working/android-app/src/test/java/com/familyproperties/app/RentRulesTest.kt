package com.familyproperties.app

import org.junit.Assert.assertEquals
import org.junit.Test
import java.math.BigDecimal
import java.time.LocalDate

class RentRulesTest {
    @Test fun residentialMinimumBeforeSeptember() {
        assertEquals(BigDecimal("250.00"), RentRules.law164ResidentialRent(BigDecimal("100"), LocalDate.of(2026, 8, 1)))
    }
    @Test fun residentialIncreaseFromSeptember() {
        assertEquals(BigDecimal("287.50"), RentRules.law164ResidentialRent(BigDecimal("250"), LocalDate.of(2026, 9, 1)))
    }
    @Test fun residentialIncreaseIsNotRepeatedAfterItWasAppliedThisYear() {
        assertEquals(BigDecimal("287.50"), RentRules.law164ResidentialRent(
            BigDecimal("287.50"), LocalDate.of(2026, 10, 1), LocalDate.of(2026, 9, 1)
        ))
    }
    @Test fun residentialIncreaseCanApplyAgainInFollowingYear() {
        assertEquals(BigDecimal("330.63"), RentRules.law164ResidentialRent(
            BigDecimal("287.50"), LocalDate.of(2027, 9, 1), LocalDate.of(2026, 9, 1)
        ))
    }
    @Test fun commercialHasNoResidentialMinimumOrAutomaticIncrease() {
        assertEquals(BigDecimal("100.00"), RentRules.commercialRent(BigDecimal("100")))
    }
    @Test fun remainingCannotBeNegative() {
        assertEquals(BigDecimal("0.00"), RentRules.remaining(BigDecimal("100"), BigDecimal("120")))
    }
    @Test fun netIncomeSubtractsExpensesFromCollections() {
        assertEquals(BigDecimal("750.00"), RentRules.netIncome(BigDecimal("1000"), BigDecimal("250")))
    }
}
