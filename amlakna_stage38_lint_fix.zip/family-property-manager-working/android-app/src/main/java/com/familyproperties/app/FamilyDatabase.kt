package com.familyproperties.app

import android.content.Context
import net.zetetic.database.sqlcipher.SQLiteDatabase
import net.zetetic.database.sqlcipher.SQLiteOpenHelper
import com.familyproperties.app.security.DatabaseKeyStore
import java.io.File

/** SQLCipher-backed helper. Database upgrades are explicit and never destructive. */
class FamilyDatabase private constructor(
    context: Context,
    passphrase: ByteArray
) : SQLiteOpenHelper(
    context.applicationContext,
    DATABASE_NAME,
    passphrase,
    null,
    DATABASE_VERSION,
    0,
    null,
    null,
    true
) {
    private val appContext = context.applicationContext

    override fun onConfigure(db: SQLiteDatabase) {
        db.setForeignKeyConstraintsEnabled(true)
        db.execSQL("PRAGMA cipher_memory_security = ON")
    }

    override fun onCreate(db: SQLiteDatabase) {
        executeAssetScript(db, "database/001_initial_schema.sql")
        executeAssetScript(db, "database/005_relationship_financial_integrity.sql")
        executeAssetScript(db, "database/006_active_lease_integrity.sql")
        executeAssetScript(db, "database/007_fresh_install_policy.sql")
        executeAssetScript(db, "database/008_archive_indexes.sql")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 5 && newVersion >= 5) {
            executeAssetScript(db, "database/005_relationship_financial_integrity.sql")
        }
        if (oldVersion < 6 && newVersion >= 6) {
            executeAssetScript(db, "database/006_active_lease_integrity.sql")
        }
        if (oldVersion < 7 && newVersion >= 7) {
            executeAssetScript(db, "database/007_law164_policy_separation.sql")
        }
        if (oldVersion < 8 && newVersion >= 8) {
            executeAssetScript(db, "database/008_archive_indexes.sql")
        }
        if (newVersion > DATABASE_VERSION) {
            throw IllegalStateException("Unsupported database migration: $oldVersion -> $newVersion")
        }
    }

    override fun onDowngrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        throw IllegalStateException("Database downgrade is blocked to protect family data: $oldVersion -> $newVersion")
    }

    private fun executeAssetScript(db: SQLiteDatabase, assetPath: String) {
        val script = appContext.assets.open(assetPath).bufferedReader(Charsets.UTF_8).use { it.readText() }
        val statement = StringBuilder()
        var triggerStatement = false
        script.lineSequence().forEach { line ->
            val trimmed = line.trim()
            if (trimmed.isEmpty() || trimmed.startsWith("--")) return@forEach
            statement.append(line).append('\n')
            val accumulated = statement.toString()
            if (!triggerStatement && Regex("(?i)^CREATE\\s+TRIGGER\\b").containsMatchIn(accumulated.trimStart())) {
                triggerStatement = true
            }
            // Trigger bodies contain internal semicolons. Wait for the trigger's final END;
            // but keep supporting the existing one-line trigger definitions.
            val triggerFinished = triggerStatement && (
                trimmed.equals("END;", ignoreCase = true) ||
                    (trimmed.contains("BEGIN", ignoreCase = true) && trimmed.endsWith("END;", ignoreCase = true) && trimmed.count { it == ';' } >= 2)
                )
            if ((!triggerStatement && trimmed.endsWith(";")) || triggerFinished) {
                val sql = statement.toString().trim().removeSuffix(";").trim()
                if (sql.isNotEmpty() && !sql.startsWith("PRAGMA foreign_keys", ignoreCase = true)) {
                    db.execSQL(sql)
                }
                statement.clear()
                triggerStatement = false
            }
        }
        check(statement.isEmpty()) { "Incomplete SQL statement in $assetPath" }
    }

    companion object {
        private const val DATABASE_NAME = "family_properties.db"
        private const val DATABASE_VERSION = 8
        private const val SQLITE_HEADER = "SQLite format 3\u0000"

        /** Must be called after the native SQLCipher library is loaded. */
        fun create(context: Context): FamilyDatabase {
            System.loadLibrary("sqlcipher")
            val appContext = context.applicationContext
            val databaseFile = appContext.getDatabasePath(DATABASE_NAME)
            if (isPlaintextSqlite(databaseFile)) {
                throw IllegalStateException(
                    "An older unencrypted database was found. It has not been changed or deleted; " +
                        "a verified encrypted migration is required before continuing."
                )
            }
            val passphrase = DatabaseKeyStore(appContext)
                .getOrCreateDatabasePassphrase(databaseFile.exists())
            return FamilyDatabase(appContext, passphrase)
        }

        private fun isPlaintextSqlite(file: File): Boolean {
            if (!file.isFile || file.length() < SQLITE_HEADER.length) return false
            val header = ByteArray(SQLITE_HEADER.length)
            return file.inputStream().use { input ->
                if (input.read(header) != header.size) false
                else header.contentEquals(SQLITE_HEADER.toByteArray(Charsets.US_ASCII))
            }
        }
    }
}
