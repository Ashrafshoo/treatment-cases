from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
local_db = (ROOT / 'android/app/src/main/java/com/treatmentcases/app/LocalDb.kt').read_text()
main = (ROOT / 'android/app/src/main/java/com/treatmentcases/app/MainActivity.kt').read_text()
backup = (ROOT / 'android/app/src/main/java/com/treatmentcases/app/EncryptedBackup.kt').read_text()
build = (ROOT / 'android/app/build.gradle').read_text()
checks = {
 'shared restore preflight exists': 'fun restoreBundleIssues(bundle:BackupBundle):List<String>' in local_db,
 'case validation included': 'CaseDataRules.validate(bundle.cases)' in local_db,
 'medicine-name review included': 'medicineNameReviewIssues(bundle.cases)' in local_db,
 'catalog near-match warnings included': 'catalogNameIssues' in local_db,
 'employee import validation included': 'planEmployeeImport(bundle.employees).issues' in local_db,
 'restore transaction reuses preflight': 'val preflightIssues=restoreBundleIssues(bundle)' in local_db,
 'restore preview uses same preflight': 'val restoreIssues=db.restoreBundleIssues(bundle)' in main,
 'restore button disabled on any issue': 'enabled=restoreIssues.isEmpty()' in main,
 'backup manifest counts verified': 'عدد سجلات الحالات لا يطابق بيان النسخة الاحتياطية' in backup and 'عدد العيارات لا يطابق بيان النسخة الاحتياطية' in backup,
 'backup metadata updated': '.put("app_version", "2.7.5-dev")' in backup,
 'version code incremented': 'versionCode 31' in build and "versionName '2.7.5-dev'" in build,
 'isolated preview id': 'com.treatmentcases.app.preview275' in build,
 'interactive medicine catalog preserved': 'strengthSummary' in main and 'مستفيد' in main,
}
for name, ok in checks.items(): print(('PASS' if ok else 'FAIL') + ' - ' + name)
assert all(checks.values()), 'Restore safety verification failed'
print(f'{len(checks)} assertions passed')
