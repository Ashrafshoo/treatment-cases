package com.example.rentals.features.review

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.rentals.data.RentalsDb
import com.example.rentals.data.UnitRecord
import com.example.rentals.data.LegacyImportRecord
import com.example.rentals.data.LegacyUnitReviewAnalyzer
import com.example.rentals.data.LegacyReceiptMatchAnalyzer
import com.example.rentals.data.ReviewFlag
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.example.rentals.ui.components.MetricCard
import com.example.rentals.ui.components.PremiumScreenHeader

private data class ReviewScreenData(
    val flags: List<ReviewFlag> = emptyList(),
    val counts: Map<String,Int> = emptyMap(),
    val staged: List<LegacyImportRecord> = emptyList(),
    val approvedContractCount: Int = 0,
    val archivedContracts: List<RentalsDb.LegacyContractArchiveRow> = emptyList(),
    val unitCandidates: List<LegacyUnitReviewAnalyzer.Result> = emptyList(),
    val receiptMatches: List<LegacyReceiptMatchAnalyzer.Result> = emptyList(),
    val approvedUnitRecords: List<LegacyImportRecord> = emptyList(),
    val approvedUniqueUnitCount: Int = 0
)

@Composable fun ReviewScreen(db:RentalsDb,units:List<UnitRecord>){
    var refresh by remember{mutableIntStateOf(0)}
    var search by remember{mutableStateOf("")}
    var statusFilter by remember{mutableStateOf("all")}
    var typeFilter by remember{mutableStateOf("all")}
    var expandedId by remember{mutableStateOf<Long?>(null)}
    var noteRecord by remember{mutableStateOf<com.example.rentals.data.LegacyImportRecord?>(null)}
    var noteText by remember{mutableStateOf("")}
    var message by remember{mutableStateOf("")}
    var loadError by remember{mutableStateOf("")}
    var loading by remember{mutableStateOf(true)}
    var data by remember { mutableStateOf(ReviewScreenData()) }
    var confirmLegacyMigration by remember{mutableStateOf(false)}
    var confirmAutomaticMigration by remember{mutableStateOf(false)}
    var confirmContractArchive by remember{mutableStateOf(false)}
    var linkingArchiveId by remember{mutableLongStateOf(0L)}
    var selectedLinkUnitId by remember{mutableStateOf("")}
    var contractLinkNote by remember{mutableStateOf("")}
    var confirmUnlinkArchiveId by remember{mutableLongStateOf(0L)}
    var unlinkReason by remember{mutableStateOf("")}

    LaunchedEffect(refresh,search,statusFilter,typeFilter,units) {
        loading = true
        loadError = ""
        try {
            val loaded = withContext(Dispatchers.IO) {
                val allRecords = db.legacyImportRecords()
                val currentUnits = db.units()
                val codes = currentUnits.map { it.code }.filter { it.isNotBlank() }.toSet()
                val matches = LegacyReceiptMatchAnalyzer.analyze(allRecords)
                val approvedUnits = db.legacyImportRecords(status="approved_for_mapping",recordType="unit_source")
                val approvedCount = db.legacyImportRecords(recordType="lease_source").count { it.status == "approved_for_mapping" }
                val uniqueCount = approvedUnits.count { record ->
                    val code = runCatching { org.json.JSONObject(record.rawJson).optString("معرّف السجل",record.sourceRecordId) }.getOrDefault(record.sourceRecordId)
                    code !in codes && matches.any { it.sourceImportId==record.id && it.matchStatus==LegacyReceiptMatchAnalyzer.MatchStatus.UNIQUE_SOURCE_MATCH }
                }
                ReviewScreenData(
                    flags=db.reviewFlags(),
                    counts=db.legacyImportCounts(),
                    staged=db.legacyImportRecords(status=statusFilter.takeIf{it!="all"},recordType=typeFilter.takeIf{it!="all"},query=search.trim()),
                    approvedContractCount=approvedCount,
                    archivedContracts=db.legacyContractArchive(),
                    unitCandidates=LegacyUnitReviewAnalyzer.analyze(db.legacyImportRecords(recordType="unit_source"),codes),
                    receiptMatches=matches,
                    approvedUnitRecords=approvedUnits,
                    approvedUniqueUnitCount=uniqueCount
                )
            }
            data = loaded
        } catch (e: Exception) {
            loadError = e.message ?: "تعذر تحميل بيانات مركز المراجعة"
        } finally { loading = false }
    }
    val flags=data.flags
    val counts=data.counts
    val staged=data.staged
    val approvedContractCount=data.approvedContractCount
    val archivedContracts=data.archivedContracts
    val unitCandidates=data.unitCandidates
    val unitClassCounts=remember(unitCandidates){unitCandidates.groupingBy{it.classification}.eachCount()}
    val receiptMatches=data.receiptMatches
    val uniqueReceiptMatches=receiptMatches.count{it.matchStatus==LegacyReceiptMatchAnalyzer.MatchStatus.UNIQUE_SOURCE_MATCH}
    val ambiguousReceiptMatches=receiptMatches.filter{it.matchStatus==LegacyReceiptMatchAnalyzer.MatchStatus.AMBIGUOUS_GROUP}
    val approvedUnitRecords=data.approvedUnitRecords
    val approvedUniqueUnitCount=data.approvedUniqueUnitCount
    val totalStaged=counts.values.sum()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
        PremiumScreenHeader("مركز المراجعة والترحيل الآمن", "جودة البيانات والمطابقة والمراجعة قبل أي ترحيل", Icons.Default.FactCheck)
        if(loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        if(loadError.isNotBlank()) Text("تعذر تحميل مركز المراجعة: $loadError",color=MaterialTheme.colorScheme.error)
        Row(verticalAlignment=Alignment.CenterVertically){Text("مراجعة نواقص التشغيل",fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f));IconButton(onClick={refresh++}){Icon(Icons.Default.Refresh,"تحديث")}}
        Text("مراجعة نواقص التشغيل",fontWeight=FontWeight.Bold)
        MetricCard("بنود تحتاج مراجعة",flags.size.toString(),Icons.Default.FactCheck,Modifier.fillMaxWidth())
        Text("هذه تنبيهات بيانات وليست أحكامًا على المستأجر أو الحالة القانونية. غياب الإيصال لا يعني وحده توقف الدفع، والقيمة الفارغة لا تعني صفرًا.",color=MaterialTheme.colorScheme.onSurfaceVariant)
        if(flags.isEmpty()) Text("لا توجد نواقص من الأنواع التي يفحصها هذا المركز حاليًا.")
        flags.take(80).forEach{f->Card(Modifier.fillMaxWidth()){ListItem(headlineContent={Text(f.issue,fontWeight=FontWeight.SemiBold)},supportingContent={Text("${f.unitCode.ifBlank{"دون كود"}} • ${f.tenant.ifBlank{"مستأجر غير محدد"}}")},leadingContent={Icon(Icons.Default.WarningAmber,null,tint=MaterialTheme.colorScheme.tertiary)})}}
        HorizontalDivider(Modifier.padding(vertical=8.dp))
        Text("منطقة مراجعة ملف Q022",fontSize=19.sp,fontWeight=FontWeight.Bold)
        Text("السجلات التالية محفوظة كمصادر تاريخية خام. تغيير حالة المراجعة لا ينشئ وحدة أو عقدًا أو إيصالًا أو حركة مالية، ولا يربط أي سجل تلقائيًا.",color=MaterialTheme.colorScheme.onSurfaceVariant)
        Text("تحليل تمهيدي لسجل الوحدات",fontWeight=FontWeight.Bold)
        Text("هذا تحليل تصنيفي للمعاينة فقط؛ لا يعتمد أي سجل ولا يرحّله. السجلات ذات الحالة الفارغة لا تُعامل كنشطة تلقائيًا.",color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=12.sp)
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            MetricCard("سجلات وحدات محللة",unitCandidates.size.toString(),Icons.Default.Apartment,Modifier.weight(1f))
            MetricCard("أكواد تتعارض مع الحالي",unitCandidates.count { it.conflictsWithExistingCode }.toString(),Icons.Default.WarningAmber,Modifier.weight(1f))
        }
        unitClassCounts.entries.sortedBy { it.key.ordinal }.forEach { (kind,count) ->
            ListItem(headlineContent={Text(LegacyUnitReviewAnalyzer.label(kind))},trailingContent={Text(count.toString(),fontWeight=FontWeight.Bold)})
        }
        Text("مطابقة الوحدات بمصادر الإيصالات الأصلية",fontWeight=FontWeight.Bold)
        Text("مطابقة حرفية للاسم والقيمة ووصف العين والعنوان ومصدر البيانات. هذه مطابقة مصدرية فقط وليست إثباتًا للسداد ولا تنشئ إيصالات أو قيودًا.",color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=12.sp)
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            MetricCard("مطابقات مصدرية فريدة",uniqueReceiptMatches.toString(),Icons.Default.ReceiptLong,Modifier.weight(1f))
            MetricCard("حالات ملتبسة",ambiguousReceiptMatches.size.toString(),Icons.Default.WarningAmber,Modifier.weight(1f))
        }
        ambiguousReceiptMatches.forEach { m ->
            ListItem(headlineContent={Text("${m.unitCode} • ${m.tenant}",fontWeight=FontWeight.SemiBold)},supportingContent={Text("تتشارك أكثر من وحدة/مطابقة في نفس بيانات المصدر. صفوف الإيصالات: ${m.receiptRows.joinToString("، ")}")},leadingContent={Icon(Icons.Default.WarningAmber,null,tint=MaterialTheme.colorScheme.tertiary)})
        }
        HorizontalDivider(Modifier.padding(vertical=6.dp))
        HorizontalDivider(Modifier.padding(vertical=6.dp))
        Text("أرشفة العقود القديمة المعتمدة",fontWeight=FontWeight.Bold)
        Text("يتم نسخ بيانات العقد الأصلية كما هي إلى أرشيف مستقل غير مرتبط بوحدة. لا تُنشأ عقود تشغيلية ولا تُفسّر التواريخ أو المبالغ النصية ولا تُنشأ إيصالات أو قيود مالية. ربط العقد بوحدة سيظل إجراءً منفصلًا وصريحًا.",color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=12.sp)
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            MetricCard("عقود معتمدة للأرشفة",approvedContractCount.toString(),Icons.Default.Description,Modifier.weight(1f))
            MetricCard("عقود محفوظة بالأرشيف",archivedContracts.size.toString(),Icons.Default.FolderOpen,Modifier.weight(1f))
        }
        Button(onClick={confirmContractArchive=true},enabled=approvedContractCount>0,modifier=Modifier.fillMaxWidth()) { Text("حفظ العقود المعتمدة في الأرشيف غير المرتبط") }
        if(archivedContracts.isNotEmpty()) {
            Text("العقود المحفوظة دون ربط",fontWeight=FontWeight.SemiBold)
            archivedContracts.forEach { a ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(10.dp),verticalArrangement=Arrangement.spacedBy(3.dp)) {
                        Text("${a.sourceContractId.ifBlank { "عقد بلا معرّف" }} • ${a.sourceSheet} • صف ${a.sourceRow}",fontWeight=FontWeight.Bold)
                        Text(if(a.linkStatus=="linked_by_user") "مرتبط بوحدة باختيار المستخدم (رقم ${a.linkedUnitId})" else "أرشيف غير مرتبط بوحدة",color=MaterialTheme.colorScheme.primary)
                        Text("${a.sourceWorkbook} • ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm",java.util.Locale.getDefault()).format(java.util.Date(a.createdAt))}",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(horizontalArrangement=Arrangement.spacedBy(6.dp), verticalAlignment=Alignment.CenterVertically) {
                            OutlinedButton(onClick={linkingArchiveId=a.id;selectedLinkUnitId=(a.linkedUnitId?:units.firstOrNull()?.id)?.toString().orEmpty();contractLinkNote=""}) { Text(if(a.linkStatus=="linked_by_user") "تغيير الوحدة المرتبطة" else "اختيار وحدة لربط العقد") }
                            if(a.linkStatus=="linked_by_user") TextButton(onClick={confirmUnlinkArchiveId=a.id;unlinkReason=""}) { Text("إلغاء الربط",color=MaterialTheme.colorScheme.error) }
                        }
                        TextButton(onClick={expandedId=if(expandedId== -a.id) null else -a.id}) { Text(if(expandedId== -a.id) "إخفاء البيانات الأصلية" else "عرض البيانات الأصلية") }
                        if(expandedId== -a.id) Text(runCatching{org.json.JSONObject(a.rawJson).toString(2)}.getOrDefault(a.rawJson),fontSize=11.sp)
                    }
                }
            }
        }
        Text("استيراد أولي آمن للبيانات المؤكدة مصدريًا",fontWeight=FontWeight.Bold)
        Text("ينقل الوحدات التي لها مطابقة مصدرية فريدة فقط، ويستبعد المباعة والمغلقة والمستبعدة والتكرارات التوثيقية. تظل الوحدات بحالة غير محسومة (أو متوقفة إذا كان ذلك مثبتًا صراحة). لا ينشئ هذا الإجراء عقودًا أو إيصالات مدفوعة أو قيودًا مالية.",color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=12.sp)
        Button(onClick={confirmAutomaticMigration=true},modifier=Modifier.fillMaxWidth()) { Text("استيراد الوحدات ذات المطابقة الفريدة") }
        Text("ترحيل الوحدات المعتمدة إلى السجل التشغيلي",fontWeight=FontWeight.Bold)
        Text("الترحيل هنا تحفظي: لا يشمل إلا السجلات التي اعتمدتها فرديًا وكانت لها مطابقة إيصال مصدرية فريدة. تُنشأ الوحدة بحالة (غير محسومة)، مع حفظ الوصف والعنوان والمصدر في الملاحظات. لا يُنشأ إيصال مسودة أو إيصال مدفوع أو عقد أو قيد مالي.",color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=12.sp)
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            MetricCard("معتمدة للمطابقة",approvedUnitRecords.size.toString(),Icons.Default.FactCheck,Modifier.weight(1f))
            MetricCard("صالحة للترحيل التحفظي",approvedUniqueUnitCount.toString(),Icons.Default.Apartment,Modifier.weight(1f))
        }
        Button(onClick={confirmLegacyMigration=true},enabled=approvedUniqueUnitCount>0,modifier=Modifier.fillMaxWidth()) { Text("ترحيل الوحدات المعتمدة كغير محسومة") }
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){
            MetricCard("إجمالي المصادر",totalStaged.toString(),Icons.Default.Inventory2,Modifier.weight(1f))
            MetricCard("بانتظار المراجعة",(counts["pending_review"]?:0).toString(),Icons.Default.PendingActions,Modifier.weight(1f))
        }
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){
            MetricCard("جاهز للمطابقة",(counts["approved_for_mapping"]?:0).toString(),Icons.Default.FactCheck,Modifier.weight(1f))
            MetricCard("مستبعد",(counts["excluded"]?:0).toString(),Icons.Default.Block,Modifier.weight(1f))
        }
        OutlinedTextField(search,{search=it},modifier=Modifier.fillMaxWidth(),singleLine=true,label={Text("بحث بالمعرّف أو الورقة أو محتوى السجل")},leadingIcon={Icon(Icons.Default.Search,null)})
        Text("حالة المراجعة",fontWeight=FontWeight.SemiBold)
        Row(horizontalArrangement=Arrangement.spacedBy(5.dp)){
            FilterChip(selected=statusFilter=="all",onClick={statusFilter="all"},label={Text("الكل")})
            FilterChip(selected=statusFilter=="pending_review",onClick={statusFilter="pending_review"},label={Text("قيد المراجعة")})
            FilterChip(selected=statusFilter=="approved_for_mapping",onClick={statusFilter="approved_for_mapping"},label={Text("جاهز للمطابقة")})
            FilterChip(selected=statusFilter=="excluded",onClick={statusFilter="excluded"},label={Text("مستبعد")})
            FilterChip(selected=statusFilter=="migrated_to_review",onClick={statusFilter="migrated_to_review"},label={Text("رُحّل للمراجعة")})
            FilterChip(selected=statusFilter=="archived_unlinked",onClick={statusFilter="archived_unlinked"},label={Text("أُرشف العقد")})
        }
        Text("نوع المصدر",fontWeight=FontWeight.SemiBold)
        Row(horizontalArrangement=Arrangement.spacedBy(5.dp),modifier=Modifier.horizontalScroll(rememberScrollState())){
            listOf(
                "all" to "الكل", "unit_source" to "الوحدات", "lease_source" to "العقود",
                "lease_match_source" to "مطابقة العقود", "receipt_source" to "الإيصالات",
                "audit_source" to "التعديلات", "sold_unit_source" to "المباعة",
                "unified_statement_source" to "الكشف الموحد", "aggregate_statement_source" to "الكشف المجمع",
                "followup_source" to "النواقص والربط", "owner_answers_source" to "إجابات المالك",
                "duplicate_review_source" to "التكرار والفروق", "law164_review_source" to "مراجعة 164",
                "contract_term_review_source" to "مدد العقود", "residential_classification_source" to "تصنيف السكني",
                "rent_increase_followup_source" to "الزيادة",
                "receipt_match_q022_source" to "مطابقة Q022",
                "receipt_match_summary_q022_source" to "ملخص Q022",
                "receipt_duplicate_q022_source" to "الأسماء المكررة Q022",
                "receipt_match_followup_q022_source" to "إغلاق Q022"
            ).forEach{(value,label)->FilterChip(selected=typeFilter==value,onClick={typeFilter=value},label={Text(label)})}
        }
        Text("السجلات المعروضة: ${staged.size}${if(staged.size==1000)" (الحد الأقصى للعرض 1000)" else ""}",color=MaterialTheme.colorScheme.onSurfaceVariant)
        if(staged.isEmpty()) Text(if(totalStaged==0)"لم يتم حفظ أي سجلات Q022 بعد. استخدم استيراد Q022 من الإعدادات." else "لا توجد سجلات مطابقة للفلاتر الحالية.")
        staged.forEach{r->
            val expanded=expandedId==r.id
            val statusLabel=when(r.status){"approved_for_mapping"->"جاهز للمطابقة";"excluded"->"مستبعد من الترحيل";"migrated_to_review"->"رُحّل كوحدة غير محسومة";"archived_unlinked"->"أُرشف كعقد غير مرتبط";else->"قيد المراجعة"}
            Card(Modifier.fillMaxWidth()){
                Column(Modifier.fillMaxWidth().clickable{expandedId=if(expanded)null else r.id}.padding(12.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){
                    Row(verticalAlignment=Alignment.CenterVertically){Text("${r.sourceRecordId.ifBlank{"بلا معرّف"}} • ${r.sourceSheet}",fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f));Text("${r.sourceRow}",color=MaterialTheme.colorScheme.onSurfaceVariant)}
                    Text("${r.recordType}  |  $statusLabel",color=MaterialTheme.colorScheme.primary)
                    Text(r.reviewNote.ifBlank{"لا توجد ملاحظة مراجعة"},color=MaterialTheme.colorScheme.onSurfaceVariant)
                    if(expanded){
                        HorizontalDivider()
                        Text("الملف: ${r.sourceWorkbook}",fontSize=12.sp)
                        Text("رقم الصف: ${r.sourceRow} • الدفعة: ${r.batchId.take(8)}",fontSize=12.sp)
                        Text("البيانات المصدرية:",fontWeight=FontWeight.SemiBold)
                        Text(runCatching{org.json.JSONObject(r.rawJson).toString(2)}.getOrDefault(r.rawJson),fontSize=12.sp)
                        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){
                            OutlinedButton(onClick={noteRecord=r;noteText=r.reviewNote}){Text("تعديل الملاحظة")}
                            if(r.status!="approved_for_mapping" && r.status!="migrated_to_review" && r.status!="archived_unlinked") Button(onClick={try{db.updateLegacyImportReview(r.id,"approved_for_mapping",r.reviewNote);message="تم اعتماد السجل للمطابقة فقط، ولم يتم ترحيله.";refresh++}catch(e:Exception){message=e.message?:"تعذر تحديث الحالة"}}){Text("جاهز للمطابقة")}
                        }
                        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){
                            if(r.status!="pending_review" && r.status!="migrated_to_review" && r.status!="archived_unlinked") OutlinedButton(onClick={try{db.updateLegacyImportReview(r.id,"pending_review",r.reviewNote);refresh++}catch(e:Exception){message=e.message?:"تعذر تحديث الحالة"}}){Text("إعادة للمراجعة")}
                            if(r.status!="excluded" && r.status!="migrated_to_review" && r.status!="archived_unlinked") TextButton(onClick={try{db.updateLegacyImportReview(r.id,"excluded",r.reviewNote);message="تم استبعاد السجل من الترحيل دون حذفه.";refresh++}catch(e:Exception){message=e.message?:"تعذر تحديث الحالة"}}){Text("استبعاد من الترحيل")}
                        }
                    } else Text("اضغط لعرض البيانات المصدرية وإجراءات المراجعة",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        if(message.isNotBlank()) Text(message,color=MaterialTheme.colorScheme.primary)
    }
    if(linkingArchiveId>0){
        AlertDialog(onDismissRequest={linkingArchiveId=0L},title={Text("ربط العقد بوحدة")},text={
            Column(Modifier.fillMaxWidth().heightIn(max=420.dp),verticalArrangement=Arrangement.spacedBy(5.dp)) {
                Text("اختر الوحدة بنفسك بعد مراجعة بيانات العقد. لن يتغير اسم المستأجر أو الإيجار أو الإيصالات بسبب هذا الربط.",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
                Column(Modifier.weight(1f,fill=false).verticalScroll(rememberScrollState())) {
                    units.forEach { u ->
                        Row(Modifier.fillMaxWidth().clickable{selectedLinkUnitId=u.id.toString()}.padding(vertical=3.dp),verticalAlignment=Alignment.CenterVertically) {
                            RadioButton(selected=selectedLinkUnitId==u.id.toString(),onClick={selectedLinkUnitId=u.id.toString()})
                            Column(Modifier.weight(1f)) { Text("${u.code} • ${u.tenant}",fontWeight=FontWeight.SemiBold); Text(u.property,fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant) }
                        }
                    }
                }
                OutlinedTextField(contractLinkNote,{contractLinkNote=it},modifier=Modifier.fillMaxWidth(),label={Text("ملاحظة الربط (اختياري)")},minLines=2)
            }
        },confirmButton={TextButton(onClick={try{db.linkLegacyContractToUnit(linkingArchiveId,selectedLinkUnitId.toLong(),contractLinkNote);message="تم حفظ الربط الذي اخترته. لم تُنشأ حركة مالية أو عقد تشغيلي.";refresh++}catch(e:Exception){message="تعذر ربط العقد: ${e.message}"};linkingArchiveId=0L}){Text("حفظ الربط")}},dismissButton={TextButton(onClick={linkingArchiveId=0L}){Text("إلغاء")}})
    }
    if(confirmUnlinkArchiveId>0L){
        AlertDialog(onDismissRequest={confirmUnlinkArchiveId=0L},title={Text("تأكيد إلغاء ربط العقد")},text={
            Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
                Text("سيُزال ارتباط هذا العقد بالوحدة فقط. ستظل نسخة العقد الأصلية محفوظة في الأرشيف، ولن تتأثر الوحدة أو المستأجر أو الإيصالات أو القيود المالية.")
                OutlinedTextField(unlinkReason,{unlinkReason=it},modifier=Modifier.fillMaxWidth(),label={Text("سبب إلغاء الربط (مطلوب)")},minLines=2)
            }
        },confirmButton={TextButton(enabled=unlinkReason.isNotBlank(),onClick={try{db.unlinkLegacyContractFromUnit(confirmUnlinkArchiveId,unlinkReason.trim());message="أُلغي الربط مع الاحتفاظ بالعقد والملاحظات وسجل التدقيق.";refresh++}catch(e:Exception){message="تعذر إلغاء الربط: ${e.message}"};confirmUnlinkArchiveId=0L}){Text("تأكيد الإلغاء")}},dismissButton={TextButton(onClick={confirmUnlinkArchiveId=0L}){Text("تراجع")}})
    }
    if(confirmContractArchive){
        AlertDialog(onDismissRequest={confirmContractArchive=false},title={Text("تأكيد أرشفة العقود")},text={Text("سيتم حفظ $approvedContractCount عقدًا معتمدًا كنسخ مصدرية مستقلة في الأرشيف غير المرتبط. لن تُنشأ عقود تشغيلية أو روابط وحدات أو إيصالات أو قيود مالية. هل تريد المتابعة؟")},confirmButton={TextButton(onClick={try{val result=db.archiveApprovedLegacyContracts();message="نتيجة الأرشفة: ${result.inserted} عقد جديد، ${result.alreadyArchived} محفوظ سابقًا.";refresh++}catch(e:Exception){message="تعذرت أرشفة العقود: ${e.message}"};confirmContractArchive=false}){Text("تأكيد الأرشفة")}},dismissButton={TextButton(onClick={confirmContractArchive=false}){Text("إلغاء")}})
    }
    if(confirmAutomaticMigration){
        AlertDialog(onDismissRequest={confirmAutomaticMigration=false},title={Text("تأكيد الاستيراد الأولي الآمن")},text={Text("سيتم نقل سجلات الوحدات ذات المطابقة المصدرية الفريدة فقط. ستبقى القيم والإيجارات في حالة مراجعة، ولن تُنشأ إيصالات مدفوعة أو عقود أو قيود مالية. السجلات المباعة والمغلقة والمكررة والمستبعدة ستظل في مركز المراجعة. هل تريد المتابعة؟")},confirmButton={TextButton(onClick={try{val result=db.migrateUniquelyMatchedLegacyUnitsToReview();message="نتيجة الاستيراد: ${result.inserted} وحدة أضيفت، ${result.alreadyMigrated} سبق ترحيلها، ${result.blocked} سجلات حُجبت للمراجعة.";refresh++}catch(e:Exception){message="تعذر الاستيراد: ${e.message}"};confirmAutomaticMigration=false}){Text("تأكيد الاستيراد")}},dismissButton={TextButton(onClick={confirmAutomaticMigration=false}){Text("إلغاء")}})
    }
    if(confirmLegacyMigration){
        AlertDialog(onDismissRequest={confirmLegacyMigration=false},title={Text("تأكيد الترحيل التحفظي")},text={Text("سيتم إنشاء حتى $approvedUniqueUnitCount وحدة من السجلات المعتمدة ذات المطابقة المصدرية الفريدة. ستبقى كل وحدة بحالة (غير محسومة)، ولن تُنشأ إيصالات أو قيود مالية. هل تريد المتابعة؟")},confirmButton={TextButton(onClick={try{val result=db.migrateApprovedLegacyUnitsToReview();message="نتيجة الترحيل: ${result.inserted} وحدة جديدة، ${result.alreadyMigrated} سبق ترحيلها، ${result.blocked} سجلات لم تجتز شروط المطابقة.";refresh++}catch(e:Exception){message="تعذر الترحيل: ${e.message}"};confirmLegacyMigration=false}){Text("تأكيد الترحيل")}},dismissButton={TextButton(onClick={confirmLegacyMigration=false}){Text("إلغاء")}})
    }
    if(noteRecord!=null){
        AlertDialog(onDismissRequest={noteRecord=null},title={Text("ملاحظة المراجعة")},text={OutlinedTextField(noteText,{noteText=it},modifier=Modifier.fillMaxWidth(),minLines=3,label={Text("سبب المراجعة أو المستند المطلوب")})},confirmButton={TextButton(onClick={try{db.updateLegacyImportReview(noteRecord!!.id,noteRecord!!.status,noteText);message="تم حفظ الملاحظة";refresh++}catch(e:Exception){message=e.message?:"تعذر حفظ الملاحظة"};noteRecord=null}){Text("حفظ")}},dismissButton={TextButton(onClick={noteRecord=null}){Text("إلغاء")}})
    }
}

