# مسار البناء السحابي — Android Native

- Kotlin + Jetpack Compose فقط؛ Flutter خارج المسار نهائياً.
- GitHub Actions يجهز JDK 17 وAndroid SDK 35 وGradle 8.9.
- ملف Workflow: `.github/workflows/android-apk.yml`.
- ملف الحزمة الذي يرفعه المستخدم بعد اكتمال المشروع: `project-source.zip`.
- اختبارات Python/SQLite تسبق اختبارات Android وLint وبناء APK.
- الـ Artifact المتوقع عند نجاح البناء: `family-property-manager-native-debug`.

## إعداد أول مرة
يجب أن يكون ملف Workflow موجوداً في المستودع خارج ZIP قبل أن يستطيع GitHub تشغيله؛ GitHub لا يفك ملفات ZIP بحثاً عن workflows. أنشئ المسار `.github/workflows/android-apk.yml` مرة واحدة وانسخ إليه محتوى الملف المرفق داخل الحزمة. بعد ذلك ارفع ZIP باسم `project-source.zip` إلى جذر المستودع، ثم شغّل Workflow من تبويب Actions.

## حالة المشروع
التطبيق ما زال قيد التطوير. توجد نواة Kotlin وقاعدة بيانات SQLCipher وتسجيل دخول وصلاحيات أولية، كما أضيف أساس العقود والتحصيلات ومسودات الإيصالات. لم يُنفذ بناء Android فعلي أو اختبار على جهاز حقيقي حتى الآن. لا تستخدم بيانات العائلة الفعلية قبل اجتياز هذه الاختبارات.
