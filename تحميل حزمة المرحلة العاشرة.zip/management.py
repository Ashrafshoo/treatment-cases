"""Write-side services for the medication management app.
All mutations are transactional and recorded in Data_Audit_Log.
"""
from __future__ import annotations
import json, sqlite3, shutil, hashlib
from pathlib import Path
from datetime import datetime


def connect(path):
    c=sqlite3.connect(str(path), timeout=15)
    c.row_factory=sqlite3.Row
    c.execute('PRAGMA foreign_keys=ON')
    c.execute('PRAGMA busy_timeout=15000')
    return c


def initialize(path):
    with connect(path) as c:
        c.execute('''CREATE TABLE IF NOT EXISTS Medicine_Dictionary(
            medicine_id INTEGER PRIMARY KEY AUTOINCREMENT,
            medicine_name TEXT NOT NULL COLLATE NOCASE UNIQUE,
            active_ingredient TEXT,
            dosage_form TEXT,
            specialty TEXT,
            is_active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )''')
        c.execute('''CREATE TABLE IF NOT EXISTS Medicine_Strengths(
            strength_id INTEGER PRIMARY KEY AUTOINCREMENT,
            medicine_id INTEGER NOT NULL REFERENCES Medicine_Dictionary(medicine_id) ON DELETE CASCADE,
            strength TEXT NOT NULL,
            is_active INTEGER NOT NULL DEFAULT 1,
            UNIQUE(medicine_id,strength)
        )''')
        c.execute('CREATE INDEX IF NOT EXISTS idx_medicine_strengths_med ON Medicine_Strengths(medicine_id)')
        c.execute("""CREATE TABLE IF NOT EXISTS Medicine_Name_Aliases(
            alias_id INTEGER PRIMARY KEY AUTOINCREMENT,
            raw_alias TEXT NOT NULL UNIQUE COLLATE NOCASE,
            medicine_id INTEGER NOT NULL REFERENCES Medicine_Dictionary(medicine_id),
            created_by TEXT,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )""")
        c.execute("""CREATE TABLE IF NOT EXISTS Medicine_Review_Queue(
            review_id INTEGER PRIMARY KEY AUTOINCREMENT,
            batch_id INTEGER NOT NULL,
            medicine_name_raw TEXT NOT NULL,
            first_seen_row INTEGER,
            review_status TEXT NOT NULL DEFAULT 'PENDING',
            review_note TEXT,
            UNIQUE(batch_id,medicine_name_raw)
        )""")
        # Seed exact names/strengths already present in the approved treatment table.
        # No fuzzy merging or rewriting of source records is performed.
        try:
            c.execute('''INSERT OR IGNORE INTO Medicine_Dictionary(medicine_name)
                         SELECT DISTINCT TRIM(medicine_name_raw) FROM Treatment_Entries
                         WHERE medicine_name_raw IS NOT NULL AND TRIM(medicine_name_raw)<>'' ''')
            c.execute('''INSERT OR IGNORE INTO Medicine_Strengths(medicine_id,strength)
                         SELECT DISTINCT d.medicine_id,TRIM(t.strength_raw)
                         FROM Treatment_Entries t JOIN Medicine_Dictionary d
                           ON d.medicine_name=t.medicine_name_raw COLLATE NOCASE
                         WHERE t.strength_raw IS NOT NULL AND TRIM(t.strength_raw)<>'' ''')
        except sqlite3.OperationalError:
            # Allows initialization against a schema fixture before treatment tables exist.
            pass


def backup_once(path):
    p=Path(path)
    stamp=datetime.now().strftime('%Y%m%d_%H%M%S')
    target=p.with_name(p.stem+f'.backup_{stamp}'+p.suffix)
    if p.exists():
        shutil.copy2(p,target)
        return str(target)
    return None


def _audit(c, entity, key, action, before, after, actor):
    c.execute('''INSERT INTO Data_Audit_Log(entity_type,entity_key,action,before_json,after_json,actor)
                 VALUES(?,?,?,?,?,?)''',
              (entity,str(key),action,json.dumps(before,ensure_ascii=False,default=str) if before is not None else None,
               json.dumps(after,ensure_ascii=False,default=str) if after is not None else None,actor))


def save_person(path, data, actor, original_number=None):
    perf=(data.get('performance_number') or '').strip()
    name=(data.get('full_name') or '').strip()
    if not perf or not name: raise ValueError('رقم الأداء والاسم مطلوبان.')
    allowed=['full_name','job_title','region','department','mobile1','mobile2','national_id','gender','birth_date']
    vals={k:(data.get(k) or '').strip() or None for k in allowed}
    with connect(path) as c:
        old=None
        if original_number:
            row=c.execute('SELECT * FROM Personnel WHERE performance_number=?',(original_number,)).fetchone()
            if not row: raise ValueError('المستفيد المطلوب تعديله غير موجود.')
            old=dict(row)
            c.execute('''UPDATE Personnel SET performance_number=?,full_name=?,job_title=?,region=?,department=?,mobile1=?,mobile2=?,national_id=?,gender=?,birth_date=?,updated_at=CURRENT_TIMESTAMP WHERE performance_number=?''',
                      (perf,vals['full_name'],vals['job_title'],vals['region'],vals['department'],vals['mobile1'],vals['mobile2'],vals['national_id'],vals['gender'],vals['birth_date'],original_number))
            c.execute('UPDATE Beneficiaries SET performance_number=?,full_name=?,region=?,department=? WHERE performance_number=?',
                      (perf,vals['full_name'],vals['region'],vals['department'],original_number))
            action='UPDATE'
        else:
            c.execute('''INSERT INTO Personnel(performance_number,full_name,job_title,region,department,mobile1,mobile2,national_id,gender,birth_date)
                         VALUES(?,?,?,?,?,?,?,?,?,?)''',
                      (perf,vals['full_name'],vals['job_title'],vals['region'],vals['department'],vals['mobile1'],vals['mobile2'],vals['national_id'],vals['gender'],vals['birth_date']))
            action='INSERT'
        new={'performance_number':perf,**vals}
        _audit(c,'PERSONNEL',perf,action,old,new,actor)
    return perf


def add_treatment(path, data, actor):
    perf=(data.get('performance_number') or '').strip()
    med=(data.get('medicine_name_raw') or '').strip()
    if not perf or not med: raise ValueError('رقم الأداء واسم الدواء مطلوبان.')
    try: order=int(data.get('treatment_order') or 1)
    except ValueError: raise ValueError('ترتيب العلاج غير صحيح.')
    if order not in (1,2,3): raise ValueError('يسمح بثلاثة ترتيبات علاج كحد أقصى.')
    with connect(path) as c:
        p=c.execute('SELECT * FROM Personnel WHERE performance_number=?',(perf,)).fetchone()
        if not p: raise ValueError('يجب تسجيل العامل أولاً.')
        b=c.execute('SELECT * FROM Beneficiaries WHERE performance_number=?',(perf,)).fetchone()
        if not b:
            batch=c.execute('SELECT batch_id FROM Import_Batches ORDER BY imported_at DESC,batch_id DESC LIMIT 1').fetchone()
            if not batch: raise ValueError('لا توجد دفعة مصدر مرجعية لإنشاء ملف العلاج.')
            payload={'performance_number':perf,'full_name':p['full_name'],'medicine_name_raw':med}
            cur=c.execute('''INSERT INTO Beneficiaries(source_batch_id,source_sheet,source_row,region,department,full_name,performance_number,dispensing_duration,dosage_text,medical_condition,approval_date,original_row_json)
                             VALUES(?,?,?,?,?,?,?,?,?,?,?,?)''',
                          (batch['batch_id'],'MANUAL',0,p['region'],p['department'],p['full_name'],perf,data.get('dispensing_duration') or None,data.get('dosage_text') or None,data.get('medical_condition') or None,data.get('approval_date') or None,json.dumps(payload,ensure_ascii=False)))
            bid=cur.lastrowid
        else: bid=b['beneficiary_id']
        existing=c.execute('SELECT * FROM Treatment_Entries WHERE beneficiary_id=? AND treatment_order=?',(bid,order)).fetchone()
        before=dict(existing) if existing else None
        if existing:
            c.execute('UPDATE Treatment_Entries SET medicine_name_raw=?,strength_raw=?,source_field=? WHERE treatment_entry_id=?',
                      (med,data.get('strength_raw') or None,'MANUAL',existing['treatment_entry_id']))
            action='UPDATE'
        else:
            c.execute('INSERT INTO Treatment_Entries(beneficiary_id,treatment_order,medicine_name_raw,strength_raw,source_field) VALUES(?,?,?,?,?)',
                      (bid,order,med,data.get('strength_raw') or None,'MANUAL'))
            action='INSERT'
        c.execute('''UPDATE Beneficiaries SET dispensing_duration=COALESCE(?,dispensing_duration),
                     dosage_text=COALESCE(?,dosage_text),medical_condition=COALESCE(?,medical_condition),
                     approval_date=COALESCE(?,approval_date) WHERE beneficiary_id=?''',
                  (data.get('dispensing_duration') or None,data.get('dosage_text') or None,
                   data.get('medical_condition') or None,data.get('approval_date') or None,bid))
        after={'performance_number':perf,'treatment_order':order,'medicine_name_raw':med,'strength_raw':data.get('strength_raw') or None,'approval_date':data.get('approval_date') or None}
        _audit(c,'TREATMENT_ENTRY',f'{perf}:{order}',action,before,after,actor)
    return perf


def list_medicines(path):
    with connect(path) as c:
        return [dict(r) for r in c.execute('''SELECT m.*,GROUP_CONCAT(s.strength,'، ') strengths FROM Medicine_Dictionary m LEFT JOIN Medicine_Strengths s ON s.medicine_id=m.medicine_id AND s.is_active=1 GROUP BY m.medicine_id ORDER BY m.medicine_name''')]


def save_medicine(path, name, ingredient='', form='', specialty='', strengths='', actor='', medicine_id=None):
    name=(name or '').strip()
    if not name: raise ValueError('اسم الدواء مطلوب.')
    strength_list=list(dict.fromkeys(x.strip() for x in (strengths or '').replace('،',',').split(',') if x.strip()))
    with connect(path) as c:
        old=None
        if medicine_id:
            row=c.execute('SELECT * FROM Medicine_Dictionary WHERE medicine_id=?',(medicine_id,)).fetchone()
            if not row: raise ValueError('الدواء غير موجود.')
            old=dict(row)
            c.execute('UPDATE Medicine_Dictionary SET medicine_name=?,active_ingredient=?,dosage_form=?,specialty=?,updated_at=CURRENT_TIMESTAMP WHERE medicine_id=?',
                      (name,ingredient or None,form or None,specialty or None,medicine_id))
            mid=medicine_id; action='UPDATE'
        else:
            cur=c.execute('INSERT INTO Medicine_Dictionary(medicine_name,active_ingredient,dosage_form,specialty) VALUES(?,?,?,?)',
                          (name,ingredient or None,form or None,specialty or None))
            mid=cur.lastrowid; action='INSERT'
        for s in strength_list:
            c.execute('INSERT OR IGNORE INTO Medicine_Strengths(medicine_id,strength) VALUES(?,?)',(mid,s))
        after={'medicine_id':mid,'medicine_name':name,'active_ingredient':ingredient,'dosage_form':form,'specialty':specialty,'strengths':strength_list}
        _audit(c,'MEDICINE',mid,action,old,after,actor)
    return mid


def list_users(path):
    with connect(path) as c:
        return [dict(r) for r in c.execute('SELECT user_id,username,display_name,role,active,created_at FROM users ORDER BY username')]


def set_user_active(auth_path, user_id, active, actor):
    with connect(auth_path) as c:
        row=c.execute('SELECT user_id,username,display_name,role,active FROM users WHERE user_id=?',(user_id,)).fetchone()
        if not row: raise ValueError('المستخدم غير موجود.')
        if row['role']=='manager' and not active:
            managers=c.execute("SELECT count(*) FROM users WHERE role='manager' AND active=1").fetchone()[0]
            if managers<=1: raise ValueError('لا يمكن تعطيل آخر حساب مدير نشط.')
        c.execute('UPDATE users SET active=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?',(int(bool(active)),user_id))
        if not active: c.execute('UPDATE sessions SET revoked=1 WHERE user_id=?',(user_id,))
        c.execute('INSERT INTO security_audit(username,event,detail) VALUES(?,?,?)',(row['username'],'USER_ACTIVATED' if active else 'USER_DEACTIVATED',f'by {actor}'))


def list_medicine_review(path):
    query = """SELECT q.review_id,q.batch_id,q.medicine_name_raw,q.first_seen_row,q.review_status,q.review_note,
      b.source_file,d.medicine_id,d.medicine_name canonical_name
      FROM Medicine_Review_Queue q LEFT JOIN Import_Batches_Ext b USING(batch_id)
      LEFT JOIN Medicine_Name_Aliases a ON a.raw_alias=q.medicine_name_raw
      LEFT JOIN Medicine_Dictionary d ON d.medicine_id=a.medicine_id
      ORDER BY CASE q.review_status WHEN 'PENDING' THEN 0 ELSE 1 END,q.review_id DESC"""
    with connect(path) as c:
        return [dict(r) for r in c.execute(query)]


def save_medicine_alias(path, alias, medicine_id, actor=''):
    alias=(alias or '').strip()
    if not alias: raise ValueError('اسم الدواء المراد توحيده مطلوب.')
    with connect(path) as c:
        med=c.execute('SELECT medicine_id,medicine_name FROM Medicine_Dictionary WHERE medicine_id=? AND is_active=1',(int(medicine_id),)).fetchone()
        if not med: raise ValueError('الدواء المعتمد غير موجود أو غير نشط.')
        existing=c.execute('SELECT * FROM Medicine_Name_Aliases WHERE raw_alias=? COLLATE NOCASE',(alias,)).fetchone()
        if existing and existing['medicine_id']!=int(medicine_id):
            raise ValueError('هذا الاسم مربوط بالفعل بدواء آخر. راجع الربط الحالي قبل تغييره.')
        c.execute('INSERT OR IGNORE INTO Medicine_Name_Aliases(raw_alias,medicine_id,created_by) VALUES(?,?,?)',(alias,int(medicine_id),actor))
        try:
            c.execute("UPDATE Medicine_Review_Queue SET review_status='APPROVED',review_note=? WHERE medicine_name_raw=? COLLATE NOCASE",(f'تم ربط الاسم بالدواء المعتمد: {med["medicine_name"]}',alias))
        except sqlite3.OperationalError:
            # The review queue is installed by the import migration; alias mapping can still be prepared before it.
            pass
        _audit(c,'MEDICINE_ALIAS',alias,'MAP_ALIAS',dict(existing) if existing else None,{'raw_alias':alias,'medicine_id':int(medicine_id),'canonical_name':med['medicine_name']},actor)
        return med['medicine_name']
