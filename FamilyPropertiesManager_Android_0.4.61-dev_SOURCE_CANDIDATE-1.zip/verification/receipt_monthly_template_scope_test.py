#!/usr/bin/env python3
"""Monthly receipt selection excludes semiannual and special receipt sheets."""
import json
from pathlib import Path
R=Path(__file__).resolve().parents[1]
D=json.loads((R/'app/src/main/assets/receipt_templates/receipt_template_catalog_v1.json').read_text(encoding='utf-8'))
S=(R/'app/src/main/java/com/example/rentals/printing/OriginalReceiptTemplateRenderer.kt').read_text(encoding='utf-8')
P=(R/'app/src/main/java/com/example/rentals/features/printing/AggregateStatementsPanel.kt').read_text(encoding='utf-8')
assert sum(bool(t['monthlyEligible']) for t in D['templates'])==81
for t in D['templates']:
    if 'نصف سنوى' in t['sheet'] or t['sheet']=='00': assert not t['monthlyEligible'],t['template_id']
    else: assert t['monthlyEligible'],t['template_id']
assert 'templateIds(monthlyOnly = true)' in P
assert 'filter { !monthlyOnly || it.optBoolean("monthlyEligible", true) }' in S
print('PASS: monthly selector exposes 81 monthly templates and excludes 7 semiannual/special templates')
