from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MAIN = ROOT / "android-app/src/main/java/com/familyproperties/app/MainActivity.kt"
EXCEL = ROOT / "android-app/src/main/java/com/familyproperties/app/ExcelInterchange.kt"


def test_excel_section_is_routed_to_real_screen():
    source = MAIN.read_text(encoding="utf-8")
    assert '"استيراد وتصدير Excel" -> ExcelInterchangeScreen' in source
    assert "private fun ExcelInterchangeScreen" in source
    assert "SectionPlaceholder(selected" in source  # other unfinished sections remain explicitly marked


def test_excel_screen_uses_android_document_picker_and_saver():
    source = MAIN.read_text(encoding="utf-8")
    assert "ActivityResultContracts.OpenDocument()" in source
    assert "ActivityResultContracts.CreateDocument(" in source
    assert "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" in source
    assert "application/vnd.ms-excel" in source
    assert "openInputStream(uri)" in source
    assert "openOutputStream(uri)" in source


def test_preview_is_background_and_does_not_apply_to_database():
    source = MAIN.read_text(encoding="utf-8")
    assert "withContext(Dispatchers.IO)" in source
    assert "ExcelInterchange.preview(it)" in source
    assert "لم يتم تعديل قاعدة البيانات" in source
    screen = source.split("private fun ExcelInterchangeScreen", 1)[1].split("private fun SectionPlaceholder", 1)[0]
    assert "repository.applyExcelImport(previews)" in screen
    assert "confirmImport" in screen


def test_existing_excel_preview_keeps_non_destructive_parser_and_validation():
    source = EXCEL.read_text(encoding="utf-8")
    assert "fun preview(input: InputStream): List<Preview>" in source
    assert "validateRow(sheet.sheetName" in source
    assert '"العقارات"' in source and '"الوحدات"' in source
    assert '"المصروفات"' in source
    assert "fun writeBlankTemplate(output: OutputStream)" in source


def test_excel_headers_reject_missing_or_extra_columns_and_validate_more_numeric_fields():
    source = EXCEL.read_text(encoding="utf-8")
    assert "maxOf(expected.size, headerRow?.lastCellNum?.toInt() ?: 0)" in source
    assert '"duration_value", "share_percent"' in source
