from pathlib import Path
root = Path(__file__).resolve().parents[1]
ui = (root / 'app/src/main/java/com/example/rentals/MainActivity.kt').read_text()
checks = {
    'document picker lifecycle exempted while active': 'event == Lifecycle.Event.ON_STOP && !pickerInProgressState.value' in ui,
    'picker activity flag enabled before launch': 'setExternalPickerInProgress(true);importQ012.launch' in ui,
    'picker activity flag cleared on return': 'importQ012=rememberLauncherForActivityResult' in ui and 'setExternalPickerInProgress(false)' in ui,
    'one confirmation stages and migrates': 'LegacyQ012Importer.stage(ctx.contentResolver,selectedUri,db.writableDatabase)' in ui and 'db.migrateUniquelyMatchedLegacyUnitsToReview()' in ui,
    'work moved off main thread': 'withContext(Dispatchers.IO)' in ui,
    'completion summary displayed after import': 'onImportComplete(completedSummary!!)' in ui and 'importSummary.isNotBlank()' in ui,
    'bottom navigation has overflow menu': 'NavigationBarItem(selected=tab==Tab.Review||tab==Tab.Contracts||tab==Tab.Entities||tab==Tab.Settings' in ui and 'DropdownMenuItem(text={Text("الإعدادات والاستيراد")}' in ui,
    'navigation labels kept to one line': 'maxLines=1,softWrap=false,fontSize=10.sp' in ui,
    'file format warning shown': 'ملف 11 2026(1).xls هو ملف Excel قديم' in ui,
}
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
assert all(checks.values())
