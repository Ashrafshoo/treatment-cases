package com.example.rentals

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.DisposableEffect
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import android.print.PrintAttributes
import android.print.PrintManager
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import android.provider.OpenableColumns
import java.io.File
import java.util.UUID
import com.example.rentals.backup.BackupManager
import com.example.rentals.backup.DatabaseTransfer
import com.example.rentals.backup.EncryptedBackup
import com.example.rentals.data.RentalsDb
import com.example.rentals.data.LegacyUnitReviewAnalyzer
import com.example.rentals.data.LegacyReceiptMatchAnalyzer
import com.example.rentals.data.UnitRecord
import com.example.rentals.data.ReceiptRecord
import com.example.rentals.data.PropertyRecord
import com.example.rentals.data.TenantRecord
import com.example.rentals.io.XlsxManager
import com.example.rentals.io.WorkbookExporter
import com.example.rentals.io.WorkbookImporter
import com.example.rentals.io.LegacyQ012Importer
import com.example.rentals.printing.DatabasePdfExporter
import com.example.rentals.printing.ReceiptPrintAdapter
import com.example.rentals.security.AppSecurity
import com.example.rentals.ui.SettingsStore
import com.example.rentals.ui.UiSettings
import java.text.NumberFormat
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); window.statusBarColor=android.graphics.Color.rgb(244,247,248); setContent { RentalsRoot(this) } }
}

@Composable private fun RentalsRoot(activity:FragmentActivity){
    val context= LocalContext.current
    val db= remember { RentalsDb.get(context) }
    val security= remember { AppSecurity(context) }
    val store= remember { SettingsStore(context) }
    var settings by remember { mutableStateOf(store.read()) }
    var unlocked by remember { mutableStateOf(!security.hasPin()) }
    // Android document pickers temporarily move this activity to the background.
    // Keep the session alive until the picker returns; otherwise ON_STOP hides and
    // discards the import confirmation state before the Activity Result is handled.
    var externalPickerInProgress by remember { mutableStateOf(false) }
    val pickerInProgressState = rememberUpdatedState(externalPickerInProgress)
    DisposableEffect(activity, settings.lockOnBackground, security.hasPin()) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP && !pickerInProgressState.value && settings.lockOnBackground && security.hasPin()) unlocked = false
        }
        activity.lifecycle.addObserver(observer)
        onDispose { activity.lifecycle.removeObserver(observer) }
    }
    var refresh by remember { mutableIntStateOf(0) }
    val units= remember(refresh){db.units()}
    val dark= settings.dark
    val accent=when(settings.accent){"blue"->Color(0xff3977a8);"olive"->Color(0xff71845a);"sand"->Color(0xffa77c52);"purple"->Color(0xff7656a5);"rose"->Color(0xffb45f72);"navy"->Color(0xff365477);else->Color(0xff247b75)}
    val scheme=if(dark) darkColorScheme(primary=accent,background=Color(0xff111a20),surface=Color(0xff1b2830)) else lightColorScheme(primary=accent,background=Color(0xfff4f7f8),surface=Color.White)
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
      MaterialTheme(colorScheme=scheme,typography=Typography(bodyLarge=MaterialTheme.typography.bodyLarge.copy(fontSize=MaterialTheme.typography.bodyLarge.fontSize*settings.fontScale,fontFamily=when(settings.fontFamily){"serif"->FontFamily.Serif;"mono"->FontFamily.Monospace;else->FontFamily.SansSerif}),bodyMedium=MaterialTheme.typography.bodyMedium.copy(fontSize=MaterialTheme.typography.bodyMedium.fontSize*settings.fontScale,fontFamily=when(settings.fontFamily){"serif"->FontFamily.Serif;"mono"->FontFamily.Monospace;else->FontFamily.SansSerif})),content={
        if(!unlocked){LockScreen(security,activity,onUnlock={unlocked=true})}
        else if(!security.hasPin()){PinSetup(security,onDone={unlocked=true})}
        else {MainShell(activity,db,units,settings,onSettings={settings=it;store.save(it)},onRefresh={refresh++},setExternalPickerInProgress={externalPickerInProgress=it})}
      })
    }
}

@Composable private fun LockScreen(sec:AppSecurity,activity:FragmentActivity,onUnlock:()->Unit){
    var pin by remember{mutableStateOf("")};var error by remember{mutableStateOf("")};var checking by remember{mutableStateOf(false)}
    val ctx= LocalContext.current;val scope= rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(28.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){
        Icon(Icons.Default.Lock,null,tint=MaterialTheme.colorScheme.primary,modifier=Modifier.size(56.dp));Text("أملاك العائلة",fontSize=23.sp,fontWeight=FontWeight.Bold);Text("أدخل رمز الدخول لفتح بياناتك",color=MaterialTheme.colorScheme.onSurfaceVariant);Spacer(Modifier.height(22.dp))
        OutlinedTextField(pin,{pin=it.filter(Char::isDigit).take(8)},label={Text("رمز الدخول")},visualTransformation=PasswordVisualTransformation(),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.NumberPassword),singleLine=true,enabled=!checking)
        if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)
        Button(enabled=!checking && pin.isNotEmpty(),onClick={checking=true;error="";scope.launch{val valid=withContext(Dispatchers.Default){runCatching{sec.verifyPin(pin)}.getOrDefault(false)};checking=false;if(valid)onUnlock()else error="رمز الدخول غير صحيح"}},modifier=Modifier.fillMaxWidth()){if(checking)CircularProgressIndicator(Modifier.size(18.dp),strokeWidth=2.dp)else Text("فتح التطبيق")}
        if(sec.biometricEnabled()&&sec.biometricAvailable(ctx)){OutlinedButton(enabled=!checking,onClick={sec.prompt(activity,onUnlock,{error=it})},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Fingerprint,null);Text("  استخدام البصمة")}}
    }
}
@Composable private fun PinSetup(sec:AppSecurity,onDone:()->Unit){
    var pin by remember{mutableStateOf("")};var confirm by remember{mutableStateOf("")};var error by remember{mutableStateOf("")};var saving by remember{mutableStateOf(false)}
    val scope= rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(24.dp),verticalArrangement=Arrangement.Center,horizontalAlignment=Alignment.CenterHorizontally){
        Icon(Icons.Default.Security,null,modifier=Modifier.size(54.dp),tint=MaterialTheme.colorScheme.primary);Text("إنشاء رمز الدخول",fontSize=24.sp,fontWeight=FontWeight.Bold);Text("يُستخدم لحماية فتح التطبيق على هذا الهاتف.")
        OutlinedTextField(pin,{pin=it.filter(Char::isDigit).take(8)},label={Text("رمز جديد – 4 أرقام على الأقل")},visualTransformation=PasswordVisualTransformation(),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.NumberPassword),enabled=!saving,singleLine=true)
        OutlinedTextField(confirm,{confirm=it.filter(Char::isDigit).take(8)},label={Text("تأكيد الرمز")},visualTransformation=PasswordVisualTransformation(),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.NumberPassword),enabled=!saving,singleLine=true)
        if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)
        Button(enabled=!saving,onClick={
            when { pin.length<4->error="الرمز قصير جدًا";pin!=confirm->error="الرمزان غير متطابقين";else->{saving=true;error="";scope.launch{
                val result=withContext(Dispatchers.Default){runCatching{sec.setPin(pin)}}
                result.onSuccess{onDone()}.onFailure{error="تعذر حفظ رمز الدخول: ${it.message?:"خطأ غير معروف"}";saving=false}
            }}
        }},modifier=Modifier.fillMaxWidth()) {if(saving){CircularProgressIndicator(Modifier.size(18.dp),strokeWidth=2.dp);Text(" جارٍ حفظ الرمز...")}else Text("حفظ وبدء الاستخدام")}
    }
}

private enum class Tab(val label:String,val icon:androidx.compose.ui.graphics.vector.ImageVector){Home("الرئيسية",Icons.Default.Dashboard),Units("الوحدات",Icons.Default.Apartment),Finance("المالية",Icons.Default.AccountBalanceWallet),Print("التحصيل",Icons.Default.ReceiptLong),Personal("دفتري",Icons.Default.MenuBook),Review("المراجعة",Icons.Default.FactCheck),Contracts("العقود والأرشيف",Icons.Default.FolderOpen),Entities("العقارات والمستأجرون",Icons.Default.Domain),Settings("الإعدادات",Icons.Default.Settings)}
@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun MainShell(activity:FragmentActivity,db:RentalsDb,initial:List<UnitRecord>,settings:UiSettings,onSettings:(UiSettings)->Unit,onRefresh:()->Unit,setExternalPickerInProgress:(Boolean)->Unit){
    var tab by remember{mutableStateOf(Tab.Home)}
    var units by remember{mutableStateOf(initial)}
    var moreExpanded by remember{mutableStateOf(false)}
    var importSummary by remember{mutableStateOf("")}
    LaunchedEffect(tab){units=db.units()}
    Scaffold(
        topBar={CenterAlignedTopAppBar(title={Text("أملاك العائلة",fontWeight=FontWeight.Bold)},actions={IconButton(onClick={units=db.units()}){Icon(Icons.Default.Refresh,"تحديث")}})},
        bottomBar={
            Box {
                NavigationBar {
                    listOf(Tab.Home,Tab.Units,Tab.Finance,Tab.Print,Tab.Personal).forEach { t ->
                        NavigationBarItem(selected=tab==t,onClick={tab=t},icon={Icon(t.icon,null)},label={Text(t.label,maxLines=1,softWrap=false,fontSize=10.sp)})
                    }
                    NavigationBarItem(selected=tab==Tab.Review||tab==Tab.Contracts||tab==Tab.Entities||tab==Tab.Settings,onClick={moreExpanded=true},icon={Icon(Icons.Default.MoreHoriz,null)},label={Text("المزيد",maxLines=1,softWrap=false,fontSize=10.sp)})
                }
                DropdownMenu(expanded=moreExpanded,onDismissRequest={moreExpanded=false}) {
                    DropdownMenuItem(text={Text("المراجعة")},leadingIcon={Icon(Icons.Default.FactCheck,null)},onClick={tab=Tab.Review;moreExpanded=false})
                    DropdownMenuItem(text={Text("العقود والأرشيف")},leadingIcon={Icon(Icons.Default.FolderOpen,null)},onClick={tab=Tab.Contracts;moreExpanded=false})
                    DropdownMenuItem(text={Text("العقارات والمستأجرون")},leadingIcon={Icon(Icons.Default.Domain,null)},onClick={tab=Tab.Entities;moreExpanded=false})
                    DropdownMenuItem(text={Text("الإعدادات والاستيراد")},leadingIcon={Icon(Icons.Default.Settings,null)},onClick={tab=Tab.Settings;moreExpanded=false})
                }
            }
        }
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(pad)) {
            when(tab){
                Tab.Home->Dashboard(db,units)
                Tab.Units->UnitsScreen(activity,db,units,settings.compact,{units=db.units();onRefresh()})
                Tab.Finance->FinanceScreen(db)
                Tab.Print->PrintScreen(activity,db,units,settings)
                Tab.Personal->PersonalRentNotebook(db)
                Tab.Review->ReviewScreen(db,units)
                Tab.Contracts->ContractsArchiveScreen(activity,db,units)
                Tab.Entities->EntityManagementScreen(db)
                Tab.Settings->SettingsScreen(activity,db,settings,onSettings,{units=db.units();onRefresh()},{summary->importSummary=summary;tab=Tab.Units;units=db.units();onRefresh()},setExternalPickerInProgress)
            }
            if(importSummary.isNotBlank()) {
                Card(Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(10.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.primaryContainer)) {
                    Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically) {
                        Text(importSummary,Modifier.weight(1f),color=MaterialTheme.colorScheme.onPrimaryContainer,fontSize=12.sp)
                        TextButton(onClick={importSummary=""}){Text("إغلاق")}
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun EntityManagementScreen(db:RentalsDb) {
    var refresh by remember { mutableIntStateOf(0) }
    val properties=remember(refresh){db.properties()}
    val tenants=remember(refresh){db.tenants()}
    var editingProperty by remember { mutableStateOf<PropertyRecord?>(null) }
    var editingTenant by remember { mutableStateOf<TenantRecord?>(null) }
    var message by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Text("إدارة العقارات والمستأجرين",fontSize=21.sp,fontWeight=FontWeight.Bold)
        Text("سجلات مستقلة مرتبطة بالوحدات والعقود، مع الاحتفاظ بتاريخ المستأجرين السابقين.",color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=13.sp)
        Row(verticalAlignment=Alignment.CenterVertically) { Text("العقارات (${properties.size})",fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f)); Button(onClick={editingProperty=PropertyRecord(name="")}) { Icon(Icons.Default.Add,null);Text("إضافة عقار") } }
        if(properties.isEmpty()) Text("لا توجد سجلات عقارات مستقلة بعد. ستُنشأ السجلات تلقائيًا أيضًا عند حفظ الوحدات.",color=MaterialTheme.colorScheme.onSurfaceVariant)
        properties.forEach { p ->
            Card(Modifier.fillMaxWidth()) { ListItem(headlineContent={Text(p.name,fontWeight=FontWeight.SemiBold)},supportingContent={Text("${p.address.ifBlank{"دون عنوان تفصيلي"}} • ${p.linkedUnits} وحدة")},trailingContent={Row { IconButton(onClick={editingProperty=p}){Icon(Icons.Default.Edit,"تعديل العقار")};IconButton(onClick={try{db.deleteProperty(p.id);refresh++;message="تم حذف العقار"}catch(e:Exception){message=e.message?:"تعذر الحذف"}}){Icon(Icons.Default.Delete,"حذف العقار")} }}) }
        }
        HorizontalDivider()
        Row(verticalAlignment=Alignment.CenterVertically) { Text("المستأجرون (${tenants.size})",fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f)); Button(onClick={editingTenant=TenantRecord(name="")}) { Icon(Icons.Default.Add,null);Text("إضافة مستأجر") } }
        Text("تغيير اسم المستأجر المرتبط بوحدة يتم من بطاقة الوحدة، حتى يُسجل النظام تغيير المستأجر وينشئ إيصالًا جديدًا دون المساس بالسجل التاريخي.",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
        if(tenants.isEmpty()) Text("لا توجد سجلات مستأجرين مستقلة بعد. ستُنشأ تلقائيًا عند حفظ الوحدات.",color=MaterialTheme.colorScheme.onSurfaceVariant)
        tenants.forEach { t ->
            Card(Modifier.fillMaxWidth()) { ListItem(headlineContent={Text(t.name,fontWeight=FontWeight.SemiBold)},supportingContent={Text("${t.phone.ifBlank{"لا يوجد هاتف"}} • ${t.linkedUnits} وحدة حالية • ${t.linkedLeases} عقد")},trailingContent={Row { IconButton(onClick={editingTenant=t}){Icon(Icons.Default.Edit,"تعديل بيانات المستأجر")};IconButton(onClick={try{db.deleteTenant(t.id);refresh++;message="تم حذف المستأجر"}catch(e:Exception){message=e.message?:"تعذر الحذف"}}){Icon(Icons.Default.Delete,"حذف المستأجر")} }}) }
        }
        if(message.isNotBlank()) Text(message,color=MaterialTheme.colorScheme.primary,fontSize=12.sp)
    }
    editingProperty?.let { item ->
        var name by remember(item.id){mutableStateOf(item.name)}; var address by remember(item.id){mutableStateOf(item.address)}; var notes by remember(item.id){mutableStateOf(item.notes)}
        AlertDialog(onDismissRequest={editingProperty=null},title={Text(if(item.id==0L)"إضافة عقار" else "تعديل العقار")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Field("اسم العقار",name,onChange={name=it});Field("العنوان",address,onChange={address=it});OutlinedTextField(notes,{notes=it},label={Text("ملاحظات")},modifier=Modifier.fillMaxWidth())}},confirmButton={TextButton(onClick={try{db.saveProperty(item.copy(name=name,address=address,notes=notes));editingProperty=null;refresh++;message="تم حفظ العقار وربطه بوحداته"}catch(e:Exception){message=e.message?:"تعذر الحفظ"}}){Text("حفظ")}},dismissButton={TextButton(onClick={editingProperty=null}){Text("إلغاء")}})
    }
    editingTenant?.let { item ->
        var name by remember(item.id){mutableStateOf(item.name)}; var phone by remember(item.id){mutableStateOf(item.phone)}; var notes by remember(item.id){mutableStateOf(item.notes)}
        AlertDialog(onDismissRequest={editingTenant=null},title={Text(if(item.id==0L)"إضافة مستأجر" else "تعديل بيانات المستأجر")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Field("اسم المستأجر",name,onChange={name=it});Field("رقم الهاتف",phone,KeyboardType.Phone,onChange={phone=it});OutlinedTextField(notes,{notes=it},label={Text("ملاحظات")},modifier=Modifier.fillMaxWidth())}},confirmButton={TextButton(onClick={try{db.saveTenant(item.copy(name=name,phone=phone,notes=notes));editingTenant=null;refresh++;message="تم حفظ بيانات المستأجر"}catch(e:Exception){message=e.message?:"تعذر الحفظ"}}){Text("حفظ")}},dismissButton={TextButton(onClick={editingTenant=null}){Text("إلغاء")}})
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun ContractsArchiveScreen(activity:FragmentActivity,db:RentalsDb,units:List<UnitRecord>){
    var refresh by remember{mutableIntStateOf(0)}
    var showEditor by remember{mutableStateOf(false)}
    var editingLeaseId by remember{mutableLongStateOf(0L)}
    var selectedUnit by remember{mutableStateOf(units.firstOrNull()?.id?.toString()?: "")}
    var start by remember{mutableStateOf(java.time.LocalDate.now().toString())}
    var end by remember{mutableStateOf("")}
    var rent by remember{mutableStateOf("")}
    var status by remember{mutableStateOf("نشط")}
    var notes by remember{mutableStateOf("")}
    var message by remember{mutableStateOf("")}
    var attachOwnerType by remember{mutableStateOf("unit")}
    var attachOwnerId by remember{mutableStateOf(units.firstOrNull()?.id?.toString()?:"")}
    var confirmDeleteLease by remember{mutableStateOf<Long?>(null)}
    var confirmDeleteAttachment by remember{mutableStateOf<Long?>(null)}
    val attachments= remember(refresh){db.attachments()}
    val leases=remember(refresh){db.leases()}
    val reminders=remember(refresh){db.reminders()}
    val picker= rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->
        if(uri!=null){try{
            activity.contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)
            val ownerId=if(attachOwnerType=="unit") attachOwnerId else attachOwnerId
            db.addAttachment(attachOwnerType,ownerId,uri.toString(),uri.lastPathSegment?:"مستند",activity.contentResolver.getType(uri)?:"application/octet-stream")
            message="تم ربط المستند وحفظه في الأرشيف";refresh++
        }catch(e:Exception){message="تعذر حفظ المستند: ${e.message}"}}
    }
    fun beginEdit(id:Long){
        val l=leases.firstOrNull{it.id==id} ?: return
        editingLeaseId=l.id;selectedUnit=l.unitId.toString();start=l.startDate;end=l.endDate
        rent=l.rent?.toString()?: "";status=l.status;notes=l.notes;showEditor=true
    }
    fun beginRenewal(id:Long){
        val previous=leases.firstOrNull{it.id==id} ?: return
        // A renewal is a new lease record; never overwrite the previous contract's dates or terms.
        editingLeaseId=0L;selectedUnit=previous.unitId.toString()
        start=java.time.LocalDate.now().toString();end="";rent=previous.rent?.toString()?:"";status="نشط"
        notes=("تجديد مستقل للعقد السابق رقم ${previous.id}. العقد السابق محفوظ كما هو.\n"+previous.notes).trim()
        showEditor=true
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        Text("العقود والأرشيف والتنبيهات",fontSize=21.sp,fontWeight=FontWeight.Bold)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
            Button(onClick={editingLeaseId=0;selectedUnit=units.firstOrNull()?.id?.toString()?: "";start=java.time.LocalDate.now().toString();end="";rent="";status="نشط";notes="";showEditor=true},modifier=Modifier.weight(1f)){Text("إضافة عقد")}
            OutlinedButton(onClick={picker.launch(arrayOf("application/pdf","image/*","application/msword","application/vnd.openxmlformats-officedocument.wordprocessingml.document"))},modifier=Modifier.weight(1f)){Text("إضافة مستند")}
        }
        Text("العقود المسجلة",fontWeight=FontWeight.Bold)
        if(leases.isEmpty())Text("لا توجد عقود مسجلة بعد",color=MaterialTheme.colorScheme.onSurfaceVariant)
        leases.forEach{l->Card(Modifier.fillMaxWidth()){
            Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){
                Text("الوحدة ${l.unitCode} – ${l.tenant}",fontWeight=FontWeight.Bold)
                Text("من ${l.startDate} إلى ${l.endDate.ifBlank{"غير محدد"}}")
                Text("الإيجار: ${l.rent?.let{money(it)}?:"غير محدد"} • ${l.status}")
                if(l.notes.isNotBlank())Text(l.notes)
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically){
                    TextButton(onClick={beginEdit(l.id)}){Text("تعديل البيانات")}
                    TextButton(onClick={beginRenewal(l.id)}){Text("تسجيل تجديد جديد")}
                    TextButton(onClick={confirmDeleteLease=l.id}){Text("حذف",color=MaterialTheme.colorScheme.error)}
                }
            }
        }}
        HorizontalDivider();Text("أرشيف المستندات",fontWeight=FontWeight.Bold)
        Text("اختر نوع الربط ورقمه قبل إضافة المستند. المستندات القديمة ذات الربط العام ستظل محفوظة.",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
        var ownerExpanded by remember{mutableStateOf(false)}
        ExposedDropdownMenuBox(expanded=ownerExpanded,onExpandedChange={ownerExpanded=it}){
            OutlinedTextField(value=if(attachOwnerType=="unit")"ربط بوحدة" else "ربط بعقد",onValueChange={},readOnly=true,label={Text("نوع المستند المرتبط")},modifier=Modifier.menuAnchor().fillMaxWidth())
            ExposedDropdownMenu(expanded=ownerExpanded,onDismissRequest={ownerExpanded=false}){
                DropdownMenuItem(text={Text("وحدة")},onClick={attachOwnerType="unit";attachOwnerId=units.firstOrNull()?.id?.toString()?: "";ownerExpanded=false})
                DropdownMenuItem(text={Text("عقد")},onClick={attachOwnerType="lease";attachOwnerId=leases.firstOrNull()?.id?.toString()?: "";ownerExpanded=false})
            }
        }
        var targetExpanded by remember{mutableStateOf(false)}
        val targetLabel=if(attachOwnerType=="unit") units.firstOrNull{it.id.toString()==attachOwnerId}?.let{"${it.code} – ${it.tenant}"} else leases.firstOrNull{it.id.toString()==attachOwnerId}?.let{"عقد ${it.id} – ${it.unitCode}"}
        ExposedDropdownMenuBox(expanded=targetExpanded,onExpandedChange={targetExpanded=it}){
            OutlinedTextField(value=targetLabel?:"اختر السجل المرتبط",onValueChange={},readOnly=true,label={Text("السجل المرتبط")},modifier=Modifier.menuAnchor().fillMaxWidth())
            ExposedDropdownMenu(expanded=targetExpanded,onDismissRequest={targetExpanded=false}){
                if(attachOwnerType=="unit") units.forEach{u->DropdownMenuItem(text={Text("${u.code} – ${u.tenant}")},onClick={attachOwnerId=u.id.toString();targetExpanded=false})}
                else leases.forEach{l->DropdownMenuItem(text={Text("عقد ${l.id} – ${l.unitCode}")},onClick={attachOwnerId=l.id.toString();targetExpanded=false})}
            }
        }
        if(attachments.isEmpty())Text("لا توجد مستندات محفوظة بعد",color=MaterialTheme.colorScheme.onSurfaceVariant)
        attachments.forEach{a->
            val ownerLabel=when(a.ownerType){"unit"->"وحدة رقم ${a.ownerId}";"lease"->"عقد رقم ${a.ownerId}";else->"أرشيف عام"}
            ListItem(headlineContent={Text(a.name)},supportingContent={Text("$ownerLabel • ${a.mime} • ${java.text.SimpleDateFormat("yyyy-MM-dd",Locale.US).format(java.util.Date(a.createdAt))}")},leadingContent={Icon(Icons.Default.AttachFile,null)},trailingContent={
                Row { IconButton(onClick={try{activity.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(android.net.Uri.parse(a.uri),a.mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))}catch(_:Exception){message="تعذر فتح المستند"}}){Icon(Icons.Default.OpenInNew,"فتح")};IconButton(onClick={confirmDeleteAttachment=a.id}){Icon(Icons.Default.Delete,"حذف",tint=MaterialTheme.colorScheme.error)} }
            })
        }
        HorizontalDivider();Text("التنبيهات",fontWeight=FontWeight.Bold)
        if(reminders.isEmpty())Text("لا توجد تنبيهات عقود قريبة وفق البيانات المسجلة.") else reminders.forEach{ListItem(headlineContent={Text(it)},leadingContent={Icon(Icons.Default.NotificationsActive,null,tint=MaterialTheme.colorScheme.primary)})}
        if(message.isNotBlank())Text(message,color=MaterialTheme.colorScheme.primary)
    }
    if(showEditor) AlertDialog(onDismissRequest={showEditor=false},title={Text(if(editingLeaseId>0)"تعديل بيانات العقد" else if(notes.startsWith("تجديد مستقل للعقد السابق"))"تسجيل تجديد جديد مع الاحتفاظ بالعقد السابق" else "إضافة عقد")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
        var expanded by remember{mutableStateOf(false)}
        ExposedDropdownMenuBox(expanded=expanded,onExpandedChange={expanded=it}){OutlinedTextField(value=units.firstOrNull{it.id.toString()==selectedUnit}?.let{"${it.code} – ${it.tenant}"}?:"اختر الوحدة",onValueChange={},readOnly=true,label={Text("الوحدة")},modifier=Modifier.menuAnchor().fillMaxWidth());ExposedDropdownMenu(expanded=expanded,onDismissRequest={expanded=false}){units.forEach{u->DropdownMenuItem(text={Text("${u.code} – ${u.tenant}")},onClick={selectedUnit=u.id.toString();if(rent.isBlank())rent=u.rent?.toString()?: "";expanded=false})}}}
        OutlinedTextField(start,{start=it},label={Text("بداية العقد YYYY-MM-DD")},singleLine=true)
        OutlinedTextField(end,{end=it},label={Text("نهاية العقد YYYY-MM-DD (اختياري)")},singleLine=true)
        OutlinedTextField(rent,{rent=it},label={Text("قيمة الإيجار (اختياري)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),singleLine=true)
        OutlinedTextField(status,{status=it},label={Text("حالة العقد")},singleLine=true)
        OutlinedTextField(notes,{notes=it},label={Text("ملاحظات")})
    }},confirmButton={TextButton(onClick={try{db.saveLease(editingLeaseId,selectedUnit.toLong(),start,end,rent.toDoubleOrNull(),status,notes);message=if(editingLeaseId>0)"تم تحديث العقد" else "تم حفظ العقد";showEditor=false;refresh++}catch(e:Exception){message=e.message?:"تعذر حفظ العقد"}}){Text("حفظ")}},dismissButton={TextButton(onClick={showEditor=false}){Text("إلغاء")}})
    if(confirmDeleteLease!=null)AlertDialog(onDismissRequest={confirmDeleteLease=null},title={Text("حذف العقد؟")},text={Text("سيتم حذف سجل العقد فقط. لن تُحذف المستندات المرتبطة به تلقائيًا حتى لا تفقد ملفاتك.")},confirmButton={TextButton(onClick={try{db.deleteLease(confirmDeleteLease!!);message="تم حذف سجل العقد؛ بقيت مرفقاته محفوظة";refresh++}catch(e:Exception){message=e.message?:"تعذر الحذف"};confirmDeleteLease=null}){Text("حذف")}},dismissButton={TextButton(onClick={confirmDeleteLease=null}){Text("إلغاء")}})
    if(confirmDeleteAttachment!=null)AlertDialog(onDismissRequest={confirmDeleteAttachment=null},title={Text("إزالة المستند من الأرشيف؟")},text={Text("سيُحذف ربط المستند من التطبيق فقط؛ لا نحذف الملف الأصلي من مزود الملفات.")},confirmButton={TextButton(onClick={try{db.deleteAttachment(confirmDeleteAttachment!!);message="تمت إزالة المستند من فهرس الأرشيف";refresh++}catch(e:Exception){message=e.message?:"تعذر الإزالة"};confirmDeleteAttachment=null}){Text("إزالة")}},dismissButton={TextButton(onClick={confirmDeleteAttachment=null}){Text("إلغاء")}})
}

@Composable private fun Dashboard(db:RentalsDb,units:List<UnitRecord>){val active=units.filter{!excludedFromCurrent(status=it.status)};val rent=active.filter{it.rent!=null}.sumOf{it.rent?:0.0};val pending=units.count{it.rent==null||it.status.contains("مؤجل")||it.status.contains("تغيير مستأجر")};Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)){Text("مرحبًا بك",fontSize=26.sp,fontWeight=FontWeight.Bold);Text("ملخص سريع لحالة العقارات والإيجارات",color=MaterialTheme.colorScheme.onSurfaceVariant);Spacer(Modifier.height(16.dp));Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){Metric("سجلات الوحدات",units.size.toString(),Icons.Default.Apartment,Modifier.weight(1f));Metric("وحدات نشطة مبدئيًا",active.size.toString(),Icons.Default.HomeWork,Modifier.weight(1f))};Spacer(Modifier.height(10.dp));Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){Metric("إجمالي الإيجار المسجل",money(rent),Icons.Default.Payments,Modifier.weight(1f));Metric("بيانات تحتاج استكمال",pending.toString(),Icons.Default.PendingActions,Modifier.weight(1f))};Spacer(Modifier.height(16.dp));Card(colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.primaryContainer)){Column(Modifier.padding(16.dp)){Text("تذكير محاسبي",fontWeight=FontWeight.Bold);Text("الإيجار يستحق في أول كل شهر ميلادي. لا تُعدّ الوحدة محصلة لمجرد وجودها في السجل؛ التحصيل الفعلي يُسجل في دفتر الحركات.")}};Spacer(Modifier.height(16.dp));Text("أقسام النظام",fontWeight=FontWeight.Bold,fontSize=18.sp);listOf("بطاقات العقارات والوحدات","دفتر الحركات والتحصيلات","المحصل والمبالغ لديه","المصروفات والتوزيع على الورثة","العقود والأرشيف والتنبيهات","النسخ الاحتياطي والاستعادة").forEach{ListItem(headlineContent={Text(it)},leadingContent={Icon(Icons.Default.CheckCircleOutline,null)})}}
}
@Composable private fun Metric(title:String,value:String,icon:androidx.compose.ui.graphics.vector.ImageVector,modifier:Modifier=Modifier){Card(modifier){Column(Modifier.padding(14.dp)){Icon(icon,null,tint=MaterialTheme.colorScheme.primary);Spacer(Modifier.height(8.dp));Text(value,fontSize=21.sp,fontWeight=FontWeight.Bold);Text(title,color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=12.sp)}}}

@Composable private fun UnitsScreen(activity:FragmentActivity,db:RentalsDb,units:List<UnitRecord>,compact:Boolean,onRefresh:()->Unit){
 var search by remember{mutableStateOf("")};var edit by remember{mutableStateOf<UnitRecord?>(null)};var add by remember{mutableStateOf(false)};var docsUnit by remember{mutableStateOf<UnitRecord?>(null)}
 val filtered=units.filter{search.isBlank()||it.tenant.contains(search,true)||it.property.contains(search,true)||it.code.contains(search,true)}
 Column(Modifier.fillMaxSize().padding(14.dp)){
  Row(verticalAlignment=Alignment.CenterVertically){Text("سجل الوحدات",fontSize=21.sp,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f));FilledTonalButton(onClick={add=true}){Icon(Icons.Default.Add,null);Text("إضافة وحدة")}}
  OutlinedTextField(search,{search=it},modifier=Modifier.fillMaxWidth(),label={Text("بحث بالاسم أو العقار أو الكود")},leadingIcon={Icon(Icons.Default.Search,null)},singleLine=true)
  Spacer(Modifier.height(8.dp))
  LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){
   items(filtered,key={if(it.id>0)it.id else it.code.hashCode().toLong()}){u->
    Card(modifier=Modifier.fillMaxWidth()){
     Column(Modifier.padding(if(compact)10.dp else 14.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){
      Row(verticalAlignment=Alignment.CenterVertically){Text(u.tenant.ifBlank{"مستأجر غير محدد"},fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f));Text(u.code,color=MaterialTheme.colorScheme.primary,fontSize=12.sp)}
      Text("${u.property}  •  ${u.unitType}",color=MaterialTheme.colorScheme.onSurfaceVariant)
      Row(verticalAlignment=Alignment.CenterVertically){Text(u.status,fontSize=12.sp);Spacer(Modifier.weight(1f));Text(u.rent?.let{money(it)+" / شهر"}?:"القيمة غير محددة",fontWeight=FontWeight.SemiBold)}
      Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
       TextButton(onClick={edit=u}){Icon(Icons.Default.Edit,null);Text("تعديل البيانات")}
       TextButton(onClick={docsUnit=u}){Icon(Icons.Default.FolderOpen,null);Text("عقد الوحدة ومستنداتها")}
      }
     }
    }
   }
  }
 }
 if(add||edit!=null){UnitEditor(edit,onDismiss={add=false;edit=null},onSave={db.saveUnit(it);add=false;edit=null;onRefresh()})}
 docsUnit?.let{u->UnitDocumentsDialog(activity,db,u,onDismiss={docsUnit=null})}
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun UnitDocumentsDialog(activity:FragmentActivity,db:RentalsDb,unit:UnitRecord,onDismiss:()->Unit){
 var refresh by remember{mutableIntStateOf(0)}
 var note by remember{mutableStateOf("")}
 var category by remember{mutableStateOf("عقد أساسي")}
 var categoryExpanded by remember{mutableStateOf(false)}
 var message by remember{mutableStateOf("")}
 var pendingCameraFile by remember{mutableStateOf<File?>(null)}
 val folder=remember(unit.id){File(activity.filesDir,"attachments/units/${unit.id}").apply{mkdirs()}}
 fun registerFile(file:File,mime:String,displayName:String,notes:String=""){
  val contentUri=FileProvider.getUriForFile(activity,"${activity.packageName}.fileprovider",file)
  db.addAttachment("unit",unit.id.toString(),contentUri.toString(),displayName,mime,notes,category)
  refresh++;message="تم حفظ الملف داخل التطبيق وربطه بالوحدة. النسخ السابقة لم تُستبدل."
 }
 fun importUri(uri:Uri,notesForFile:String){
  val mime=activity.contentResolver.getType(uri)?:"application/octet-stream"
  require(mime.startsWith("image/")||mime in setOf("application/pdf","application/msword","application/vnd.openxmlformats-officedocument.wordprocessingml.document")){"نوع الملف غير مدعوم"}
  var originalName="مستند"
  activity.contentResolver.query(uri,arrayOf(OpenableColumns.DISPLAY_NAME),null,null,null)?.use{c->if(c.moveToFirst())originalName=c.getString(0)?:originalName}
  val ext=originalName.substringAfterLast('.',"").takeIf{it.matches(Regex("[A-Za-z0-9]{1,8}"))}?.let{".$it"}?:when(mime){"image/jpeg"->".jpg";"image/png"->".png";"application/pdf"->".pdf";"application/msword"->".doc";"application/vnd.openxmlformats-officedocument.wordprocessingml.document"->".docx";else->".img"}
  val dest=File(folder,"${System.currentTimeMillis()}_${UUID.randomUUID()}$ext")
  try{activity.contentResolver.openInputStream(uri).use{input->requireNotNull(input){"تعذر قراءة الملف"};dest.outputStream().use{input.copyTo(it)}};registerFile(dest,mime,originalName,notesForFile)}catch(e:Exception){dest.delete();throw e}
 }
 val camera=rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()){ok->
  val f=pendingCameraFile
  if(ok&&f!=null&&f.exists()&&f.length()>0){try{registerFile(f,"image/jpeg","عقد_${unit.code}_${System.currentTimeMillis()}.jpg",note);note=""}catch(e:Exception){f.delete();message="تعذر حفظ الصورة: ${e.message}"}}
  else{f?.delete();message="لم يتم التقاط صورة"}
  pendingCameraFile=null
 }
 val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()){uris->
  if(uris.isNotEmpty()){val sharedNote=note;var saved=0;var errors=0;uris.forEach{u->try{importUri(u,sharedNote);saved++}catch(_:Exception){errors++}};note="";message=when{saved>0&&errors==0->"تم حفظ $saved ملف/صفحة بنجاح";saved>0->"تم حفظ $saved ملف، وتعذر استيراد $errors ملف";else->"تعذر استيراد الملفات المحددة"}}
 }
 val docs=remember(refresh){db.attachments().filter{it.ownerType=="unit"&&it.ownerId==unit.id.toString()}}
 AlertDialog(onDismissRequest=onDismiss,title={Text("عقد الوحدة ومستنداتها")},text={
  Column(Modifier.fillMaxWidth().heightIn(max=560.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)){
   Text("${unit.code} – ${unit.tenant}",fontWeight=FontWeight.Bold)
   Text("أضف العقد أو صفحاته أو الملاحق أو التجديدات. كل ملف يُحفظ كنسخة مستقلة داخل التطبيق، ولا يستبدل أي ملف سابق.",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
   ExposedDropdownMenuBox(expanded=categoryExpanded,onExpandedChange={categoryExpanded=it}){
    OutlinedTextField(value=category,onValueChange={},readOnly=true,label={Text("نوع المستند")},modifier=Modifier.menuAnchor().fillMaxWidth(),trailingIcon={ExposedDropdownMenuDefaults.TrailingIcon(expanded=categoryExpanded)})
    ExposedDropdownMenu(expanded=categoryExpanded,onDismissRequest={categoryExpanded=false}){
     listOf("عقد أساسي","صفحة من العقد","ملحق عقد","تجديد عقد","إنذار / إخطار","مستند آخر").forEach{item->DropdownMenuItem(text={Text(item)},onClick={category=item;categoryExpanded=false})}
    }
   }
   OutlinedTextField(note,{note=it},label={Text("ملاحظة على الملف (اختياري)")},modifier=Modifier.fillMaxWidth(),minLines=2)
   Button(onClick={try{val f=File(folder,"capture_${System.currentTimeMillis()}.jpg");pendingCameraFile=f;camera.launch(FileProvider.getUriForFile(activity,"${activity.packageName}.fileprovider",f))}catch(e:Exception){message="تعذر تشغيل الكاميرا: ${e.message}"}},modifier=Modifier.fillMaxWidth()){
    Icon(Icons.Default.PhotoCamera,null);Text("  تصوير صفحة العقد بالكاميرا")
   }
   OutlinedButton(onClick={picker.launch(arrayOf("image/*","application/pdf","application/msword","application/vnd.openxmlformats-officedocument.wordprocessingml.document"))},modifier=Modifier.fillMaxWidth()){
    Icon(Icons.Default.UploadFile,null);Text("  رفع ملف أو عدة صفحات / ملفات")
   }
   HorizontalDivider();Text("المستندات المحفوظة (${docs.size})",fontWeight=FontWeight.Bold)
   if(docs.isEmpty())Text("لم تتم إضافة عقد أو مستند لهذه الوحدة بعد.",color=MaterialTheme.colorScheme.onSurfaceVariant)
   docs.forEach{d->
    Card(Modifier.fillMaxWidth()){
     Column(Modifier.padding(8.dp),verticalArrangement=Arrangement.spacedBy(4.dp)){
      Text(d.name,fontWeight=FontWeight.SemiBold)
      Text("${d.category} • ${d.mime}",fontSize=11.sp,color=MaterialTheme.colorScheme.primary)
      Text("أضيف في ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(java.util.Date(d.createdAt))}",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
      if(d.notes.isNotBlank())Text(d.notes,fontSize=12.sp)
      TextButton(onClick={try{activity.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(d.uri),d.mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))}catch(e:Exception){message="تعذر فتح الملف: ${e.message}"}}){Icon(Icons.Default.OpenInNew,null);Text("فتح المستند")}
     }
    }
   }
   if(message.isNotBlank())Text(message,color=MaterialTheme.colorScheme.primary,fontSize=12.sp)
  }
 },confirmButton={TextButton(onClick=onDismiss){Text("إغلاق")}})
}

@Composable
private fun UnitEditor(existing: UnitRecord?, onDismiss: () -> Unit, onSave: (UnitRecord) -> Unit) {
    var code by remember { mutableStateOf(existing?.code ?: "") }
    var property by remember { mutableStateOf(existing?.property ?: "") }
    var tenant by remember { mutableStateOf(existing?.tenant ?: "") }
    var type by remember { mutableStateOf(existing?.unitType ?: "سكني") }
    var rent by remember { mutableStateOf(existing?.rent?.toString() ?: "") }
    var status by remember { mutableStateOf(existing?.status ?: "نشطة") }
    var desc by remember { mutableStateOf(existing?.description ?: "") }
    var notes by remember { mutableStateOf(existing?.notes ?: "") }
    AlertDialog(onDismissRequest=onDismiss,title={Text(if(existing==null)"إضافة وحدة" else "تعديل بيانات الوحدة")},text={Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(6.dp)){
      Field("كود الوحدة",code,onChange={code=it});Field("العقار / العنوان",property,onChange={property=it});Field("اسم المستأجر",tenant,onChange={tenant=it});Field("نوع الوحدة",type,onChange={type=it});Field("القيمة الشهرية بالجنيه",rent,KeyboardType.Decimal,onChange={rent=it});Field("الحالة التشغيلية",status,onChange={status=it});Field("وصف العين",desc,onChange={desc=it});Field("ملاحظات",notes,onChange={notes=it})
    }},confirmButton={TextButton(onClick={if(tenant.isNotBlank()) onSave(UnitRecord(existing?.id?:0,code,property,tenant,type,rent.toDoubleOrNull(),status,desc,notes))}){Text("حفظ")}},dismissButton={TextButton(onClick=onDismiss){Text("إلغاء")}})
}
@Composable private fun Field(label:String,value:String,kb:KeyboardType=KeyboardType.Text,onChange:(String)->Unit){OutlinedTextField(value,onChange,label={Text(label)},modifier=Modifier.fillMaxWidth(),singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=kb))}

@Composable
private fun FinanceScreen(db: RentalsDb) {
    var summary by remember { mutableStateOf(db.financeSummary()) }
    var dialog by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var method by remember { mutableStateOf("نقدًا") }
    var notes by remember { mutableStateOf("") }
    var period by remember { mutableStateOf(java.time.LocalDate.now().toString().take(7)) }
    var collector by remember { mutableStateOf("المحصل") }
    var expenses by remember { mutableStateOf("0") }
    var distributeDialog by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("الدفتر المالي", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("الفصل بين المستحقات والتحصيل الفعلي وأموال المحصل والمصروفات", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(12.dp))
        listOf(
            "الرصيد المستحق من المستأجرين" to summary["due"],
            "التحصيلات التي تسلمتها من المحصل" to summary["received"],
            "مبالغ محصلة وما زالت لدى المحصل" to summary["collectorHeld"],
            "مصروفات مسجلة" to summary["expenses"],
            "صافي غير موزع على الورثة" to summary["undistributed"],
            "استلامات تاريخية تحتاج تحديد فترتها" to summary["unassignedLegacy"],
            "مصروفات تاريخية تحتاج تحديد فترتها" to summary["unassignedLegacyExpenses"]
        ).forEach { (label, value) ->
            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                ListItem(headlineContent = { Text(label) }, trailingContent = { Text(money(value ?: 0.0), fontWeight = FontWeight.Bold) })
            }
        }
        Spacer(Modifier.height(12.dp))
        Button(onClick = { dialog = "استحقاق إيجار"; error = "" }, modifier = Modifier.fillMaxWidth()) { Text("تسجيل استحقاق إيجار") }
        OutlinedButton(onClick = { dialog = "تحصيل من مستأجر"; error = "" }, modifier = Modifier.fillMaxWidth()) { Text("تسجيل تحصيل من مستأجر") }
        OutlinedButton(onClick = { dialog = "تحصيل لدى المحصل"; error = "" }, modifier = Modifier.fillMaxWidth()) { Text("إثبات مبلغ حصّله المحصل ولم يسلّمه بعد") }
        OutlinedButton(onClick = { dialog = "استلام من المحصل"; error = "" }, modifier = Modifier.fillMaxWidth()) { Text("تسجيل استلام مبلغ من المحصل") }
        OutlinedButton(onClick = { dialog = "مصروف"; error = "" }, modifier = Modifier.fillMaxWidth()) { Text("تسجيل مصروف") }
        OutlinedButton(onClick = { distributeDialog = true }, modifier = Modifier.fillMaxWidth()) { Text("توزيع صافي المبلغ – وسيلة دفع مستقلة لكل وارث") }
        Text("طريقة استلام المبلغ من المحصل مستقلة عن طريقة الدفع لكل وارث. لا تسجل مبلغًا محصلًا لدى المحصل على أنه وصل إليك قبل الاستلام الفعلي.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }

    if (dialog.isNotBlank()) {
        AlertDialog(
            onDismissRequest = { dialog = "" },
            title = { Text(dialog) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (dialog.contains("المحصل")) Field("اسم المحصل", collector, onChange = { v -> collector = v })
                    if (dialog == "استلام من المحصل") {
                        Field("مصروفات تخصم من المبلغ", expenses, KeyboardType.Decimal, onChange = { v -> expenses = v })
                    }
                    Field(if (dialog == "مصروف") "بيان المصروف" else "اسم المستأجر / الوحدة / البيان", title, onChange = { v -> title = v })
                    Field("المبلغ بالجنيه", amount, KeyboardType.Decimal, onChange = { v -> amount = v })
                    Field("الفترة YYYY-MM", period, onChange = { v -> period = v })
                    if (dialog == "تحصيل من مستأجر" || dialog == "استلام من المحصل" || dialog == "توزيع صافي على الورثة") {
                        Field("طريقة الاستلام/الدفع", method, onChange = { v -> method = v })
                    }
                    Field("ملاحظات", notes, onChange = { v -> notes = v })
                    if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val value = amount.toDoubleOrNull() ?: 0.0
                    val today = java.time.LocalDate.now().toString()
                    try {
                        when (dialog) {
                            "استحقاق إيجار" -> db.addLedger("", title, today, period, "استحقاق", value, 0.0, "", notes)
                            "تحصيل من مستأجر" -> db.addLedger("", title, today, period, "تحصيل", 0.0, value, method, notes)
                            "تحصيل لدى المحصل" -> db.addCollectorReceivable(collector, period, today, value, notes)
                            "استلام من المحصل" -> db.handoverCollector(collector, today, value, method, expenses.toDoubleOrNull() ?: 0.0, 0.0, period, notes)
                            "مصروف" -> db.addExpense(title, value, today, period, "عام", notes)
                        }
                        summary = db.financeSummary()
                        dialog = ""; title = ""; amount = ""; notes = ""; error = ""
                    } catch (e: Exception) {
                        error = e.message ?: "تعذر حفظ الحركة"
                    }
                }) { Text("حفظ الحركة") }
            },
            dismissButton = { TextButton(onClick = { dialog = "" }) { Text("إلغاء") } }
        )
    }
    if (distributeDialog) {
        HeirDistributionDialog(db, onClose = { distributeDialog = false }, onSaved = { summary = db.financeSummary(); distributeDialog = false })
    }
}

@Composable
private fun HeirDistributionDialog(db: RentalsDb, onClose: () -> Unit, onSaved: () -> Unit) {
    val heirs = remember { db.heirs() }
    var net by remember { mutableStateOf("") }
    var period by remember { mutableStateOf(java.time.LocalDate.now().toString().take(7)) }
    val amounts = remember { androidx.compose.runtime.mutableStateMapOf<Long, String>() }
    val methods = remember { androidx.compose.runtime.mutableStateMapOf<Long, String>() }
    var error by remember { mutableStateOf("") }
    LaunchedEffect(net) {
        val value = net.toDoubleOrNull()
        if (value != null && value.isFinite() && value > 0.0 && kotlin.math.abs(value * 100.0 - kotlin.math.round(value * 100.0)) < 0.000001 && heirs.isNotEmpty()) {
            val totalCents = kotlin.math.round(value * 100.0).toLong()
            val raw = heirs.map { (id, _, share) ->
                val exact = totalCents * share
                Triple(id, kotlin.math.floor(exact).toLong(), exact - kotlin.math.floor(exact))
            }
            val remainder = (totalCents - raw.sumOf { it.second }).coerceAtLeast(0L)
            val extraIds = raw.sortedByDescending { it.third }.take(remainder.toInt()).map { it.first }.toSet()
            raw.forEach { (id, cents, _) -> amounts[id] = String.format(Locale.US, "%.2f", (cents + if (id in extraIds) 1 else 0) / 100.0) }
        }
    }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("توزيع صافي المبلغ على الورثة") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Field("صافي المبلغ المراد توزيعه", net, KeyboardType.Decimal, onChange = { v -> net = v })
                Field("فترة الأموال YYYY-MM", period, onChange = { v -> period = v })
                heirs.forEach { (id, name, share) ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(10.dp)) {
                            Text("$name  •  ${(share * 100).toInt()}%", fontWeight = FontWeight.Bold)
                            OutlinedTextField(amounts[id] ?: "", { amounts[id] = it }, label = { Text("مبلغ $name") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                            OutlinedTextField(methods[id] ?: "نقدًا", { methods[id] = it }, label = { Text("طريقة دفع $name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        }
                    }
                }
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val available = net.toDoubleOrNull() ?: 0.0
                val total = heirs.sumOf { (id, _, _) -> amounts[id]?.toDoubleOrNull() ?: 0.0 }
                when {
                    available <= 0 || !available.isFinite() -> error = "أدخل صافي مبلغ صحيحًا"
                    kotlin.math.abs(available * 100.0 - kotlin.math.round(available * 100.0)) >= 0.000001 -> error = "المبلغ يجب ألا يتجاوز منزلتين عشريتين"
                    total <= 0 || kotlin.math.abs(total * 100.0 - kotlin.math.round(total * 100.0)) >= 0.000001 || total > available + 0.000001 -> error = "راجع مجموع الدفعات؛ يجب أن يكون موجبًا وبحد أقصى صافي المبلغ وبمنزلتين عشريتين"
                    else -> {
                        val today = java.time.LocalDate.now().toString()
                        val payouts = heirs.mapNotNull { (id, _, _) ->
                            val value = amounts[id]?.toDoubleOrNull() ?: 0.0
                            if (value > 0) Triple(id, value, methods[id] ?: "نقدًا") else null
                        }
                        try {
                            db.payHeirsDetailed(payouts, today, period)
                            onSaved()
                        } catch (e: Exception) {
                            error = e.message ?: "تعذر حفظ التوزيع"
                        }
                    }
                }
            }) { Text("حفظ التوزيع") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("إلغاء") } }
    )
}

@Composable private fun ReviewScreen(db:RentalsDb,units:List<UnitRecord>){
    var refresh by remember{mutableIntStateOf(0)}
    var search by remember{mutableStateOf("")}
    var statusFilter by remember{mutableStateOf("all")}
    var typeFilter by remember{mutableStateOf("all")}
    var expandedId by remember{mutableStateOf<Long?>(null)}
    var noteRecord by remember{mutableStateOf<com.example.rentals.data.LegacyImportRecord?>(null)}
    var noteText by remember{mutableStateOf("")}
    var message by remember{mutableStateOf("")}
    var confirmLegacyMigration by remember{mutableStateOf(false)}
    var confirmAutomaticMigration by remember{mutableStateOf(false)}
    var confirmContractArchive by remember{mutableStateOf(false)}
    var linkingArchiveId by remember{mutableLongStateOf(0L)}
    var selectedLinkUnitId by remember{mutableStateOf("")}
    var contractLinkNote by remember{mutableStateOf("")}
    var confirmUnlinkArchiveId by remember{mutableLongStateOf(0L)}
    var unlinkReason by remember{mutableStateOf("")}
    val flags=remember(refresh,units){db.reviewFlags()}
    val counts=remember(refresh){db.legacyImportCounts()}
    val staged=remember(refresh,search,statusFilter,typeFilter){db.legacyImportRecords(
        status=if(statusFilter=="all") null else statusFilter,
        recordType=if(typeFilter=="all") null else typeFilter,
        query=search.trim()
    )}
    val totalStaged=counts.values.sum()
    val approvedContractCount = remember(refresh) { db.legacyImportRecords(recordType="lease_source").count { it.status == "approved_for_mapping" } }
    val archivedContracts = remember(refresh) { db.legacyContractArchive() }
    val unitCandidates = remember(refresh) { LegacyUnitReviewAnalyzer.analyze(db.legacyImportRecords(recordType="unit_source"), db.units().map { it.code }.filter { it.isNotBlank() }.toSet()) }
    val unitClassCounts = remember(unitCandidates) { unitCandidates.groupingBy { it.classification }.eachCount() }
    val receiptMatches = remember(refresh) { LegacyReceiptMatchAnalyzer.analyze(db.legacyImportRecords()) }
    val uniqueReceiptMatches = receiptMatches.count { it.matchStatus == LegacyReceiptMatchAnalyzer.MatchStatus.UNIQUE_SOURCE_MATCH }
    val ambiguousReceiptMatches = receiptMatches.filter { it.matchStatus == LegacyReceiptMatchAnalyzer.MatchStatus.AMBIGUOUS_GROUP }
    val approvedUnitRecords = remember(refresh) { db.legacyImportRecords(status="approved_for_mapping", recordType="unit_source") }
    val existingUnitCodes = remember(refresh, units) { db.units().map { it.code }.filter { it.isNotBlank() }.toSet() }
    val approvedUniqueUnitCount = approvedUnitRecords.count { r ->
        val code = runCatching { org.json.JSONObject(r.rawJson).optString("معرّف السجل", r.sourceRecordId) }.getOrDefault(r.sourceRecordId)
        code !in existingUnitCodes && receiptMatches.any { it.sourceImportId == r.id && it.matchStatus == LegacyReceiptMatchAnalyzer.MatchStatus.UNIQUE_SOURCE_MATCH }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
        Row(verticalAlignment=Alignment.CenterVertically){Text("مركز المراجعة والترحيل الآمن",fontSize=21.sp,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f));IconButton(onClick={refresh++}){Icon(Icons.Default.Refresh,"تحديث")}}
        Text("مراجعة نواقص التشغيل",fontWeight=FontWeight.Bold)
        Metric("بنود تحتاج مراجعة",flags.size.toString(),Icons.Default.FactCheck,Modifier.fillMaxWidth())
        Text("هذه تنبيهات بيانات وليست أحكامًا على المستأجر أو الحالة القانونية. غياب الإيصال لا يعني وحده توقف الدفع، والقيمة الفارغة لا تعني صفرًا.",color=MaterialTheme.colorScheme.onSurfaceVariant)
        if(flags.isEmpty()) Text("لا توجد نواقص من الأنواع التي يفحصها هذا المركز حاليًا.")
        flags.take(80).forEach{f->Card(Modifier.fillMaxWidth()){ListItem(headlineContent={Text(f.issue,fontWeight=FontWeight.SemiBold)},supportingContent={Text("${f.unitCode.ifBlank{"دون كود"}} • ${f.tenant.ifBlank{"مستأجر غير محدد"}}")},leadingContent={Icon(Icons.Default.WarningAmber,null,tint=MaterialTheme.colorScheme.tertiary)})}}
        HorizontalDivider(Modifier.padding(vertical=8.dp))
        Text("منطقة مراجعة ملف Q012",fontSize=19.sp,fontWeight=FontWeight.Bold)
        Text("السجلات التالية محفوظة كمصادر تاريخية خام. تغيير حالة المراجعة لا ينشئ وحدة أو عقدًا أو إيصالًا أو حركة مالية، ولا يربط أي سجل تلقائيًا.",color=MaterialTheme.colorScheme.onSurfaceVariant)
        Text("تحليل تمهيدي لسجل الوحدات",fontWeight=FontWeight.Bold)
        Text("هذا تحليل تصنيفي للمعاينة فقط؛ لا يعتمد أي سجل ولا يرحّله. السجلات ذات الحالة الفارغة لا تُعامل كنشطة تلقائيًا.",color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=12.sp)
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            Metric("سجلات وحدات محللة",unitCandidates.size.toString(),Icons.Default.Apartment,Modifier.weight(1f))
            Metric("أكواد تتعارض مع الحالي",unitCandidates.count { it.conflictsWithExistingCode }.toString(),Icons.Default.WarningAmber,Modifier.weight(1f))
        }
        unitClassCounts.entries.sortedBy { it.key.ordinal }.forEach { (kind,count) ->
            ListItem(headlineContent={Text(LegacyUnitReviewAnalyzer.label(kind))},trailingContent={Text(count.toString(),fontWeight=FontWeight.Bold)})
        }
        Text("مطابقة الوحدات بمصادر الإيصالات الأصلية",fontWeight=FontWeight.Bold)
        Text("مطابقة حرفية للاسم والقيمة ووصف العين والعنوان ومصدر البيانات. هذه مطابقة مصدرية فقط وليست إثباتًا للسداد ولا تنشئ إيصالات أو قيودًا.",color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=12.sp)
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            Metric("مطابقات مصدرية فريدة",uniqueReceiptMatches.toString(),Icons.Default.ReceiptLong,Modifier.weight(1f))
            Metric("حالات ملتبسة",ambiguousReceiptMatches.size.toString(),Icons.Default.WarningAmber,Modifier.weight(1f))
        }
        ambiguousReceiptMatches.forEach { m ->
            ListItem(headlineContent={Text("${m.unitCode} • ${m.tenant}",fontWeight=FontWeight.SemiBold)},supportingContent={Text("تتشارك أكثر من وحدة/مطابقة في نفس بيانات المصدر. صفوف الإيصالات: ${m.receiptRows.joinToString("، ")}")},leadingContent={Icon(Icons.Default.WarningAmber,null,tint=MaterialTheme.colorScheme.tertiary)})
        }
        HorizontalDivider(Modifier.padding(vertical=6.dp))
        HorizontalDivider(Modifier.padding(vertical=6.dp))
        Text("أرشفة العقود القديمة المعتمدة",fontWeight=FontWeight.Bold)
        Text("يتم نسخ بيانات العقد الأصلية كما هي إلى أرشيف مستقل غير مرتبط بوحدة. لا تُنشأ عقود تشغيلية ولا تُفسّر التواريخ أو المبالغ النصية ولا تُنشأ إيصالات أو قيود مالية. ربط العقد بوحدة سيظل إجراءً منفصلًا وصريحًا.",color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=12.sp)
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            Metric("عقود معتمدة للأرشفة",approvedContractCount.toString(),Icons.Default.Description,Modifier.weight(1f))
            Metric("عقود محفوظة بالأرشيف",archivedContracts.size.toString(),Icons.Default.FolderOpen,Modifier.weight(1f))
        }
        Button(onClick={confirmContractArchive=true},enabled=approvedContractCount>0,modifier=Modifier.fillMaxWidth()) { Text("حفظ العقود المعتمدة في الأرشيف غير المرتبط") }
        if(archivedContracts.isNotEmpty()) {
            Text("العقود المحفوظة دون ربط",fontWeight=FontWeight.SemiBold)
            archivedContracts.forEach { a ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(10.dp),verticalArrangement=Arrangement.spacedBy(3.dp)) {
                        Text("${a.sourceContractId.ifBlank { "عقد بلا معرّف" }} • ${a.sourceSheet} • صف ${a.sourceRow}",fontWeight=FontWeight.Bold)
                        Text(if(a.linkStatus=="linked_by_user") "مرتبط بوحدة باختيار المستخدم (رقم ${a.linkedUnitId})" else "أرشيف غير مرتبط بوحدة",color=MaterialTheme.colorScheme.primary)
                        Text("${a.sourceWorkbook} • ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm",java.util.Locale.getDefault()).format(java.util.Date(a.createdAt))}",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(horizontalArrangement=Arrangement.spacedBy(6.dp), verticalAlignment=Alignment.CenterVertically) {
                            OutlinedButton(onClick={linkingArchiveId=a.id;selectedLinkUnitId=(a.linkedUnitId?:units.firstOrNull()?.id)?.toString().orEmpty();contractLinkNote=""}) { Text(if(a.linkStatus=="linked_by_user") "تغيير الوحدة المرتبطة" else "اختيار وحدة لربط العقد") }
                            if(a.linkStatus=="linked_by_user") TextButton(onClick={confirmUnlinkArchiveId=a.id;unlinkReason=""}) { Text("إلغاء الربط",color=MaterialTheme.colorScheme.error) }
                        }
                        TextButton(onClick={expandedId=if(expandedId== -a.id) null else -a.id}) { Text(if(expandedId== -a.id) "إخفاء البيانات الأصلية" else "عرض البيانات الأصلية") }
                        if(expandedId== -a.id) Text(runCatching{org.json.JSONObject(a.rawJson).toString(2)}.getOrDefault(a.rawJson),fontSize=11.sp)
                    }
                }
            }
        }
        Text("استيراد أولي آمن للبيانات المؤكدة مصدريًا",fontWeight=FontWeight.Bold)
        Text("ينقل الوحدات التي لها مطابقة مصدرية فريدة فقط، ويستبعد المباعة والمغلقة والمستبعدة والتكرارات التوثيقية. تظل الوحدات بحالة غير محسومة (أو متوقفة إذا كان ذلك مثبتًا صراحة). لا ينشئ هذا الإجراء عقودًا أو إيصالات مدفوعة أو قيودًا مالية.",color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=12.sp)
        Button(onClick={confirmAutomaticMigration=true},modifier=Modifier.fillMaxWidth()) { Text("استيراد الوحدات ذات المطابقة الفريدة") }
        Text("ترحيل الوحدات المعتمدة إلى السجل التشغيلي",fontWeight=FontWeight.Bold)
        Text("الترحيل هنا تحفظي: لا يشمل إلا السجلات التي اعتمدتها فرديًا وكانت لها مطابقة إيصال مصدرية فريدة. تُنشأ الوحدة بحالة (غير محسومة)، مع حفظ الوصف والعنوان والمصدر في الملاحظات. لا يُنشأ إيصال مسودة أو إيصال مدفوع أو عقد أو قيد مالي.",color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=12.sp)
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            Metric("معتمدة للمطابقة",approvedUnitRecords.size.toString(),Icons.Default.FactCheck,Modifier.weight(1f))
            Metric("صالحة للترحيل التحفظي",approvedUniqueUnitCount.toString(),Icons.Default.Apartment,Modifier.weight(1f))
        }
        Button(onClick={confirmLegacyMigration=true},enabled=approvedUniqueUnitCount>0,modifier=Modifier.fillMaxWidth()) { Text("ترحيل الوحدات المعتمدة كغير محسومة") }
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){
            Metric("إجمالي المصادر",totalStaged.toString(),Icons.Default.Inventory2,Modifier.weight(1f))
            Metric("بانتظار المراجعة",(counts["pending_review"]?:0).toString(),Icons.Default.PendingActions,Modifier.weight(1f))
        }
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){
            Metric("جاهز للمطابقة",(counts["approved_for_mapping"]?:0).toString(),Icons.Default.FactCheck,Modifier.weight(1f))
            Metric("مستبعد",(counts["excluded"]?:0).toString(),Icons.Default.Block,Modifier.weight(1f))
        }
        OutlinedTextField(search,{search=it},modifier=Modifier.fillMaxWidth(),singleLine=true,label={Text("بحث بالمعرّف أو الورقة أو محتوى السجل")},leadingIcon={Icon(Icons.Default.Search,null)})
        Text("حالة المراجعة",fontWeight=FontWeight.SemiBold)
        Row(horizontalArrangement=Arrangement.spacedBy(5.dp)){
            FilterChip(selected=statusFilter=="all",onClick={statusFilter="all"},label={Text("الكل")})
            FilterChip(selected=statusFilter=="pending_review",onClick={statusFilter="pending_review"},label={Text("قيد المراجعة")})
            FilterChip(selected=statusFilter=="approved_for_mapping",onClick={statusFilter="approved_for_mapping"},label={Text("جاهز للمطابقة")})
            FilterChip(selected=statusFilter=="excluded",onClick={statusFilter="excluded"},label={Text("مستبعد")})
            FilterChip(selected=statusFilter=="migrated_to_review",onClick={statusFilter="migrated_to_review"},label={Text("رُحّل للمراجعة")})
            FilterChip(selected=statusFilter=="archived_unlinked",onClick={statusFilter="archived_unlinked"},label={Text("أُرشف العقد")})
        }
        Text("نوع المصدر",fontWeight=FontWeight.SemiBold)
        Row(horizontalArrangement=Arrangement.spacedBy(5.dp),modifier=Modifier.horizontalScroll(rememberScrollState())){
            listOf(
                "all" to "الكل", "unit_source" to "الوحدات", "lease_source" to "العقود",
                "lease_match_source" to "مطابقة العقود", "receipt_source" to "الإيصالات",
                "audit_source" to "التعديلات", "sold_unit_source" to "المباعة",
                "unified_statement_source" to "الكشف الموحد", "aggregate_statement_source" to "الكشف المجمع",
                "followup_source" to "النواقص والربط", "owner_answers_source" to "إجابات المالك",
                "duplicate_review_source" to "التكرار والفروق", "law164_review_source" to "مراجعة 164",
                "contract_term_review_source" to "مدد العقود", "residential_classification_source" to "تصنيف السكني",
                "rent_increase_followup_source" to "الزيادة"
            ).forEach{(value,label)->FilterChip(selected=typeFilter==value,onClick={typeFilter=value},label={Text(label)})}
        }
        Text("السجلات المعروضة: ${staged.size}${if(staged.size==1000)" (الحد الأقصى للعرض 1000)" else ""}",color=MaterialTheme.colorScheme.onSurfaceVariant)
        if(staged.isEmpty()) Text(if(totalStaged==0)"لم يتم حفظ أي سجلات Q012 بعد. استخدم استيراد Q012 من الإعدادات." else "لا توجد سجلات مطابقة للفلاتر الحالية.")
        staged.forEach{r->
            val expanded=expandedId==r.id
            val statusLabel=when(r.status){"approved_for_mapping"->"جاهز للمطابقة";"excluded"->"مستبعد من الترحيل";"migrated_to_review"->"رُحّل كوحدة غير محسومة";"archived_unlinked"->"أُرشف كعقد غير مرتبط";else->"قيد المراجعة"}
            Card(Modifier.fillMaxWidth()){
                Column(Modifier.fillMaxWidth().clickable{expandedId=if(expanded)null else r.id}.padding(12.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){
                    Row(verticalAlignment=Alignment.CenterVertically){Text("${r.sourceRecordId.ifBlank{"بلا معرّف"}} • ${r.sourceSheet}",fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f));Text("${r.sourceRow}",color=MaterialTheme.colorScheme.onSurfaceVariant)}
                    Text("${r.recordType}  |  $statusLabel",color=MaterialTheme.colorScheme.primary)
                    Text(r.reviewNote.ifBlank{"لا توجد ملاحظة مراجعة"},color=MaterialTheme.colorScheme.onSurfaceVariant)
                    if(expanded){
                        HorizontalDivider()
                        Text("الملف: ${r.sourceWorkbook}",fontSize=12.sp)
                        Text("رقم الصف: ${r.sourceRow} • الدفعة: ${r.batchId.take(8)}",fontSize=12.sp)
                        Text("البيانات المصدرية:",fontWeight=FontWeight.SemiBold)
                        Text(runCatching{org.json.JSONObject(r.rawJson).toString(2)}.getOrDefault(r.rawJson),fontSize=12.sp)
                        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){
                            OutlinedButton(onClick={noteRecord=r;noteText=r.reviewNote}){Text("تعديل الملاحظة")}
                            if(r.status!="approved_for_mapping" && r.status!="migrated_to_review" && r.status!="archived_unlinked") Button(onClick={try{db.updateLegacyImportReview(r.id,"approved_for_mapping",r.reviewNote);message="تم اعتماد السجل للمطابقة فقط، ولم يتم ترحيله.";refresh++}catch(e:Exception){message=e.message?:"تعذر تحديث الحالة"}}){Text("جاهز للمطابقة")}
                        }
                        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){
                            if(r.status!="pending_review" && r.status!="migrated_to_review" && r.status!="archived_unlinked") OutlinedButton(onClick={try{db.updateLegacyImportReview(r.id,"pending_review",r.reviewNote);refresh++}catch(e:Exception){message=e.message?:"تعذر تحديث الحالة"}}){Text("إعادة للمراجعة")}
                            if(r.status!="excluded" && r.status!="migrated_to_review" && r.status!="archived_unlinked") TextButton(onClick={try{db.updateLegacyImportReview(r.id,"excluded",r.reviewNote);message="تم استبعاد السجل من الترحيل دون حذفه.";refresh++}catch(e:Exception){message=e.message?:"تعذر تحديث الحالة"}}){Text("استبعاد من الترحيل")}
                        }
                    } else Text("اضغط لعرض البيانات المصدرية وإجراءات المراجعة",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        if(message.isNotBlank()) Text(message,color=MaterialTheme.colorScheme.primary)
    }
    if(linkingArchiveId>0){
        AlertDialog(onDismissRequest={linkingArchiveId=0L},title={Text("ربط العقد بوحدة")},text={
            Column(Modifier.fillMaxWidth().heightIn(max=420.dp),verticalArrangement=Arrangement.spacedBy(5.dp)) {
                Text("اختر الوحدة بنفسك بعد مراجعة بيانات العقد. لن يتغير اسم المستأجر أو الإيجار أو الإيصالات بسبب هذا الربط.",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
                Column(Modifier.weight(1f,fill=false).verticalScroll(rememberScrollState())) {
                    units.forEach { u ->
                        Row(Modifier.fillMaxWidth().clickable{selectedLinkUnitId=u.id.toString()}.padding(vertical=3.dp),verticalAlignment=Alignment.CenterVertically) {
                            RadioButton(selected=selectedLinkUnitId==u.id.toString(),onClick={selectedLinkUnitId=u.id.toString()})
                            Column(Modifier.weight(1f)) { Text("${u.code} • ${u.tenant}",fontWeight=FontWeight.SemiBold); Text(u.property,fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant) }
                        }
                    }
                }
                OutlinedTextField(contractLinkNote,{contractLinkNote=it},modifier=Modifier.fillMaxWidth(),label={Text("ملاحظة الربط (اختياري)")},minLines=2)
            }
        },confirmButton={TextButton(onClick={try{db.linkLegacyContractToUnit(linkingArchiveId,selectedLinkUnitId.toLong(),contractLinkNote);message="تم حفظ الربط الذي اخترته. لم تُنشأ حركة مالية أو عقد تشغيلي.";refresh++}catch(e:Exception){message="تعذر ربط العقد: ${e.message}"};linkingArchiveId=0L}){Text("حفظ الربط")}},dismissButton={TextButton(onClick={linkingArchiveId=0L}){Text("إلغاء")}})
    }
    if(confirmUnlinkArchiveId>0L){
        AlertDialog(onDismissRequest={confirmUnlinkArchiveId=0L},title={Text("تأكيد إلغاء ربط العقد")},text={
            Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
                Text("سيُزال ارتباط هذا العقد بالوحدة فقط. ستظل نسخة العقد الأصلية محفوظة في الأرشيف، ولن تتأثر الوحدة أو المستأجر أو الإيصالات أو القيود المالية.")
                OutlinedTextField(unlinkReason,{unlinkReason=it},modifier=Modifier.fillMaxWidth(),label={Text("سبب إلغاء الربط (مطلوب)")},minLines=2)
            }
        },confirmButton={TextButton(enabled=unlinkReason.isNotBlank(),onClick={try{db.unlinkLegacyContractFromUnit(confirmUnlinkArchiveId,unlinkReason.trim());message="أُلغي الربط مع الاحتفاظ بالعقد والملاحظات وسجل التدقيق.";refresh++}catch(e:Exception){message="تعذر إلغاء الربط: ${e.message}"};confirmUnlinkArchiveId=0L}){Text("تأكيد الإلغاء")}},dismissButton={TextButton(onClick={confirmUnlinkArchiveId=0L}){Text("تراجع")}})
    }
    if(confirmContractArchive){
        AlertDialog(onDismissRequest={confirmContractArchive=false},title={Text("تأكيد أرشفة العقود")},text={Text("سيتم حفظ $approvedContractCount عقدًا معتمدًا كنسخ مصدرية مستقلة في الأرشيف غير المرتبط. لن تُنشأ عقود تشغيلية أو روابط وحدات أو إيصالات أو قيود مالية. هل تريد المتابعة؟")},confirmButton={TextButton(onClick={try{val result=db.archiveApprovedLegacyContracts();message="نتيجة الأرشفة: ${result.inserted} عقد جديد، ${result.alreadyArchived} محفوظ سابقًا.";refresh++}catch(e:Exception){message="تعذرت أرشفة العقود: ${e.message}"};confirmContractArchive=false}){Text("تأكيد الأرشفة")}},dismissButton={TextButton(onClick={confirmContractArchive=false}){Text("إلغاء")}})
    }
    if(confirmAutomaticMigration){
        AlertDialog(onDismissRequest={confirmAutomaticMigration=false},title={Text("تأكيد الاستيراد الأولي الآمن")},text={Text("سيتم نقل سجلات الوحدات ذات المطابقة المصدرية الفريدة فقط. ستبقى القيم والإيجارات في حالة مراجعة، ولن تُنشأ إيصالات مدفوعة أو عقود أو قيود مالية. السجلات المباعة والمغلقة والمكررة والمستبعدة ستظل في مركز المراجعة. هل تريد المتابعة؟")},confirmButton={TextButton(onClick={try{val result=db.migrateUniquelyMatchedLegacyUnitsToReview();message="نتيجة الاستيراد: ${result.inserted} وحدة أضيفت، ${result.alreadyMigrated} سبق ترحيلها، ${result.blocked} سجلات حُجبت للمراجعة.";refresh++}catch(e:Exception){message="تعذر الاستيراد: ${e.message}"};confirmAutomaticMigration=false}){Text("تأكيد الاستيراد")}},dismissButton={TextButton(onClick={confirmAutomaticMigration=false}){Text("إلغاء")}})
    }
    if(confirmLegacyMigration){
        AlertDialog(onDismissRequest={confirmLegacyMigration=false},title={Text("تأكيد الترحيل التحفظي")},text={Text("سيتم إنشاء حتى $approvedUniqueUnitCount وحدة من السجلات المعتمدة ذات المطابقة المصدرية الفريدة. ستبقى كل وحدة بحالة (غير محسومة)، ولن تُنشأ إيصالات أو قيود مالية. هل تريد المتابعة؟")},confirmButton={TextButton(onClick={try{val result=db.migrateApprovedLegacyUnitsToReview();message="نتيجة الترحيل: ${result.inserted} وحدة جديدة، ${result.alreadyMigrated} سبق ترحيلها، ${result.blocked} سجلات لم تجتز شروط المطابقة.";refresh++}catch(e:Exception){message="تعذر الترحيل: ${e.message}"};confirmLegacyMigration=false}){Text("تأكيد الترحيل")}},dismissButton={TextButton(onClick={confirmLegacyMigration=false}){Text("إلغاء")}})
    }
    if(noteRecord!=null){
        AlertDialog(onDismissRequest={noteRecord=null},title={Text("ملاحظة المراجعة")},text={OutlinedTextField(noteText,{noteText=it},modifier=Modifier.fillMaxWidth(),minLines=3,label={Text("سبب المراجعة أو المستند المطلوب")})},confirmButton={TextButton(onClick={try{db.updateLegacyImportReview(noteRecord!!.id,noteRecord!!.status,noteText);message="تم حفظ الملاحظة";refresh++}catch(e:Exception){message=e.message?:"تعذر حفظ الملاحظة"};noteRecord=null}){Text("حفظ")}},dismissButton={TextButton(onClick={noteRecord=null}){Text("إلغاء")}})
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun PrintScreen(activity:FragmentActivity,db:RentalsDb,units:List<UnitRecord>,settings:UiSettings){
    var period by remember { mutableStateOf(java.time.YearMonth.now().toString()) }
    var issuedDate by remember { mutableStateOf(java.time.LocalDate.now().toString()) }
    var propertyFilter by remember { mutableStateOf("الكل") }
    var selected by remember { mutableStateOf<Set<Long>>(emptySet()) }
    var refresh by remember { mutableIntStateOf(0) }
    var activeBatch by remember { mutableStateOf<Long?>(null) }
    var message by remember { mutableStateOf("") }
    val properties=remember(units){units.map{it.property}.filter{it.isNotBlank()}.distinct().sorted()}
    val eligible=remember(units,propertyFilter){units.filter{!it.status.contains("متوقف")&&!it.status.contains("مباع")&&!it.status.contains("مغلق")&&(propertyFilter=="الكل"||it.property==propertyFilter)}}
    val batches=remember(refresh){db.monthlyBatches()}
    val batchReceipts=remember(activeBatch,refresh){activeBatch?.let{db.monthlyBatchReceipts(it)}?: emptyList()}
    val printManager=activity.getSystemService(android.content.Context.PRINT_SERVICE) as PrintManager
    val context= LocalContext.current
    var exportBatchId by remember{mutableLongStateOf(0L)}
    var editingCollectionItem by remember{mutableStateOf<Array<String>?>(null)}
    val exportCollectorPdf=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")){uri->if(uri!=null&&exportBatchId>0)try{val b=db.monthlyBatches().first{it.id==exportBatchId};com.example.rentals.printing.CollectorSheetPdfExporter.export(context.contentResolver,uri,b.title,db.monthlyBatchItems(exportBatchId).map{arrayOf(it[1],it[2],it[3],it[4],collectionStatusArabic(it[5]),it[6],it[8])});message="تم إنشاء كشف المحصّل PDF للوحدات المحددة فقط."}catch(e:Exception){message="تعذر إنشاء PDF: ${e.message}"}}
    val exportCollectorXlsx=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")){uri->if(uri!=null&&exportBatchId>0)try{val b=db.monthlyBatches().first{it.id==exportBatchId};val data=db.monthlyBatchItems(exportBatchId);com.example.rentals.io.WorkbookExporter.exportRows(context.contentResolver,uri,b.title,listOf("كود الوحدة","العقار","المستأجر","قيمة الإيجار","حالة التحصيل","المبلغ المحصل فعليًا","تاريخ التحصيل","ملاحظات"),data.map{listOf(it[1],it[2],it[3],it[4],collectionStatusArabic(it[5]),it[6],it[7],it[8])});message="تم تصدير كشف المحصّل Excel للوحدات المحددة فقط."}catch(e:Exception){message="تعذر إنشاء Excel: ${e.message}"}}
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal=12.dp, vertical=8.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
        Text("تجهيز التحصيل الشهري للمحصّل",fontSize=20.sp,fontWeight=FontWeight.Bold)
        Text("اختر الوحدات التي ستُسلّم للمحصّل. إنشاء الدفعة لا يسجل سدادًا ولا يضيف قيدًا ماليًا.",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
        OutlinedTextField(value=period,onValueChange={period=it},label={Text("شهر التحصيل بصيغة YYYY-MM")},singleLine=true,modifier=Modifier.fillMaxWidth())
        OutlinedTextField(value=issuedDate,onValueChange={issuedDate=it},label={Text("تاريخ إصدار الإيصالات YYYY-MM-DD")},singleLine=true,modifier=Modifier.fillMaxWidth())
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically){
            var expanded by remember{mutableStateOf(false)}
            Box(Modifier.weight(1f)){
                OutlinedButton(onClick={expanded=true},modifier=Modifier.fillMaxWidth()){Text("العقار: $propertyFilter")}
                DropdownMenu(expanded=expanded,onDismissRequest={expanded=false}){
                    DropdownMenuItem(text={Text("كل العقارات")},onClick={propertyFilter="الكل";selected=emptySet();expanded=false})
                    properties.forEach{p->DropdownMenuItem(text={Text(p)},onClick={propertyFilter=p;selected=emptySet();expanded=false})}
                }
            }
            Text("${selected.size} محدد",fontWeight=FontWeight.Bold)
        }
        Row(verticalAlignment=Alignment.CenterVertically){
            Checkbox(checked=eligible.isNotEmpty()&&eligible.all{it.id in selected},onCheckedChange={checked->selected=if(checked)selected+eligible.map{it.id}else selected-eligible.map{it.id}.toSet()})
            Text("تحديد الكل (${eligible.size})")
            Spacer(Modifier.weight(1f))
            TextButton(onClick={selected=emptySet()}){Text("إلغاء التحديد")}
        }
        eligible.forEach{u->
            Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=if(u.id in selected)MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surface)){
                Row(Modifier.fillMaxWidth().padding(horizontal=8.dp,vertical=2.dp),verticalAlignment=Alignment.CenterVertically){
                    Checkbox(checked=u.id in selected,onCheckedChange={checked->selected=if(checked)selected+u.id else selected-u.id})
                    Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(1.dp)){
                        Text("${u.code} • ${u.tenant}",fontWeight=FontWeight.SemiBold)
                        Text("${u.property} • ${u.rent?.let{money(it)}?:"القيمة غير محددة"}",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        Button(onClick={
            try{val id=db.createMonthlyCollectionBatch(period,issuedDate,selected,if(propertyFilter=="الكل")"" else propertyFilter);activeBatch=id;refresh++;message="تم تجهيز دفعة التحصيل وحفظ الوحدات المختارة فقط."}
            catch(e:Exception){message=e.message?:"تعذر تجهيز الدفعة"}
        },enabled=selected.isNotEmpty(),modifier=Modifier.fillMaxWidth()) { Text("إنشاء دفعة التحصيل والإيصالات (${selected.size})") }
        if(message.isNotBlank())Text(message,color=MaterialTheme.colorScheme.primary,fontSize=12.sp)
        HorizontalDivider()
        Text("دفعات التحصيل المحفوظة",fontWeight=FontWeight.Bold)
        batches.forEach{b->
            Card(Modifier.fillMaxWidth()){
                Row(Modifier.fillMaxWidth().padding(10.dp),verticalAlignment=Alignment.CenterVertically){
                    Column(Modifier.weight(1f)){
                        Text(b.title,fontWeight=FontWeight.SemiBold)
                        Text("${b.itemCount} وحدة • ${if(b.propertyFilter.isBlank())"كل العقارات" else b.propertyFilter}",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    TextButton(onClick={activeBatch=b.id;refresh++}){Text("عرض")}
                    IconButton(onClick={
                        val rs=db.monthlyBatchReceipts(b.id)
                        if(rs.isNotEmpty())printManager.print("إيصالات_${b.period}",ReceiptPrintAdapter(activity,rs,3,settings.marginMm,true),PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setResolution(android.print.PrintAttributes.Resolution("rentals","طباعة",300,300)).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build())
                    }){Icon(Icons.Default.Print,"طباعة الإيصالات")}
                }
            }
        }
        activeBatch?.let{batchId->
            val b=batches.firstOrNull{it.id==batchId}
            HorizontalDivider()
            Text(b?.title?:"دفعة التحصيل",fontWeight=FontWeight.Bold)
            Text("كشف المحصّل يضم عناصر هذه الدفعة المختارة فقط، ولا يشمل الوحدات غير المختارة.",fontSize=12.sp)
            db.monthlyBatchItems(batchId).forEach{row->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth().padding(10.dp),verticalArrangement=Arrangement.spacedBy(4.dp)) {
                        Text("${row[1]} • ${row[3]}",fontWeight=FontWeight.SemiBold)
                        Text("${row[2]} • الإيجار: ${row[4].ifBlank{"غير محدد"}} جنيه",fontSize=12.sp)
                        Text("الحالة: ${collectionStatusArabic(row[5])} • المحصل فعليًا: ${row[6].ifBlank{"—"}} جنيه",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
                        if(row[8].isNotBlank()) Text("ملاحظة: ${row[8]}",fontSize=12.sp)
                        TextButton(onClick={editingCollectionItem=row}){Text("تسجيل / تعديل نتيجة مرور المحصّل")}
                    }
                }
            }
            OutlinedButton(onClick={
                val rs=db.monthlyBatchReceipts(batchId)
                if(rs.isNotEmpty())printManager.print("إيصالات_${b?.period?:""}",ReceiptPrintAdapter(activity,rs,3,settings.marginMm,true),PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setResolution(android.print.PrintAttributes.Resolution("rentals","طباعة",300,300)).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build())
            },modifier=Modifier.fillMaxWidth()){Text("طباعة إيصالات هذه الدفعة – 3 في A4")}
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                OutlinedButton(onClick={exportBatchId=batchId;exportCollectorPdf.launch("${b?.title?:"كشف_التحصيل"}.pdf")},modifier=Modifier.weight(1f)){Text("كشف PDF")}
                OutlinedButton(onClick={exportBatchId=batchId;exportCollectorXlsx.launch("${b?.title?:"كشف_التحصيل"}.xlsx")},modifier=Modifier.weight(1f)){Text("كشف Excel")}
            }
        }
    }
    editingCollectionItem?.let { row ->
        var status by remember(row[0]) { mutableStateOf(row[5].ifBlank { "not_recorded" }) }
        var amount by remember(row[0]) { mutableStateOf(row[6]) }
        var date by remember(row[0]) { mutableStateOf(row[7].ifBlank { java.time.LocalDate.now().toString() }) }
        var notes by remember(row[0]) { mutableStateOf(row[8]) }
        var statusMenu by remember { mutableStateOf(false) }
        AlertDialog(onDismissRequest={editingCollectionItem=null},title={Text("نتيجة التحصيل — ${row[1]}")},text={
            Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
                Text("${row[3]} • ${row[2]}")
                Box { OutlinedButton(onClick={statusMenu=true},modifier=Modifier.fillMaxWidth()){Text("الحالة: ${collectionStatusArabic(status)}")};DropdownMenu(expanded=statusMenu,onDismissRequest={statusMenu=false}){listOf("not_recorded","paid","partial","unpaid","unreachable").forEach{v->DropdownMenuItem(text={Text(collectionStatusArabic(v))},onClick={status=v;statusMenu=false})}} }
                OutlinedTextField(amount,{amount=it},label={Text("المبلغ المحصل فعليًا (جنيه)")},singleLine=true,modifier=Modifier.fillMaxWidth())
                OutlinedTextField(date,{date=it},label={Text("تاريخ المرور YYYY-MM-DD")},singleLine=true,modifier=Modifier.fillMaxWidth())
                OutlinedTextField(notes,{notes=it},label={Text("ملاحظات المحصّل")},minLines=2,modifier=Modifier.fillMaxWidth())
                Text("تسجيل النتيجة لا ينشئ إيصال سداد أو قيدًا ماليًا تلقائيًا.",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },confirmButton={TextButton(onClick={try{val value=amount.trim().takeIf{it.isNotEmpty()}?.toDouble();db.updateMonthlyCollectionResult(row[0].toLong(),status,value,date.trim(),notes.trim());message="تم حفظ نتيجة مرور المحصّل دون إنشاء قيد مالي.";refresh++}catch(e:Exception){message=e.message?:"تعذر حفظ النتيجة"};editingCollectionItem=null}){Text("حفظ النتيجة")}},dismissButton={TextButton(onClick={editingCollectionItem=null}){Text("إلغاء")}})
    }
}

private fun collectionStatusArabic(status:String):String = when(status){"not_recorded"->"لم تسجل بعد";"paid"->"تم التحصيل";"partial"->"تحصيل جزئي";"unpaid"->"لم يتم التحصيل";"unreachable"->"تعذر الوصول";else->status}

@Composable private fun PersonalRentNotebook(db:RentalsDb){
    val now=java.time.YearMonth.now()
    var yearText by remember{mutableStateOf(now.year.toString())}
    var monthText by remember{mutableStateOf(now.monthValue.toString())}
    var monthId by remember{mutableLongStateOf(db.personalMonthId(now.year,now.monthValue))}
    var refresh by remember{mutableIntStateOf(0)}
    var expenseTitle by remember{mutableStateOf("")};var expenseAmount by remember{mutableStateOf("")};var expenseDate by remember{mutableStateOf(java.time.LocalDate.now().toString())}
    val rows=remember(monthId,refresh){db.personalRows(monthId)}
    val expenses=remember(monthId,refresh){db.personalExpenses(monthId)}
    val total=rows.sumOf{it[2].toDoubleOrNull()?:0.0};val expenseTotal=expenses.sumOf{it[2].toDoubleOrNull()?:0.0}
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
        Text("دفتر الإيجارات الشخصي",fontSize=20.sp,fontWeight=FontWeight.Bold)
        Text("قسم مستقل؛ بياناته وحساباته لا تختلط بسجلات أملاك العائلة.",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
            OutlinedTextField(yearText,{yearText=it.filter(Char::isDigit).take(4)},label={Text("السنة")},modifier=Modifier.weight(1f),singleLine=true)
            OutlinedTextField(monthText,{monthText=it.filter(Char::isDigit).take(2)},label={Text("الشهر 1–12")},modifier=Modifier.weight(1f),singleLine=true)
            Button(onClick={try{monthId=db.personalMonthId(yearText.toInt(),monthText.toInt());refresh++}catch(_:Exception){}},modifier=Modifier.align(Alignment.CenterVertically)){Text("فتح")}
        }
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
            OutlinedButton(onClick={try{val y=yearText.toInt();val m=monthText.toInt();val prev=java.time.YearMonth.of(y,m).minusMonths(1);val source=db.personalMonthId(prev.year,prev.monthValue);monthId=db.copyPersonalNames(source,y,m);refresh++}catch(_:Exception){}},modifier=Modifier.weight(1f)){Text("ترحيل أسماء الشهر السابق")}
            Text("15 صفًا",modifier=Modifier.align(Alignment.CenterVertically),fontSize=12.sp)
        }
        Text("بيان توزيع عن شهر $monthText لسنة $yearText",fontWeight=FontWeight.Bold)
        Text("المستأجر • الإجمالي • نصيب البنت (1/7) • نصيب الولد (2/7) • ملاحظات",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
        rows.forEach{r->
            val rowNo=r[0].toIntOrNull()?:1
            var tenant by remember(monthId,rowNo,r[1]){mutableStateOf(r[1])}
            var amount by remember(monthId,rowNo,r[2]){mutableStateOf(r[2])}
            var notes by remember(monthId,rowNo,r[5]){mutableStateOf(r[5])}
            val value=amount.toDoubleOrNull()?:0.0
            Card(Modifier.fillMaxWidth()){
                Column(Modifier.padding(8.dp),verticalArrangement=Arrangement.spacedBy(4.dp)){
                    Text("السطر $rowNo",fontWeight=FontWeight.SemiBold,fontSize=11.sp)
                    OutlinedTextField(tenant,{tenant=it;db.savePersonalRow(monthId,rowNo,it,value,value/7.0,value*2.0/7.0,notes);refresh++},label={Text("اسم المستأجر")},modifier=Modifier.fillMaxWidth(),singleLine=true)
                    Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){
                        OutlinedTextField(amount,{amount=it;val v=it.toDoubleOrNull()?:0.0;db.savePersonalRow(monthId,rowNo,tenant,v,v/7.0,v*2.0/7.0,notes);refresh++},label={Text("الإجمالي")},modifier=Modifier.weight(1f),singleLine=true)
                        Column(Modifier.weight(1f)){Text("البنت: ${money(value/7.0)}",fontSize=12.sp);Text("الولد: ${money(value*2.0/7.0)}",fontSize=12.sp)}
                    }
                    OutlinedTextField(notes,{notes=it;db.savePersonalRow(monthId,rowNo,tenant,value,value/7.0,value*2.0/7.0,it);refresh++},label={Text("ملاحظات")},modifier=Modifier.fillMaxWidth(),singleLine=true)
                }
            }
        }
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)){Text("إجمالي الإيرادات: ${money(total)} جنيه",fontWeight=FontWeight.Bold);Text("إجمالي المصروفات: ${money(expenseTotal)} جنيه");Text("الصافي: ${money(total-expenseTotal)} جنيه",fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary)} }
        HorizontalDivider();Text("المصروفات الأخرى",fontWeight=FontWeight.Bold)
        OutlinedTextField(expenseTitle,{expenseTitle=it},label={Text("بيان المصروف")},modifier=Modifier.fillMaxWidth())
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
            OutlinedTextField(expenseAmount,{expenseAmount=it},label={Text("المبلغ")},modifier=Modifier.weight(1f),singleLine=true)
            OutlinedTextField(expenseDate,{expenseDate=it},label={Text("التاريخ")},modifier=Modifier.weight(1f),singleLine=true)
        }
        Button(onClick={try{db.addPersonalExpense(monthId,expenseTitle,expenseAmount.toDouble(),expenseDate);expenseTitle="";expenseAmount="";refresh++}catch(_:Exception){}},enabled=expenseTitle.isNotBlank()&&(expenseAmount.toDoubleOrNull()?:-1.0)>=0,modifier=Modifier.fillMaxWidth()){Text("إضافة مصروف")}
        expenses.forEach{e->ListItem(headlineContent={Text(e[1])},supportingContent={Text(e[3])},trailingContent={Text("${money(e[2].toDoubleOrNull()?:0.0)} جنيه")})}
    }
}

@Composable private fun SettingsScreen(activity:FragmentActivity,db:RentalsDb,s:UiSettings,onChange:(UiSettings)->Unit,onRefresh:()->Unit,onImportComplete:(String)->Unit,setExternalPickerInProgress:(Boolean)->Unit){val ctx= LocalContext.current;val security= remember{AppSecurity(ctx)};var bio by remember{mutableStateOf(security.biometricEnabled() && security.biometricAvailable(ctx))};var includeDb by remember{mutableStateOf(true)};var includeFiles by remember{mutableStateOf(true)};var restoreDb by remember{mutableStateOf(true)};var restoreFiles by remember{mutableStateOf(true)};var msg by remember{mutableStateOf("")};var changePin by remember{mutableStateOf(false)};var editShares by remember{mutableStateOf(false)};var confirmRawImport by remember{mutableStateOf(false)};var backupPasswordDialog by remember{mutableStateOf(false)};var restorePasswordDialog by remember{mutableStateOf(false)};var backupPassword by remember{mutableStateOf("")};var restorePassword by remember{mutableStateOf("")};var pendingImport by remember{mutableStateOf<List<UnitRecord>?>(null)};var pendingWorkbookUri by remember{mutableStateOf<Uri?>(null)};var pendingWorkbookPreview by remember{mutableStateOf<WorkbookImporter.Preview?>(null)};var pendingQ012Uri by remember{mutableStateOf<Uri?>(null)};var pendingQ012Preview by remember{mutableStateOf<LegacyQ012Importer.Preview?>(null)};var q012Busy by remember{mutableStateOf(false)};val importScope= rememberCoroutineScope();var selectedPdfReport by remember{mutableStateOf("units")};var reportPeriod by remember{mutableStateOf("")};var reportHeirName by remember{mutableStateOf("")}
 val exportExcel=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")){uri->if(uri!=null)try{WorkbookExporter.exportAll(ctx.contentResolver,uri,db.readableDatabase);msg="تم تصدير جداول قاعدة البيانات إلى Excel في أوراق منفصلة";val send=Intent(Intent.ACTION_SEND).apply{type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";putExtra(Intent.EXTRA_STREAM,uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)};ctx.startActivity(Intent.createChooser(send,"مشاركة ملف Excel"))}catch(e:Exception){msg="فشل التصدير: ${e.message}"}}
 val importAllExcel=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->if(uri!=null)try{val p=WorkbookImporter.preview(ctx.contentResolver,uri,db.readableDatabase);pendingWorkbookUri=uri;pendingWorkbookPreview=p;msg="تم تحليل ملف Excel وتجهيز ملخص الاستيراد"}catch(e:Exception){msg="تعذر تحليل ملف Excel: ${e.message}"}}
 val importQ012=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->setExternalPickerInProgress(false);if(uri!=null){q012Busy=true;importScope.launch{try{val p=withContext(Dispatchers.IO){LegacyQ012Importer.preview(ctx.contentResolver,uri)};pendingQ012Uri=uri;pendingQ012Preview=p;msg="تم التعرف على ملف Q012 وتجهيز ملخص الاستيراد"}catch(e:Exception){msg="تعذر قراءة ملف Q012: ${e.message}"}finally{q012Busy=false}}}}
 val exportPdf=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")){uri->if(uri!=null)try{DatabasePdfExporter.exportReport(ctx.contentResolver,uri,db.readableDatabase,selectedPdfReport,reportPeriod,reportHeirName);msg="تم إنشاء تقرير PDF متخصص"}catch(e:Exception){msg="فشل إنشاء PDF: ${e.message}"}}
 val importExcel=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->if(uri!=null)try{val list=XlsxManager.import(ctx.contentResolver,uri);pendingImport=list;msg="تمت قراءة ${list.size} وحدة. راجع الملخص قبل اعتماد الاستيراد."}catch(e:Exception){msg="تعذر الاستيراد: ${e.message}"}}
 val exportDb=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.sqlite3")){uri->if(uri!=null)try{DatabaseTransfer.export(ctx,uri);msg="تم تصدير قاعدة البيانات بصيغة SQLite"}catch(e:Exception){msg="فشل تصدير قاعدة البيانات: ${e.message}"}}
 val importDb=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->if(uri!=null)try{DatabaseTransfer.import(ctx,uri);msg="تم استيراد قاعدة البيانات. أعد فتح التطبيق لتحديث جميع الشاشات.";onRefresh()}catch(e:Exception){msg="رفض استيراد قاعدة البيانات: ${e.message}"}}
 val backup=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")){uri->if(uri!=null)try{BackupManager.create(ctx,uri,includeDb,includeFiles);msg="تم إنشاء النسخة الاحتياطية"}catch(e:Exception){msg="فشل النسخ: ${e.message}"}}
 val encryptedBackup=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")){uri->if(uri!=null)try{EncryptedBackup.create(ctx,uri,includeDb,includeFiles,backupPassword);msg="تم إنشاء نسخة احتياطية مشفرة؛ احتفظ بكلمة المرور";backupPassword=""}catch(e:Exception){msg="فشل إنشاء النسخة المشفرة: ${e.message}"}}
 val encryptedRestore=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->if(uri!=null)try{EncryptedBackup.restore(ctx,uri,restoreDb,restoreFiles,restorePassword);msg="تمت استعادة النسخة المشفرة؛ أعد فتح التطبيق";restorePassword="";onRefresh()}catch(e:Exception){msg="فشلت الاستعادة: ${e.message}"}}
 val restore=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->if(uri!=null)try{BackupManager.restore(ctx,uri,restoreDb,restoreFiles);msg="تمت الاستعادة؛ أعد فتح التطبيق للتأكد من البيانات";onRefresh()}catch(e:Exception){msg="فشلت الاستعادة: ${e.message}"}}
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){Text("الإعدادات والتخصيص",fontSize=22.sp,fontWeight=FontWeight.Bold);Text("المظهر وراحة العين",fontWeight=FontWeight.Bold);SettingSwitch("الوضع الليلي",s.dark){onChange(s.copy(dark=it))};Text("حجم الخط: ${(s.fontScale*100).toInt()}%");Slider(value=s.fontScale, onValueChange={onChange(s.copy(fontScale=it))},valueRange=.85f..1.35f);Text("نوع الخط");Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){listOf("sans" to "واضح", "serif" to "تقليدي", "mono" to "ثابت").forEach{(v,l)->FilterChip(selected=s.fontFamily==v,onClick={onChange(s.copy(fontFamily=v))},label={Text(l)})}};Text("لون الواجهة");Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){listOf("teal" to "فيروزي","blue" to "أزرق","olive" to "زيتوني","sand" to "رملي","purple" to "بنفسجي","rose" to "وردي","navy" to "كحلي").forEach{(v,l)->FilterChip(selected=s.accent==v,onClick={onChange(s.copy(accent=v))},label={Text(l)})}};SettingSwitch("عرض مضغوط للقوائم",s.compact){onChange(s.copy(compact=it))};Text("عدد الإيصالات في ورقة A4: ${s.receiptsPerPage}");Slider(value=s.receiptsPerPage.toFloat(),onValueChange={onChange(s.copy(receiptsPerPage=it.toInt().coerceIn(1,3)))},valueRange=1f..3f,steps=1);Text("هامش الطباعة: ${s.marginMm.toInt()} مم");Slider(value=s.marginMm,onValueChange={onChange(s.copy(marginMm=it))},valueRange=2f..12f);HorizontalDivider();Text("الحماية",fontWeight=FontWeight.Bold);SettingSwitch("قفل التطبيق تلقائيًا عند مغادرته",s.lockOnBackground){onChange(s.copy(lockOnBackground=it))};SettingSwitch("تفعيل البصمة / قفل الجهاز",bio){if(it&&!security.biometricAvailable(ctx)){msg="هذا الهاتف لا يوفر بصمة/قفل جهاز متوافقًا حاليًا";bio=false;security.setBiometricEnabled(false)}else{bio=it;security.setBiometricEnabled(it)}};Text("يمكنك تحديث رمز الدخول في أي وقت.",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant);OutlinedButton(onClick={changePin=true},modifier=Modifier.fillMaxWidth()){Text("تغيير رمز الدخول")};HorizontalDivider();Text("التقارير والاستيراد والتصدير",fontWeight=FontWeight.Bold);Text("لاستيراد بيانات الإيجارات الأساسية اختر ملف Q012 بصيغة XLSX من الزر التالي. ملف 11 2026(1).xls هو ملف Excel قديم لنماذج الإيصالات وليس ملف Q012.",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant);Button(onClick={exportExcel.launch("تصدير_كامل_بيانات_الإيجارات.xlsx")},modifier=Modifier.fillMaxWidth()){Text("تصدير جميع جداول النظام إلى Excel")};OutlinedButton(onClick={exportPdf.launch("تقرير_كامل_بيانات_الإيجارات.pdf")},modifier=Modifier.fillMaxWidth()){Text("تصدير تقرير شامل إلى PDF")};Text("تقارير PDF المتخصصة",fontWeight=FontWeight.Bold);Field("تصفية التقرير بالفترة: YYYY أو YYYY-MM أو غير محددة (اتركه فارغًا للكل)",reportPeriod,onChange={reportPeriod=it});Field("اسم الوارث لكشف حساب فردي (اختياري — مطابق للاسم المسجل)",reportHeirName,onChange={reportHeirName=it});listOf("units" to "كشف الوحدات", "receipts" to "تقرير الإيصالات", "ledger" to "كشف حركة الحسابات", "expenses" to "تقرير المصروفات", "collections" to "استلامات المحصّل", "heirs" to "أنصبة وتوزيعات الورثة", "financial" to "كشف الحركة المالية الموحد", "heir_statement" to "كشف الدفعات الفعلية للورثة").forEach{(key,label)->OutlinedButton(onClick={selectedPdfReport=key;exportPdf.launch("${label.replace(' ','_')}.pdf")},modifier=Modifier.fillMaxWidth()){Text(label)}};Text("يحتوي Excel وPDF على أوراق/جداول قاعدة البيانات الحالية. التصدير لا يغيّر البيانات الأصلية.",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant);OutlinedButton(onClick={importAllExcel.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","application/zip"))},modifier=Modifier.fillMaxWidth()){Text("استيراد جميع أقسام النظام من Excel (قالب التطبيق)")};Button(onClick={setExternalPickerInProgress(true);importQ012.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","application/zip"))},modifier=Modifier.fillMaxWidth()){Text(if(q012Busy)"جارٍ تجهيز ملف Q012…" else "استيراد ملف الإيجارات Q012 (XLSX)") };OutlinedButton(onClick={importExcel.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))},modifier=Modifier.fillMaxWidth()){Text("استيراد وحدات من ملف Excel خارجي / كشف الوحدات")};Text("الاستيراد الشامل مخصص لملف XLSX صادر من التطبيق وبنفس أسماء الأعمدة. يضيف سجلات جديدة فقط ولا يعدّل السجلات القائمة؛ أي تعارض يوقف العملية كاملة.",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant);SettingSwitch("تضمين قاعدة البيانات",includeDb){includeDb=it};SettingSwitch("تضمين المرفقات",includeFiles){includeFiles=it};OutlinedButton(onClick={exportDb.launch("قاعدة_بيانات_الإيجارات.db")},modifier=Modifier.fillMaxWidth()){Text("تصدير قاعدة البيانات SQLite")};OutlinedButton(onClick={confirmRawImport=true},modifier=Modifier.fillMaxWidth()){Text("استيراد قاعدة بيانات SQLite")};Button(onClick={backupPasswordDialog=true},modifier=Modifier.fillMaxWidth()){Text("إنشاء نسخة احتياطية مشفرة بكلمة مرور")};Text("عند الاستعادة، اختر ما تريد استعادته:",fontWeight=FontWeight.Bold);SettingSwitch("استعادة قاعدة البيانات",restoreDb){restoreDb=it};SettingSwitch("استعادة المرفقات",restoreFiles){restoreFiles=it};OutlinedButton(onClick={restorePasswordDialog=true},modifier=Modifier.fillMaxWidth()){Text("استعادة نسخة احتياطية مشفرة")};OutlinedButton(onClick={editShares=true},modifier=Modifier.fillMaxWidth()){Text("إدارة أنصبة الورثة")};HorizontalDivider();Text("الذكاء الاصطناعي والخصوصية",fontWeight=FontWeight.Bold);SettingSwitch("أسمح بتفعيل ميزات AI عبر الإنترنت عند الطلب فقط",s.aiConsent){onChange(s.copy(aiConsent=it))};Text("الوظائف الأساسية محلية. لا توجد أي عملية إرسال بيانات في هذه النسخة؛ الموافقة هنا تحفظ تفضيلك فقط.",fontSize=12.sp);if(msg.isNotBlank())Text(msg,color=MaterialTheme.colorScheme.primary,fontWeight=FontWeight.SemiBold)}
 if(backupPasswordDialog) AlertDialog(onDismissRequest={backupPasswordDialog=false},title={Text("حماية النسخة الاحتياطية")},text={Column{Text("أنشئ كلمة مرور لا تقل عن 8 أحرف. لن تُحفظ داخل التطبيق؛ احتفظ بها لاستعادة النسخة.");OutlinedTextField(backupPassword,{backupPassword=it},label={Text("كلمة مرور النسخة")},visualTransformation=PasswordVisualTransformation())}},confirmButton={TextButton(onClick={if(backupPassword.length>=8){backupPasswordDialog=false;encryptedBackup.launch("نسخة_إيجارات_مشفرة.rntbak")}else msg="كلمة المرور يجب ألا تقل عن 8 أحرف"}){Text("إنشاء النسخة")}},dismissButton={TextButton(onClick={backupPasswordDialog=false}){Text("إلغاء")}})
 if(restorePasswordDialog) AlertDialog(onDismissRequest={restorePasswordDialog=false},title={Text("استعادة نسخة مشفرة")},text={Column{Text("أدخل كلمة المرور التي استخدمتها عند إنشاء النسخة.");OutlinedTextField(restorePassword,{restorePassword=it},label={Text("كلمة المرور")},visualTransformation=PasswordVisualTransformation())}},confirmButton={TextButton(onClick={if(restorePassword.isNotBlank()){restorePasswordDialog=false;encryptedRestore.launch(arrayOf("application/octet-stream","application/zip","*/*"))}else msg="أدخل كلمة المرور أولًا"}){Text("اختيار النسخة")}},dismissButton={TextButton(onClick={restorePasswordDialog=false}){Text("إلغاء")}})
 if(pendingQ012Uri!=null && pendingQ012Preview!=null) { val preview=pendingQ012Preview!!; AlertDialog(onDismissRequest={if(!q012Busy){pendingQ012Uri=null;pendingQ012Preview=null}},title={Text("مراجعة ملف الإيجارات قبل الاستيراد")},text={Column(Modifier.heightIn(max=420.dp).verticalScroll(rememberScrollState())){Text("الملف: ${preview.workbookName}");Text("إجمالي السجلات التي تم التعرف عليها: ${preview.totalRows}",fontWeight=FontWeight.SemiBold);preview.counts.forEach{Text("${it.sheet}: ${it.rows} سجل")};Spacer(Modifier.height(8.dp));Text("بعد الضغط على استيراد الآن، سيحفظ التطبيق بيانات المصدر ويضيف الوحدات التي ثبتت مطابقتها فقط إلى قائمة الوحدات بحالة تحتاج مراجعة. لن ينشئ إيصالات مدفوعة أو قيودًا مالية، ولن يخمن القيم الناقصة. السجلات غير المؤكدة ستظل محفوظة للمراجعة.");if(q012Busy){Spacer(Modifier.height(10.dp));Row(verticalAlignment=Alignment.CenterVertically){CircularProgressIndicator(Modifier.size(20.dp),strokeWidth=2.dp);Text(" جارٍ استيراد البيانات، اترك التطبيق مفتوحًا…")}}}},confirmButton={TextButton(enabled=!q012Busy,onClick={val selectedUri=pendingQ012Uri;if(selectedUri!=null){q012Busy=true;importScope.launch{var completedSummary:String?=null;try{val result=withContext(Dispatchers.IO){val staged=LegacyQ012Importer.stage(ctx.contentResolver,selectedUri,db.writableDatabase);val migrated=db.migrateUniquelyMatchedLegacyUnitsToReview();staged to migrated};val staged=result.first;val migrated=result.second;msg="اكتمل الاستيراد: ${migrated.inserted} وحدة أضيفت، ${migrated.alreadyMigrated} موجودة سابقًا، ${migrated.blocked} تحتاج مراجعة. حُفظ ${staged.inserted} سجلًا مصدريًا جديدًا.";completedSummary=msg;onRefresh()}catch(e:Exception){msg="تعذر إكمال الاستيراد: ${e.message}"}finally{q012Busy=false;pendingQ012Uri=null;pendingQ012Preview=null};if(completedSummary!=null)onImportComplete(completedSummary!!)}}}){Text(if(q012Busy)"جارٍ الاستيراد…" else "استيراد الآن")}},dismissButton={TextButton(enabled=!q012Busy,onClick={pendingQ012Uri=null;pendingQ012Preview=null}){Text("إلغاء")}}) }
 if(pendingWorkbookUri!=null && pendingWorkbookPreview!=null) { val preview=pendingWorkbookPreview!!; AlertDialog(onDismissRequest={pendingWorkbookUri=null;pendingWorkbookPreview=null},title={Text("معاينة استيراد Excel الشامل")},text={Column(Modifier.heightIn(max=420.dp).verticalScroll(rememberScrollState())){Text("عدد السجلات المقروءة: ${preview.totalRows}");preview.tables.forEach{(table,count)->Text("$table: $count سجل")};if(preview.ignoredSheets.isNotEmpty())Text("أوراق غير مستوردة: ${preview.ignoredSheets.joinToString()}");Spacer(Modifier.height(8.dp));Text("سيتم إضافة السجلات الجديدة فقط مع الحفاظ على المعرّفات والعلاقات. لن يتم تعديل أو حذف أي سجل موجود. إذا ظهر تعارض في رقم أو قيد فريد أو علاقة، ستُلغى العملية كلها دون اعتماد أي جزء. أنشئ نسخة احتياطية قبل المتابعة.")}},confirmButton={TextButton(onClick={try{val result=WorkbookImporter.importAppend(ctx.contentResolver,pendingWorkbookUri!!,db.writableDatabase);msg="تمت معالجة ${result.totalRows} سجلًا من ${result.tables.size} جدول؛ أضيفت السجلات الجديدة وتُركت السجلات المطابقة كما هي.";onRefresh()}catch(e:Exception){msg="لم يعتمد الاستيراد: ${e.message}"};pendingWorkbookUri=null;pendingWorkbookPreview=null}){Text("اعتماد الإضافة")}},dismissButton={TextButton(onClick={pendingWorkbookUri=null;pendingWorkbookPreview=null}){Text("إلغاء")}}) }
 if(pendingImport!=null) { val incoming=pendingImport!!; val existingCodes=db.units().map{it.code}.filter{it.isNotBlank()}.toSet(); val duplicates=incoming.count{it.code.isNotBlank()&&it.code in existingCodes}; val repeatedInFile=incoming.filter{it.code.isNotBlank()}.groupingBy{it.code}.eachCount().values.sumOf{(it-1).coerceAtLeast(0)}; AlertDialog(onDismissRequest={pendingImport=null},title={Text("مراجعة استيراد Excel")},text={Text("عدد السجلات المقروءة: ${incoming.size}\nسجلات لها كود موجود مسبقًا: $duplicates\nأكواد مكررة داخل الملف نفسه: $repeatedInFile\n${if(repeatedInFile>0)"لن نسمح بالاستيراد قبل إزالة تكرار الأكواد داخل الملف حتى لا يستبدل سجلٌ سجلًا آخر دون قصد." else "السجلات المتطابقة بالكود ستحدّث بيانات الوحدة الحالية بعد موافقتك مع تسجيل التعديل في سجل المراجعة. الاستيراد أصبح عملية واحدة: إذا فشل أي سجل فلن يُعتمد أي جزء من الملف."}\nهل تعتمد الاستيراد؟")},confirmButton={TextButton(enabled=repeatedInFile==0,onClick={try{db.importUnitsAtomically(incoming);msg="تم استيراد ${incoming.size} سجل وحدة بعد المراجعة في عملية واحدة";onRefresh()}catch(e:Exception){msg="فشل الاستيراد: ${e.message}"};pendingImport=null}){Text(if(repeatedInFile==0)"اعتماد الاستيراد" else "عالج التكرارات أولًا")}},dismissButton={TextButton(onClick={pendingImport=null}){Text("إلغاء")}}) }
 if(confirmRawImport) AlertDialog(onDismissRequest={confirmRawImport=false},title={Text("تأكيد استبدال قاعدة البيانات")},text={Text("سيؤدي الاستيراد إلى استبدال بيانات هذا التطبيق ببيانات الملف المختار. أنشئ نسخة احتياطية أولًا. هل تريد المتابعة؟")},confirmButton={TextButton(onClick={confirmRawImport=false;importDb.launch(arrayOf("application/vnd.sqlite3","application/octet-stream","*/*"))}){Text("اختيار ملف والمتابعة")}},dismissButton={TextButton(onClick={confirmRawImport=false}){Text("إلغاء")}})
 if(changePin) ChangePinDialog(security,onClose={changePin=false},onSaved={msg="تم تحديث رمز الدخول";changePin=false})
 if(editShares) HeirSharesDialog(db,onClose={editShares=false},onSaved={msg="تم حفظ الأنصبة وتسجيل التعديل في السجل التاريخي";editShares=false})
}
@Composable
private fun ChangePinDialog(sec: AppSecurity, onClose: () -> Unit, onSaved: () -> Unit) {
    var old by remember { mutableStateOf("") }
    var fresh by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("تغيير رمز الدخول") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(old, { old = it }, label = { Text("الرمز الحالي") }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
                OutlinedTextField(fresh, { fresh = it }, label = { Text("الرمز الجديد") }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
                OutlinedTextField(confirm, { confirm = it }, label = { Text("تأكيد الرمز الجديد") }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                when {
                    !sec.verifyPin(old) -> error = "الرمز الحالي غير صحيح"
                    fresh.length < 4 -> error = "الرمز الجديد يجب ألا يقل عن 4 أرقام"
                    fresh != confirm -> error = "تأكيد الرمز غير مطابق"
                    else -> { sec.setPin(fresh); onSaved() }
                }
            }) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("إلغاء") } }
    )
}
@Composable
private fun HeirSharesDialog(db: RentalsDb, onClose: () -> Unit, onSaved: () -> Unit) {
    val heirs = remember { db.heirs() }
    val values = remember { androidx.compose.runtime.mutableStateMapOf<Long, String>() }
    var error by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { heirs.forEach { (id, _, share) -> values[id] = String.format(Locale.US, "%.4f", share * 100.0) } }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("أنصبة الورثة") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("النسب الافتراضية: الذكر 2/7 والأنثى 1/7. يمكنك تعديلها يدويًا؛ يجب أن يكون المجموع 100٪.", fontSize = 12.sp)
                heirs.forEach { (id, name, _) ->
                    OutlinedTextField(values[id] ?: "", { values[id] = it }, label = { Text("نصيب $name (%)") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                }
                Text("المجموع: ${heirs.sumOf { values[it.first]?.toDoubleOrNull() ?: 0.0 }}٪")
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val map = heirs.associate { it.first to (values[it.first]?.toDoubleOrNull() ?: 0.0) }
                try { db.updateHeirShares(map); onSaved() } catch (e: Exception) { error = e.message ?: "تعذر حفظ الأنصبة" }
            }) { Text("حفظ الأنصبة") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("إلغاء") } }
    )
}

@Composable private fun SettingSwitch(label:String,checked:Boolean,onChange:(Boolean)->Unit){Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text(label,modifier=Modifier.weight(1f));Switch(checked,onChange)}}
private fun excludedFromCurrent(status:String):Boolean { val s=status.lowercase(); return listOf("مغلقة","مباعة","متوقف","مكرر","مستبعد","غير محسومة").any{s.contains(it)} }
private fun money(v:Double)=NumberFormat.getNumberInstance(Locale("ar","EG")).format(v)+" ج.م"
