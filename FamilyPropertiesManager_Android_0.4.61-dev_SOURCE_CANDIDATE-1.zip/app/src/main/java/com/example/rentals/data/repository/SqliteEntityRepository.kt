package com.example.rentals.data.repository

import com.example.rentals.data.PropertyRecord
import com.example.rentals.data.RentalsDb
import com.example.rentals.data.TenantRecord
import com.example.rentals.domain.entities.EntityRepository

/** SQLite adapter preserving the database's existing relationship and history safeguards. */
class SqliteEntityRepository(private val database: RentalsDb) : EntityRepository {
    override fun getProperties(): List<PropertyRecord> = database.properties()
    override fun getTenants(): List<TenantRecord> = database.tenants()
    override fun saveProperty(item: PropertyRecord): Long = database.saveProperty(item)
    override fun saveTenant(item: TenantRecord): Long = database.saveTenant(item)
    override fun deleteProperty(id: Long) = database.deleteProperty(id)
    override fun deleteTenant(id: Long) = database.deleteTenant(id)
}
