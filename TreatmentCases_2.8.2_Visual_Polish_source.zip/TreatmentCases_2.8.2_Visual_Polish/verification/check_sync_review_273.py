#!/usr/bin/env python3
"""Review/apply safeguards for 2.7.5-dev; static source checks plus SQLite behavior simulation."""
from pathlib import Path
import sqlite3
root=Path(__file__).resolve().parents[1]
db=(root/'android/app/src/main/java/com/treatmentcases/app/LocalDb.kt').read_text(encoding='utf-8')
ui=(root/'android/app/src/main/java/com/treatmentcases/app/MainActivity.kt').read_text(encoding='utf-8')
gradle=(root/'android/app/build.gradle').read_text(encoding='utf-8')
checks=[
 ('review queue reads received/conflict/error only', 'fun syncReviewItems(limit:Int=100)' in db and "apply_state IN ('received','conflict','error')" in db),
 ('review dialog compares local and remote payloads', 'item.localPayloadJson.take(5000)' in ui and 'item.payloadJson.take(5000)' in ui),
 ('remote upsert is applied only after explicit action', 'fun applyReviewedRemoteEvent(eventId:String)' in db and 'Apply Incoming' in ui),
 ('remote delete is blocked safely', 'if(operation!="upsert")return' in db and 'item.operation=="upsert"' in ui),
 ('payload size is bounded', 'payloadText.length<=131072' in db),
 ('payload columns are allowlisted from table schema', 'PRAGMA table_info($table)' in db and 'if(key !in allowed)return' in db),
 ('natural-key collisions are not silently merged', 'يوجد سجل محلي مشابه بمعرّف مختلف' in db),
 ('remote case uses existing case validation and medicine catalog matching', 'CaseDataRules.validate(listOf(record))' in db and 'medicineNameMatch(record.medicine)' in db),
 ('employee and medicine fields have length limits', 'field("performance_no").length>64' in db and 'field("name").length>200' in db),
 ('payload UUID must match event UUID', 'json.optString("entity_uuid")!=uuid' in db),
 ('review uses optimistic local-version check', 'if(localVersion!=reviewedVersion)return' in db),
 ('inbound apply suppresses outbound capture', 'suppress_capture=1' in db and 'suppress_capture=0' in db),
 ('remote decision updates inbox and conflict ledger', 'put("apply_state","applied")' in db and 'put("resolution","remote_wins")' in db),
 ('remote win supersedes pending local outbox events', 'تم اعتماد النسخة الواردة بقرار المستخدم' in db and "delivery_state='pending'" in db),
 ('keep-local decision republishes newer local revision', 'fun keepLocalForRemoteEvent' in db and 'put("delivery_state","superseded")' in db and 'put("base_version",baseVersion)' in db),
 ('keep-local is offered for conflicts and incoming deletes', 'enabled=item.state=="conflict"||item.operation=="delete"' in ui),
 ('defer leaves the event pending', 'Text(appLabel("لاحقاً","Later",isEnglish))' in ui),
 ('development package is isolated and versioned', "applicationId 'com.treatmentcases.app.preview275'" in gradle and "versionCode 34" in gradle and "versionName '2.8.2-visual-polish'" in gradle),
 ('schema version advanced to 11 with additive account migration', 'treatment_cases_local.db",null,11' in db and 'if(oldVersion<11)' in db),
]
for name,ok in checks: print(('PASS' if ok else 'FAIL')+': '+name)
assert all(ok for _,ok in checks)
# Transactional model: accepted remote updates suppress echo capture and version drift rejects stale approval.
con=sqlite3.connect(':memory:'); c=con.cursor()
c.executescript('''
CREATE TABLE cases(id INTEGER PRIMARY KEY,name TEXT NOT NULL);
CREATE TABLE sync_entity_identity(entity_type TEXT,local_id INTEGER,entity_uuid TEXT UNIQUE,version INTEGER,PRIMARY KEY(entity_type,local_id));
CREATE TABLE sync_outbox(event_uuid TEXT PRIMARY KEY,entity_uuid TEXT,operation TEXT,base_version INTEGER,new_version INTEGER,delivery_state TEXT);
CREATE TABLE sync_inbox(event_uuid TEXT PRIMARY KEY,apply_state TEXT,base_version INTEGER,remote_version INTEGER,payload_json TEXT);
CREATE TABLE sync_conflicts(remote_event_uuid TEXT,local_version INTEGER,resolution TEXT);
CREATE TABLE sync_runtime_flags(id INTEGER PRIMARY KEY,suppress_capture INTEGER);
INSERT INTO sync_runtime_flags VALUES(1,0);
INSERT INTO cases VALUES(1,'local'); INSERT INTO sync_entity_identity VALUES('case',1,'entity-a',4);
INSERT INTO sync_inbox VALUES('event-a','conflict',3,5,'{"name":"remote"}');
INSERT INTO sync_conflicts VALUES('event-a',4,'pending');
CREATE TRIGGER capture_case_update AFTER UPDATE ON cases WHEN (SELECT suppress_capture FROM sync_runtime_flags WHERE id=1)=0 BEGIN INSERT INTO sync_outbox VALUES('local-echo','entity-a','upsert',4,5,'pending'); END;
''')
# A reviewed conflict at local version 4 can be applied atomically without creating an echo.
c.execute('BEGIN')
c.execute('UPDATE sync_runtime_flags SET suppress_capture=1 WHERE id=1')
c.execute("UPDATE cases SET name='remote' WHERE id=1")
c.execute("UPDATE sync_entity_identity SET version=5 WHERE entity_uuid='entity-a'")
c.execute("UPDATE sync_inbox SET apply_state='applied' WHERE event_uuid='event-a'")
c.execute("UPDATE sync_conflicts SET resolution='remote_wins' WHERE remote_event_uuid='event-a'")
c.execute('UPDATE sync_runtime_flags SET suppress_capture=0 WHERE id=1')
con.commit()
assert c.execute('SELECT name FROM cases').fetchone()==('remote',)
assert c.execute('SELECT version FROM sync_entity_identity').fetchone()==(5,)
assert c.execute('SELECT COUNT(*) FROM sync_outbox').fetchone()==(0,)
assert c.execute('SELECT apply_state FROM sync_inbox').fetchone()==('applied',)
print('PASS: SQLite apply simulation commits remote row + version + inbox atomically without echo')
# A local edit after review must invalidate the earlier approval.
c.execute("UPDATE sync_entity_identity SET version=6 WHERE entity_uuid='entity-a'")
con.commit()
current=c.execute('SELECT version FROM sync_entity_identity').fetchone()[0]
reviewed=c.execute('SELECT local_version FROM sync_conflicts WHERE remote_event_uuid=?',('event-a',)).fetchone()[0]
assert current!=reviewed
print('PASS: SQLite stale-review simulation detects local version drift')
# Keep-local emits a new event from the current local version.
c.execute('BEGIN')
base=c.execute('SELECT version FROM sync_entity_identity').fetchone()[0]
c.execute("UPDATE sync_entity_identity SET version=? WHERE entity_uuid='entity-a'",(base+1,))
c.execute("INSERT INTO sync_outbox VALUES('local-choice','entity-a','upsert',?,?, 'pending')",(base,base+1))
c.execute("UPDATE sync_inbox SET apply_state='kept_local' WHERE event_uuid='event-a'")
c.execute("UPDATE sync_conflicts SET resolution='local_kept' WHERE remote_event_uuid='event-a'")
con.commit()
assert c.execute("SELECT base_version,new_version FROM sync_outbox WHERE event_uuid='local-choice'").fetchone()==(6,7)
print('PASS: SQLite keep-local simulation republishes the local choice as a new version')
print(f'{len(checks)+3} sync-review assertions passed')
