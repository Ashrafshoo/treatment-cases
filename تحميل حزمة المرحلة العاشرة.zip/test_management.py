import unittest, tempfile, sqlite3
from pathlib import Path
import management, security

ROOT=Path(__file__).resolve().parent

class ManagementTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.db=Path(self.tmp.name)/'med.db'
        c=sqlite3.connect(self.db)
        c.executescript("""
        CREATE TABLE Personnel(personnel_id INTEGER PRIMARY KEY AUTOINCREMENT,performance_number TEXT NOT NULL UNIQUE,full_name TEXT,job_title TEXT,region TEXT,department TEXT,mobile1 TEXT,mobile2 TEXT,national_id TEXT,gender TEXT,birth_date TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP,source_batch_id INTEGER);
        CREATE TABLE Beneficiaries(beneficiary_id INTEGER PRIMARY KEY AUTOINCREMENT,source_batch_id INTEGER NOT NULL,source_sheet TEXT NOT NULL,source_row INTEGER NOT NULL,source_serial TEXT,region TEXT,department TEXT,full_name TEXT,performance_number TEXT,dispensing_duration TEXT,dosage_text TEXT,medical_condition TEXT,approval_date TEXT,original_row_json TEXT NOT NULL);
        CREATE TABLE Treatment_Entries(treatment_entry_id INTEGER PRIMARY KEY AUTOINCREMENT,beneficiary_id INTEGER NOT NULL REFERENCES Beneficiaries(beneficiary_id),treatment_order INTEGER NOT NULL,medicine_name_raw TEXT,strength_raw TEXT,source_field TEXT NOT NULL,UNIQUE(beneficiary_id,treatment_order));
        CREATE TABLE Import_Batches(batch_id INTEGER PRIMARY KEY,batch_name TEXT NOT NULL,source_file TEXT NOT NULL,source_sha256 TEXT NOT NULL,imported_at TEXT NOT NULL,source_note TEXT);
        INSERT INTO Import_Batches VALUES(1,'fixture','fixture.xlsx','abc','2026-01-01',NULL);
        CREATE TABLE Data_Audit_Log(audit_id INTEGER PRIMARY KEY,entity_type TEXT,entity_key TEXT,action TEXT,before_json TEXT,after_json TEXT,actor TEXT,action_at TEXT DEFAULT CURRENT_TIMESTAMP);
        """)
        c.commit(); c.close()
        self.auth=Path(self.tmp.name)/'auth.db'
        security.initialize(self.auth); management.initialize(self.db)

    def tearDown(self): self.tmp.cleanup()

    def test_add_person_and_audit(self):
        perf=management.save_person(self.db,{'performance_number':'TEST-9001','full_name':'مستخدم اختبار','region':'اختبار'},'tester')
        c=sqlite3.connect(self.db)
        self.assertEqual(c.execute('select full_name from Personnel where performance_number=?',(perf,)).fetchone()[0],'مستخدم اختبار')
        self.assertEqual(c.execute("select action from Data_Audit_Log where entity_key='TEST-9001'").fetchone()[0],'INSERT')
        c.close()

    def test_duplicate_performance_rejected(self):
        with self.assertRaises(sqlite3.IntegrityError):
            management.save_person(self.db,{'performance_number':'TEST-DUP','full_name':'أول'},'tester')
            management.save_person(self.db,{'performance_number':'TEST-DUP','full_name':'ثان'},'tester')

    def test_medicine_and_strengths(self):
        mid=management.save_medicine(self.db,'دواء اختبار','مادة فعالة','أقراص','تخصص','10 mg, 20 mg','tester')
        rows=management.list_medicines(self.db)
        found=next(x for x in rows if x['medicine_id']==mid)
        self.assertIn('10 mg',found['strengths']); self.assertIn('20 mg',found['strengths'])

    def test_medicine_alias_mapping_preserves_raw_alias_and_audits(self):
        mid=management.save_medicine(self.db,'الاسم المعتمد','مادة فعالة','أقراص','تخصص','10 mg','tester')
        canonical=management.save_medicine_alias(self.db,'اسم قديم مختلف',mid,'reviewer')
        self.assertEqual(canonical,'الاسم المعتمد')
        c=sqlite3.connect(self.db)
        self.assertEqual(c.execute('SELECT medicine_name FROM Medicine_Dictionary WHERE medicine_id=?',(mid,)).fetchone()[0],'الاسم المعتمد')
        self.assertEqual(c.execute('SELECT medicine_id FROM Medicine_Name_Aliases WHERE raw_alias=?',('اسم قديم مختلف',)).fetchone()[0],mid)
        self.assertEqual(c.execute("SELECT action FROM Data_Audit_Log WHERE entity_type='MEDICINE_ALIAS'").fetchone()[0],'MAP_ALIAS')
        c.close()

    def test_add_treatment_links_person_and_creates_case(self):
        management.save_person(self.db,{'performance_number':'TREAT-1','full_name':'مستفيد اختبار'},'tester')
        management.add_treatment(self.db,{'performance_number':'TREAT-1','medicine_name_raw':'دواء تجريبي','strength_raw':'5 mg','treatment_order':'1'},'tester')
        c=sqlite3.connect(self.db)
        self.assertEqual(c.execute('select count(*) from Beneficiaries where performance_number=?',('TREAT-1',)).fetchone()[0],1)
        self.assertEqual(c.execute('select medicine_name_raw from Treatment_Entries').fetchone()[0],'دواء تجريبي')
        c.close()

    def test_user_disable_revokes_sessions(self):
        uid=security.create_user(self.auth,'testuser','مستخدم اختبار','Password12345!','viewer')
        token=security.create_session(self.auth,uid)
        management.set_user_active(self.auth,uid,False,'admin')
        self.assertIsNone(security.validate_session(self.auth,token))

if __name__=='__main__': unittest.main()
