package com.treatmentcases.app

fun main() {
    var assertions = 0
    fun expect(condition: Boolean, label: String) {
        check(condition) { "FAILED: $label" }
        assertions++
    }
    fun record(
        name: String = "أحمد",
        performance: String = "00123",
        medicine: String = "دواء أ",
        strength: String = "10mg",
        approval: String = "2026-01-01",
        expiry: String = "2026-12-31"
    ) = CaseRecord(name = name, performanceNo = performance, medicine = medicine,
        strength = strength, approvalDate = approval, approvalExpiry = expiry)

    expect(CaseDataRules.isValidIsoDate("2024-02-29"), "valid leap date")
    expect(!CaseDataRules.isValidIsoDate("2025-02-29"), "invalid leap date")
    expect(!CaseDataRules.isValidIsoDate("2026-13-01"), "invalid month")
    expect(!CaseDataRules.isValidIsoDate("2026-01-01junk"), "trailing date content")
    expect(!CaseDataRules.isValidIsoDate("2026-00-10"), "zero month rejected")
    expect(!CaseDataRules.isValidIsoDate("2026-04-31"), "impossible day rejected")
    expect(CaseDataRules.normalizePerformanceNo(" ٠٠١٢٣ ") == "00123", "Arabic digit normalization")
    expect(CaseDataRules.normalizePerformanceNo(" ۰۰۱۲۳ ") == "00123", "Persian digit normalization")
    expect(CaseDataRules.normalizePerformanceNo("00 123") == "00123", "performance spaces removed without losing leading zeros")
    expect(CaseDataRules.validate(listOf(record())).isEmpty(), "valid row")
    expect(CaseDataRules.validate(listOf(record(expiry = "2025-12-31"))).any { it.contains("يسبق") }, "expiry before approval")
    expect(CaseDataRules.validate(listOf(record(approval = "2026-02-30"))).any { it.contains("تاريخ الموافقة") }, "invalid approval date rejected")
    expect(CaseDataRules.validate(listOf(record(expiry = "2026-02-30"))).any { it.contains("تاريخ انتهاء") }, "invalid expiry date rejected")
    expect(CaseDataRules.validate(listOf(record(performance = ""))).any { it.contains("رقم الأداء مطلوب") }, "required performance number")
    expect(CaseDataRules.validate(listOf(record(name = ""))).any { it.contains("اسم العامل مطلوب") }, "required employee name")
    expect(CaseDataRules.validate(listOf(record(medicine = ""))).any { it.contains("اسم الدواء مطلوب") }, "required medicine")
    expect(CaseDataRules.validate(listOf(record(), record(name = "اسم مختلف"))).any { it.contains("مرتبط باسمين") }, "conflicting names for same performance number")
    expect(CaseDataRules.validate(listOf(record(), record(medicine = "دواء ب"))).isEmpty(), "multiple medicines for same employee are valid")
    val normalized = record(name = " أحمد ", performance = " ٠٠١٢٣ ", medicine = "دواء   أ")
    expect(CaseDataRules.signature(record()) == CaseDataRules.signature(normalized), "normalized duplicate signature")
    expect(CaseDataRules.signature(record()) != CaseDataRules.signature(record(strength = "20mg")), "different strength is a different treatment record")
    expect(CaseDataRules.signature(record()) != CaseDataRules.signature(record(approval = "2026-02-01")), "different approval date is a different treatment record")
    expect(CaseDataRules.signature(record(medicine = "  دواء   أ ")) == CaseDataRules.signature(record(medicine = "دواء أ")), "medicine whitespace normalization")
    expect(CaseDataRules.validate(listOf(record(name = "أ".repeat(201)))).any { it.contains("200") }, "oversized name rejected")
    println("PASS: $assertions CaseDataRules regression assertions")
}
