import 'package:flutter/material.dart';
import '../data/records_repository.dart';
import '../../auth/data/app_session.dart';
import '../../archive_review/presentation/archive_review_screen.dart';

class RecordsScreen extends StatefulWidget {
  const RecordsScreen({super.key, this.initialTab = 0});
  final int initialTab;
  @override
  State<RecordsScreen> createState() => _RecordsScreenState();
}

class _RecordsScreenState extends State<RecordsScreen> with SingleTickerProviderStateMixin {
  final _repo = RecordsRepository();
  late final TabController _tabs = TabController(length: 5, initialIndex: widget.initialTab.clamp(0, 4).toInt(), vsync: this);
  int _refresh = 0;
  void _reload() => setState(() => _refresh++);
  @override
  void dispose() { _tabs.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('إدارة البيانات الأساسية'), bottom: TabBar(controller: _tabs, tabs: const [Tab(text: 'العقارات'), Tab(text: 'الوحدات'), Tab(text: 'المستأجرون'), Tab(text: 'الملاك'), Tab(text: 'حصص الملكية')]), actions:[if(AppSession.instance.isAdmin)IconButton(tooltip:'مجموعات العقارات',onPressed:_manageGroups,icon:const Icon(Icons.folder_copy_outlined))]),
    body: FutureBuilder<Map<String,int>>(
      key: ValueKey(_refresh), future: _repo.counts(),
      builder: (context, snapshot) => Column(children: [
        if (snapshot.hasData) Padding(padding: const EdgeInsets.all(10), child: Wrap(spacing: 18, children: [Text('العقارات: ${snapshot.data!['properties']}'), Text('الوحدات: ${snapshot.data!['units']}'), Text('المستأجرون: ${snapshot.data!['tenants']}'), Text('الملاك: ${snapshot.data!['owners']}')])) ,
        Expanded(child: TabBarView(controller: _tabs, children: [
          _RecordList(future: _repo.properties(), titleField: 'name', subtitle: (m) => '${m['group_name'] == null ? '' : '${m['group_name']} • '}${m['address_text'] ?? 'لا يوجد عنوان'}', onAdd: () => _propertyDialog(), onEdit: (m) => _propertyDialog(row:m), onArchive: (m) => _archive('properties',m), onClearModified:(m)=>_clearModified('properties',m)),
          _RecordList(future: _repo.units(), titleField: 'unit_number', subtitle: (m) => '${m['property_name']} • ${m['unit_type'] ?? 'وحدة'} • ${m['tenant_name'] ?? 'بلا مستأجر'}', onAdd: () => _unitDialog(), onEdit: (m) => _unitDialog(row:m), onArchive: (m) => _archive('units',m), onClearModified:(m)=>_clearModified('units',m), onDocuments:_openUnitDocuments),
          _RecordList(future: _repo.tenants(), titleField: 'full_name', subtitle: (m) => (m['phone'] ?? 'لا يوجد هاتف').toString(), onAdd: () => _tenantDialog(), onEdit: (m) => _tenantDialog(row:m), onArchive: (m) => _archive('tenants',m), onClearModified:(m)=>_clearModified('tenants',m)),
          _RecordList(future: _repo.owners(), titleField: 'full_name', subtitle: (m) => (m['phone'] ?? 'لا يوجد هاتف').toString(), onAdd: () => _ownerDialog(), onEdit: (m) => _ownerDialog(row:m), onArchive: (m) => _archive('owners',m), onClearModified:(m)=>_clearModified('owners',m)),
          _RecordList(future: _repo.ownershipShares(), titleField: 'owner_name', subtitle: (m) => '${m['property_name']} • ${m['share_percent']}%', onAdd: () => _shareDialog(), onEdit: (m) => _shareDialog(row:m), onArchive: (_) {}, allowArchive:false, onClearModified:(m)=>_clearModified('ownership_shares',m)),
        ]))
      ]),
    ),
  );

  Future<void> _openUnitDocuments(Map<String,Object?> unit) async {
    await Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => ArchiveReviewScreen(
      entityType: 'unit', entityId: unit['id'] as String,
      title: 'مستندات الوحدة ${unit['unit_number'] ?? ''}',
    )));
    if (mounted) _reload();
  }

  Future<void> _propertyDialog({Map<String,Object?>? row}) async {
    final groups=await _repo.propertyGroups();
    if(!mounted)return;
    final name=TextEditingController(text:row?['name']?.toString()??'');
    final address=TextEditingController(text:row?['address_text']?.toString()??'');
    final city=TextEditingController(text:row?['city']?.toString()??'');
    final district=TextEditingController(text:row?['district']?.toString()??'');
    final notes=TextEditingController(text:row?['notes']?.toString()??'');
    String? groupId=row?['group_id'] as String?;
    if(groupId!=null&&!groups.any((g)=>g['id']==groupId))groupId=null;
    await showDialog<void>(context:context,builder:(ctx)=>StatefulBuilder(builder:(ctx,setLocal)=>AlertDialog(
      title:Text(row==null?'إضافة عقار':'تعديل عقار'),
      content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
        _field(name,'اسم العقار *'),
        DropdownButtonFormField<String?>(value:groupId,decoration:const InputDecoration(labelText:'مجموعة / بيت (اختياري)'),items:[const DropdownMenuItem<String?>(value:null,child:Text('بدون مجموعة')),...groups.map((g)=>DropdownMenuItem<String?>(value:g['id'] as String,child:Text(g['name'] as String)))],onChanged:(v)=>setLocal(()=>groupId=v)),
        _field(address,'العنوان'),_field(city,'المدينة'),_field(district,'المنطقة / الحي'),_field(notes,'ملاحظات'),
      ])),
      actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('إلغاء')),FilledButton(onPressed:()async{if(name.text.trim().isEmpty)return;await _repo.saveProperty(id:row?['id']?.toString(),name:name.text,address:address.text,city:city.text,district:district.text,notes:notes.text,groupId:groupId);if(ctx.mounted)Navigator.pop(ctx);_reload();},child:const Text('حفظ'))],
    )));
    name.dispose();address.dispose();city.dispose();district.dispose();notes.dispose();
  }

  Future<void> _manageGroups() async {
    var groups=await _repo.propertyGroups();
    final name=TextEditingController(),description=TextEditingController();
    if(!mounted)return;
    await showDialog<void>(context:context,builder:(ctx)=>StatefulBuilder(builder:(ctx,setLocal)=>AlertDialog(
      title:const Text('مجموعات العقارات / البيوت'),
      content:SizedBox(width:420,child:Column(mainAxisSize:MainAxisSize.min,children:[
        TextField(controller:name,decoration:const InputDecoration(labelText:'اسم المجموعة / البيت')),
        TextField(controller:description,decoration:const InputDecoration(labelText:'وصف اختياري')),
        const SizedBox(height:8),
        FilledButton.icon(onPressed:()async{if(name.text.trim().isEmpty)return;try{await _repo.savePropertyGroup(name:name.text,description:description.text);name.clear();description.clear();groups=await _repo.propertyGroups();setLocal((){});}catch(e){if(ctx.mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}},icon:const Icon(Icons.add),label:const Text('إضافة مجموعة')),
        const Divider(),
        SizedBox(height:220,child:ListView(children:groups.map((g)=>ListTile(title:Text('${g['name']}'),subtitle:Text('${g['description']??''}'),trailing:IconButton(icon:const Icon(Icons.archive_outlined),onPressed:()async{try{await _repo.archivePropertyGroup(g['id'] as String);groups=await _repo.propertyGroups();setLocal((){});}catch(e){if(ctx.mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}}))).toList())),
      ])),
      actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('إغلاق'))],
    )));
    name.dispose();description.dispose();
    if(mounted)_reload();
  }

  Future<void> _tenantDialog({Map<String,Object?>? row}) async {
    final name = TextEditingController(text: row?['full_name']?.toString() ?? '');
    final phone = TextEditingController(text: row?['phone']?.toString() ?? '');
    final nationalId = TextEditingController(text: row?['national_id_last4']?.toString() ?? '');
    final notes = TextEditingController(text: row?['notes']?.toString() ?? '');
    await _formDialog('المستأجر', [_field(name,'اسم المستأجر *'),_field(phone,'رقم الهاتف',keyboard:TextInputType.phone),_field(nationalId,'آخر 4 أرقام من الرقم القومي'),_field(notes,'ملاحظات')], () async { if(name.text.trim().isEmpty)return; await _repo.saveTenant(id:row?['id']?.toString(),name:name.text,phone:phone.text,nationalIdLast4:nationalId.text,notes:notes.text); _reload(); });
    name.dispose();phone.dispose();nationalId.dispose();notes.dispose();
  }

  Future<void> _ownerDialog({Map<String,Object?>? row}) async {
    final name=TextEditingController(text:row?['full_name']?.toString()??'');
    final phone=TextEditingController(text:row?['phone']?.toString()??'');
    final notes=TextEditingController(text:row?['notes']?.toString()??'');
    await _formDialog(row==null?'إضافة مالك':'تعديل مالك',[_field(name,'اسم المالك *'),_field(phone,'رقم الهاتف'),_field(notes,'ملاحظات')],()async{if(name.text.trim().isEmpty)return;await _repo.saveOwner(id:row?['id'] as String?,name:name.text,phone:phone.text,notes:notes.text);_reload();});
    name.dispose();phone.dispose();notes.dispose();
  }

  Future<void> _shareDialog({Map<String,Object?>? row}) async {
    final properties=await _repo.properties();final owners=await _repo.owners();
    if(!mounted)return;
    if(properties.isEmpty||owners.isEmpty){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('أضف عقاراً ومالكاً أولاً')));return;}
    String propertyId=(row?['property_id'] as String?)??(properties.first['id'] as String);
    String ownerId=(row?['owner_id'] as String?)??(owners.first['id'] as String);
    final percent=TextEditingController(text:row?['share_percent']?.toString()??'');
    final notes=TextEditingController(text:row?['notes']?.toString()??'');
    DateTime? from=row?['valid_from']==null?null:DateTime.tryParse(row!['valid_from'] as String);
    DateTime? to=row?['valid_to']==null?null:DateTime.tryParse(row!['valid_to'] as String);
    String fmt(DateTime? d)=>d==null?'غير محدد':'${d.year}-${d.month.toString().padLeft(2,'0')}-${d.day.toString().padLeft(2,'0')}';
    await showDialog<void>(context:context,builder:(ctx)=>StatefulBuilder(builder:(ctx,setLocal)=>AlertDialog(title:Text(row==null?'إضافة حصة ملكية':'تعديل حصة ملكية'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
      DropdownButtonFormField<String>(value:propertyId,decoration:const InputDecoration(labelText:'العقار'),items:properties.map((r)=>DropdownMenuItem(value:r['id'] as String,child:Text(r['name'] as String))).toList(),onChanged:(v)=>setLocal(()=>propertyId=v??propertyId)),
      DropdownButtonFormField<String>(value:ownerId,decoration:const InputDecoration(labelText:'المالك'),items:owners.map((r)=>DropdownMenuItem(value:r['id'] as String,child:Text(r['full_name'] as String))).toList(),onChanged:(v)=>setLocal(()=>ownerId=v??ownerId)),
      TextField(controller:percent,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'نسبة الملكية %')),
      ListTile(title:const Text('بداية سريان الحصة'),subtitle:Text(fmt(from)),trailing:IconButton(icon:const Icon(Icons.calendar_month),onPressed:()async{final d=await showDatePicker(context:ctx,initialDate:from??DateTime.now(),firstDate:DateTime(1950),lastDate:DateTime(2100));if(d!=null)setLocal(()=>from=d);})),
      ListTile(title:const Text('نهاية سريان الحصة'),subtitle:Text(fmt(to)),trailing:Wrap(children:[IconButton(icon:const Icon(Icons.calendar_month),onPressed:()async{final d=await showDatePicker(context:ctx,initialDate:to??from??DateTime.now(),firstDate:DateTime(1950),lastDate:DateTime(2100));if(d!=null)setLocal(()=>to=d);}),IconButton(icon:const Icon(Icons.clear),onPressed:()=>setLocal(()=>to=null))])),
      TextField(controller:notes,decoration:const InputDecoration(labelText:'ملاحظات')),
    ])),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('إلغاء')),FilledButton(onPressed:()async{try{final value=double.parse(percent.text.trim());await _repo.saveOwnershipShare(id:row?['id'] as String?,propertyId:propertyId,ownerId:ownerId,percent:value,validFrom:from,validTo:to,notes:notes.text);if(ctx.mounted)Navigator.pop(ctx);_reload();}catch(e){if(ctx.mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تعذر حفظ الحصة: $e')));}},child:const Text('حفظ'))])));
    percent.dispose();notes.dispose();
  }

  Future<void> _unitDialog({Map<String,Object?>? row}) async {
    final props = await _repo.properties(); final tenants = await _repo.tenants();
    if (!mounted) return;
    if (props.isEmpty) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('أضف عقاراً أولاً قبل إضافة وحدة.'))); return; }
    String propertyId = row?['property_id']?.toString() ?? props.first['id'].toString();
    String? tenantId = row?['current_tenant_id']?.toString();
    String type = row?['unit_type']?.toString() ?? 'سكني';
    bool oldLaw164 = (row?['old_law_164_2025'] as num?)?.toInt() == 1;
    String occupancy = row?['occupancy_status']?.toString() ?? 'unknown';
    final number = TextEditingController(text:row?['unit_number']?.toString() ?? '');
    final floor = TextEditingController(text:row?['floor_label']?.toString() ?? '');
    final area = TextEditingController(text:row?['area']?.toString() ?? '');
    final addressDetails = TextEditingController(text:row?['address_details']?.toString() ?? '');
    final notes = TextEditingController(text:row?['notes']?.toString() ?? '');
    await showDialog<void>(context:context,builder:(ctx)=>StatefulBuilder(builder:(ctx,setLocal)=>AlertDialog(
      title:Text(row==null?'إضافة وحدة':'تعديل وحدة'), content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
        TextField(controller:number,decoration:const InputDecoration(labelText:'رقم الوحدة / وصفها')),
        TextField(controller:floor,decoration:const InputDecoration(labelText:'الدور')),
        TextField(controller:area,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'المساحة (اختياري)')),
        TextField(controller:addressDetails,decoration:const InputDecoration(labelText:'تفاصيل العنوان')),
        DropdownButtonFormField<String>(value:propertyId,decoration:const InputDecoration(labelText:'العقار'),items:props.map((p)=>DropdownMenuItem(value:p['id'].toString(),child:Text(p['name'].toString(),overflow:TextOverflow.ellipsis))).toList(),onChanged:(v)=>setLocal(()=>propertyId=v!)),
        DropdownButtonFormField<String>(value:type,decoration:const InputDecoration(labelText:'نوع الوحدة'),items:const [DropdownMenuItem(value:'سكني',child:Text('سكني')),DropdownMenuItem(value:'شقة',child:Text('شقة')),DropdownMenuItem(value:'تجاري',child:Text('تجاري')),DropdownMenuItem(value:'محل',child:Text('محل')),DropdownMenuItem(value:'دكان',child:Text('دكان')),DropdownMenuItem(value:'مصنع',child:Text('مصنع')),DropdownMenuItem(value:'مخزن',child:Text('مخزن')),DropdownMenuItem(value:'مكتب',child:Text('مكتب')),DropdownMenuItem(value:'عيادة',child:Text('عيادة')),DropdownMenuItem(value:'استوديو تصوير',child:Text('استوديو تصوير')),DropdownMenuItem(value:'جراج',child:Text('جراج')),DropdownMenuItem(value:'أرض',child:Text('أرض')),DropdownMenuItem(value:'ورشة',child:Text('ورشة')),DropdownMenuItem(value:'أخرى',child:Text('أخرى'))],onChanged:(v)=>setLocal(()=>type=v!)),
        SwitchListTile(contentPadding:EdgeInsets.zero,title:const Text('وسم إيجار قديم – قانون 164 لسنة 2025'),value:oldLaw164,onChanged:(v)=>setLocal(()=>oldLaw164=v)),
        DropdownButtonFormField<String>(value:occupancy,decoration:const InputDecoration(labelText:'حالة الإشغال'),items:const [DropdownMenuItem(value:'unknown',child:Text('غير محدد')),DropdownMenuItem(value:'occupied',child:Text('مشغولة')),DropdownMenuItem(value:'vacant',child:Text('شاغرة')),DropdownMenuItem(value:'closed',child:Text('مغلقة'))],onChanged:(v)=>setLocal(()=>occupancy=v!)),
        DropdownButtonFormField<String?>(value:tenantId,decoration:const InputDecoration(labelText:'المستأجر الحالي (اختياري)'),items:[const DropdownMenuItem<String?>(value:null,child:Text('بدون مستأجر')), ...tenants.map((t)=>DropdownMenuItem<String?>(value:t['id'].toString(),child:Text(t['full_name'].toString())))],onChanged:(v)=>setLocal(()=>tenantId=v)),
        TextField(controller:notes,decoration:const InputDecoration(labelText:'ملاحظات')),
      ])),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('إلغاء')),FilledButton(onPressed:()async{await _repo.saveUnit(id:row?['id']?.toString(),propertyId:propertyId,number:number.text,type:type,occupancy:occupancy,floorLabel:floor.text,area:area.text.trim().isEmpty?null:double.tryParse(area.text),addressDetails:addressDetails.text,oldLaw164:oldLaw164,tenantId:tenantId,notes:notes.text);if(ctx.mounted)Navigator.pop(ctx);_reload();},child:const Text('حفظ'))])));
    number.dispose();floor.dispose();area.dispose();addressDetails.dispose();notes.dispose();
  }

  Widget _field(TextEditingController c,String label,{TextInputType? keyboard}) => Padding(padding:const EdgeInsets.only(bottom:10),child:TextField(controller:c,keyboardType:keyboard,decoration:InputDecoration(labelText:label)));
  Future<void> _formDialog(String title,List<Widget> fields,Future<void> Function() save) async {
    await showDialog<void>(context:context,builder:(ctx)=>AlertDialog(title:Text(title),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:fields)),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('إلغاء')),FilledButton(onPressed:()async{await save();if(ctx.mounted)Navigator.pop(ctx);},child:const Text('حفظ'))]));
  }
  Future<void> _clearModified(String table,Map<String,Object?> row) async {
    final ok=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(title:const Text('تأكيد المراجعة'),content:const Text('سيتم إزالة علامة التعديل بعد مراجعة بيانات السجل.'),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('تمت المراجعة'))]));
    if(ok==true){try{await _repo.clearModifiedFlag(table,row['id'] as String);_reload();}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}}
  }

  Future<void> _archive(String table,Map<String,Object?> row) async {
    final ok=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(title:const Text('تأكيد الأرشفة'),content:const Text('سيتم إخفاء السجل من القوائم دون حذف بياناته التاريخية.'),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('أرشفة'))]));
    if(ok==true){try{await _repo.archive(table,row['id'].toString());_reload();}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تعذر الأرشفة: $e')));}}
  }
}

class _RecordList extends StatelessWidget {
  const _RecordList({
    required this.future,
    required this.titleField,
    required this.subtitle,
    required this.onAdd,
    required this.onEdit,
    required this.onArchive,
    this.allowArchive = true,
    this.onClearModified,
    this.onDocuments,
  });

  final Future<List<Map<String, Object?>>> future;
  final String titleField;
  final String Function(Map<String, Object?>) subtitle;
  final VoidCallback onAdd;
  final ValueChanged<Map<String, Object?>> onEdit;
  final ValueChanged<Map<String, Object?>> onArchive;
  final bool allowArchive;
  final ValueChanged<Map<String, Object?>>? onClearModified;
  final ValueChanged<Map<String, Object?>>? onDocuments;

  @override
  Widget build(BuildContext context) => FutureBuilder<List<Map<String, Object?>>>(
        future: future,
        builder: (context, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text('تعذر تحميل البيانات: ${snapshot.error}'));
          }
          final rows = snapshot.data ?? [];
          return Stack(
            children: [
              if (rows.isEmpty)
                const Center(child: Text('لا توجد سجلات بعد. اضغط + لإضافة أول سجل.'))
              else
                ListView.separated(
                  padding: const EdgeInsets.only(bottom: 88),
                  itemCount: rows.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (context, index) {
                    final row = rows[index];
                    final reviewStatus = row['review_status'];
                    final modified = (row['modified_unreviewed'] as num?)?.toInt() == 1;
                    final tileColor = reviewStatus == 'incorrect'
                        ? Theme.of(context).colorScheme.errorContainer.withOpacity(0.35)
                        : modified
                            ? Theme.of(context).colorScheme.tertiaryContainer.withOpacity(0.35)
                            : reviewStatus == 'needs_review'
                                ? Theme.of(context).colorScheme.secondaryContainer.withOpacity(0.22)
                                : null;
                    return ListTile(
                      title: Text((row[titleField] ?? '—').toString()),
                      subtitle: Text(subtitle(row)),
                      onTap: AppSession.instance.isAdmin ? () => onEdit(row) : null,
                      tileColor: tileColor,
                      trailing: (AppSession.instance.isAdmin || onDocuments != null)
                          ? PopupMenuButton<String>(
                              onSelected: (value) {
                                if (value == 'edit') onEdit(row);
                                if (value == 'archive') onArchive(row);
                                if (value == 'clear') onClearModified?.call(row);
                                if (value == 'documents') onDocuments?.call(row);
                              },
                              itemBuilder: (_) => [
                                if (AppSession.instance.isAdmin)
                                  const PopupMenuItem(value: 'edit', child: Text('تعديل')),
                                if (AppSession.instance.isAdmin && allowArchive)
                                  const PopupMenuItem(value: 'archive', child: Text('أرشفة')),
                                if (AppSession.instance.isAdmin && onClearModified != null && modified)
                                  const PopupMenuItem(
                                    value: 'clear',
                                    child: Text('إزالة علامة التعديل بعد المراجعة'),
                                  ),
                                if (onDocuments != null)
                                  const PopupMenuItem(
                                    value: 'documents',
                                    child: Text('العقود والمستندات'),
                                  ),
                              ],
                            )
                          : null,
                    );
                  },
                ),
              if (AppSession.instance.isAdmin)
                Positioned(
                  left: 16,
                  bottom: 16,
                  child: FloatingActionButton(onPressed: onAdd, child: const Icon(Icons.add)),
                ),
            ],
          );
        },
      );
}
