import com.example.rentals.printing.VbaMonitize
fun main(){
 val values=listOf(6000.0,16200.0,15000.0,50000.0,12000.0,2248.25,1547.463,892.2505,502.205,287.5,1312.0,3087.75,4956.5,1334.0,2292.111,6274.69545953419,92.0,1776.75,1466.25,11500.0,1017.75,575.0,863.65,1619.43,610.2,251.119356542744,2071.725,410.55,5500.0,1500.0,550.0,3000.0,100.0,250.0,75.0,1000.0,184.0,224.25,187.0,120.0,800.0,172.5,70.0,50.0,62.79)
 values.forEach { value -> val words=VbaMonitize.amountWords(value); check(words.isNotBlank()) { "empty amount words for $value" } }
 println("PASS: "+values.size+" unique positive monthly template amounts converted to words")
}
