class AppSession {
  AppSession._();
  static final AppSession instance=AppSession._();
  String? userId;
  String? username;
  String? displayName;
  String? role;
  bool get isAuthenticated=>userId!=null;
  bool get isAdmin=>role=='administrator';
  bool get isViewer=>role=='family_viewer';
  void start({required String id,required String user,required String name,required String userRole}){userId=id;username=user;displayName=name;role=userRole;}
  void end(){userId=null;username=null;displayName=null;role=null;}
  void requireAdmin(){if(!isAdmin)throw StateError('هذه العملية متاحة لحساب المدير فقط');}
}
