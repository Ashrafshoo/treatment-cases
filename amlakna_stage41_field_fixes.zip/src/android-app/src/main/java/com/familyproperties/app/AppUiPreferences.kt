package com.familyproperties.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Device-local presentation preferences; never stored in the family database. */
data class UiPreferences(
    val palette: String = "classic",
    val font: String = "sans",
    val fontScale: Float = 1.0f,
    val boldText: Boolean = false,
    val biometricEnabled: Boolean = false,
    val biometricUserId: String? = null
)

object AppUiPreferences {
    var current by mutableStateOf(UiPreferences())
        private set

    fun load(context: Context) {
        val p = context.getSharedPreferences("amlakna_ui_preferences", Context.MODE_PRIVATE)
        current = UiPreferences(
            palette = p.getString("palette", "classic") ?: "classic",
            font = (p.getString("font", "sans") ?: "sans").takeIf { it in setOf("sans", "serif") } ?: "sans",
            fontScale = p.getFloat("font_scale", 1.0f).coerceIn(.85f, 1.35f),
            boldText = p.getBoolean("bold_text", false),
            biometricEnabled = p.getBoolean("biometric_enabled", false),
            biometricUserId = p.getString("biometric_user_id", null)
        )
    }

    fun update(context: Context, value: UiPreferences) {
        current = value
        context.getSharedPreferences("amlakna_ui_preferences", Context.MODE_PRIVATE).edit()
            .putString("palette", value.palette)
            .putString("font", value.font)
            .putFloat("font_scale", value.fontScale)
            .putBoolean("bold_text", value.boldText)
            .putBoolean("biometric_enabled", value.biometricEnabled)
            .putString("biometric_user_id", value.biometricUserId)
            .apply()
    }
}
