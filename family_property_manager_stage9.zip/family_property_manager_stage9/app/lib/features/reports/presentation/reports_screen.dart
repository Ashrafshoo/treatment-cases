import 'package:flutter/material.dart';
import '../data/reports_repository.dart';
import '../services/reports_print_service.dart';
import '../../auth/data/app_session.dart';

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});
  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  final _repo = ReportsRepository();
  DateTime _from = DateTime(DateTime.now().year, 1, 1);
  DateTime _to = DateTime.now();
  DateTime _statementMonth = DateTime(DateTime.now().year, DateTime.now().month, 1);
  late Future<List<Map<String, Object?>>> _rentStatement;
  late Future<Map<String, Object?>> _summary;
  late Future<List<Map<String, Object?>>> _properties;
  late Future<List<Map<String, Object?>>> _months;
  late Future<List<Map<String, Object?>>> _years;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  void _refresh() {
    _summary = _repo.summary(from: _from, to: _to);
    _rentStatement = _repo.monthlyRentStatement(_statementMonth);
    _properties = _repo.propertyStatement(from: _from, to: _to);
    _months = _repo.monthly(from: _from, to: _to);
    _years = _repo.annual();
  }

  String _money(Object? value) =>
      '${(((value as num?) ?? 0).toInt() / 100).toStringAsFixed(2)} ج.م';

  String _date(DateTime d) => '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  Future<void> _pick(bool start) async {
    final value = await showDatePicker(
      context: context,
      initialDate: start ? _from : _to,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (value != null) {
      setState(() {
        if (start) {
          _from = value;
        } else {
          _to = value;
        }
        _refresh();
      });
    }
  }

  Future<void> _pickStatementMonth() async {
    final value = await showDatePicker(context: context, initialDate: _statementMonth, firstDate: DateTime(2000), lastDate: DateTime(2100));
    if (value != null) setState(() { _statementMonth = DateTime(value.year, value.month, 1); _refresh(); });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الكشوف والتقارير'),actions:[if(AppSession.instance.isAdmin)IconButton(tooltip:'طباعة كشف الإيجارات الشهري PDF',onPressed:()async{try{await ReportsPrintService().printMonthlyStatement(_statementMonth);}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تعذرت الطباعة: $e')));}},icon:const Icon(Icons.picture_as_pdf_outlined))]),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  Expanded(child: ListTile(title: const Text('من تاريخ'), subtitle: Text(_date(_from)), onTap: () => _pick(true))),
                  Expanded(child: ListTile(title: const Text('إلى تاريخ'), subtitle: Text(_date(_to)), onTap: () => _pick(false))),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(child: ListTile(title: const Text('كشف الإيجارات الشهري المجمع'), subtitle: Text('الشهر: ${_statementMonth.year}-${_statementMonth.month.toString().padLeft(2, '0')}'), trailing: const Icon(Icons.calendar_month), onTap: _pickStatementMonth)),
          FutureBuilder<List<Map<String, Object?>>>(
            future: _rentStatement,
            builder: (context, snapshot) {
              if (snapshot.hasError) return Text('تعذر حساب كشف الإيجارات: ${snapshot.error}');
              final rows = snapshot.data ?? [];
              if (rows.isEmpty) return const ListTile(title: Text('لا توجد عقود نشطة في هذا الشهر'));
              final groups = <String, List<Map<String, Object?>>>{};
              var dueTotal = 0, paidTotal = 0;
              for (final row in rows) {
                final property = row['property_name']?.toString() ?? 'عقار غير محدد';
                groups.putIfAbsent(property, () => []).add(row);
                dueTotal += (row['due_minor'] as num).toInt();
                paidTotal += (row['paid_minor'] as num).toInt();
              }
              final remaining = dueTotal > paidTotal ? dueTotal - paidTotal : 0;
              return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(children: [
                  _metric('إجمالي المستحق', _money(dueTotal)),
                  _metric('إجمالي المحصل', _money(paidTotal)),
                  _metric('المتبقي', _money(remaining)),
                ]))),
                ...groups.entries.map((entry) => Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(entry.key, style: Theme.of(context).textTheme.titleMedium),
                  ...entry.value.map((r) {
                    final due = (r['due_minor'] as num).toInt();
                    final paid = (r['paid_minor'] as num).toInt();
                    final rest = due > paid ? due - paid : 0;
                    return ListTile(dense: true, contentPadding: EdgeInsets.zero, title: Text('${r['tenant_name']} • وحدة ${r['unit_number'] ?? '—'}'), subtitle: Text('مستحق: ${_money(due)} • محصل: ${_money(paid)}'), trailing: Text('متبقي ${_money(rest)}'));
                  }),
                ])))),
              ]);
            },
          ),
          const SizedBox(height: 12),
          FutureBuilder<Map<String, Object?>>(
            future: _summary,
            builder: (context, snapshot) {
              final r = snapshot.data ?? {};
              if (snapshot.hasError) return Text('تعذر حساب الملخص: ${snapshot.error}');
              return Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('ملخص الفترة', style: Theme.of(context).textTheme.titleLarge),
                      const SizedBox(height: 12),
                      _metric('الإيجارات المحصلة', _money(r['collected'])),
                      _metric('المصروفات العامة', _money(r['expenses'])),
                      _metric('صافي الدخل', _money(r['net_income'])),
                      const Divider(),
                      _metric('العقارات', '${r['properties_count'] ?? '—'}'),
                      _metric('الوحدات', '${r['units_count'] ?? '—'}'),
                      _metric('العقود النشطة', '${r['active_leases'] ?? '—'}'),
                      _metric('الإيصالات', '${r['receipts_count'] ?? '—'}'),
                    ],
                  ),
                ),
              );
            },
          ),
          const SizedBox(height: 16),
          Text('كشف حسب العقار', style: Theme.of(context).textTheme.titleLarge),
          FutureBuilder<List<Map<String, Object?>>>(
            future: _properties,
            builder: (context, snapshot) {
              if (snapshot.hasError) return Text('تعذر تحميل كشف العقارات: ${snapshot.error}');
              final rows = snapshot.data ?? [];
              if (rows.isEmpty) return const ListTile(title: Text('لا توجد بيانات في هذه الفترة'));
              return Column(
                children: rows.map((r) => Card(
                  child: ListTile(
                    title: Text('${r['property_name']}'),
                    subtitle: Text('عدد الوحدات: ${r['units_count']} • عدد التحصيلات: ${r['payment_count']}'),
                    trailing: Text(_money(r['collected'])),
                  ),
                )).toList(),
              );
            },
          ),
          const SizedBox(height: 16),
          Text('الملخص الشهري', style: Theme.of(context).textTheme.titleLarge),
          FutureBuilder<List<Map<String, Object?>>>(
            future: _months,
            builder: (context, snapshot) {
              if (snapshot.hasError) return Text('تعذر تحميل الملخص الشهري: ${snapshot.error}');
              final rows = snapshot.data ?? [];
              return Column(
                children: rows.map((r) => Card(
                  child: ListTile(
                    title: Text('${r['month']}'),
                    subtitle: Text('مصروفات: ${_money(r['expenses'])}'),
                    trailing: Text('تحصيل: ${_money(r['collected'])}'),
                  ),
                )).toList(),
              );
            },
          ),
          const SizedBox(height: 16),
          Text('الملخص السنوي', style: Theme.of(context).textTheme.titleLarge),
          FutureBuilder<List<Map<String, Object?>>>(
            future: _years,
            builder: (context, snapshot) {
              if (snapshot.hasError) return Text('تعذر تحميل الملخص السنوي: ${snapshot.error}');
              final rows = snapshot.data ?? [];
              return Column(
                children: rows.map((r) {
                  final net = (r['collected'] as num) - (r['expenses'] as num);
                  return Card(
                    child: ListTile(
                      title: Text('${r['year']}'),
                      subtitle: Text('صافي الدخل: ${_money(net)}'),
                      trailing: Text(_money(r['collected'])),
                    ),
                  );
                }).toList(),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _metric(String label, String value) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          children: [
            Expanded(child: Text(label)),
            Text(value, style: const TextStyle(fontWeight: FontWeight.w600)),
          ],
        ),
      );
}
