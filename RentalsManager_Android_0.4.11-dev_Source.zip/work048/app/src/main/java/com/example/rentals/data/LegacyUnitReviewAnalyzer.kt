package com.example.rentals.data

import org.json.JSONObject

/** Classifies staged Q012 unit rows for review only. It never writes operational data. */
object LegacyUnitReviewAnalyzer {
    enum class Class {
        STATUS_UNRESOLVED,
        RECEIPT_LINKED_STATUS_NOT_RECORDED,
        RECEIPT_LINKED_INCOMPLETE,
        NO_RECEIPT_LINK,
        EXCLUDED_SOURCE_ONLY,
        CLOSED_STOPPED_CONFIRMED,
        ACTIVE_FINANCIAL_UNRESOLVED,
        STOPPED_CONFIRMED,
        SOLD_ARCHIVE_ONLY,
        TENANT_CHANGE_PENDING,
        CLOSED_ARCHIVE_ONLY,
        DOCUMENTARY_DUPLICATE,
        OTHER_REVIEW
    }

    data class Result(
        val record: LegacyImportRecord,
        val code: String,
        val tenant: String,
        val sourceProperty: String,
        val address: String,
        val currentRent: String,
        val statusText: String,
        val classification: Class,
        val conflictsWithExistingCode: Boolean
    )

    fun analyze(records: List<LegacyImportRecord>, existingCodes: Set<String>): List<Result> =
        records.filter { it.recordType == "unit_source" }.map { record ->
            val json = runCatching { JSONObject(record.rawJson) }.getOrElse { JSONObject() }
            fun field(name: String) = json.optString(name, "").trim()
            val code = field("معرّف السجل")
            val status = field("حالة الوحدة التشغيلية")
            val notes = field("ملاحظات الكشف/الاعتماد")
            val link = field("حالة الربط")
            val tenant = field("اسم المستأجر كما ورد")
            val rent = field("القيمة الحالية (جنيه/شهر)")
            val receipt = field("قيمة الإيصال (جنيه)")
            val classification = classifySourceFields(status, link, tenant, rent, receipt, notes)
            Result(
                record = record,
                code = code,
                tenant = tenant,
                sourceProperty = field("المجموعة/العقار كما ورد بالمصدر"),
                address = field("العنوان كما ورد بالإيصال"),
                currentRent = rent,
                statusText = status,
                classification = classification,
                conflictsWithExistingCode = code.isNotBlank() && code in existingCodes
            )
        }

    /** Pure classification helper, deliberately separating a missing operational status from source evidence. */
    fun classifySourceFields(
        status: String,
        link: String,
        tenant: String,
        rent: String,
        receipt: String,
        notes: String = ""
    ): Class {
        val normalized = status.trim().replace('–', '-').replace('—', '-')
        val normalizedLink = link.trim().replace('–', '-').replace('—', '-')
        if (normalized.isNotBlank()) return when {
            normalized.contains("مباعة") -> Class.SOLD_ARCHIVE_ONLY
            normalized.contains("متوقف عن الدفع") -> Class.STOPPED_CONFIRMED
            normalized.contains("تغيير مستأجر") -> Class.TENANT_CHANGE_PENDING
            normalized.contains("مغلقة") -> Class.CLOSED_ARCHIVE_ONLY
            normalized.contains("مكرر توثيقي") || notes.contains("لا يُحسب") -> Class.DOCUMENTARY_DUPLICATE
            normalized.contains("نشطة") && normalized.contains("غير محسومة") -> Class.ACTIVE_FINANCIAL_UNRESOLVED
            else -> Class.OTHER_REVIEW
        }

        // These source decisions are more informative than the blank operational-status cell.
        if (normalizedLink.contains("مغلق") || normalizedLink.contains("متوقف عن الدفع")) return Class.CLOSED_STOPPED_CONFIRMED
        if (normalizedLink.contains("مستبعد")) return Class.EXCLUDED_SOURCE_ONLY
        if (normalizedLink.contains("كشف مجمع فقط")) return Class.NO_RECEIPT_LINK
        if (normalizedLink.contains("مرتبط بإيصال")) {
            val cleanedTenant = tenant.trim()
                .removePrefix("-").trim()
                .replace(Regex("^(السيد|السادة|السيدة|أ\\s*/|ا\\s*/|م\\s*/|مدام)\\s*/?\\s*"), "")
                .trim()
            val rentValue = rent.trim().replace(",", "").toDoubleOrNull()
            val receiptValue = receipt.trim().replace(",", "").toDoubleOrNull()
            return if (cleanedTenant.isNotBlank() && rentValue != null && rentValue > 0.0 && receiptValue != null && receiptValue > 0.0) {
                Class.RECEIPT_LINKED_STATUS_NOT_RECORDED
            } else {
                Class.RECEIPT_LINKED_INCOMPLETE
            }
        }
        return Class.STATUS_UNRESOLVED
    }

    fun label(value: Class): String = when (value) {
        Class.STATUS_UNRESOLVED -> "الحالة التشغيلية غير محددة وتحتاج مراجعة"
        Class.RECEIPT_LINKED_STATUS_NOT_RECORDED -> "بيانات مرتبطة بإيصال؛ الحالة التشغيلية غير مدونة"
        Class.RECEIPT_LINKED_INCOMPLETE -> "ربط بإيصال مع نقص في الاسم أو القيمة"
        Class.NO_RECEIPT_LINK -> "كشف مجمع فقط – لا يوجد ربط موثق بإيصال"
        Class.EXCLUDED_SOURCE_ONLY -> "مستبعد من الكشف الجاري – يحفظ كمصدر فقط"
        Class.CLOSED_STOPPED_CONFIRMED -> "مغلق/متوقف وفق قرار المالك – أرشيف فقط"
        Class.ACTIVE_FINANCIAL_UNRESOLVED -> "نشطة مبدئيًا – مراجعة مالية"
        Class.STOPPED_CONFIRMED -> "متوقفة عن الدفع بتأكيد المالك"
        Class.SOLD_ARCHIVE_ONLY -> "مباعة – أرشيف فقط"
        Class.TENANT_CHANGE_PENDING -> "تغيير مستأجر – بيانات الجديد مطلوبة"
        Class.CLOSED_ARCHIVE_ONLY -> "مغلقة – أرشيف فقط"
        Class.DOCUMENTARY_DUPLICATE -> "تكرار توثيقي – لا دمج تلقائي"
        Class.OTHER_REVIEW -> "تحتاج مراجعة يدوية"
    }
}
