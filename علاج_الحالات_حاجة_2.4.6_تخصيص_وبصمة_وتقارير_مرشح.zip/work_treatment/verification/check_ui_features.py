from pathlib import Path
src = Path("android/app/src/main/java/com/treatmentcases/app/MainActivity.kt").read_text()
checks = {
    "dropdown font family": "PreferenceDropdown(\"نوع الخط\"" in src,
    "eight palette options": all(f'"{x}" to' in src for x in ["blue","green","purple","teal","indigo","rose","amber","slate"]),
    "ten font choices": all(f'"{x}" to' in src for x in ["sans","naskh","serif","mono","cursive","condensed","rounded","light","medium","black"]),
    "background dropdown": "PreferenceDropdown(\"لون خلفية التطبيق\"" in src,
    "compact spacing preference": "compact_spacing" in src,
    "visible reports tab": '"التقارير"' in src and "تصدير PDF" in src and "تصدير Excel" in src,
    "single/multiple/all report selection": "اختيار الكل" in src and "selectedReportMeds" in src,
    "biometric prompt": "BiometricPrompt" in src and "BIOMETRIC_STRONG" in src,
    "fingerprint login entry": "الدخول بالبصمة" in src,
}
for label, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + label)
if not all(checks.values()): raise SystemExit(1)
