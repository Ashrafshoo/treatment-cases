package com.familyproperties.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

/** Creates a print-ready A4 PDF with exactly three independent receipts per page. */
object ReceiptPdfExporter {
    private const val PAGE_WIDTH = 595
    private const val PAGE_HEIGHT = 842
    private const val OUTER_MARGIN = 24f
    private const val RECEIPT_GAP = 12f
    private const val RECEIPT_HEIGHT = 252f

    fun create(context: Context, receipts: List<PropertyRepository.ReceiptPrintRow>): File {
        require(receipts.isNotEmpty()) { "لا توجد إيصالات معتمدة للطباعة." }
        val document = PdfDocument()
        try {
            receipts.chunked(3).forEachIndexed { pageIndex, pageReceipts ->
                val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageIndex + 1).create()
                val page = document.startPage(pageInfo)
                page.canvas.drawColor(android.graphics.Color.WHITE)
                pageReceipts.forEachIndexed { slot, receipt ->
                    val top = OUTER_MARGIN + slot * (RECEIPT_HEIGHT + RECEIPT_GAP)
                    drawReceipt(page.canvas, receipt, top)
                }
                document.finishPage(page)
            }
            val directory = File(context.cacheDir, "printouts").apply { mkdirs() }
            val output = File(directory, "family-rent-receipts-${System.currentTimeMillis()}.pdf")
            FileOutputStream(output).use { stream -> document.writeTo(stream) }
            return output
        } finally {
            document.close()
        }
    }

    fun shareIntent(context: Context, pdf: File): android.content.Intent {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", pdf)
        return android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(android.content.Intent.EXTRA_STREAM, uri)
            addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    private fun drawReceipt(canvas: Canvas, receipt: PropertyRepository.ReceiptPrintRow, top: Float) {
        val left = OUTER_MARGIN
        val right = PAGE_WIDTH - OUTER_MARGIN
        val bottom = top + RECEIPT_HEIGHT
        val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.rgb(32, 48, 76)
            style = Paint.Style.STROKE
            strokeWidth = 1.1f
        }
        canvas.drawRoundRect(RectF(left, top, right, bottom), 7f, 7f, border)
        val gold = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.rgb(190, 145, 65)
            strokeWidth = 2.2f
        }
        canvas.drawLine(left + 12, top + 35, right - 12, top + 35, gold)

        val contentLeft = left + 14
        val contentWidth = (right - left - 28).toInt()
        val rows = buildList {
            add(ReceiptLine("إيصال استلام أجرة", 15f, true, android.graphics.Color.rgb(16, 29, 54), Layout.Alignment.ALIGN_CENTER))
            add(ReceiptLine("رقم الإيصال: ${receipt.receiptNumber}     التاريخ: ${receipt.issuedAt}", 9.5f, true))
            add(ReceiptLine("استلمنا من السيد/ة: ${receipt.tenant}", 10.5f, true))
            add(ReceiptLine("العقار: ${receipt.property}     الوحدة: ${receipt.unit}", 9.5f, false))
            add(ReceiptLine("مبلغ وقدره: ${formatEgp(receipt.amountMinor)}", 11f, true))
            add(ReceiptLine("وذلك عن: ${receipt.period ?: "—"}     طريقة السداد: ${receipt.paymentMethod ?: "—"}", 9.5f, false))
            receipt.amountWords?.takeIf { it.isNotBlank() }?.let { add(ReceiptLine("فقط: $it", 9f, false)) }
            receipt.remainingMinor?.let { add(ReceiptLine("المتبقي من إيجار الفترة: ${formatEgp(it)}", 9.5f, true)) }
            if (receipt.law164) add(ReceiptLine("إيجار قديم – قانون 164 لسنة 2025", 8.5f, true, android.graphics.Color.rgb(130, 91, 35)))
            if (!receipt.landlord.isNullOrBlank()) add(ReceiptLine("المؤجر / الإدارة: ${receipt.landlord}", 9f, false))
        }
        val bodyTop = top + 43f
        val bodyBottom = bottom - 43f
        // Long Arabic names/amounts must never collide with the signature or the next receipt.
        var scale = 1f
        while (scale > 0.49f && rows.sumOf { lineHeight(it, contentWidth, scale).toDouble() } > bodyBottom - bodyTop) {
            scale -= 0.05f
        }
        var y = bodyTop
        canvas.save()
        canvas.clipRect(contentLeft.toFloat(), bodyTop, (right - 14).toFloat(), bodyBottom)
        rows.forEach { row ->
            y = paragraph(canvas, row.text, contentLeft, y, contentWidth, row.size * scale,
                row.bold, row.color, row.alignment)
        }
        canvas.restore()

        val signatureY = bottom - 36f
        val signaturePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.DKGRAY
            textSize = 9f
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        }
        canvas.drawText("التوقيع", right - 64f, signatureY + 15f, signaturePaint)
        canvas.drawLine(right - 110f, signatureY + 20f, right - 16f, signatureY + 20f, border)
        canvas.drawText("حُرر من أصل الإيصال", left + 14f, signatureY + 15f, signaturePaint)
    }

    private data class ReceiptLine(
        val text: String,
        val size: Float,
        val bold: Boolean,
        val color: Int = android.graphics.Color.BLACK,
        val alignment: Layout.Alignment = Layout.Alignment.ALIGN_OPPOSITE
    )

    private fun lineHeight(line: ReceiptLine, width: Int, scale: Float): Int {
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = line.size * scale
            typeface = Typeface.create("sans-serif", if (line.bold) Typeface.BOLD else Typeface.NORMAL)
        }
        return StaticLayout.Builder.obtain(line.text, 0, line.text.length, paint, width)
            .setAlignment(line.alignment)
            .setTextDirection(TextDirectionHeuristics.RTL)
            .setIncludePad(false)
            .setLineSpacing(0f, 1.08f)
            .build().height + 4
    }

    private fun paragraph(
        canvas: Canvas,
        text: String,
        x: Float,
        y: Float,
        width: Int,
        size: Float,
        bold: Boolean,
        color: Int = android.graphics.Color.BLACK,
        alignment: Layout.Alignment = Layout.Alignment.ALIGN_OPPOSITE
    ): Float {
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size
            this.color = color
            typeface = Typeface.create("sans-serif", if (bold) Typeface.BOLD else Typeface.NORMAL)
        }
        val layout = StaticLayout.Builder.obtain(text, 0, text.length, paint, width)
            .setAlignment(alignment)
            .setTextDirection(TextDirectionHeuristics.RTL)
            .setIncludePad(false)
            .setLineSpacing(0f, 1.08f)
            .build()
        canvas.save()
        canvas.translate(x, y)
        layout.draw(canvas)
        canvas.restore()
        return y + layout.height + 4f
    }

    private fun formatEgp(minor: Long): String {
        val amount = minor / 100
        val piastres = kotlin.math.abs(minor % 100)
        return if (piastres == 0L) "$amount جنيه" else "$amount.${piastres.toString().padStart(2, '0')} جنيه"
    }
}
