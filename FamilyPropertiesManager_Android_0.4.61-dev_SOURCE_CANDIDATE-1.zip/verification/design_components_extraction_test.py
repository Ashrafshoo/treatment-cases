from pathlib import Path
root = Path(__file__).resolve().parents[1]
main = (root / 'app/src/main/java/com/example/rentals/MainActivity.kt').read_text()
components = (root / 'app/src/main/java/com/example/rentals/ui/components/PropertyComponents.kt').read_text()
settings = (root / 'app/src/main/java/com/example/rentals/features/settings/SettingsScreen.kt').read_text()
for name in ('AppField', 'MetricCard', 'SettingSwitchRow'):
    assert f'fun {name}(' in components, name
    assert f'import com.example.rentals.ui.components.{name}' in main, name
    assert f'fun {name}(' not in main, name
assert 'OutlinedTextAppField' not in main
units = (root / 'app/src/main/java/com/example/rentals/features/units/UnitsScreen.kt').read_text()
review = (root / 'app/src/main/java/com/example/rentals/features/review/ReviewScreen.kt').read_text()
assert 'AppField(' in units and 'MetricCard(' in review and 'SettingSwitchRow(' in settings
print('PASS: shared UI components extracted and referenced from feature screens.')
