package com.example.rentals.data.repository

import com.example.rentals.data.RentalsDb
import com.example.rentals.domain.contracts.ContractAttachment
import com.example.rentals.domain.contracts.DocumentRepository

/** SQLite adapter for document metadata; file bytes remain in app storage/content providers. */
class SqliteDocumentRepository(private val database: RentalsDb) : DocumentRepository {
    override fun list(ownerType: String, ownerId: String) = database.attachments()
        .asSequence()
        .filter { it.ownerType == ownerType && it.ownerId == ownerId }
        .map { ContractAttachment(it.id, it.ownerType, it.ownerId, it.uri, it.name, it.mime, it.createdAt, it.notes, it.category) }
        .toList()

    override fun add(ownerType: String, ownerId: String, uri: String, name: String, mime: String, notes: String, category: String) =
        database.addAttachment(ownerType, ownerId, uri, name, mime, notes, category)

    /** Deletes only the metadata row; deliberately does not delete the physical file. */
    override fun removeIndex(id: Long) = database.deleteAttachment(id)
}
