#!/usr/bin/env python3
from pathlib import Path
p=Path(__file__).resolve().parents[1]/'app/src/main/java/com/example/rentals/printing/OriginalReceiptTemplateRenderer.kt'
s=p.read_text(encoding='utf-8')
assert 'kotlin.math.floor((256.0 * chars' in s
assert 'pixels * 0.75' in s
image=s.index('drawSideImages(canvas, grid')
borders=s.index('drawCellBorders(canvas, x, y, w, h, style, borders)')
text=s.index('textCells.forEach')
assert image < borders < text, 'Images must be below cell borders and text'
assert 'TextCell(raw, x, y, w, hh, style)' in s
assert 'drawCellBackground(canvas, x, y, w, hh, style, fills)' in s
assert 'drawCellBorders(canvas, x, y, w, h, style, borders)' in s
print('PASS: Excel column-width conversion and image/text layer order')
