from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MAIN = ROOT / "android-app/src/main/java/com/familyproperties/app/MainActivity.kt"
AUTH = ROOT / "android-app/src/main/java/com/familyproperties/app/AuthRepository.kt"
BIO = ROOT / "android-app/src/main/java/com/familyproperties/app/security/BiometricLogin.kt"
REPO = ROOT / "android-app/src/main/java/com/familyproperties/app/PropertyRepository.kt"


def test_password_no_longer_forces_ten_characters_or_mixed_character_types():
    auth = AUTH.read_text(encoding="utf-8")
    assert "private const val MIN_PASSWORD_LENGTH = 10" not in auth
    assert "password.size >= MIN_PASSWORD_LENGTH" not in auth
    assert "password.any { it.isLetter() }" not in auth
    assert "require(password.isNotEmpty())" in auth
    main = MAIN.read_text(encoding="utf-8")
    assert "استخدم 10 أحرف على الأقل" not in main
    assert "10 أحرف على الأقل، وبها حرف ورقم" not in main


def test_biometric_prompt_has_negative_button_and_safe_exception_handling():
    bio = BIO.read_text(encoding="utf-8")
    assert '.setNegativeButtonText("إلغاء")' in bio
    assert "catch (error: RuntimeException)" in bio
    assert "override fun onAuthenticationFailed() = Unit" in bio


def test_drawer_uses_one_source_of_truth_for_gesture_and_button_state():
    main = MAIN.read_text(encoding="utf-8")
    app = main.split("fun FamilyPropertyApp", 1)[1].split("private fun DashboardContent", 1)[0]
    assert "var drawer by remember" not in app
    assert "LaunchedEffect(drawer)" not in app
    assert "drawerScope.launch { drawerState.open() }" in app
    assert "drawerScope.launch { drawerState.close() }" in app


def test_duplicate_property_names_are_not_used_as_identity_or_auto_merge_key():
    repo = REPO.read_text(encoding="utf-8")
    method = repo.split("fun applyExcelImport", 1)[1].split("fun exportExcelData", 1)[0]
    assert "lower(trim(name))" not in method
    assert "propertyNames" not in method
    assert "stable property_id" in method


def test_excel_preview_reports_duplicate_unit_numbers_before_confirmation():
    excel = (ROOT / "android-app/src/main/java/com/familyproperties/app/ExcelInterchange.kt").read_text(encoding="utf-8")
    assert "Cross-row natural-key validation must appear in the preview" in excel
    assert "رقم الوحدة مكرر داخل العقار نفسه" in excel
    assert "unitPreview.issues += RowIssue" in excel


def test_preview_issue_list_is_mutable_for_cross_sheet_findings():
    excel = (ROOT / "android-app/src/main/java/com/familyproperties/app/ExcelInterchange.kt").read_text(encoding="utf-8")
    assert "issues: MutableList<RowIssue>" in excel


def test_workflow_accepts_one_root_zip_with_any_filename():
    workflow = (ROOT / ".github/workflows/android-apk.yml").read_text(encoding="utf-8")
    assert "BUNDLES=( *.zip )" in workflow
    assert "Expected one source ZIP" in workflow
    assert "unzip -q \"${BUNDLES[0]}\" -d extracted" in workflow
