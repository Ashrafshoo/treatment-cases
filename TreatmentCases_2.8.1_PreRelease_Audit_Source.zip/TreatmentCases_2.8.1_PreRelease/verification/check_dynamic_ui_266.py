#!/usr/bin/env python3
from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'android/app/src/main/java/com/treatmentcases/app/MainActivity.kt').read_text(encoding='utf-8')
g=(root/'android/app/build.gradle').read_text(encoding='utf-8')
checks={
 'isolated preview package id': "applicationId 'com.treatmentcases.app.preview275'" in g,
 'development version 2.7.3': "versionName '2.8.1-ui-polish'" in g and 'versionCode 33' in g,
 'compose animation dependency': 'androidx.compose.animation:animation' in g,
 'real image asset used in hero': 'painterResource(id=R.drawable.medical_hero)' in s,
 'hero is an actual clickable component': 'DashboardHero(isEnglish=isEnglish' in s and 'onOpenRecords' in s,
 'gradient overlay exists in app source': 'Brush.horizontalGradient' in s,
 'animated live statistics': 'AnimatedContent(targetState=value' in s and 'db.count()' in s and 'meds.size' in s,
 'animated interactive shortcut tiles': 'animateFloatAsState' in s and 'shortcutPress' in s,
 'medicine shortcuts navigate to real screens': 'page="الأدوية"' in s and 'page="التقارير"' in s,
 'Arabic-English dashboard heading': 'appLabel("لوحة المتابعة","Dashboard",isEnglish)' in s,
 'no demo records injected': 'demo_dataset_200.json' not in s,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+': '+k)
assert all(checks.values())
print(f'PASS: {len(checks)} dynamic UI assertions')
