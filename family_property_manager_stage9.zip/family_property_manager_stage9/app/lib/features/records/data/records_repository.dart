import 'dart:convert';
import 'package:sqflite_sqlcipher/sqflite.dart';
import '../../../core/database/app_database.dart';
import '../../auth/data/app_session.dart';

class RecordsRepository {
  Future<Database> get _db async => AppDatabase.instance.database;
  String _id() => '${DateTime.now().microsecondsSinceEpoch}';
  Future<void> _writeAudit(Transaction tx, String entity, String id, String action, Map<String,Object?>? before, Map<String,Object?>? after) async {
    await tx.insert('audit_log', {'id': _id(), 'user_id': AppSession.instance.userId, 'entity_type': entity, 'entity_id': id, 'action': action, 'before_json': before == null ? null : jsonEncode(before), 'after_json': after == null ? null : jsonEncode(after)});
  }

  Future<List<Map<String, Object?>>> properties() async => (await _db).rawQuery('''
    SELECT p.*,g.name AS group_name FROM properties p
    LEFT JOIN property_groups g ON g.id=p.group_id
    WHERE p.archived_at IS NULL ORDER BY COALESCE(g.name,p.name) COLLATE NOCASE,p.name COLLATE NOCASE
  ''');

  Future<List<Map<String,Object?>>> propertyGroups() async => (await _db).query('property_groups',where:'archived_at IS NULL',orderBy:'name COLLATE NOCASE');

  Future<void> savePropertyGroup({String? id,required String name,String? description}) async {
    AppSession.instance.requireAdmin();
    if(name.trim().isEmpty)throw ArgumentError('اسم المجموعة مطلوب');
    final db=await _db;final now=DateTime.now().toIso8601String();
    await db.transaction((tx)async{
      final isNew=id==null;final recordId=id??_id();
      final before=isNew?<Map<String,Object?>>[]:await tx.query('property_groups',where:'id=?',whereArgs:[recordId],limit:1);
      final values=<String,Object?>{'name':name.trim(),'description':description,'updated_at':now};
      if(isNew){values['id']=recordId;await tx.insert('property_groups',values);}else{await tx.update('property_groups',values,where:'id=?',whereArgs:[recordId]);}
      await _writeAudit(tx,'property_group',recordId,isNew?'create':'update',isNew?null:before.first,values);
    });
  }

  Future<void> archivePropertyGroup(String id) async {
    AppSession.instance.requireAdmin();final db=await _db;
    final linked=Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM properties WHERE group_id=? AND archived_at IS NULL',[id]))??0;
    if(linked>0)throw StateError('لا يمكن أرشفة المجموعة قبل نقل العقارات المرتبطة بها');
    final rows=await db.query('property_groups',where:'id=? AND archived_at IS NULL',whereArgs:[id],limit:1);if(rows.isEmpty)return;
    final now=DateTime.now().toIso8601String();await db.update('property_groups',{'archived_at':now,'updated_at':now},where:'id=?',whereArgs:[id]);
    await db.insert('audit_log',{'id':_id(),'user_id':AppSession.instance.userId,'entity_type':'property_group','entity_id':id,'action':'archive','before_json':jsonEncode(rows.first),'after_json':jsonEncode({'archived_at':now})});
  }


  Future<List<Map<String,Object?>>> owners() async => (await _db).query('owners',where:'archived_at IS NULL',orderBy:'full_name COLLATE NOCASE');

  Future<List<Map<String,Object?>>> ownershipShares() async => (await _db).rawQuery('''
    SELECT s.*,p.name AS property_name,o.full_name AS owner_name
    FROM ownership_shares s JOIN properties p ON p.id=s.property_id JOIN owners o ON o.id=s.owner_id
    ORDER BY p.name,o.full_name,s.valid_from
  ''');

  Future<void> saveOwner({String? id,required String name,String? phone,String? notes}) async {
    AppSession.instance.requireAdmin();if(name.trim().isEmpty)throw ArgumentError('اسم المالك مطلوب');
    final db=await _db;final now=DateTime.now().toIso8601String();
    await db.transaction((tx)async{final isNew=id==null;final recordId=id??_id();final before=isNew?<Map<String,Object?>>[]:await tx.query('owners',where:'id=?',whereArgs:[recordId],limit:1);final values=<String,Object?>{'full_name':name.trim(),'phone':phone,'notes':notes,'updated_at':now,'modified_unreviewed':1};if(isNew){values['id']=recordId;await tx.insert('owners',values);}else{await tx.update('owners',values,where:'id=?',whereArgs:[recordId]);}await _writeAudit(tx,'owner',recordId,isNew?'create':'update',isNew?null:before.first,values);});
  }

  Future<void> saveOwnershipShare({String? id,required String propertyId,required String ownerId,required double percent,DateTime? validFrom,DateTime? validTo,String? notes}) async {
    AppSession.instance.requireAdmin();
    if(percent<=0||percent>100)throw ArgumentError('نسبة الملكية يجب أن تكون أكبر من صفر ولا تتجاوز 100%');
    if(validFrom!=null&&validTo!=null&&validTo.isBefore(validFrom))throw ArgumentError('تاريخ نهاية الحصة يسبق بدايتها');
    final db=await _db;final from=validFrom==null?'':_date(validFrom);final to=validTo==null?null:_date(validTo);
    final overlaps=await db.rawQuery('''SELECT COALESCE(SUM(share_percent),0) AS total FROM ownership_shares WHERE property_id=? AND id<>COALESCE(?, '') AND (valid_to IS NULL OR valid_to>=?) AND (? IS NULL OR valid_from IS NULL OR valid_from<=?)''',[propertyId,id,from,to,to??'9999-12-31']);
    final total=(overlaps.first['total'] as num).toDouble()+percent;
    if(total>100.0001)throw StateError('مجموع حصص الملكية المتداخلة للعقار سيتجاوز 100%');
    await db.transaction((tx)async{final isNew=id==null;final recordId=id??_id();final before=isNew?<Map<String,Object?>>[]:await tx.query('ownership_shares',where:'id=?',whereArgs:[recordId],limit:1);final values=<String,Object?>{'property_id':propertyId,'owner_id':ownerId,'share_percent':percent,'valid_from':validFrom==null?null:from,'valid_to':to,'notes':notes,'modified_unreviewed':1};if(isNew){values['id']=recordId;await tx.insert('ownership_shares',values);}else{await tx.update('ownership_shares',values,where:'id=?',whereArgs:[recordId]);}await _writeAudit(tx,'ownership_share',recordId,isNew?'create':'update',isNew?null:before.first,values);});
  }

  static String _date(DateTime d)=>'${d.year.toString().padLeft(4,'0')}-${d.month.toString().padLeft(2,'0')}-${d.day.toString().padLeft(2,'0')}';

  Future<List<Map<String, Object?>>> tenants() async => (await _db).query(
    'tenants', where: 'archived_at IS NULL', orderBy: 'full_name COLLATE NOCASE');

  Future<List<Map<String, Object?>>> units() async => (await _db).rawQuery('''
    SELECT u.*, p.name AS property_name, t.full_name AS tenant_name
    FROM units u JOIN properties p ON p.id=u.property_id
    LEFT JOIN tenants t ON t.id=u.current_tenant_id
    WHERE u.archived_at IS NULL AND p.archived_at IS NULL ORDER BY p.name, u.unit_number
  ''');

  Future<void> saveProperty({String? id, required String name, String? address, String? city, String? district, String? notes, String? groupId}) async {
    AppSession.instance.requireAdmin();
    final db = await _db; final now = DateTime.now().toIso8601String();
    await db.transaction((tx) async {
      if (id == null) {
        final newId = _id();
        final after = {'id': newId, 'name': name.trim(), 'address_text': address, 'city': city, 'district': district, 'notes': notes, 'group_id': groupId, 'review_status': 'needs_review', 'modified_unreviewed':1, 'source_status': 'manual'};
        await tx.insert('properties', after);
        await _writeAudit(tx, 'property', newId, 'create', null, after);
      } else {
        final beforeRows = await tx.query('properties', where: 'id=?', whereArgs: [id], limit: 1);
        final after = {'name': name.trim(), 'address_text': address, 'city': city, 'district': district, 'notes': notes, 'group_id': groupId, 'updated_at': now, 'modified_unreviewed': 1, 'review_status':'needs_review'};
        await tx.update('properties', after, where: 'id=?', whereArgs: [id]);
        await _writeAudit(tx, 'property', id, 'update', beforeRows.isEmpty ? null : beforeRows.first, after);
      }
    });
  }

  Future<void> saveTenant({String? id, required String name, String? phone, String? nationalIdLast4, String? notes}) async {
    AppSession.instance.requireAdmin();
    final db = await _db; final now = DateTime.now().toIso8601String();
    await db.transaction((tx) async {
      if (id == null) {
        final newId = _id(); final after = {'id': newId, 'full_name': name.trim(), 'phone': phone, 'national_id_last4': nationalIdLast4, 'notes': notes};
        await tx.insert('tenants', after); await _writeAudit(tx, 'tenant', newId, 'create', null, after);
      } else {
        final beforeRows = await tx.query('tenants', where: 'id=?', whereArgs: [id], limit: 1);
        final after = {'full_name': name.trim(), 'phone': phone, 'national_id_last4': nationalIdLast4, 'notes': notes, 'updated_at': now, 'modified_unreviewed':1};
        await tx.update('tenants', after, where: 'id=?', whereArgs: [id]); await _writeAudit(tx, 'tenant', id, 'update', beforeRows.isEmpty ? null : beforeRows.first, after);
      }
    });
  }

  Future<void> saveUnit({String? id, required String propertyId, required String number, required String type, required String occupancy, String? floorLabel, double? area, String? addressDetails, bool oldLaw164=false, String? tenantId, String? notes}) async {
    AppSession.instance.requireAdmin();
    final db = await _db; final now = DateTime.now().toIso8601String();
    final data = {'property_id': propertyId, 'unit_number': number.trim(), 'floor_label': floorLabel, 'unit_type': type, 'area': area, 'occupancy_status': occupancy, 'address_details': addressDetails, 'old_law_164_2025': oldLaw164 ? 1 : 0, 'current_tenant_id': tenantId, 'notes': notes, 'updated_at': now, 'modified_unreviewed': 1, 'review_status':'needs_review'};
    await db.transaction((tx) async {
      if (id == null) { final newId = _id(); data['id'] = newId; data['review_status'] = 'needs_review'; data['source_status'] = 'manual'; await tx.insert('units', data); await _writeAudit(tx, 'unit', newId, 'create', null, data); }
      else { final beforeRows = await tx.query('units', where: 'id=?', whereArgs: [id], limit: 1); await tx.update('units', data, where: 'id=?', whereArgs: [id]); await _writeAudit(tx, 'unit', id, 'update', beforeRows.isEmpty ? null : beforeRows.first, data); }
    });
  }

  Future<void> archive(String table, String id) async {
    AppSession.instance.requireAdmin();
    if (!{'properties','units','tenants','owners'}.contains(table)) throw ArgumentError('Unsupported table');
    final db = await _db;
    if(table=='owners'){final linked=Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM ownership_shares WHERE owner_id=?',[id]))??0;if(linked>0)throw StateError('لا يمكن أرشفة المالك قبل إنهاء أو نقل حصص الملكية المرتبطة به');}
    await db.transaction((tx) async {
      final rows = await tx.query(table, where: 'id=?', whereArgs: [id], limit: 1);
      final now = DateTime.now().toIso8601String();
      await tx.update(table, {'archived_at': now}, where: 'id=?', whereArgs: [id]);
      await _writeAudit(tx, table == 'properties' ? 'property' : table == 'units' ? 'unit' : table == 'owners' ? 'owner' : 'tenant', id, 'archive', rows.isEmpty ? null : rows.first, {'archived_at': now});
    });
  }

  Future<void> clearModifiedFlag(String table,String id) async {
    AppSession.instance.requireAdmin();
    if(!{'properties','units','tenants','owners','ownership_shares','leases','expenses'}.contains(table))throw ArgumentError('نوع السجل غير مدعوم');
    final db=await _db;final before=await db.query(table,where:'id=?',whereArgs:[id],limit:1);if(before.isEmpty)return;
    final after=<String,Object?>{'modified_unreviewed':0};
    if(table!='ownership_shares')after['updated_at']=DateTime.now().toIso8601String();
    // Clearing the visual modified flag must not silently certify a record as
    // sound; review_status is managed only by the explicit review workflow.
    await db.update(table,after,where:'id=?',whereArgs:[id]);
    final entityType=switch(table){'properties'=>'property','units'=>'unit','tenants'=>'tenant','owners'=>'owner','ownership_shares'=>'ownership_share','leases'=>'lease','expenses'=>'expense',_=>'record'};
    await db.insert('audit_log',{'id':_id(),'user_id':AppSession.instance.userId,'entity_type':entityType,'entity_id':id,'action':'update','before_json':jsonEncode(before.first),'after_json':jsonEncode(after)});
  }

  Future<Map<String, int>> counts() async {
    final db = await _db;
    Future<int> count(String table) async => Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM $table WHERE archived_at IS NULL')) ?? 0;
    return {'properties': await count('properties'), 'units': await count('units'), 'tenants': await count('tenants'), 'owners': await count('owners')};
  }
}
