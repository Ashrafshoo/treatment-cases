from pathlib import Path
import json
R=Path(__file__).resolve().parents[1]
renderer=(R/'app/src/main/java/com/example/rentals/printing/OriginalReceiptTemplateRenderer.kt').read_text(encoding='utf-8')
vba=(R/'app/src/main/java/com/example/rentals/printing/VbaMonitize.kt').read_text(encoding='utf-8')
catalog=json.loads((R/'app/src/main/assets/receipt_templates/receipt_template_catalog_v1.json').read_text(encoding='utf-8'))
assert len(catalog['templates'])==88
assert all(t['grid'].get('rightToLeft',True) for t in catalog['templates'])
assert 'totalWidth - colKeys.filter' in renderer
assert 'TextDirectionHeuristics.RTL' in renderer
assert 'TextDirectionHeuristics.LTR' in renderer
assert 'VbaMonitize.amountWords(item.amount)' in renderer
assert 'Public Function Monitize' not in vba
assert 'Digit_Translator' in vba and 'HALF_EVEN' in vba
assert 'old.replace("2026/11/01", date)' in renderer
print('PASS: RTL column mirroring and Arabic text direction are wired')
print('PASS: all 88 templates preserve workbook RTL metadata')
print('PASS: renderer uses VBA-derived amount words and replaces only November issue date')
