#!/usr/bin/env python3
"""Regression checks for template-specific receipt rendering safety."""
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CATALOG_PATH = ROOT / "app/src/main/assets/receipt_templates/receipt_template_catalog_v1.json"
RENDERER_PATH = ROOT / "app/src/main/java/com/example/rentals/printing/OriginalReceiptTemplateRenderer.kt"
PANEL_PATH = ROOT / "app/src/main/java/com/example/rentals/features/printing/AggregateStatementsPanel.kt"
SCREEN_PATH = ROOT / "app/src/main/java/com/example/rentals/features/printing/MonthlyCollectionScreen.kt"
CATALOG = json.loads(CATALOG_PATH.read_text(encoding="utf-8"))
RENDERER = RENDERER_PATH.read_text(encoding="utf-8")
PANEL = PANEL_PATH.read_text(encoding="utf-8")
SCREEN = SCREEN_PATH.read_text(encoding="utf-8")

assert len(CATALOG["templates"]) == 88
monthly = [t for t in CATALOG["templates"] if t.get("monthlyEligible", True)]
assert len(monthly) == 81

for template in monthly:
    tid = template["template_id"]
    grid = template["grid"]
    cells = grid["cells"]
    values = [(c, str(c.get("value") or "")) for c in cells]
    editable = template.get("editableFields") or {}
    formula_cells = [(c, v) for c, v in values if v.startswith("=Monitize(")]
    tenant_cells = [(c, v) for c, v in values if "وصلنا من" in v]
    amount_rows = [c.get("r") for c, v in values if "المبلغ المرقوم" in v]
    has_blank_tenant = any(c.get("c") == 1 and c.get("r") == row - 1 for c, _ in values for row in amount_rows)
    assert editable.get("tenant") or tenant_cells or has_blank_tenant, (tid, "tenant")
    assert editable.get("amount") or formula_cells, (tid, "amount")
    assert editable.get("amountInWords") or formula_cells or amount_rows, (tid, "amount in words")

    date_fields = editable.get("dateLiterals") or []
    assert date_fields, (tid, "explicit issue date mapping")
    by_address = {c.get("addr"): str(c.get("value") or "") for c in cells}
    for field in date_fields:
        value = by_address.get(field.get("address"), "")
        assert "2026/11/01" in value, (tid, field, value)

    descriptions = [v for _, v in values if "وذلك" in v and "إيجار" in v and "رقم" in v]
    locations = [v for _, v in values if "رقم" in v and "شارع" in v]
    assert len(descriptions) == 1, (tid, "description mapping ambiguous", len(descriptions))
    assert len(locations) == 1, (tid, "location mapping ambiguous", len(locations))

    for image in grid.get("images", []):
        name = image.get("file")
        assert name and (ROOT / "app/src/main/assets/receipt_templates" / name).is_file(), (tid, name)
        assert all(k in image for k in ("fromCol", "fromRow", "toCol", "toRow")), (tid, image)

# Historical start-of-period date in T076 must not be an editable issue-date field.
t076 = next(t for t in CATALOG["templates"] if t["template_id"] == "T076")
assert "B57" not in [x["address"] for x in t076["editableFields"]["dateLiterals"]]
assert "B59" in [x["address"] for x in t076["editableFields"]["dateLiterals"]]

assert 'require(item.templateId.isNotBlank())' in RENDERER
assert 'val template = templates[item.templateId]' in RENDERER
assert 'templates.values.firstOrNull()' not in RENDERER
assert 'dateAddresses.forEach' in RENDERER
assert '0, 1 -> 0' in RENDERER
assert '2, 4, 165 -> 2' in RENDERER
assert '10, 166, 169 -> 1' in RENDERER
assert 'Only catalog-declared issue-date cells are editable' in RENDERER
assert 'tenant_text' in RENDERER
assert 'LruCache<String, android.graphics.Bitmap>(4 * 1024)' in RENDERER
assert 'sideImageCache.get(file)' in RENDERER
assert 'bitmap.recycle()' not in RENDERER
assert 'ReceiptDateFormat.toArabicDigits(text)' in RENDERER
assert 'ReceiptDateFormat.toArabicDigits(String.format(Locale.US, pattern, value))' in RENDERER
assert 'StaticLayout.Builder.obtain(displayText' in RENDERER
assert 'this.style = Paint.Style.STROKE' in RENDERER
assert 'canvas.clipRect(target)' in RENDERER and 'canvas.translate(target.left + offsetX' in RENDERER
assert 'finally {\n            canvas.restore()' in RENDERER
assert 'findUniqueCellAddress' not in RENDERER
assert 'descriptionAddresses = declared("description")' in RENDERER
assert 'locationAddresses = declared("location")' in RENDERER
assert 'findCellAddress(template)' not in RENDERER
assert 'drawSideImages(canvas' in RENDERER
assert 'ReceiptDateFormat.toSheet(ReceiptDateFormat.toStorage(issuedDate))' in (ROOT / 'app/src/main/java/com/example/rentals/printing/AggregateReceiptPdfExporter.kt').read_text(encoding='utf-8')
assert 'ReceiptDateFormat.toSheet(ReceiptDateFormat.toStorage(issuedDate))' in (ROOT / 'app/src/main/java/com/example/rentals/printing/AggregateReceiptPrintAdapter.kt').read_text(encoding='utf-8')
assert RENDERER.index('drawSideImages(canvas') < RENDERER.index('drawCellBorders(canvas') < RENDERER.index('textCells.forEach')
assert 'غير محدد' in PANEL and 'قالب الإيصال غير محدد أو غير موجود' in PANEL
assert 'templateOptions.none { it.first == item.templateId }' in PANEL
assert 'it.templateId' in SCREEN and 'it.templateId.ifBlank { "T001" }' not in SCREEN

print("PASS: 88 catalog entries; 81 monthly templates; tenant/amount/words/date fields audited")
print("PASS: all monthly templates have unique description/location cells and existing image anchors")
print("PASS: T076 historical period-start date is preserved")
print("PASS: unknown template IDs fail explicitly; render layers and optional field mappings are safe")
