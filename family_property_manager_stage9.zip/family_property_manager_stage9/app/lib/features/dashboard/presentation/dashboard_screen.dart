import 'package:flutter/material.dart';
import '../../records/data/records_repository.dart';
import '../../records/presentation/records_screen.dart';
import '../../leases/presentation/leases_screen.dart';
import '../../payments/presentation/payments_screen.dart';
import '../../expenses/presentation/expenses_screen.dart';
import '../../archive_review/presentation/archive_review_screen.dart';
import '../../reports/presentation/reports_screen.dart';
import '../../notifications/presentation/notifications_screen.dart';
import '../../data_exchange/presentation/data_exchange_screen.dart';
import '../../settings/presentation/settings_screen.dart';
import '../../auth/data/app_session.dart';
import '../../../core/theme/app_preferences.dart';
import '../../reports/data/reports_repository.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final _repository = RecordsRepository();
  final _reports = ReportsRepository();
  late Future<Map<String,int>> _countsFuture;
  late Future<Map<String,Object?>> _summaryFuture;
  @override
  void initState() { super.initState(); _refreshDashboard(); }
  void _refreshDashboard() { final now=DateTime.now(); _countsFuture=_repository.counts(); _summaryFuture=_reports.summary(from:DateTime(now.year,now.month,1),to:now); }
  Future<void> _openRecords() async {
    await Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const RecordsScreen()));
    if (mounted) setState(_refreshDashboard);
  }

  Future<void> _openLeases() async {
    await Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const LeasesScreen()));
    if (mounted) setState(_refreshDashboard);
  }

  Future<void> _openPayments() async {
    await Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const PaymentsScreen()));
    if (mounted) setState(_refreshDashboard);
  }

  Future<void> _openExpenses() async {
    await Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const ExpensesScreen()));
    if (mounted) setState(_refreshDashboard);
  }

  Future<void> _openArchiveReview() async {
    await Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const ArchiveReviewScreen()));
    if (mounted) setState(_refreshDashboard);
  }

  Future<void> _openReports() async {
    await Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const ReportsScreen()));
    if (mounted) setState(_refreshDashboard);
  }

  Future<void> _openNotifications() async {
    await Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const NotificationsScreen()));
    if (mounted) setState(_refreshDashboard);
  }

  Future<void> _openDataExchange() async {
    await Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const DataExchangeScreen()));
    if (mounted) setState(_refreshDashboard);
  }

  Future<void> _openSettings() async {
    await Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const SettingsScreen()));
    if (mounted) setState(_refreshDashboard);
  }

  static const _modules = <_ModuleItem>[
    _ModuleItem('العقارات', Icons.apartment_outlined, 'إدارة مجموعات العقارات والبيوت'),
    _ModuleItem('الوحدات', Icons.meeting_room_outlined, 'بيانات الوحدات وحالات الإشغال'),
    _ModuleItem('المستأجرون', Icons.people_outline, 'ملفات المستأجرين وسجلهم'),
    _ModuleItem('العقود', Icons.description_outlined, 'مدد العقود والزيادات والتنبيهات'),
    _ModuleItem('التحصيلات والإيصالات', Icons.receipt_long_outlined, 'التحصيل والطباعة والأرشفة'),
    _ModuleItem('الكشوف والتقارير', Icons.analytics_outlined, 'الكشوف الشهرية والسنوية'),
    _ModuleItem('المصروفات', Icons.account_balance_wallet_outlined, 'المصروفات العامة'),
    _ModuleItem('الأرشيف', Icons.folder_open_outlined, 'المستندات والصور'),
    _ModuleItem('مركز المراجعة', Icons.fact_check_outlined, 'البيانات الناقصة والمتعارضة'),
    _ModuleItem('Excel والاستيراد والتصدير', Icons.table_chart_outlined, 'قوالب Excel وفحص وتصدير البيانات'),
    _ModuleItem('الإعدادات', Icons.settings_outlined, 'المظهر والخط والتخصيص'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('لوحة التحكم${AppSession.instance.displayName == null ? '' : ' • ${AppSession.instance.displayName}'}'),
        actions: [
          IconButton(tooltip:'تسجيل الخروج',onPressed:(){AppSession.instance.end();Navigator.of(context).pop();},icon:const Icon(Icons.logout)),
          IconButton(
            tooltip: 'التنبيهات',
            onPressed: _openNotifications,
            icon: const Icon(Icons.notifications_none_rounded),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          FutureBuilder<Map<String,int>>(future:_countsFuture,builder:(context,snapshot){final c=snapshot.data??{};return Wrap(spacing:12,runSpacing:12,children:[_SummaryCard(title:'العقارات',value:'${c['properties']??'—'}',icon:Icons.apartment),_SummaryCard(title:'الوحدات',value:'${c['units']??'—'}',icon:Icons.meeting_room),_SummaryCard(title:'المستأجرون',value:'${c['tenants']??'—'}',icon:Icons.people_outline),_SummaryCard(title:'الملاك',value:'${c['owners']??'—'}',icon:Icons.groups_outlined)]);}),
          Text('نظرة مالية لهذا الشهر',style:Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight:FontWeight.bold)),
          const SizedBox(height:12),
          FutureBuilder<Map<String,Object?>>(future:_summaryFuture,builder:(context,snapshot){final r=snapshot.data??{};if(snapshot.hasError)return Text('تعذر تحميل الملخص: ${snapshot.error}');final collected=((r['collected'] as num?)??0).toInt();final expenses=((r['expenses'] as num?)??0).toInt();final net=((r['net_income'] as num?)??0).toInt();final maxValue=(collected>expenses?collected:expenses);final ratio=maxValue==0?0.0:collected/maxValue;return Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[Wrap(spacing:10,runSpacing:10,children:[_SummaryCard(title:'المحصل',value:'${(collected/100).toStringAsFixed(2)} ج.م',icon:Icons.payments_outlined),_SummaryCard(title:'المصروفات',value:'${(expenses/100).toStringAsFixed(2)} ج.م',icon:Icons.account_balance_wallet_outlined),_SummaryCard(title:'صافي الدخل',value:'${(net/100).toStringAsFixed(2)} ج.م',icon:Icons.trending_up)]),if(!AppPreferences.instance.compactDashboard)Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('مقارنة التحصيل بالمصروفات'),const SizedBox(height:8),LinearProgressIndicator(value:ratio,minHeight:10),const SizedBox(height:6),Text('التحصيل ${(ratio*100).round()}% من أعلى القيمتين في الفترة')])))]);}),
          const SizedBox(height:26),
          Text(
            'أقسام التطبيق',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
          ),
          const SizedBox(height: 12),
          ..._modules.map(
            (module) => Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Card(
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor:
                        Theme.of(context).colorScheme.primaryContainer,
                    child: Icon(
                      module.icon,
                      color: Theme.of(context).colorScheme.primary,
                    ),
                  ),
                  title: Text(
                    module.title,
                    style: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                  subtitle: AppPreferences.instance.compactDashboard ? null : Text(module.subtitle),
                  trailing: const Icon(Icons.chevron_left),
                  onTap: () { if (module.title == 'العقارات' || module.title == 'الوحدات' || module.title == 'المستأجرون') { _openRecords(); } else if (module.title == 'العقود') { _openLeases(); } else if (module.title == 'التحصيلات والإيصالات') { _openPayments(); } else if (module.title == 'المصروفات') { _openExpenses(); } else if (module.title == 'الكشوف والتقارير') { _openReports(); } else if (module.title == 'الأرشيف' || module.title == 'مركز المراجعة') { _openArchiveReview(); } else if (module.title == 'الإعدادات') { _openSettings(); } else if (module.title == 'Excel والاستيراد والتصدير') { _openDataExchange(); } else { ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('قسم ${module.title}: لم يُربط بعد.'))); } },
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SummaryCard extends StatelessWidget {
  const _SummaryCard({
    required this.title,
    required this.value,
    required this.icon,
  });

  final String title;
  final String value;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 160,
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon, color: Theme.of(context).colorScheme.primary),
              const SizedBox(height: 12),
              Text(title, style: Theme.of(context).textTheme.bodyMedium),
              const SizedBox(height: 4),
              Text(
                value,
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ModuleItem {
  const _ModuleItem(this.title, this.icon, this.subtitle);
  final String title;
  final IconData icon;
  final String subtitle;
}
