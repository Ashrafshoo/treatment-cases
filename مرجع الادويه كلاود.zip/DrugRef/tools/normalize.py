"""تفكيك التركيز إلى (قوة/عبوة) واستخراج المادة الفعّالة من الاسم."""
import re
import parse_names as P

STR_UNITS = {"MG", "MCG", "UG", "IU", "%", "MEQ", "U"}
PACK_UNITS = {"ML", "GM", "KG", "L", "CM", "MM", "DOSE"}
GM_STRENGTH_FORMS = {"TAB", "CAP", "AMP", "VIAL", "INJ", "SACHET", "SUPP"}
NUM = re.compile(r"^\d+(?:\.\d+)?$")
NUMF = re.compile(r"^\d+(?:\.\d+)?/\d+(?:\.\d+)?$")


def strength_pack(variant: str):
    """يعيد (strength, pack) نصّين، مثل ('500 MG', '10 TAB')."""
    v = re.sub(r"\bI\s+U\b", "IU", variant or "")
    t = v.split()
    forms_present = set(t) & GM_STRENGTH_FORMS
    strength = pack = ""
    i = 0
    while i < len(t):
        a = t[i]
        b = t[i + 1] if i + 1 < len(t) else ""
        isn = bool(NUM.match(a)) or bool(NUMF.match(a))
        if isn and (b in STR_UNITS or (b == "GM" and forms_present)):
            if not strength: strength = f"{a} {b}"
            i += 2; continue
        if isn and (b in P.FORMS or b in PACK_UNITS):
            if not pack: pack = f"{a} {b}"
            i += 2; continue
        if NUMF.match(a) and not strength:
            strength = a
        i += 1
    return strength, pack


FORM_WORDS = {"E", "N", "EYE", "EAR", "NASAL", "DROPS", "DROP", "ORAL", "IMPORTED", "IMP", "LOCAL", "EGYPT", "EGYPTIAN", "MADE", "IN", "MASRY"}


def generic_from_name(name: str, stem_word=None):
    """المادة الفعّالة: ما بين قوسين إن كان اسمًا علميًا، وإلا الكلمة المطابقة لجذر دوائي."""
    m = re.search(r"\(([A-Za-z][A-Za-z \-+/&.]{3,40})\)", name or "")
    if m:
        g = re.sub(r"\s+", " ", m.group(1)).strip().upper()
        if not (set(g.replace(".", "").split()) <= FORM_WORDS):
            return g
    return (stem_word or "").upper()
