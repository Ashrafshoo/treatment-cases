#!/usr/bin/env python3
"""Static + SQLite policy simulation for 2.7.5-dev. Not an Android instrumentation test."""
from pathlib import Path
import sqlite3, re
ROOT=Path(__file__).resolve().parents[1]
local=(ROOT/'android/app/src/main/java/com/treatmentcases/app/LocalDb.kt').read_text()
auth=(ROOT/'android/app/src/main/java/com/treatmentcases/app/AuthManager.kt').read_text()
ui=(ROOT/'android/app/src/main/java/com/treatmentcases/app/MainActivity.kt').read_text()
gradle=(ROOT/'android/app/build.gradle').read_text()
checks=[]
def ok(name,cond):
    if not cond: raise AssertionError(name)
    checks.append(name)

ok('current versionName 2.8.1-ui-polish and versionCode 33','versionCode 33' in gradle and "versionName '2.8.1-ui-polish'" in gradle and 'preview275' in gradle)
ok('additive database migration to v11','null,11)' in local and 'if(oldVersion<11)' in local)
ok('delegated account permission and active fields','permissions TEXT NOT NULL DEFAULT' in local and 'active INTEGER NOT NULL DEFAULT 1' in local)
ok('one-time activation table stores salted hash, expiry and use time',all(x in local for x in ['code_salt TEXT NOT NULL','code_hash TEXT NOT NULL','expires_at INTEGER NOT NULL','used_at INTEGER']))
ok('activation codes are hashed with PBKDF2 and random salt', 'PBKDF2WithHmacSHA256' in auth and '160_000' in auth and 'code_salt' in auth)
ok('activation code consumed atomically only once','used_at IS NULL' in auth and 'd.beginTransaction()' in auth and 'd.setTransactionSuccessful()' in auth)
ok('activation checks expiry and password minimum','expires_at' in auth and 'System.currentTimeMillis()' in auth and 'password.length<8' in auth)
ok('disabled accounts cannot authenticate','c.getInt(5)!=1' in auth)
ok('delegated manager is limited to own permissions','permissions.any{it !in permissionKeys || it !in db.activePermissions()}' in auth)
ok('delegated manager account listing is owner-scoped','WHERE owner_user_id=?' in auth)
ok('account enable/disable and permission changes are owner-scoped',auth.count('owner_user_id=?')>=2)
ok('database triggers protect cases, employees, medicines and strengths',all(f'"{t}" to "{p1}"' in local for t,p1 in [('cases','add_edit'),('employees','add_edit'),('medicines','manage_medicines'),('strengths','manage_medicines')]))
ok('session is set after successful sign-in','db.setActiveSession(signed.role,signed.permissions,signed.userId)' in ui)
ok('fingerprint path is restricted to administrator','username.equals("admin",true)&&accountMode=="login"' in ui)
ok('user management UI and delegated import page exist','UserManagementCard(auth,isEnglish)' in ui and '"استيراد"->{' in ui)

# Execute the same authorization-trigger pattern against SQLite and verify deny/allow boundaries.
c=sqlite3.connect(':memory:')
c.executescript('''
CREATE TABLE cases(id INTEGER PRIMARY KEY, name TEXT);
CREATE TABLE employees(id INTEGER PRIMARY KEY, name TEXT);
CREATE TABLE medicines(id INTEGER PRIMARY KEY, name TEXT);
CREATE TABLE strengths(id INTEGER PRIMARY KEY, medicine TEXT, strength TEXT);
CREATE TABLE auth_runtime(id INTEGER PRIMARY KEY CHECK(id=1),role TEXT NOT NULL,permissions TEXT NOT NULL DEFAULT '',user_id INTEGER);
INSERT INTO auth_runtime VALUES(1,'ADMIN','view_search,add_edit,export_share,import_excel,manage_medicines,manage_users',NULL);
''')
for table,permission in [('cases','add_edit'),('employees','add_edit'),('medicines','manage_medicines'),('strengths','manage_medicines')]:
    for op in ('INSERT','UPDATE','DELETE'):
        c.execute(f"CREATE TRIGGER auth_{table}_{op.lower()} BEFORE {op} ON {table} WHEN COALESCE((SELECT role FROM auth_runtime WHERE id=1),'GUEST')!='ADMIN' AND instr(','||COALESCE((SELECT permissions FROM auth_runtime WHERE id=1),'')||',',',{permission},')=0 BEGIN SELECT RAISE(ABORT,'permission_denied'); END")
# Guest and read-only must not mutate cases or medicine catalog.
c.execute("UPDATE auth_runtime SET role='GUEST',permissions='' WHERE id=1")
for table in ('cases','medicines'):
    try: c.execute(f"INSERT INTO {table}(name) VALUES('x')")
    except sqlite3.IntegrityError: pass
    else: raise AssertionError(f'guest write unexpectedly allowed: {table}')
c.execute("UPDATE auth_runtime SET role='USER',permissions='view_search' WHERE id=1")
try: c.execute("INSERT INTO cases(name) VALUES('read-only')")
except sqlite3.IntegrityError: pass
else: raise AssertionError('view-only user wrote a case')
# Add/edit user can write cases and staff, but not medicine dictionary.
c.execute("UPDATE auth_runtime SET permissions='view_search,add_edit' WHERE id=1")
c.execute("INSERT INTO cases(name) VALUES('allowed case')")
c.execute("INSERT INTO employees(name) VALUES('allowed employee')")
try: c.execute("INSERT INTO medicines(name) VALUES('blocked medicine')")
except sqlite3.IntegrityError: pass
else: raise AssertionError('add/edit user modified medicine catalog')
# Import permission is an additional gate; the user also needs the domain write permission.
c.execute("UPDATE auth_runtime SET permissions='import_excel' WHERE id=1")
try: c.execute("INSERT INTO cases(name) VALUES('blocked import')")
except sqlite3.IntegrityError: pass
else: raise AssertionError('import-only user bypassed the add/edit domain permission')
c.execute("UPDATE auth_runtime SET permissions='import_excel,add_edit' WHERE id=1")
c.execute("INSERT INTO cases(name) VALUES('imported case')")
# Medicine manager can maintain medicines, but cannot edit cases absent add_edit.
c.execute("UPDATE auth_runtime SET permissions='manage_medicines' WHERE id=1")
c.execute("INSERT INTO medicines(name) VALUES('allowed medicine')")
try: c.execute("UPDATE cases SET name='blocked' WHERE id=1")
except sqlite3.IntegrityError: pass
else: raise AssertionError('medicine manager edited cases without add_edit')
checks += ['SQLite trigger denies guest/read-only writes','SQLite trigger allows scoped add/edit and import operations','SQLite trigger denies cross-domain medicine edits']

# Model the additive v7 -> v11 migration and verify pre-existing rows remain intact.
m=sqlite3.connect(':memory:')
m.executescript('''
CREATE TABLE cases(id INTEGER PRIMARY KEY,name TEXT); INSERT INTO cases VALUES(41,'existing case');
CREATE TABLE employees(id INTEGER PRIMARY KEY,name TEXT); INSERT INTO employees VALUES(42,'existing employee');
CREATE TABLE medicines(id INTEGER PRIMARY KEY,name TEXT); INSERT INTO medicines VALUES(43,'existing medicine');
CREATE TABLE strengths(id INTEGER PRIMARY KEY,medicine TEXT,strength TEXT); INSERT INTO strengths VALUES(44,'existing medicine','5 mg');
CREATE TABLE app_users(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT UNIQUE,password_hash TEXT,role TEXT); INSERT INTO app_users(username,password_hash,role) VALUES('olduser','salt:hash','USER');
''')
m.execute("ALTER TABLE app_users ADD COLUMN permissions TEXT NOT NULL DEFAULT '[]'")
m.execute("ALTER TABLE app_users ADD COLUMN active INTEGER NOT NULL DEFAULT 1")
m.execute("ALTER TABLE app_users ADD COLUMN owner_user_id INTEGER")
m.execute("CREATE TABLE activation_codes(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT NOT NULL,code_salt TEXT NOT NULL,code_hash TEXT NOT NULL,permissions TEXT NOT NULL,expires_at INTEGER NOT NULL,used_at INTEGER,created_by TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)")
m.execute("ALTER TABLE activation_codes ADD COLUMN created_by_user_id INTEGER")
m.execute("CREATE TABLE auth_runtime(id INTEGER PRIMARY KEY CHECK(id=1),role TEXT NOT NULL,permissions TEXT NOT NULL DEFAULT '',user_id INTEGER)")
m.execute("INSERT INTO auth_runtime VALUES(1,'ADMIN','view_search,add_edit,export_share,import_excel,manage_medicines,manage_users',NULL)")
assert m.execute("SELECT name FROM cases WHERE id=41").fetchone()[0]=='existing case'
assert m.execute("SELECT name FROM employees WHERE id=42").fetchone()[0]=='existing employee'
assert m.execute("SELECT name FROM medicines WHERE id=43").fetchone()[0]=='existing medicine'
assert m.execute("SELECT strength FROM strengths WHERE id=44").fetchone()[0]=='5 mg'
assert m.execute("SELECT permissions,active,owner_user_id FROM app_users WHERE username='olduser'").fetchone()==('[]',1,None)
checks += ['SQLite v7-to-v11 additive migration preserves existing business rows and legacy users']

# 2.7.5 permission-boundary regressions: import workflows and destructive actions.
ok('case import requires import_excel plus add_edit','hasActivePermission("import_excel")&&hasActivePermission("add_edit")' in local[local.index('fun importRows'):local.index('fun employeeCount')])
ok('employee import requires import_excel plus add_edit','hasActivePermission("import_excel")&&hasActivePermission("add_edit")' in local[local.index('fun commitEmployeeImport'):local.index('fun saveEmployee')])
ok('backup restore requires all data-domain permissions','hasActivePermission("import_excel")&&hasActivePermission("add_edit")&&hasActivePermission("manage_medicines")' in local[local.index('fun restoreBundle('):])
ok('medicine catalog mutations require medicine permission','require(hasActivePermission("manage_medicines")' in local[local.index('fun addMedicine'):local.index('private fun caseSignature')])
ok('destructive data resets are administrator-only',all('require(isAdminSession())' in local[local.index(f'fun {fn}'):local.index(f'fun {nextfn}')] for fn,nextfn in [('clearCases','clearEmployees'),('clearEmployees','factoryResetData')]) and 'require(isAdminSession())' in local[local.index('fun factoryResetData'):local.index('private fun reconcileVerifiedMedicineAliases')])
ok('non-manager cannot add unknown medicine during case save','MedicineNameMatchType.NEW&&!hasActivePermission("manage_medicines")' in local[local.index('fun save(r:CaseRecord)'):local.index('fun delete(id:Long)')])
ok('existing medicine lookup does not trigger catalog write','if(exists)return;require(hasActivePermission("manage_medicines")' in local)
ok('restore UI requires all relevant permissions','session.can("import_excel")&&session.can("add_edit")&&session.can("manage_medicines")' in ui)
ok('delegated users do not see destructive reset controls','OutlinedButton(enabled=session.isAdmin,onClick={resetMode="employees"' in ui and 'Button(enabled=session.isAdmin,onClick={resetMode="all"' in ui)

# SQLite gate behavior: import requires both permissions; catalog restoration needs its own domain grant.
a=sqlite3.connect(':memory:')
a.executescript("CREATE TABLE auth_runtime(role TEXT,permissions TEXT); INSERT INTO auth_runtime VALUES('USER','view_search,add_edit');")
def allowed(permission):
    role,perms=a.execute('SELECT role,permissions FROM auth_runtime').fetchone()
    return role=='ADMIN' or permission in perms.split(',')
assert allowed('add_edit') and not allowed('import_excel')
a.execute("UPDATE auth_runtime SET permissions='view_search,add_edit,import_excel'")
assert allowed('add_edit') and allowed('import_excel') and not allowed('manage_medicines')
a.execute("UPDATE auth_runtime SET permissions='view_search,add_edit,import_excel,manage_medicines'")
assert all(allowed(x) for x in ('add_edit','import_excel','manage_medicines'))
checks += ['SQLite policy rejects import without import_excel','SQLite policy separates case import from medicine catalog restore','SQLite policy permits full restore only with all required grants']
print('\n'.join('PASS: '+x for x in checks))
print(f'{len(checks)} user-access assertions passed (static + SQLite policy/migration simulation).')
