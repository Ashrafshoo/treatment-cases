package com.familyproperties.app

/** Arabic wording for EGP receipt snapshots. The numeric amount remains the source of truth. */
object ArabicAmountWords {
    private val small = arrayOf(
        "صفر", "واحد", "اثنان", "ثلاثة", "أربعة", "خمسة", "ستة", "سبعة", "ثمانية", "تسعة",
        "عشرة", "أحد عشر", "اثنا عشر", "ثلاثة عشر", "أربعة عشر", "خمسة عشر", "ستة عشر",
        "سبعة عشر", "ثمانية عشر", "تسعة عشر"
    )
    private val tens = arrayOf("", "", "عشرون", "ثلاثون", "أربعون", "خمسون", "ستون", "سبعون", "ثمانون", "تسعون")
    private val hundreds = arrayOf(
        "", "مائة", "مائتان", "ثلاثمائة", "أربعمائة", "خمسمائة", "ستمائة", "سبعمائة", "ثمانمائة", "تسعمائة"
    )

    fun forEgpMinorUnits(amountMinor: Long): String {
        require(amountMinor >= 0) { "المبلغ لا يمكن أن يكون سالباً" }
        val pounds = amountMinor / 100
        val piastres = amountMinor % 100
        val result = StringBuilder()
        when (pounds) {
            0L -> result.append("صفر جنيه مصري")
            1L -> result.append("جنيه مصري واحد")
            2L -> result.append("جنيهان مصريان")
            in 3L..10L -> result.append(convert(pounds)).append(" جنيهات مصرية")
            else -> result.append(convert(pounds)).append(" جنيهاً مصرياً")
        }
        if (piastres > 0) {
            result.append(" و")
            when (piastres) {
                1L -> result.append("قرش واحد")
                2L -> result.append("قرشان")
                in 3L..10L -> result.append(convert(piastres)).append(" قروش")
                else -> result.append(convert(piastres)).append(" قرشاً")
            }
        }
        return result.append(" فقط لا غير").toString()
    }

    fun convert(value: Long): String {
        require(value >= 0) { "العدد لا يمكن أن يكون سالباً" }
        if (value == 0L) return "صفر"
        require(value <= 999_999_999_999L) { "المبلغ أكبر من النطاق المدعوم" }
        val groups = listOf(
            (value / 1_000_000_000L) % 1000 to Scale("مليار", "ملياران", "مليارات", "ملياراً"),
            (value / 1_000_000L) % 1000 to Scale("مليون", "مليونان", "ملايين", "مليوناً"),
            (value / 1000L) % 1000 to Scale("ألف", "ألفان", "آلاف", "ألفاً")
        )
        val parts = mutableListOf<String>()
        groups.forEach { (group, scale) -> if (group > 0) parts += scaled(group, scale) }
        val remainder = (value % 1000).toInt()
        if (remainder > 0) parts += underThousand(remainder)
        return parts.joinToString(" و")
    }

    private data class Scale(val one: String, val two: String, val plural: String, val other: String)

    private fun scaled(number: Long, scale: Scale): String = when (number) {
        1L -> scale.one
        2L -> scale.two
        in 3L..10L -> "${underThousand(number.toInt())} ${scale.plural}"
        else -> "${underThousand(number.toInt())} ${scale.other}"
    }

    private fun underThousand(number: Int): String {
        require(number in 0..999)
        if (number < 20) return small[number]
        val hundred = number / 100
        val remainder = number % 100
        val parts = mutableListOf<String>()
        if (hundred > 0) parts += hundreds[hundred]
        if (remainder in 1..19) parts += small[remainder]
        else if (remainder >= 20) {
            val unit = remainder % 10
            if (unit > 0) parts += small[unit]
            parts += tens[remainder / 10]
        }
        return parts.joinToString(" و")
    }
}
