# المرحلة 38 – إصلاح Android Lint (NewApi)

## المشكلة
أظهر تشغيل GitHub Actions أن `lintDebug` يفشل بسبب استخدام
`android:windowLightNavigationBar` داخل `res/values/styles.xml` مع أن الحد الأدنى
للتطبيق هو API 26، بينما يتطلب هذا العنصر API 27.

## الإصلاح
- إزالة `android:windowLightNavigationBar` من `res/values/styles.xml` العام.
- إنشاء `res/values-v27/styles.xml` وإضافة تعريف الثيم كاملاً إليه، بما في ذلك
  `android:windowLightNavigationBar`.
- الإبقاء على بقية عناصر الثيم دون تغيير.
- الإبقاء على `minSdk = 26` و`compileSdk = 36` و`targetSdk = 35`.
- لم يتم تعطيل Lint أو إضافة baseline لإخفاء الخطأ.

## التحقق
تم التحقق من سلامة أرشيف ZIP وتحليل ملفات XML بعد التعديل، وتشغيل اختبارات Python
الموجودة بالمشروع. يلزم إعادة تشغيل GitHub Actions للتحقق من Android Lint والبناء
على بيئة Android SDK الفعلية؛ لا يُدّعى نجاح Gradle أو إنتاج APK في هذه الخطوة.
