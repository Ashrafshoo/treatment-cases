-- Additive schema migration for phase 6. Safe to run repeatedly.
CREATE TABLE IF NOT EXISTS Medicine_Dictionary(
  medicine_id INTEGER PRIMARY KEY AUTOINCREMENT,
  medicine_name TEXT NOT NULL COLLATE NOCASE UNIQUE,
  active_ingredient TEXT,
  dosage_form TEXT,
  specialty TEXT,
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS Medicine_Strengths(
  strength_id INTEGER PRIMARY KEY AUTOINCREMENT,
  medicine_id INTEGER NOT NULL REFERENCES Medicine_Dictionary(medicine_id) ON DELETE CASCADE,
  strength TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1,
  UNIQUE(medicine_id,strength)
);
CREATE INDEX IF NOT EXISTS idx_medicine_strengths_med ON Medicine_Strengths(medicine_id);
-- Exact-value seeding only; this does not rename or merge source treatment values.
INSERT OR IGNORE INTO Medicine_Dictionary(medicine_name)
SELECT DISTINCT TRIM(medicine_name_raw) FROM Treatment_Entries
WHERE medicine_name_raw IS NOT NULL AND TRIM(medicine_name_raw)<>'';
INSERT OR IGNORE INTO Medicine_Strengths(medicine_id,strength)
SELECT DISTINCT d.medicine_id,TRIM(t.strength_raw)
FROM Treatment_Entries t JOIN Medicine_Dictionary d
  ON d.medicine_name=t.medicine_name_raw COLLATE NOCASE
WHERE t.strength_raw IS NOT NULL AND TRIM(t.strength_raw)<>'';
