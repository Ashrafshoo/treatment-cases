package com.example.rentals.io

import android.content.ContentResolver
import android.net.Uri
import android.database.sqlite.SQLiteDatabase
import android.util.Xml
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.security.MessageDigest
import java.util.UUID
import java.util.zip.ZipInputStream

/**
 * Safe first-pass importer for the reviewed Q012 workbook.
 * It archives source rows in a staging table only; it never creates paid receipts,
 * ledger entries, leases, or live units. Linking/approval is a separate workflow.
 */
object LegacyQ012Importer {
    data class SheetCount(val sheet: String, val rows: Int, val recordType: String)
    data class Preview(val workbookName: String, val fingerprint: String, val counts: List<SheetCount>) {
        val totalRows: Int get() = counts.sumOf { it.rows }
    }
    data class Result(val batchId: String, val inserted: Int, val alreadyStaged: Int, val counts: List<SheetCount>)

    private data class SourceRow(val rowNumber: Int, val recordId: String, val values: Map<String, String>)
    private data class SheetData(val name: String, val rows: List<SourceRow>, val type: String)
    private data class Cell(val value: String, val formula: String = "")

    private val targetSheets = linkedMapOf(
        "سجل الوحدات المبدئي" to "unit_source",
        "سجل عقود العمدة" to "lease_source",
        "نتائج مطابقة العقود والإيصالات" to "lease_match_source",
        "تفاصيل كل الإيصالات" to "receipt_source",
        "سجل التعديلات" to "audit_source",
        "أرشيف الوحدات المباعة" to "sold_unit_source",
        // Preserve the workbook's supporting evidence and owner decisions as read-only sources.
        "الكشف الموحد" to "unified_statement_source",
        "بيانات الكشوف المجمعة" to "aggregate_statement_source",
        "متابعة النواقص والربط" to "followup_source",
        "سجل الأسئلة والإجابات" to "owner_answers_source",
        "مراجعة التكرار والفروق" to "duplicate_review_source",
        "مراجعة تطبيق قانون 164" to "law164_review_source",
        "مراجعة مدد انتهاء العقود" to "contract_term_review_source",
        "مطابقة تصنيف الوحدات السكنية" to "residential_classification_source",
        "استكمال بيانات الزيادة" to "rent_increase_followup_source"
    )

    fun preview(resolver: ContentResolver, uri: Uri): Preview {
        val bytes = resolver.openInputStream(uri)?.use { it.readBytes() } ?: error("تعذر قراءة ملف Excel")
        val workbookName = uri.lastPathSegment?.substringAfterLast('/')?.ifBlank { "Q012.xlsx" } ?: "Q012.xlsx"
        val sheets = parseWorkbook(bytes)
        val counts = sheets.map { SheetCount(it.name, it.rows.size, it.type) }
        require(counts.isNotEmpty()) { "لم يتم العثور على أوراق Q012 التشغيلية المعروفة. تأكد من اختيار ملف Q012 بصيغة XLSX." }
        return Preview(workbookName, sha256(bytes), counts)
    }

    fun stage(resolver: ContentResolver, uri: Uri, db: SQLiteDatabase): Result {
        val bytes = resolver.openInputStream(uri)?.use { it.readBytes() } ?: error("تعذر قراءة ملف Excel")
        val workbookName = uri.lastPathSegment?.substringAfterLast('/')?.ifBlank { "Q012.xlsx" } ?: "Q012.xlsx"
        val fingerprint = sha256(bytes)
        val sheets = parseWorkbook(bytes)
        require(sheets.isNotEmpty()) { "لم يتم العثور على أوراق Q012 التشغيلية المعروفة." }
        val batchId = UUID.randomUUID().toString()
        var inserted = 0
        var already = 0
        db.beginTransaction()
        try {
            db.execSQL("""CREATE TABLE IF NOT EXISTS legacy_import_records(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                batch_id TEXT NOT NULL,
                source_fingerprint TEXT NOT NULL,
                source_workbook TEXT NOT NULL,
                source_sheet TEXT NOT NULL,
                source_row INTEGER NOT NULL,
                source_record_id TEXT,
                record_type TEXT NOT NULL,
                raw_json TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending_review',
                review_note TEXT,
                created_at INTEGER NOT NULL,
                UNIQUE(source_fingerprint, source_sheet, source_row)
            )""")
            sheets.forEach { sheet ->
                sheet.rows.forEach { row ->
                    val exists = db.rawQuery(
                        "SELECT 1 FROM legacy_import_records WHERE source_fingerprint=? AND source_sheet=? AND source_row=? LIMIT 1",
                        arrayOf(fingerprint, sheet.name, row.rowNumber.toString())
                    ).use { it.moveToFirst() }
                    if (exists) {
                        already++
                    } else {
                        val raw = JSONObject()
                        row.values.forEach { (k, v) -> raw.put(k, v) }
                        db.execSQL(
                            "INSERT INTO legacy_import_records(batch_id,source_fingerprint,source_workbook,source_sheet,source_row,source_record_id,record_type,raw_json,status,review_note,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                            arrayOf(batchId, fingerprint, workbookName, sheet.name, row.rowNumber, row.recordId, sheet.type, raw.toString(), "pending_review", initialNote(sheet.type), System.currentTimeMillis())
                        )
                        inserted++
                    }
                }
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        return Result(batchId, inserted, already, sheets.map { SheetCount(it.name, it.rows.size, it.type) })
    }

    private fun initialNote(type: String): String = when (type) {
        "receipt_source" -> "مرجع إيصال تاريخي فقط؛ لا يثبت السداد الحالي ولا يُنشئ قيدًا ماليًا. يلزم ربط موثق بوحدة وفحص عدم التكرار."
        "lease_source" -> "عقد محفوظ للمراجعة؛ لا يُربط بوحدة اعتمادًا على تشابه الاسم وحده. تُحفظ التواريخ والعبارات كما وردت ولا تُفسر قانونيًا تلقائيًا."
        "lease_match_source" -> "ورقة تحليل مطابقة مساعدة وليست أصل عقد أو إثبات ربط نهائي؛ أي معرّف وحدة مقترح يحتاج مراجعة مستقلة قبل الاعتماد."
        "audit_source" -> "سجل تاريخي للقراءة؛ لا يعاد تشغيله كأوامر تعديل."
        "sold_unit_source" -> "يجب مطابقة معرّف U مع سجل الوحدات قبل اعتماد حالة البيع."
        "unified_statement_source" -> "نسخة مصدرية من الكشف الموحد؛ تحفظ للمراجعة ولا تُنشئ إيصالًا مدفوعًا أو استحقاقًا أو حركة مالية."
        "aggregate_statement_source" -> "بيانات كشف مجمع تاريخية؛ لا تُنشئ وحدات أو قيمًا حالية أو إيصالات تلقائيًا."
        "followup_source" -> "متابعة نواقص وقرارات ربط؛ تحفظ كمرجع ولا تُنفذ تعليماتها تلقائيًا."
        "owner_answers_source" -> "إجابات واعتمادات المالك محفوظة كمرجع؛ لا تُنفذ كأوامر ترحيل آلي."
        "duplicate_review_source" -> "تحليل تكرار وفروق؛ لا يدمج أو يحذف أو يجمع أي سجل تلقائيًا."
        "law164_review_source" -> "تحليل قانوني/مالي مرجعي فقط؛ لا يغير التصنيف أو الإيجار ولا يعتمد انطباق القانون تلقائيًا."
        "contract_term_review_source" -> "تحليل مدد العقود مرجعي فقط؛ لا يحول النصوص إلى تواريخ انتهاء أو قرارات إخلاء."
        "residential_classification_source" -> "مطابقة تصنيف سكني غير نهائية؛ لا تعتمد منطقة أو قيمة قانونية دون مستند رسمي."
        "rent_increase_followup_source" -> "متابعة بيانات الزيادة؛ تحفظ قرارات المالك والنواقص دون إعادة احتساب الإيجار تلقائيًا."
        else -> "نسخة مصدر محفوظة للمطابقة؛ لا تُنشئ مسودة قابلة للتحصيل قبل اعتماد الحالة والبيانات."
    }

    private fun parseWorkbook(bytes: ByteArray): List<SheetData> {
        val entries = mutableMapOf<String, ByteArray>()
        ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
            var e = zip.nextEntry
            while (e != null) { if (!e.isDirectory) entries[e.name] = zip.readBytes(); zip.closeEntry(); e = zip.nextEntry }
        }
        val workbook = entries["xl/workbook.xml"] ?: error("ملف XLSX لا يحتوي على workbook.xml")
        val rels = entries["xl/_rels/workbook.xml.rels"] ?: error("ملف XLSX لا يحتوي على علاقات الأوراق")
        val shared = parseShared(entries["xl/sharedStrings.xml"])
        val relationships = mutableMapOf<String, String>()
        parseXml(rels) { p, event ->
            if (event == XmlPullParser.START_TAG && p.name == "Relationship") {
                val id = p.getAttributeValue(null, "Id") ?: ""
                val target = p.getAttributeValue(null, "Target") ?: ""
                if (id.isNotBlank() && target.isNotBlank()) relationships[id] = target
            }
        }
        val sheetRefs = mutableListOf<Pair<String, String>>()
        parseXml(workbook) { p, event ->
            if (event == XmlPullParser.START_TAG && p.name == "sheet") {
                val name = p.getAttributeValue(null, "name") ?: ""
                val rid = p.getAttributeValue("http://schemas.openxmlformats.org/officeDocument/2006/relationships", "id") ?: ""
                if (name in targetSheets && relationships[rid] != null) sheetRefs += name to relationships.getValue(rid)
            }
        }
        return sheetRefs.mapNotNull { (name, target) ->
            val path = if (target.startsWith("/")) target.removePrefix("/") else "xl/${target.removePrefix("./")}".replace("xl/xl/", "xl/")
            val sheetBytes = entries[path] ?: entries["xl/$target"] ?: return@mapNotNull null
            val matrix = parseRows(sheetBytes, shared)
            val headerIndex = matrix.indexOfFirst { row ->
                val joined = row.joinToString("|")
                when (name) {
                    "سجل الوحدات المبدئي" -> joined.contains("معرّف السجل") && joined.contains("اسم المستأجر")
                    "سجل عقود العمدة" -> joined.contains("معرّف العقد") && joined.contains("اسم المستأجر")
                    "نتائج مطابقة العقود والإيصالات" -> joined.contains("معرّف العقد") && joined.contains("معرّف سجل الوحدة المرتبط")
                    "تفاصيل كل الإيصالات" -> joined.contains("المستأجر كما بالإيصال") && joined.contains("حالة الإيصال")
                    "سجل التعديلات" -> joined.contains("رقم التعديل") && joined.contains("القيمة السابقة")
                    "أرشيف الوحدات المباعة" -> joined.contains("معرّف السجل") && joined.contains("حالة الأرشيف")
                    "الكشف الموحد" -> joined.contains("اسم المستأجر") && joined.contains("القيمة الإيجارية الحالية")
                    "بيانات الكشوف المجمعة" -> joined.contains("القسم") && joined.contains("اسم المستأجر") && joined.contains("القيمة الحالية")
                    "متابعة النواقص والربط" -> joined.contains("رقم المتابعة") && joined.contains("حالة المتابعة")
                    "سجل الأسئلة والإجابات" -> joined.contains("المعرّف") && joined.contains("السؤال / البيان المطلوب") && joined.contains("الإجابة المعتمدة من المالك")
                    "مراجعة التكرار والفروق" -> joined.contains("نوع المراجعة") && joined.contains("المستأجر/العين") && joined.contains("الإجراء المتخذ")
                    "مراجعة تطبيق قانون 164" -> joined.contains("معرّف السجل") && joined.contains("انطباق قانون 164")
                    "مراجعة مدد انتهاء العقود" -> joined.contains("معرّف العقد") && joined.contains("اسم المستأجر") && joined.contains("حالة المراجعة")
                    "مطابقة تصنيف الوحدات السكنية" -> joined.contains("معرّف السجل") && joined.contains("نتيجة المطابقة مع قرار 978/2026")
                    "استكمال بيانات الزيادة" -> joined.contains("الأولوية") && joined.contains("البيان المطلوب") && joined.contains("الحالة")
                    else -> false
                }
            }
            if (headerIndex < 0) return@mapNotNull null
            val headers = matrix[headerIndex].mapIndexed { i, h -> h.ifBlank { "عمود_${i + 1}" } }
            val data = matrix.drop(headerIndex + 1).mapIndexedNotNull { offset, row ->
                val values = linkedMapOf<String, String>()
                headers.forEachIndexed { i, h -> values[h] = row.getOrNull(i).orEmpty() }
                if (values.values.all { it.isBlank() }) return@mapIndexedNotNull null
                val recordId = when (name) {
                    "سجل الوحدات المبدئي", "أرشيف الوحدات المباعة" -> values.entries.firstOrNull { it.key.contains("معرّف السجل") }?.value
                    "سجل عقود العمدة", "نتائج مطابقة العقود والإيصالات" -> values.entries.firstOrNull { it.key.contains("معرّف العقد") }?.value
                    "سجل التعديلات" -> values.entries.firstOrNull { it.key.contains("رقم التعديل") }?.value
                    "الكشف الموحد" -> values.entries.firstOrNull { it.key == "م" }?.value
                    "بيانات الكشوف المجمعة" -> values.entries.firstOrNull { it.key.contains("صف المصدر") }?.value
                    "متابعة النواقص والربط" -> values.entries.firstOrNull { it.key.contains("رقم المتابعة") }?.value
                    "سجل الأسئلة والإجابات" -> values.entries.firstOrNull { it.key == "المعرّف" }?.value
                    "مراجعة تطبيق قانون 164", "مطابقة تصنيف الوحدات السكنية" -> values.entries.firstOrNull { it.key.contains("معرّف السجل") }?.value
                    "مراجعة مدد انتهاء العقود" -> values.entries.firstOrNull { it.key.contains("معرّف العقد") }?.value
                    "استكمال بيانات الزيادة" -> values.entries.firstOrNull { it.key == "رقم" }?.value
                    else -> values.entries.firstOrNull { it.key == "م" }?.value
                }.orEmpty()
                SourceRow(headerIndex + offset + 2, recordId, values)
            }
            SheetData(name, data, targetSheets.getValue(name))
        }
    }

    private fun parseRows(bytes: ByteArray, shared: List<String>): List<List<String>> {
        val rows = mutableListOf<List<String>>()
        var row = sortedMapOf<Int, String>()
        var cellIndex = 0
        var cellType = ""
        var cellValue = ""
        var inCell = false
        parseXml(bytes) { p, event ->
            if (event == XmlPullParser.START_TAG && p.name == "row") row = sortedMapOf()
            else if (event == XmlPullParser.START_TAG && p.name == "c") {
                inCell = true; cellType = p.getAttributeValue(null, "t") ?: ""
                cellIndex = colIndex(p.getAttributeValue(null, "r") ?: "A1"); cellValue = ""
            } else if (event == XmlPullParser.START_TAG && inCell && (p.name == "v" || p.name == "t")) {
                val value = p.nextText()
                if (cellType == "s") cellValue = shared.getOrNull(value.toIntOrNull() ?: -1).orEmpty() else cellValue += value
            } else if (event == XmlPullParser.END_TAG && p.name == "c") {
                row[cellIndex] = cellValue; inCell = false
            } else if (event == XmlPullParser.END_TAG && p.name == "row") {
                if (row.isNotEmpty()) rows += (0..(row.lastKey())).map { row[it].orEmpty() }
            }
        }
        return rows
    }

    private fun parseShared(bytes: ByteArray?): List<String> {
        if (bytes == null) return emptyList()
        val out = mutableListOf<String>(); var inSi = false; var text = StringBuilder()
        parseXml(bytes) { p, event ->
            if (event == XmlPullParser.START_TAG && p.name == "si") { inSi = true; text = StringBuilder() }
            else if (event == XmlPullParser.START_TAG && p.name == "t" && inSi) text.append(p.nextText())
            else if (event == XmlPullParser.END_TAG && p.name == "si") { out += text.toString(); inSi = false }
        }
        return out
    }

    private inline fun parseXml(bytes: ByteArray, crossinline onEvent: (XmlPullParser, Int) -> Unit) {
        val parser = Xml.newPullParser(); parser.setInput(ByteArrayInputStream(bytes), "UTF-8")
        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) { onEvent(parser, event); event = parser.next() }
    }
    private fun colIndex(ref: String): Int {
        val letters = ref.takeWhile { it.isLetter() }; var n = 0
        letters.forEach { n = n * 26 + (it.uppercaseChar() - 'A' + 1) }
        return (n - 1).coerceAtLeast(0)
    }
    private fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
}
