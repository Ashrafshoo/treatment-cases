#!/usr/bin/env python3
"""Focused UI regression checks for the post-2.8.0 navigation polish."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'android/app/src/main/java/com/treatmentcases/app/MainActivity.kt').read_text(encoding='utf-8')
g=(root/'android/app/build.gradle').read_text(encoding='utf-8')
b=(root/'android/app/src/main/java/com/treatmentcases/app/EncryptedBackup.kt').read_text(encoding='utf-8')
checks={
 'version code/name advanced without changing package identity': 'versionCode 33' in g and "versionName '2.8.1-ui-polish'" in g and "applicationId 'com.treatmentcases.app.preview275'" in g,
 'workspace navigation group exists': 'WORKSPACE' in s and 'مساحة العمل' in s,
 'medicine and reports navigation group exists': 'MEDICINES & REPORTS' in s and 'الأدوية والتقارير' in s,
 'administration navigation group exists': 'ADMINISTRATION & TOOLS' in s and 'الإدارة والأدوات' in s,
 'groups hide when no permitted item exists': 'if(groupItems.isNotEmpty())' in s,
 'selected marker follows layout direction': 'if(isEnglish)Icons.Default.ChevronRight else Icons.Default.ChevronLeft' in s,
 'selected settings tools remain highlighted': 'page=="الإعدادات" && item.first in setOf("المزامنة","النسخ","حول")' in s,
 'drawer closes after navigation': 'drawerScope.launch{drawerState.close()}' in s,
 'app bar shows current section context': 'Cases & Medicine Management' in s and 'Medicine Catalog' in s and 'Staff Directory' in s,
 'drawer footer displays version': 'VERSION 2.8.1' in s and 'الإصدار 2.8.1' in s,
 'backup manifest version matches app': '.put("app_version", "2.8.1-ui-polish")' in b,
 'database schema and sync source remain untouched by UI-only phase': 'treatment_cases_local.db",null,11' in (root/'android/app/src/main/java/com/treatmentcases/app/LocalDb.kt').read_text(encoding='utf-8'),
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+': '+k)
assert all(checks.values())
print(f'PASS: {len(checks)} UI polish assertions')
