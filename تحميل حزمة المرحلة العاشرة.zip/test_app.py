import unittest, sqlite3
from pathlib import Path
import app, tempfile, management
from test_fixtures import create_test_db
class AppTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(); self.old_db=app.DB
  app.DB=create_test_db(Path(self.tmp.name)/'app_test.db'); management.initialize(app.DB)
 def tearDown(self): app.DB=self.old_db; self.tmp.cleanup()
 def test_dashboard_counts(self):
  d=app.dashboard(); self.assertEqual(d['people'],2); self.assertEqual(d['entries'],2); self.assertGreater(len(d['medicines']),0)
 def test_search(self):
  rows=app.search_people('RINVOQ'); self.assertEqual(rows,[])
  c=sqlite3.connect(app.DB); perf=c.execute('select performance_number from Personnel limit 1').fetchone()[0]; c.close()
  self.assertTrue(app.search_people(perf))
 def test_profile_readonly(self):
  c=sqlite3.connect(app.DB); perf=c.execute('select performance_number from Personnel limit 1').fetchone()[0]; before=c.execute('select count(*) from Personnel').fetchone()[0]; c.close()
  p=app.beneficiary_profile(app.DB,perf); self.assertIsNotNone(p); self.assertNotIn('national_id',p['person'])
  c=sqlite3.connect(app.DB); self.assertEqual(before,c.execute('select count(*) from Personnel').fetchone()[0]); c.close()
 def test_icon(self): self.assertIn('<svg',app.ICON); self.assertIn('viewBox',app.ICON)
if __name__=='__main__': unittest.main()
