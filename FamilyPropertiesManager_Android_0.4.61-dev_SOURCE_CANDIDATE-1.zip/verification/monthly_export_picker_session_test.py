from pathlib import Path
root = Path(__file__).resolve().parents[1]
main = (root / "app/src/main/java/com/example/rentals/MainActivity.kt").read_text(encoding="utf-8")
screen = (root / "app/src/main/java/com/example/rentals/features/printing/MonthlyCollectionScreen.kt").read_text(encoding="utf-8")
# CreateDocument launches must mark the external picker as active so ON_STOP does not
# lock the app and dispose the Compose coroutine before the result callback writes data.
assert "Tab.Print->MonthlyCollectionScreen(activity,monthlyCollectionRepository,units,settings,setExternalPickerInProgress)" in main
assert "settings.lockOnBackground && security.hasPin()) unlocked = false" in main
for launcher in ("exportReceiptsPdf", "exportReceiptsXlsx", "exportCollectorPdf", "exportCollectorXlsx"):
    assert f"setExternalPickerInProgress(true);{launcher}.launch(" in screen, launcher
    assert f"{launcher}=rememberLauncherForActivityResult" in screen
# Result callback clears the guard before handling cancellation or export.
assert screen.count("){uri->setExternalPickerInProgress(false);if(uri!=null&&exportBatchId>0&&!exportBusy)") == 4
print("PASS: all monthly CreateDocument pickers preserve the unlocked session until their result callback, then release the guard.")
