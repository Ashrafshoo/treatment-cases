#!/usr/bin/env python3
"""
يقترح اسمًا عربيًا للأصناف التي ينقصها:
  (أ) اسم عربي فارغ  → من name_en
  (ب) اسم عربي مكتوب بحروف لاتينية → من نفس النص
الأسلوب (بالأولوية لكل كلمة):
  1) قاموس أساسي للوحدات والأشكال والكلمات الشائعة
  2) قاموس متعلَّم من الأصناف التي لها اسم عربي فعلي في الشيت نفسه
  3) نقل صوتي بالقواعد (تقريبي — يحتاج اعتماد المراجع)
الناتج: arabic_names.csv  (item_code, source_text, proposed, method, from_empty)
method = dict (كل الكلمات من 1 و2) | translit (كلمة واحدة على الأقل نقل صوتي)
"""
import csv, re, sys, collections

AR = re.compile("[\u0600-\u06FF]")
TOKEN = re.compile(r"\d+(?:[.,]\d+)?(?:/\d+(?:[.,]\d+)?)?%?|[A-Za-z]+|[&+]")

BASE = {
    # وحدات
    "MG": "مجم", "MCG": "مكجم", "UG": "مكجم", "GM": "جم", "GR": "جم", "ML": "مل",
    "IU": "وحدة", "KG": "كجم", "CM": "سم", "MM": "مم", "DOSE": "جرعة", "MEQ": "مكافئ",
    # أشكال
    "TAB": "قرص", "TABS": "قرص", "TABLET": "قرص", "TABLETS": "قرص",
    "CAP": "كبسول", "CAPS": "كبسول", "CAPSULE": "كبسول", "CAPSULES": "كبسول",
    "AMP": "امبول", "AMPS": "امبول", "AMPOULE": "امبول", "AMPOULES": "امبول", "AMPULE": "امبول",
    "VIAL": "فيال", "VIALS": "فيال", "INJ": "حقن", "INJECTION": "حقن",
    "SYRUP": "شراب", "SYP": "شراب", "SYR": "شراب", "LIQUID": "سائل",
    "CREAM": "كريم", "GEL": "جل", "OINT": "مرهم", "OINTMENT": "مرهم", "LOTION": "لوشن",
    "DROPS": "قطرة", "DROP": "قطرة", "SUPP": "اقماع", "SUPPOSITORIES": "اقماع", "SUPPOSITORY": "اقماع",
    "SACH": "كيس", "SACHET": "كيس", "SACHETS": "كيس", "SPRAY": "سبراي", "SHAMPOO": "شامبو",
    "OIL": "زيت", "POWDER": "بودرة", "SOLUTION": "محلول", "SOL": "محلول", "SUSP": "معلق",
    "SUSPENSION": "معلق", "SYRINGE": "سرنجة", "INHALER": "بخاخة", "LOZENGES": "اقراص مص",
    "SOAP": "صابون", "WASH": "غسول", "MASK": "ماسك", "BALM": "بلسم", "PATCH": "لصقة", "PATCHES": "لصقات",
    "SET": "طقم", "SETS": "طقم", "TUBE": "انبوب", "BOTTLE": "زجاجة", "STRIPS": "شرائح", "STRIP": "شريط",
    "MOUTHWASH": "غسول فم", "TOOTHPASTE": "معجون اسنان", "DRINK": "مشروب", "MIX": "مخلوط",
    "EYE": "للعين", "EAR": "للاذن", "NASAL": "للانف", "ORAL": "فموي", "ED": "قطرة عين",
    # كلمات شائعة
    "PLUS": "بلس", "FORTE": "فورت", "MAX": "ماكس", "EXTRA": "اكسترا", "ULTRA": "الترا", "MEGA": "ميجا",
    "OMEGA": "اوميجا", "VITAMIN": "فيتامين", "VIT": "فيتامين", "WOMENS": "نساء", "WOMEN": "نساء",
    "MENS": "رجال", "MEN": "رجال", "HAIR": "هير", "SKIN": "سكين", "CARE": "كير", "FREE": "فري",
    "DAY": "داي", "NIGHT": "نايت", "COLD": "كولد", "ONE": "وان", "CO": "كو", "KIDS": "اطفال",
    "BABY": "بيبي", "JUNIOR": "جونيور", "ADULT": "كبار", "STRENGTH": "ستريندج", "IMP": "مستورد",
    "XR": "اكس ار", "SR": "اس ار", "ER": "اي ار", "MR": "ام ار", "CR": "سي ار", "DS": "دي اس",
    "AND": "و", "WITH": "مع", "FOR": "لـ", "OF": "", "THE": "", "AM": "ام", "PM": "بي ام",
    "SUPPORT": "سابورت", "MASSAGE": "مساج", "MULTI": "ملتي", "MINERAL": "معادن", "CALCIUM": "كالسيوم",
    "IRON": "حديد", "ZINC": "زنك", "MAGNESIUM": "ماغنسيوم", "NATURAL": "ناتشورال", "PROTEIN": "بروتين",
    "SPF": "اس بي اف", "SUN": "صن", "SUNBLOCK": "صن بلوك", "MILK": "ميلك", "WATER": "ماء",
}
LETTER = dict(zip("ABCDEFGHIJKLMNOPQRSTUVWXYZ",
    "اي بي سي دي اي اف جي اتش اي جاي كي ال ام ان او بي كيو ار اس تي يو في دبليو اكس واي زد".split()))

def translit(w: str) -> str:
    w = w.upper()
    # اختصار بلا حروف علة → نطق الحروف
    if len(w) == 1 or (not re.search("[AEIOUY]", w) and len(w) <= 4):
        return " ".join(LETTER[c] for c in w)
    s, out, i, n = w, [], 0, len(w)
    V = "AEIOUY"
    def nxt(k=1): return s[i + k] if i + k < n else ""
    while i < n:
        c, d = s[i], nxt()
        two = c + d
        three = s[i:i + 3]
        if three == "TCH": out.append("تش"); i += 3; continue
        if two == "SH": out.append("ش"); i += 2; continue
        if two == "CH":
            out.append("ك" if nxt(2) in ("L", "R") else "تش"); i += 2; continue
        if two == "PH": out.append("ف"); i += 2; continue
        if two == "TH": out.append("ث"); i += 2; continue
        if two == "KH": out.append("خ"); i += 2; continue
        if two == "CK": out.append("ك"); i += 2; continue
        if two == "QU": out.append("كو"); i += 2; continue
        if two == "GH": i += 2; continue
        if two in ("OO", "OU"): out.append("و" if two == "OO" else "او"); i += 2; continue
        if two in ("EE", "EA"): out.append("ي"); i += 2; continue
        if two == "AI" or two == "AY": out.append("اي"); i += 2; continue
        if two == "AU" or two == "AW": out.append("او"); i += 2; continue
        if two == "OY" or two == "OI": out.append("وي"); i += 2; continue
        if d == c and c not in V:  # حرف مكرر
            i += 1; continue
        first, last = i == 0, i == n - 1
        if c == "A": out.append("ا")
        elif c == "E":
            if last and n > 3: pass
            elif first: out.append("ا")
            else: out.append("ي")
        elif c == "I": out.append("اي" if first else "ي")
        elif c == "O": out.append("او" if first else "و")
        elif c == "U": out.append("ا" if first else "و")
        elif c == "Y": out.append("ي")
        elif c == "C": out.append("س" if d in ("I", "E", "Y") else "ك")
        elif c == "G": out.append("ج")
        elif c == "X": out.append("كس")
        elif c == "H": out.append("ه")
        else:
            out.append({"B": "ب", "D": "د", "F": "ف", "J": "ج", "K": "ك", "L": "ل", "M": "م", "N": "ن",
                        "P": "ب", "Q": "ك", "R": "ر", "S": "س", "T": "ت", "V": "ف", "W": "و", "Z": "ز"}.get(c, ""))
        i += 1
    return "".join(out)

def prep(text: str):
    text = re.sub(r"(?<=[A-Za-z])(?=\d)|(?<=\d)(?=[A-Za-z])", " ", text)
    return TOKEN.findall(text)

def is_latin_only(s): return bool(s.strip()) and not AR.search(s)

def skeleton(a: str) -> str:
    a = re.sub("[\u064B-\u065F]", "", a)
    a = re.sub("[اأإآويى]", "", a)
    return a.replace("ة", "ه").replace("ث", "ت").replace("ظ", "ز").replace("ذ", "د").replace("ص", "س").replace("ط", "ت").replace("ق", "ك")

def plausible(e: str, a: str) -> bool:
    """يقبل التعلّم فقط إن كان الاسم العربي قريب صوتيًا من النقل الآلي (يمنع أخطاء المحاذاة)."""
    import difflib
    x, y = skeleton(translit(e)), skeleton(a)
    if not x or not y: return False
    return difflib.SequenceMatcher(None, x, y).ratio() >= 0.6

def learn(rows):
    """يتعلم كلمة→عربي من الأصناف ذات الاسم العربي الفعلي."""
    votes = collections.defaultdict(collections.Counter)
    stop_ar = set(BASE.values())
    for r in rows:
        ar, en = r["name_ar"].strip(), r["name_en"].strip()
        if not en or not AR.search(ar): continue
        ew = [t.upper() for t in prep(en) if t[0].isalpha() and t.upper() not in BASE and len(t) > 2]
        aw = [t for t in re.findall(r"[\u0600-\u06FF]+", ar)
              if t not in stop_ar and t not in ("اقراص", "قرص", "كبسول", "كبسولة", "ق", "مجم", "جم", "مل", "ملل", "قطره", "شراب", "كريم", "اقماع", "م", "مج")]
        if not ew or not aw: continue
        if len(ew) == len(aw):
            for e, a in zip(ew, aw): votes[e][a] += 1
        elif len(ew) == 1 or len(aw) == 1:
            votes[ew[0]][aw[0]] += 1
    d = {}
    for e, c in votes.items():
        a, k = c.most_common(1)[0]
        if k / sum(c.values()) >= 0.6 and plausible(e, a): d[e] = a
    return d

BIGRAMS = [
    (r"\bE\.?\s*DROPS?\b", "EYEDROPS"), (r"\bEYE\s*DROPS?\b", "EYEDROPS"),
    (r"\bNASAL\s*SPRAY\b", "NASALSPRAY"), (r"\bN\.?\s*SPRAY\b", "NASALSPRAY"),
    (r"\bNASAL\s*DROPS?\b", "NASALDROPS"),
]
BASE.update({"EYEDROPS": "قطرة عين", "NASALSPRAY": "سبراي انف", "NASALDROPS": "نقط انف"})

def convert(text, learned):
    parts, all_dict = [], True
    for pat, rep in BIGRAMS: text = re.sub(pat, rep, text, flags=re.I)
    prev_num = False
    for t in prep(text):
        if len(t) == 1 and t.upper() in "GL" and prev_num:
            parts.append("جم" if t.upper() == "G" else "لتر"); prev_num = False; continue
        prev_num = t[0].isdigit()
        u = t.upper()
        if t[0].isdigit() or t == "%": parts.append(t.replace(",", ".")); continue
        if t in "&+": parts.append("+" if t == "+" else "و"); continue
        if u in BASE: parts.append(BASE[u]); continue
        if u in learned: parts.append(learned[u]); continue
        parts.append(translit(u)); all_dict = False
    name = re.sub(r"\s+", " ", " ".join(p for p in parts if p)).strip()
    return name, ("dict" if all_dict else "translit")

def main(src, out):
    rows = list(csv.DictReader(open(src, encoding="utf-8-sig")))
    learned = learn(rows)
    res = []
    for r in rows:
        ar, en = r["name_ar"].strip(), r["name_en"].strip()
        if AR.search(ar): continue
        source = ar if is_latin_only(ar) else en
        if not source: continue
        name, method = convert(source, learned)
        if name: res.append((r["item_code"], source, name, method, "1" if not ar else "0"))
    with open(out, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f); w.writerow(["item_code", "source_text", "proposed", "method", "from_empty"]); w.writerows(res)
    c = collections.Counter(x[3] for x in res)
    print(f"learned words: {len(learned)} | proposals: {len(res)} | {dict(c)}")

if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
