from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MAIN = ROOT / "android-app/src/main/java/com/familyproperties/app/MainActivity.kt"
PREFS = ROOT / "android-app/src/main/java/com/familyproperties/app/AppUiPreferences.kt"
AUTH = ROOT / "android-app/src/main/java/com/familyproperties/app/AuthRepository.kt"


def test_device_local_settings_include_themes_fonts_scale_and_weight():
    source = PREFS.read_text(encoding="utf-8")
    main = MAIN.read_text(encoding="utf-8")
    for token in ('"palette"', '"font"', '"font_scale"', '"bold_text"', '"biometric_enabled"'):
        assert token in source
    for token in ('"classic"', '"emerald"', '"burgundy"', '"slate"', '"dark"', 'FontFamily.Serif', 'FontFamily.SansSerif', 'prefs.fontScale', 'prefs.boldText'):
        assert token in main


def test_biometric_login_requires_system_prompt_and_active_local_account():
    main = MAIN.read_text(encoding="utf-8")
    auth = AUTH.read_text(encoding="utf-8")
    assert 'BiometricLogin.authenticate' in main
    assert 'BiometricLogin.isAvailable' in main
    assert 'onBiometricLogin(biometricPrefs.biometricUserId!!)' in main
    assert 'fun loginWithBiometric(userId: String)' in auth
    assert 'WHERE id=? LIMIT 1' in auth and 'cursor.getInt(3) != 1' in auth


def test_settings_are_device_local_and_do_not_change_family_database_schema():
    source = PREFS.read_text(encoding="utf-8")
    assert 'getSharedPreferences("amlakna_ui_preferences"' in source
    assert 'never stored in the family database' in source


def test_settings_screen_is_scrollable_and_has_preview_and_reset():
    main = MAIN.read_text(encoding="utf-8")
    assert 'modifier.fillMaxSize().verticalScroll(rememberScrollState())' in main
    assert 'معاينة الخط العربي' in main
    assert 'استعادة إعدادات العرض الافتراضية' in main
    assert 'prefs.copy(palette = "classic", font = "sans", fontScale = 1.0f, boldText = false)' in main


def test_excel_validation_displays_every_issue_without_truncation():
    main = MAIN.read_text(encoding="utf-8")
    assert 'preview.issues.forEachIndexed' in main
    assert 'preview.issues.take(8)' not in main


def test_imported_initial_rent_is_not_auto_approved():
    repo = (ROOT / "android-app/src/main/java/com/familyproperties/app/PropertyRepository.kt").read_text(encoding="utf-8")
    assert 'put("source_type","import"); put("approval_status","under_review")' in repo


def test_imported_rent_review_is_available_and_audited():
    repo = (ROOT / "android-app/src/main/java/com/familyproperties/app/PropertyRepository.kt").read_text(encoding="utf-8")
    main = MAIN.read_text(encoding="utf-8")
    assert 'fun listImportedRentsUnderReview()' in repo
    assert 'fun reviewImportedRent(id: String, approve: Boolean)' in repo
    assert 'approve_imported_rent' in repo and 'reject_imported_rent' in repo
    assert 'repository.reviewImportedRent(item.id, true)' in main
    assert 'repository.reviewImportedRent(item.id, false)' in main
    assert 'session.isAdministrator, Modifier.padding(padding)' in main
