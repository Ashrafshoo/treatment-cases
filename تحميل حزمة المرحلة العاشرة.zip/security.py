"""Security foundation: password hashing, roles, permissions and opaque sessions.
This module uses a separate authentication database; it never touches medication records.
"""
from __future__ import annotations
import hashlib, hmac, secrets, sqlite3, os, time
from pathlib import Path
from typing import Iterable

PERMISSIONS = {
    'view_search': 'عرض وبحث',
    'add_edit': 'إضافة وتعديل',
    'export_share': 'تصدير ومشاركة',
    'import_excel': 'استيراد Excel',
    'manage_medicines': 'إدارة الأدوية',
    'manage_users': 'إدارة المستخدمين',
}
ROLE_DEFAULTS = {
    'manager': tuple(PERMISSIONS),
    'viewer': ('view_search',),
    'editor': ('view_search', 'add_edit'),
    'exporter': ('view_search', 'export_share'),
    'data_entry': ('view_search', 'add_edit', 'import_excel'),
    'medicine_admin': ('view_search', 'manage_medicines'),
}
ITERATIONS = 310_000

def connect(path):
    p = Path(path); p.parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(str(p), timeout=10)
    c.row_factory = sqlite3.Row
    c.execute('PRAGMA foreign_keys=ON')
    return c

def initialize(path):
    with connect(path) as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS users(
          user_id INTEGER PRIMARY KEY AUTOINCREMENT,
          username TEXT NOT NULL UNIQUE COLLATE NOCASE,
          display_name TEXT NOT NULL,
          password_hash TEXT NOT NULL,
          password_salt TEXT NOT NULL,
          password_iterations INTEGER NOT NULL,
          role TEXT NOT NULL,
          active INTEGER NOT NULL DEFAULT 1,
          created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
          updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS user_permissions(
          user_id INTEGER NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
          permission TEXT NOT NULL,
          allowed INTEGER NOT NULL CHECK(allowed IN (0,1)),
          PRIMARY KEY(user_id,permission)
        );
        CREATE TABLE IF NOT EXISTS sessions(
          token_hash TEXT PRIMARY KEY,
          user_id INTEGER NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
          created_at INTEGER NOT NULL,
          expires_at INTEGER NOT NULL,
          revoked INTEGER NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS security_audit(
          audit_id INTEGER PRIMARY KEY AUTOINCREMENT,
          username TEXT, event TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
          detail TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON sessions(expires_at);
        ''')

def _hash(password: str, salt: bytes, iterations=ITERATIONS):
    return hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, iterations).hex()

def create_user(path, username, display_name, password, role='viewer', permissions: Iterable[str] | None=None):
    username=(username or '').strip()
    if len(username)<3: raise ValueError('اسم المستخدم يجب أن يكون 3 أحرف على الأقل')
    if len(password)<12: raise ValueError('كلمة المرور يجب ألا تقل عن 12 حرفاً')
    if role not in ROLE_DEFAULTS: raise ValueError('الدور غير معروف')
    chosen=set(ROLE_DEFAULTS[role] if permissions is None else permissions)
    if not chosen.issubset(PERMISSIONS): raise ValueError('توجد صلاحية غير معروفة')
    salt=secrets.token_bytes(16)
    digest=_hash(password,salt)
    with connect(path) as c:
        cur=c.execute('INSERT INTO users(username,display_name,password_hash,password_salt,password_iterations,role) VALUES(?,?,?,?,?,?)',
          (username,display_name.strip() or username,digest,salt.hex(),ITERATIONS,role))
        uid=cur.lastrowid
        c.executemany('INSERT INTO user_permissions(user_id,permission,allowed) VALUES(?,?,?)',
          [(uid,p,int(p in chosen)) for p in PERMISSIONS])
        c.execute('INSERT INTO security_audit(username,event,detail) VALUES(?,?,?)',(username,'USER_CREATED',role))
        return uid

def authenticate(path, username, password):
    with connect(path) as c:
        row=c.execute('SELECT * FROM users WHERE username=? COLLATE NOCASE AND active=1',(username.strip(),)).fetchone()
        ok=False
        if row:
            try: salt=bytes.fromhex(row['password_salt'])
            except ValueError: salt=b''
            calculated=_hash(password,salt,row['password_iterations']) if salt else ''
            ok=hmac.compare_digest(calculated,row['password_hash'])
        c.execute('INSERT INTO security_audit(username,event) VALUES(?,?)',(username.strip(),'LOGIN_SUCCESS' if ok else 'LOGIN_FAILED'))
        if not ok:return None
        return {'user_id':row['user_id'],'username':row['username'],'display_name':row['display_name'],'role':row['role']}

def create_session(path, user_id, ttl_seconds=8*60*60, now=None):
    now=int(time.time() if now is None else now)
    token=secrets.token_urlsafe(32)
    digest=hashlib.sha256(token.encode()).hexdigest()
    with connect(path) as c:
        c.execute('INSERT INTO sessions(token_hash,user_id,created_at,expires_at) VALUES(?,?,?,?)',(digest,user_id,now,now+ttl_seconds))
    return token

def validate_session(path, token, now=None):
    if not token:return None
    now=int(time.time() if now is None else now)
    digest=hashlib.sha256(token.encode()).hexdigest()
    with connect(path) as c:
        row=c.execute('''SELECT u.user_id,u.username,u.display_name,u.role FROM sessions s
          JOIN users u ON u.user_id=s.user_id WHERE s.token_hash=? AND s.revoked=0 AND s.expires_at>? AND u.active=1''',(digest,now)).fetchone()
        if not row:return None
        perms=c.execute('SELECT permission FROM user_permissions WHERE user_id=? AND allowed=1',(row['user_id'],)).fetchall()
        result=dict(row); result['permissions']=[r[0] for r in perms]
        return result

def revoke_session(path, token):
    if not token:return
    digest=hashlib.sha256(token.encode()).hexdigest()
    with connect(path) as c:c.execute('UPDATE sessions SET revoked=1 WHERE token_hash=?',(digest,))

def has_permission(user, permission):
    return bool(user and permission in user.get('permissions', []))

if __name__=='__main__':
    import argparse, getpass
    parser=argparse.ArgumentParser(description='إنشاء حساب مدير أول مرة')
    parser.add_argument('--db',default=os.environ.get('MED_AUTH_DB','auth.sqlite3'))
    parser.add_argument('--username',required=True)
    parser.add_argument('--name',default='مدير النظام')
    args=parser.parse_args()
    initialize(args.db)
    pw=getpass.getpass('كلمة مرور المدير (12 حرفاً على الأقل): ')
    confirm=getpass.getpass('أعد كلمة المرور: ')
    if pw!=confirm: raise SystemExit('كلمتا المرور غير متطابقتين')
    create_user(args.db,args.username,args.name,pw,'manager')
    print('تم إنشاء حساب المدير في قاعدة المصادقة المنفصلة.')
