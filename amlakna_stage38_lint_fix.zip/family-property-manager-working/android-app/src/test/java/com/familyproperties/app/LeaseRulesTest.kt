package com.familyproperties.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import java.math.BigDecimal
import java.time.LocalDate

class LeaseRulesTest {
    @Test fun durationIncludesTheStartDay() {
        assertEquals(LocalDate.parse("2027-11-11"), LeaseRules.calculateEndDate(LocalDate.parse("2026-11-12"), 1, "years"))
        assertEquals(LocalDate.parse("2026-11-30"), LeaseRules.calculateEndDate(LocalDate.parse("2026-11-12"), 19, "days"))
    }

    @Test fun arabicDigitsAndLocalDecimalSeparatorAreAccepted() {
        assertEquals(123456L, LeaseRules.egpToMinorUnits("١٬٢٣٤٫٥٦"))
        assertEquals(12550L, LeaseRules.egpToMinorUnits("١٢٥,٥"))
    }

    @Test fun septemberIncreaseIsFixedAndStrictlyAfterLastRentDate() {
        assertEquals(LocalDate.parse("2026-09-01"), LeaseRules.nextIncreaseDate(
            LocalDate.parse("2024-01-01"), LocalDate.parse("2026-02-01"), "fixed_month_day", 9, 1
        ))
        assertEquals(LocalDate.parse("2027-09-01"), LeaseRules.nextIncreaseDate(
            LocalDate.parse("2024-01-01"), LocalDate.parse("2026-09-01"), "fixed_month_day", 9, 1
        ))
    }

    @Test fun anniversaryIncreaseUsesContractStart() {
        assertEquals(LocalDate.parse("2027-03-15"), LeaseRules.nextIncreaseDate(
            LocalDate.parse("2024-03-15"), LocalDate.parse("2026-03-15"), "anniversary", null, null
        ))
        assertNull(LeaseRules.nextIncreaseDate(
            LocalDate.parse("2024-03-15"), LocalDate.parse("2026-03-15"), "none", null, null
        ))
    }

    @Test fun percentageIncreaseRoundsToTheNearestPiastre() {
        assertEquals(28750L, LeaseRules.increasedRentMinor(25000L, BigDecimal("15")))
    }
}
