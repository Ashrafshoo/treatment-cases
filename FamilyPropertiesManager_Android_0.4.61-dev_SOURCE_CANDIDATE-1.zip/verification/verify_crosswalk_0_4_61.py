#!/usr/bin/env python3
"""Validate source receipt crosswalk and historical decisions; never posts payments."""
import csv, sys
p = sys.argv[1] if len(sys.argv) > 1 else "receipt_template_crosswalk_audit_0.4.60.csv"
with open(p, encoding="utf-8-sig", newline="") as f:
    rows = list(csv.DictReader(f))
assert len(rows) == 88, f"expected 88 template rows, got {len(rows)}"
by_id = {r["template_id"]: r for r in rows}
assert len(by_id) == 88
counts = {}
for r in rows: counts[r["crosswalk_status"]] = counts.get(r["crosswalk_status"], 0) + 1
assert counts.get("source_row_direct_match_needs_individual_review") == 71, counts
assert counts.get("exact_4_field_match_to_Q022_needs_individual_unit_review") == 11, counts
assert counts.get("unresolved_blank_or_incomplete_template") == 2, counts
assert counts.get("owner_confirmed_pair_unresolved_individual_receipt_assignment") == 2, counts
assert counts.get("owner_confirmed_current_receipt_match") == 1, counts
assert counts.get("historical_half_year_prior_value_archived_not_current") == 1, counts
for tid in ("T079", "T080"):
    r = by_id[tid]
    assert float(r["receipt_number_in_Q023"]) in (77.0, 78.0)
    assert r["Q023_candidate_unit"] == "U-078; U-079"
    assert "دون تعيين فردي" in r["notes"]
r = by_id["T081"]
assert float(r["receipt_number_in_Q023"]) == 79.0 and r["Q023_candidate_unit"] == "U-080"
assert float(r["Q023_amount"]) == 62.79 and "الجراج" in r["notes"]
r = by_id["T086"]
assert float(r["receipt_number_in_Q023"]) == 84.0 and r["Q023_candidate_unit"] == "U-080"
assert float(r["Q023_amount"]) == 54.6 and "نصف سنوي" in r["notes"]
assert len({r["receipt_number_in_Q023"] for r in rows if r["receipt_number_in_Q023"]}) == 86
assert not any("سداد" in r["Q023_review_action"] and "إثبات" not in r["Q023_review_action"] for r in rows if r["Q023_review_action"])
print("PASS: 88 templates; 71 direct-review + 11 four-field-review + 2 unresolved blanks")
print("PASS: U-078/U-079 safely grouped, with no unsupported individual receipt assignment")
print("PASS: receipt 79 linked to U-080; receipt 84 archived as prior half-year value")
print("PASS: 86 distinct source receipt numbers; no payment/ledger posting approved")
