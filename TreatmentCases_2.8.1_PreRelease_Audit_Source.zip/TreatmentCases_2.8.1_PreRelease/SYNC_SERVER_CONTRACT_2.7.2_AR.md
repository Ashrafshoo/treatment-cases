# عقد خادم المزامنة – 2.7.2-dev

هذه المرحلة تضيف استقبالاً آمناً للتحديثات الواردة مع حفظها محلياً في صندوق مراجعة. لا يطبّق التطبيق السجلات الواردة تلقائياً بعد؛ يجب أن تسبق ذلك مراجعة المستخدم وآلية تطبيق ذرية في إصدار لاحق.

## Push
يبقى `POST /v1/sync/push` كما في عقد 2.7.1.

## Pull
`POST /v1/sync/pull`

Headers: `Authorization: Bearer <device-token>`, `Content-Type: application/json`, `Accept: application/json`.

Request JSON: `{"protocol_version":1,"device_id":"stable-device-uuid","cursor":"opaque-cursor"}`

Response JSON: `{"events":[{"event_id":"uuid","source_device_id":"uuid","entity_type":"case|employee|medicine|strength","entity_id":"uuid","operation":"upsert|delete","base_version":1,"new_version":2,"payload":{}}],"next_cursor":"opaque-cursor"}`

## متطلبات الخادم
- التحقق من الرمز وصلاحية الجهاز والمستخدم والجهة قبل إرجاع أي حدث.
- عزل بيانات كل جهة/حساب وعدم الوثوق بـ device_id وحده.
- إرجاع أحداث متسقة بترتيب ثابت، وعدم تغيير cursor إلا مع ضمان إمكانية استكمال القراءة دون فقد.
- دعم pagination؛ الحد الأقصى للدفعة 500 حدث.
- عدم إرجاع أحداث الجهاز المصدر إليه إلا إذا كان البروتوكول يضمن منع حلقات التكرار.
- جميع عمليات النقل عبر HTTPS.

## ضوابط العميل
- التحقق من نوع السجل والعملية وتسلسل الإصدارات وتكرار معرفات الأحداث وحجم الدفعة.
- تخزين الأحداث الواردة في SQLite مع cursor بعد نجاح التخزين فقط.
- كشف اختلاف إصدار الأساس وتسجيله كتعارض.
- لا يتم تطبيق أو حذف أي سجل أعمال في هذه المرحلة؛ الأحداث الواردة تنتظر المراجعة.
