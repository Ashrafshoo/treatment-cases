from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT / "android-app/src/main/java/com/familyproperties/app/PropertyRepository.kt"


def test_native_repository_supports_core_records():
    source = REPO.read_text(encoding="utf-8")
    for method in ("dashboardStats", "listProperties", "addProperty", "addTenant", "addUnit"):
        assert f"fun {method}" in source


def test_repository_uses_schema_minor_currency_fields():
    source = REPO.read_text(encoding="utf-8")
    schema = (ROOT / "android-app/src/main/assets/database/001_initial_schema.sql").read_text(encoding="utf-8")
    assert "amount_minor" in schema
    assert 'sum(db, "payments", "amount_minor")' in source
    assert "sumActiveExpenses(db)" in source
    assert "FROM expenses WHERE archived_at IS NULL" in source


def test_repository_validates_user_input_and_preserves_fk_errors():
    source = REPO.read_text(encoding="utf-8")
    assert 'require(cleanName.isNotEmpty())' in source
    assert 'require(name.isNotEmpty())' in source
    assert 'db.insertOrThrow' in source
