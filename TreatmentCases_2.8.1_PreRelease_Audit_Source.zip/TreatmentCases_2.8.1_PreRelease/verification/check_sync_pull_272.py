#!/usr/bin/env python3
"""Static + SQLite migration checks for 2.7.2 inbound sync quarantine."""
from pathlib import Path
import sqlite3, tempfile
root=Path(__file__).resolve().parents[1]
transport=(root/'android/app/src/main/java/com/treatmentcases/app/SyncTransport.kt').read_text(encoding='utf-8')
db=(root/'android/app/src/main/java/com/treatmentcases/app/LocalDb.kt').read_text(encoding='utf-8')
ui=(root/'android/app/src/main/java/com/treatmentcases/app/MainActivity.kt').read_text(encoding='utf-8')
gradle=(root/'android/app/build.gradle').read_text(encoding='utf-8')
checks=[
 ('pull endpoint uses HTTPS connection','/v1/sync/pull' in transport and 'HttpsURLConnection' in transport),
 ('bearer authorization required','Authorization","Bearer $bearerToken' in transport),
 ('bounded pull response','take(512*1024)' in transport and 'array.length()<=500' in transport),
 ('entity types allowlisted','type in setOf("case","employee","medicine","strength")' in transport),
 ('operation and version sequence validated','op in setOf("upsert","delete")&&next>base' in transport),
 ('duplicate event IDs rejected','seen.add(eventId)' in transport),
 ('events persisted before cursor advance','db.receiveRemoteSyncEvents(result.events)' in transport and 'putString("pull_cursor",result.nextCursor)' in transport),
 ('incoming events quarantined, not auto-applied','Persist pulled events without applying them' in db and 'apply_state",state' in db),
 ('conflicts stored with remote event reference','put("remote_event_uuid",e.eventId)' in db),
 ('schema version advanced to 11','null,11)' in db),
 ('migration adds inbox payload fields','addColumnIfMissing(db,"sync_inbox","payload_json"' in db),
 ('UI shows inbox review count','syncStats["inbox"]' in ui),
 ('version metadata 2.7.3','versionName \'2.8.1-ui-polish\'' in gradle and 'preview275' in gradle),
]
for name,ok in checks: print(('PASS' if ok else 'FAIL')+': '+name)
assert all(ok for _,ok in checks)
# Simulate the v6 -> v7 additive migration and prove existing business rows remain untouched.
con=sqlite3.connect(':memory:'); cur=con.cursor()
cur.executescript('''CREATE TABLE cases(id INTEGER PRIMARY KEY,name TEXT); INSERT INTO cases VALUES(1,'سجل قائم');
CREATE TABLE employees(id INTEGER PRIMARY KEY,name TEXT); INSERT INTO employees VALUES(1,'عامل قائم');
CREATE TABLE sync_inbox(event_uuid TEXT PRIMARY KEY,source_device_uuid TEXT NOT NULL,received_at TEXT,applied_at TEXT,apply_state TEXT,error_text TEXT);
INSERT INTO sync_inbox(event_uuid,source_device_uuid,apply_state) VALUES('evt-old','device','received');
CREATE TABLE sync_conflicts(conflict_uuid TEXT PRIMARY KEY,entity_type TEXT,entity_uuid TEXT,local_version INTEGER,remote_version INTEGER,local_payload_json TEXT,remote_payload_json TEXT,detected_at TEXT,resolution TEXT,resolved_at TEXT);
''')
for table,col,definition in [('sync_inbox','entity_type',"TEXT DEFAULT ''"),('sync_inbox','entity_uuid',"TEXT DEFAULT ''"),('sync_inbox','operation',"TEXT DEFAULT 'upsert'"),('sync_inbox','base_version','INTEGER NOT NULL DEFAULT 0'),('sync_inbox','remote_version','INTEGER NOT NULL DEFAULT 0'),('sync_inbox','payload_json',"TEXT NOT NULL DEFAULT '{}'"),('sync_conflicts','remote_event_uuid',"TEXT DEFAULT ''")]:
    cur.execute(f'ALTER TABLE {table} ADD COLUMN {col} {definition}')
assert cur.execute('SELECT name FROM cases WHERE id=1').fetchone()==('سجل قائم',)
assert cur.execute('SELECT name FROM employees WHERE id=1').fetchone()==('عامل قائم',)
assert cur.execute('SELECT event_uuid,apply_state,payload_json FROM sync_inbox').fetchone()==('evt-old','received','{}')
print('PASS: SQLite v6->v7 additive migration preserves existing case, employee and inbox rows')
print(f'{len(checks)+1} inbound-sync assertions passed')
