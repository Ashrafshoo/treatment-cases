package com.treatmentcases.app

/** Conservative strength formatting: normalizes spacing/unit case only; never converts units or doses. */
object MedicineStrengthNormalizer {
    fun key(value: String): String = value.trim()
        .lowercase()
        .replace('μ', 'u')
        .replace('µ', 'u')
        .replace(Regex("(?<=\\d),(?=\\d)"), ".")
        .replace(Regex("\\s+"), "")
        .replace("micrograms", "mcg")
        .replace("microgram", "mcg")
        .replace("ug", "mcg")

    fun unique(values: Iterable<String>): List<String> {
        val seen = linkedSetOf<String>()
        return values.map { it.trim() }
            .filter { it.isNotBlank() && !it.contains("يُستكمل") && !it.contains("يستكمل") }
            .filter { seen.add(key(it)) }
    }

    fun isUnitlessNumber(value: String): Boolean = value.trim().matches(Regex("\\d+(?:[.,]\\d+)?"))
}
