import pathlib, sqlite3, unittest
ROOT = pathlib.Path(__file__).resolve().parents[2]
SCHEMA = ROOT / 'app/assets/database/001_initial_schema.sql'
class AppBindingTest(unittest.TestCase):
    def setUp(self):
        self.db = sqlite3.connect(':memory:')
        self.db.execute('PRAGMA foreign_keys=ON')
        for statement in SCHEMA.read_text(encoding='utf-8').split(';'):
            if statement.strip(): self.db.execute(statement)
        for statement in [
            'CREATE INDEX IF NOT EXISTS idx_ownership_property_dates ON ownership_shares(property_id, valid_from, valid_to)',
            'CREATE INDEX IF NOT EXISTS idx_rent_history_lease_dates ON rent_history(lease_id, valid_from, valid_to)',
            'CREATE INDEX IF NOT EXISTS idx_expenses_date ON expenses(expense_date)',
            'CREATE INDEX IF NOT EXISTS idx_payments_period ON payments(period_start, period_end)',
            'CREATE INDEX IF NOT EXISTS idx_documents_entity ON documents(entity_type, entity_id)',
            'CREATE INDEX IF NOT EXISTS idx_units_review ON units(review_status, modified_unreviewed)',
            'CREATE INDEX IF NOT EXISTS idx_properties_review ON properties(review_status, modified_unreviewed)',
            'CREATE INDEX IF NOT EXISTS idx_leases_active ON leases(status, unit_id)',
            "CREATE TRIGGER IF NOT EXISTS approved_receipt_no_update BEFORE UPDATE ON receipts WHEN OLD.approved = 1 BEGIN SELECT RAISE(ABORT, 'approved_receipt_is_immutable'); END",
            "CREATE TRIGGER IF NOT EXISTS approved_receipt_no_delete BEFORE DELETE ON receipts WHEN OLD.approved = 1 BEGIN SELECT RAISE(ABORT, 'approved_receipt_is_immutable'); END",
            "INSERT OR IGNORE INTO schema_migrations(version, name) VALUES (2, 'stage3_integrity_and_history_protection')",
        ]: self.db.execute(statement)
    def test_full_schema_and_fk(self):
        names={r[0] for r in self.db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")}
        self.assertEqual(len(names),21) # 20 business tables + migration ledger
        self.assertEqual(self.db.execute('PRAGMA foreign_key_check').fetchall(),[])
    def test_property_unit_tenant_join(self):
        self.db.execute("INSERT INTO properties(id,name) VALUES('p','Test property')")
        self.db.execute("INSERT INTO tenants(id,full_name) VALUES('t','Test tenant')")
        self.db.execute("INSERT INTO units(id,property_id,unit_number,current_tenant_id) VALUES('u','p','1','t')")
        self.assertEqual(self.db.execute('SELECT p.name,u.unit_number,t.full_name FROM units u JOIN properties p ON p.id=u.property_id LEFT JOIN tenants t ON t.id=u.current_tenant_id').fetchone(),('Test property','1','Test tenant'))
    def test_invalid_tenant_rejected(self):
        self.db.execute("INSERT INTO properties(id,name) VALUES('p','Test property')")
        with self.assertRaises(sqlite3.IntegrityError): self.db.execute("INSERT INTO units(id,property_id,current_tenant_id) VALUES('u','p','missing')")
    def test_approved_receipt_is_immutable(self):
        self.db.execute("INSERT INTO receipts(id,receipt_number,issued_at,amount_minor,approved) VALUES('r','R1','2026-11-09',100,1)")
        with self.assertRaises(sqlite3.IntegrityError): self.db.execute("UPDATE receipts SET amount_minor=200 WHERE id='r'")
if __name__=='__main__': unittest.main(verbosity=2)
