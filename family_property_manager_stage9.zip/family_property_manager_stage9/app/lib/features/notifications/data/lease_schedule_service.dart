import 'dart:convert';
import 'package:sqflite_sqlcipher/sqflite.dart';
import '../../../core/database/app_database.dart';
import '../../auth/data/app_session.dart';

/// Schedules contract reminders and rent increases from the approved rent history.
/// The residential Law 164 September rule follows the user's configured 15% rule.
/// Other annual increases remain proposals until the administrator approves them.
class LeaseScheduleService {
  Future<Database> get _db async => AppDatabase.instance.database;
  String _id() => DateTime.now().microsecondsSinceEpoch.toString();
  String _date(DateTime d) => '${d.year.toString().padLeft(4,'0')}-${d.month.toString().padLeft(2,'0')}-${d.day.toString().padLeft(2,'0')}';
  DateTime _dateFor(int year,int month,int day) {
    final first=DateTime(year,month,1);
    final last=DateTime(first.year,first.month+1,0).day;
    return DateTime(year,month,day>last?last:day);
  }

  Future<void> _reminder(DatabaseExecutor tx,{required String leaseId,required String type,required DateTime due,required int lead}) async {
    final dueText=_date(due);
    final existing=await tx.query('notifications',where:'entity_type=? AND entity_id=? AND notification_type=? AND due_at=? AND remind_days_before=?',whereArgs:['lease',leaseId,type,dueText,lead],limit:1);
    if(existing.isEmpty) await tx.insert('notifications',{'id':_id(),'entity_type':'lease','entity_id':leaseId,'notification_type':type,'due_at':dueText,'remind_days_before':lead});
  }

  Future<Map<String,int>> refresh({DateTime? asOf}) async {
    AppSession.instance.requireAdmin();
    final now=asOf??DateTime.now();
    final today=DateTime(now.year,now.month,now.day);
    final db=await _db;
    var reminders=0,applied=0,proposed=0;
    await db.transaction((tx) async {
      final leases=await tx.rawQuery('''SELECT l.*,u.unit_type,
        COALESCE(l.manual_end_date,l.calculated_end_date) AS effective_end
        FROM leases l JOIN units u ON u.id=l.unit_id
        WHERE l.archived_at IS NULL AND l.status IN ('active','ending_soon','open_ended')''');
      for(final lease in leases){
        final leaseId=lease['id'] as String;
        final endText=lease['effective_end'] as String?;
        if(endText!=null){
          final end=DateTime.tryParse(endText);
          if(end!=null){
            final days=end.difference(today).inDays;
            if(days>=0){
              for(final lead in const [90,60,30,15,7]){
                final before=await tx.query('notifications',where:'entity_type=? AND entity_id=? AND notification_type=? AND due_at=? AND remind_days_before=?',whereArgs:['lease',leaseId,'lease_end',endText,lead],limit:1);
                if(before.isEmpty){await _reminder(tx,leaseId:leaseId,type:'lease_end',due:end,lead:lead);reminders++;}
              }
            }
            if(days<0&&lease['status']=='active') await tx.update('leases',{'status':'ended','updated_at':DateTime.now().toIso8601String()},where:'id=?',whereArgs:[leaseId]);
            if(days>=0&&days<=90&&lease['status']=='active') await tx.update('leases',{'status':'ending_soon','updated_at':DateTime.now().toIso8601String()},where:'id=?',whereArgs:[leaseId]);
          }
        }

        final unitType=(lease['unit_type'] as String? ?? '').toLowerCase();
        final residential=unitType.contains('سكن')||unitType.contains('شقة')||unitType.contains('residential');
        final law164=(lease['law_164_2025_applies'] as num?)?.toInt()==1;
        final automaticLaw164=law164&&residential;
        final rule=lease['increase_rule'] as String? ?? 'none';
        final percent=automaticLaw164?15.0:(lease['annual_increase_percent'] as num?)?.toDouble();
        // Law 164 residential increases are a distinct statutory schedule;
        // a generic lease rule of 'none' or 'manual_dates' must not disable it.
        if(percent==null||percent<=0||(!automaticLaw164&&(rule=='none'||rule=='manual_dates')))continue;
        final start=DateTime.tryParse(lease['start_date'] as String? ?? '');
        if(start==null)continue;
        final history=await tx.query('rent_history',columns:['id','valid_from','amount_minor'],where:'lease_id=? AND approval_status=?',whereArgs:[leaseId,'approved'],orderBy:'valid_from DESC',limit:1);
        if(history.isEmpty)continue;
        var currentHistoryId=history.first['id'] as String;
        var lastDate=DateTime.tryParse(history.first['valid_from'] as String? ?? '')??start;
        var lastAmount=(history.first['amount_minor'] as num).toInt();
        final month=automaticLaw164?9:(rule=='fixed_month_day'?((lease['increase_month'] as num?)?.toInt()??start.month):start.month);
        final day=automaticLaw164?1:(rule=='fixed_month_day'?((lease['increase_day'] as num?)?.toInt()??start.day):start.day);
        var due=_dateFor(lastDate.year,month,day);
        if(!due.isAfter(lastDate))due=_dateFor(lastDate.year+1,month,day);
        final daysToIncrease=due.difference(today).inDays;
        if(daysToIncrease>=0){
          for(final lead in const [90,60,30,15,7]){
            final before=await tx.query('notifications',where:'entity_type=? AND entity_id=? AND notification_type=? AND due_at=? AND remind_days_before=?',whereArgs:['lease',leaseId,'rent_increase',_date(due),lead],limit:1);
            if(before.isEmpty){await _reminder(tx,leaseId:leaseId,type:'rent_increase',due:due,lead:lead);reminders++;}
          }
        }
        if(due.isAfter(today)&&!automaticLaw164)continue;

        if(automaticLaw164){
          var safety=0;
          while(!due.isAfter(today)&&safety<8){
            safety++;
            final dueText=_date(due);
            final existing=await tx.query('rent_increases',where:'lease_id=? AND effective_date=? AND status IN (?,?)',whereArgs:[leaseId,dueText,'approved','applied'],limit:1);
            final increaseId=existing.isEmpty?_id():existing.first['id'] as String;
            final newAmount=existing.isEmpty?(lastAmount*(1+percent/100)).round():(existing.first['new_rent_minor'] as num).toInt();
            if(existing.isEmpty){
              await tx.insert('rent_increases',{'id':increaseId,'lease_id':leaseId,'effective_date':dueText,'percentage':percent,'previous_rent_minor':lastAmount,'new_rent_minor':newAmount,'calculation_method':'percentage','status':'approved','notes':'زيادة سبتمبر السكنية مجدولة وفق إعداد المستخدم'});
            }
            final alreadyApplied=existing.isNotEmpty&&existing.first['status']=='applied';
            if(!alreadyApplied){
              await tx.update('rent_history',{'valid_to':_date(due.subtract(const Duration(days:1)))},where:'id=?',whereArgs:[currentHistoryId]);
              final newHistoryId=_id();
              await tx.insert('rent_history',{'id':newHistoryId,'lease_id':leaseId,'amount_minor':newAmount,'currency_code':'EGP','valid_from':dueText,'source_type':'increase','source_id':increaseId,'approval_status':'approved'});
              await tx.update('rent_increases',{'status':'applied'},where:'id=?',whereArgs:[increaseId]);
              await tx.insert('audit_log',{'id':_id(),'user_id':AppSession.instance.userId,'entity_type':'rent_increase','entity_id':increaseId,'action':'update','after_json':jsonEncode({'effective_date':dueText,'previous_rent_minor':lastAmount,'new_rent_minor':newAmount,'automatic_law164':true})});
              currentHistoryId=newHistoryId;applied++;
            }
            lastAmount=newAmount;
            lastDate=due;
            due=_dateFor(lastDate.year+1,month,day);
          }
          // Keep a six-year forward schedule; future rows are pre-approved but
          // only become effective and enter rent_history on their due date.
          var plannedDate=_dateFor(lastDate.year+1,month,day);
          var plannedRent=lastAmount;
          for(var year=0;year<6;year++){
            final plannedText=_date(plannedDate);
            final planned=await tx.query('rent_increases',where:'lease_id=? AND effective_date=? AND status IN (?,?,?)',whereArgs:[leaseId,plannedText,'approved','applied','proposed'],limit:1);
            if(planned.isNotEmpty){
              plannedRent=(planned.first['new_rent_minor'] as num?)?.toInt()??plannedRent;
            }else{
              final nextRent=(plannedRent*(1+percent/100)).round();
              await tx.insert('rent_increases',{'id':_id(),'lease_id':leaseId,'effective_date':plannedText,'percentage':percent,'previous_rent_minor':plannedRent,'new_rent_minor':nextRent,'calculation_method':'percentage','status':'approved','notes':'زيادة مستقبلية مجدولة ضمن خطة الست سنوات'});
              plannedRent=nextRent;
            }
            for(final lead in const [90,60,30,15,7]){
              final before=await tx.query('notifications',where:'entity_type=? AND entity_id=? AND notification_type=? AND due_at=? AND remind_days_before=?',whereArgs:['lease',leaseId,'rent_increase',plannedText,lead],limit:1);
              if(before.isEmpty){await _reminder(tx,leaseId:leaseId,type:'rent_increase',due:plannedDate,lead:lead);reminders++;}
            }
            plannedDate=_dateFor(plannedDate.year+1,month,day);
          }
        }else{
          final dueText=_date(due);
          final existing=await tx.query('rent_increases',where:'lease_id=? AND effective_date=? AND status IN (?,?)',whereArgs:[leaseId,dueText,'proposed','applied'],limit:1);
          if(existing.isEmpty){
            final newAmount=(lastAmount*(1+percent/100)).round();
            await tx.insert('rent_increases',{'id':_id(),'lease_id':leaseId,'effective_date':dueText,'percentage':percent,'previous_rent_minor':lastAmount,'new_rent_minor':newAmount,'calculation_method':'percentage','status':'proposed','notes':'زيادة سنوية مقترحة لاعتماد المدير'});
            proposed++;
          }
        }
      }
    });
    return {'reminders_created':reminders,'increases_applied':applied,'increases_proposed':proposed};
  }

  Future<List<Map<String,Object?>>> notifications() async => (await _db).rawQuery('''
    SELECT n.*, COALESCE(t.full_name,p.name,l.id) AS label
    FROM notifications n LEFT JOIN leases l ON n.entity_type='lease' AND l.id=n.entity_id
    LEFT JOIN tenants t ON t.id=l.tenant_id LEFT JOIN properties p ON p.id=n.entity_id
    WHERE n.status='pending' ORDER BY n.due_at
  ''');

  Future<List<Map<String,Object?>>> proposedIncreases() async => (await _db).rawQuery('''
    SELECT ri.*,t.full_name,p.name AS property_name,u.unit_number
    FROM rent_increases ri JOIN leases l ON l.id=ri.lease_id JOIN units u ON u.id=l.unit_id
    JOIN properties p ON p.id=u.property_id JOIN tenants t ON t.id=l.tenant_id
    WHERE ri.status='proposed' ORDER BY ri.effective_date
  ''');

  Future<List<Map<String,Object?>>> scheduledIncreases() async => (await _db).rawQuery('''
    SELECT ri.*,t.full_name,p.name AS property_name,u.unit_number
    FROM rent_increases ri JOIN leases l ON l.id=ri.lease_id JOIN units u ON u.id=l.unit_id
    JOIN properties p ON p.id=u.property_id JOIN tenants t ON t.id=l.tenant_id
    WHERE ri.status='approved' AND ri.effective_date>? ORDER BY ri.effective_date
  ''',[ _date(DateTime.now()) ]);

  Future<void> approveIncrease(String increaseId) async {
    AppSession.instance.requireAdmin();
    final db=await _db;
    await db.transaction((tx) async {
      final rows=await tx.query('rent_increases',where:'id=? AND status=?',whereArgs:[increaseId,'proposed'],limit:1);
      if(rows.isEmpty)throw StateError('الزيادة غير موجودة أو سبق اعتمادها');
      final r=rows.first;final leaseId=r['lease_id'] as String;final date=r['effective_date'] as String;
      final prev=(r['previous_rent_minor'] as num).toInt();final next=(r['new_rent_minor'] as num).toInt();
      final active=await tx.query('rent_history',where:'lease_id=? AND approval_status=? AND valid_to IS NULL',whereArgs:[leaseId,'approved'],orderBy:'valid_from DESC',limit:1);
      if(active.isNotEmpty)await tx.update('rent_history',{'valid_to':_date(DateTime.parse(date).subtract(const Duration(days:1)))},where:'id=?',whereArgs:[active.first['id']]);
      await tx.insert('rent_history',{'id':_id(),'lease_id':leaseId,'amount_minor':next,'currency_code':'EGP','valid_from':date,'source_type':'increase','source_id':increaseId,'approval_status':'approved'});
      await tx.update('rent_increases',{'status':'applied'},where:'id=?',whereArgs:[increaseId]);
      await tx.insert('audit_log',{'id':_id(),'user_id':AppSession.instance.userId,'entity_type':'rent_increase','entity_id':increaseId,'action':'approve','before_json':jsonEncode(r),'after_json':jsonEncode({'previous_rent_minor':prev,'new_rent_minor':next,'effective_date':date,'status':'applied'})});
    });
  }
}
