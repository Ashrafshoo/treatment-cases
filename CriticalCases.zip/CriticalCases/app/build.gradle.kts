plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val runNo: Int = (System.getenv("GITHUB_RUN_NUMBER") ?: "0").toIntOrNull() ?: 0
val shaShort: String = (System.getenv("GITHUB_SHA") ?: "local").take(7)
val builtAt: String = java.time.LocalDateTime.now(java.time.ZoneOffset.UTC)
    .format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"))

android {
    namespace = "com.critical.cases"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.critical.cases"
        minSdk = 29
        targetSdk = 34
        versionCode = 200 + runNo
        versionName = "2.0." + runNo
        buildConfigField("String", "BUILD_TIME", "\"" + builtAt + " UTC\"")
        buildConfigField("String", "BUILD_SHA", "\"" + shaShort + "\"")
    }
    signingConfigs {
        create("fixed") {
            storeFile = file("fixed.keystore")
            storePassword = "criticalcases"
            keyAlias = "criticalcases"
            keyPassword = "criticalcases"
            storeType = "pkcs12"
        }
    }
    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("fixed")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("fixed")
        }
    }
    buildFeatures {
        buildConfig = true
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.webkit:webkit:1.11.0")
    implementation("com.google.android.gms:play-services-auth:21.2.0")
}
