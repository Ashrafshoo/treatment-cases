"""تحليل الاسم الأجنبي إلى (عائلة الدواء) + (التركيز/الشكل/العبوة) وتوقيع موحّد لكشف التكرار التقريبي."""
import re

TOK = re.compile(r"\d+(?:[.,]\d+)?(?:/\d+(?:[.,]\d+)?)?|[A-Za-z\u0600-\u06FF]+|%")
SPLIT = re.compile(r"(?<=[A-Za-z\u0600-\u06FF])(?=\d)|(?<=\d)(?=[A-Za-z\u0600-\u06FF])")

SYN = {  # توحيد المرادفات (للتوقيع فقط)
    "CAPS": "CAP", "CAPSULE": "CAP", "CAPSULES": "CAP", "CAPSULS": "CAP", "CAPS.": "CAP",
    "TABS": "TAB", "TABLET": "TAB", "TABLETS": "TAB", "TABLE": "TAB",
    "AMPS": "AMP", "AMPOULE": "AMP", "AMPOULES": "AMP", "AMPULE": "AMP", "AMPULES": "AMP",
    "VIALS": "VIAL", "SUPPS": "SUPP", "SUPPOSITORY": "SUPP", "SUPPOSITORIES": "SUPP",
    "SYP": "SYRUP", "SYR": "SYRUP", "SUSPENSION": "SUSP", "SOLUTION": "SOL", "SOLN": "SOL",
    "OINTMENT": "OINT", "SACHETS": "SACHET", "SACH": "SACHET", "DROP": "DROPS",
    "MGM": "MG", "MILLIGRAM": "MG", "GRAM": "GM", "G": "GM", "GR": "GM", "GMS": "GM", "CC": "ML",
    "INJECTION": "INJ", "INJECTABLE": "INJ", "AMPOLE": "AMP",
}
UNITS = {"MG", "MCG", "UG", "GM", "ML", "IU", "KG", "L", "CM", "MM", "MEQ", "DOSE", "%", "U"}
FORMS = {"TAB", "CAP", "AMP", "VIAL", "SYRUP", "SUSP", "SOL", "CREAM", "GEL", "OINT", "LOTION", "DROPS",
         "SUPP", "SACHET", "SPRAY", "SHAMPOO", "POWDER", "INJ", "EYE", "EAR", "NASAL", "INHALER", "LOZENGES",
         "OIL", "SOAP", "WASH", "PATCH", "EMULSION", "ENEMA", "GRANULES", "FOAM", "SERUM", "MOUTHWASH"}
NOISE = {"FC", "FILM", "COATED", "THE", "OF", "AND", ""}
FC_RE = re.compile(r"\bF\s*\.?\s*C\s*\.?(?=\s|$)", re.I)


def tokens(name: str):
    name = FC_RE.sub(" FC ", name or "")
    name = SPLIT.sub(" ", name)
    out = []
    for t in TOK.findall(name):
        u = t.upper()
        u = SYN.get(u, u)
        if u[0].isdigit():
            u = u.replace(",", ".")
            if "/" not in u and "." in u:
                u = u.rstrip("0").rstrip(".")
        out.append(u)
    return out


def split_family(name: str):
    """يعيد (family, variant). العائلة = كل ما قبل أول رقم/وحدة/شكل/قوس (المادة الفعّالة بين قوسين تذهب للتفاصيل)."""
    raw = name or ""
    head = raw.split("(")[0]
    base = head if head.strip() else raw
    t = tokens(base)
    cut = len(t)
    lead = 0
    while lead < len(t) and t[lead][0].isdigit():
        lead += 1
    start = lead if (lead and lead < len(t) and t[lead] not in UNITS and t[lead] not in FORMS) else 0
    for i in range(start, len(t)):
        u = t[i]
        if (i >= start and (u[0].isdigit() or u in UNITS or u in FORMS) and i != 0) or (i == 0 and (u in UNITS or u in FORMS)):
            cut = i
            break
    # أحرف مفردة تسبق الشكل (E. DROP / N. SPRAY) تنتمي للشكل
    while cut > 1 and cut < len(t) and t[cut] in FORMS and len(t[cut - 1]) == 1 and t[cut - 1].isalpha():
        cut -= 1
    full = tokens(raw)
    fam = [x for x in t[:cut] if x not in NOISE]
    var = [x for x in full[cut:] if x not in NOISE]
    return " ".join(fam).strip(), " ".join(var).strip()


def signature(name: str) -> str:
    return " ".join(x for x in tokens(name) if x not in NOISE)
