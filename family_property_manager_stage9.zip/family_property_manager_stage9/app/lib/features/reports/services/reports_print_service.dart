import 'package:flutter/services.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import '../../../core/database/app_database.dart';
import '../../auth/data/app_session.dart';
import '../data/reports_repository.dart';

class ReportsPrintService {
  Future<void> printMonthlyStatement(DateTime month) async {
    AppSession.instance.requireAdmin();
    final repo=ReportsRepository();
    final start=DateTime(month.year,month.month,1);
    final end=DateTime(month.year,month.month+1,0);
    final rows=await repo.monthlyRentStatement(month);
    final db=await AppDatabase.instance.database;
    final collectedRows=await db.rawQuery('SELECT COALESCE(SUM(amount_minor),0) AS total FROM payments WHERE paid_at BETWEEN ? AND ?',[ _date(start),_date(end) ]);
    final collected=(collectedRows.first['total'] as num).toInt();
    final due=rows.fold<int>(0,(sum,r)=>sum+(r['due_minor'] as num).toInt());
    final paid=rows.fold<int>(0,(sum,r)=>sum+(r['paid_minor'] as num).toInt());
    final remaining=due>paid?due-paid:0;
    final groups=<String,List<Map<String,Object?>>>{};
    for(final row in rows){groups.putIfAbsent(row['property_name']?.toString()??'عقار غير محدد',()=>[]).add(row);}
    final font=pw.Font.ttf(await rootBundle.load('assets/fonts/NotoSansArabic-Regular.ttf'));
    final bold=pw.Font.ttf(await rootBundle.load('assets/fonts/NotoSansArabic-Regular.ttf'));
    final doc=pw.Document();
    doc.addPage(pw.MultiPage(
      pageFormat:PdfPageFormat.a4,
      margin:const pw.EdgeInsets.all(28),
      header:(context)=>pw.Directionality(textDirection:pw.TextDirection.rtl,child:pw.Container(alignment:pw.Alignment.centerRight,child:pw.Text('إدارة أملاك العائلة',style:pw.TextStyle(font:font,fontSize:10)))),
      footer:(context)=>pw.Directionality(textDirection:pw.TextDirection.rtl,child:pw.Align(alignment:pw.Alignment.center,child:pw.Text('صفحة ${context.pageNumber} من ${context.pagesCount}',style:pw.TextStyle(font:font,fontSize:8)))),
      build:(context)=>[
        pw.Directionality(textDirection:pw.TextDirection.rtl,child:pw.Text('كشف الإيجارات الشهري المجمع',style:pw.TextStyle(font:bold,fontSize:18,fontWeight:pw.FontWeight.bold))),
        pw.Directionality(textDirection:pw.TextDirection.rtl,child:pw.Text('عن شهر ${month.month}/${month.year}',style:pw.TextStyle(font:font,fontSize:11))),
        pw.SizedBox(height:12),
        pw.Directionality(textDirection:pw.TextDirection.rtl,child:pw.Table(border:pw.TableBorder.all(color:PdfColors.grey500),children:[
          _summaryRow(font,'إجمالي المستحق',_money(due),'إجمالي المحصل',_money(paid)),
          _summaryRow(font,'المتبقي',_money(remaining),'التحصيلات المسجلة',_money(collected)),
        ])),
        pw.SizedBox(height:14),
        if(rows.isEmpty)pw.Directionality(textDirection:pw.TextDirection.rtl,child:pw.Text('لا توجد عقود نشطة في هذه الفترة.',style:pw.TextStyle(font:font,fontSize:11))),
        for(final entry in groups.entries)...[
          pw.Directionality(textDirection:pw.TextDirection.rtl,child:pw.Container(color:PdfColors.grey300,padding:const pw.EdgeInsets.all(6),child:pw.Text(entry.key,style:pw.TextStyle(font:font,fontSize:12,fontWeight:pw.FontWeight.bold)))),
          pw.Directionality(textDirection:pw.TextDirection.rtl,child:pw.Table(border:pw.TableBorder.all(color:PdfColors.grey500),columnWidths:{0:const pw.FlexColumnWidth(3),1:const pw.FlexColumnWidth(1.5),2:const pw.FlexColumnWidth(1.5),3:const pw.FlexColumnWidth(1.5)},children:[
            pw.TableRow(decoration:const pw.BoxDecoration(color:PdfColors.grey200),children:[_cell(font,'المستأجر',true),_cell(font,'الوحدة',true),_cell(font,'المستحق',true),_cell(font,'المحصل',true)]),
            ...entry.value.map((r)=>pw.TableRow(children:[_cell(font,'${r['tenant_name']}'),_cell(font,'${r['unit_number']??'—'}'),_cell(font,_money((r['due_minor'] as num).toInt())),_cell(font,_money((r['paid_minor'] as num).toInt()))])),
          ])),
          pw.SizedBox(height:10),
        ],
      ],
    ));
    await Printing.layoutPdf(onLayout:(format)async=>doc.save(),name:'monthly_rent_statement_${month.year}_${month.month}.pdf');
  }

  pw.TableRow _summaryRow(pw.Font font,String a,String b,String c,String d)=>pw.TableRow(children:[_cell(font,a,true),_cell(font,b),_cell(font,c,true),_cell(font,d)]);
  pw.Widget _cell(pw.Font font,String value,[bool bold=false])=>pw.Padding(padding:const pw.EdgeInsets.all(5),child:pw.Text(value,style:pw.TextStyle(font:font,fontSize:9,fontWeight:bold?pw.FontWeight.bold:pw.FontWeight.normal),textAlign:pw.TextAlign.right));
  String _money(int minor)=>'${(minor/100).toStringAsFixed(2)} ج.م';
  String _date(DateTime d)=>'${d.year.toString().padLeft(4,'0')}-${d.month.toString().padLeft(2,'0')}-${d.day.toString().padLeft(2,'0')}';
}
