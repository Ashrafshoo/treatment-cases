package com.treatmentcases.app

fun main() {
    var checks = 0
    fun expect(value: Boolean, label: String) { check(value) { "FAILED: $label" }; checks++ }
    val names = listOf("OFEV", "LEQVIO", "Zoledronic acid", "دواء تجريبي")
    expect(MedicineNameMatcher.match("ofev", names).type == MedicineNameMatchType.EXACT, "case-only variation is exact match")
    expect(MedicineNameMatcher.match("O-F-E-V", names).canonicalName == "OFEV", "punctuation-only variation is normalized")
    expect(MedicineNameMatcher.match("Zoledronic-acid", names).canonicalName == "Zoledronic acid", "separator variation is normalized")
    expect(MedicineNameMatcher.match("دواء  تجريبي", names).canonicalName == "دواء تجريبي", "Arabic whitespace variation is normalized")
    expect(MedicineNameMatcher.match("دواء تجريبى", names).canonicalName == "دواء تجريبي", "Arabic ya variation is normalized")
    val fuzzy = MedicineNameMatcher.match("LEQVlO", names)
    expect(fuzzy.type == MedicineNameMatchType.SUGGESTION && fuzzy.canonicalName == "LEQVIO", "one-character typo is suggested, not auto-merged")
    expect(MedicineNameMatcher.match("BrandNewDrug", names).type == MedicineNameMatchType.NEW, "unrelated name is new")
    val alias = MedicineNameMatcher.match("Brand X", names, mapOf("Brand X" to "OFEV"))
    expect(alias.canonicalName == "OFEV" && alias.type == MedicineNameMatchType.NORMALIZED, "known alias resolves to canonical name")
    val realAlias = MedicineNameMatcher.match("Xelganz", listOf("XELJANZ"), mapOf("Xelganz" to "XELJANZ"))
    expect(realAlias.canonicalName == "XELJANZ" && realAlias.type == MedicineNameMatchType.NORMALIZED, "verified spelling alias resolves to XELJANZ")
    expect(MedicineNameMatcher.match("CINRYZE", listOf("CINRYZE"), mapOf("CINRYSE" to "CINRYZE")).canonicalName == "CINRYZE", "verified CINRYSE spelling alias resolves to CINRYZE")
    val ambiguousNames = listOf("NEORAL", "STELARA", "OLUMIANT")
    expect(MedicineNameMatcher.match("NECORUL", ambiguousNames).type == MedicineNameMatchType.SUGGESTION, "ambiguous NECORUL is quarantined for package review")
    expect(MedicineNameMatcher.match("stelorago", ambiguousNames).type == MedicineNameMatchType.SUGGESTION, "ambiguous stelorago is quarantined for package review")
    expect(MedicineNameMatcher.match("Hydra", ambiguousNames).type == MedicineNameMatchType.SUGGESTION, "ambiguous Hydra is quarantined for package review")
    expect(MedicineNameMatcher.match("factor", ambiguousNames).type == MedicineNameMatchType.SUGGESTION, "ambiguous factor is quarantined for package review")
    expect(MedicineNameMatcher.match("Baraitava", ambiguousNames).type == MedicineNameMatchType.SUGGESTION, "unapproved Baraitava remains quarantined")
    val approvedBaritava = MedicineNameMatcher.match("Baraitava", listOf("BARITAVA"), mapOf("Baraitava" to "BARITAVA"))
    expect(approvedBaritava.canonicalName == "BARITAVA" && approvedBaritava.type == MedicineNameMatchType.NORMALIZED, "approved Baraitava alias resolves to BARITAVA before quarantine")
    val approvedRecormon = MedicineNameMatcher.match("recorman", listOf("RECORMON"), mapOf("recorman" to "RECORMON"))
    expect(approvedRecormon.canonicalName == "RECORMON" && approvedRecormon.type == MedicineNameMatchType.NORMALIZED, "approved recorman alias resolves to RECORMON")
    expect(MedicineNameMatcher.match("Prefillro", names).type == MedicineNameMatchType.SUGGESTION, "unverified Prefillro is quarantined")
    expect(MedicineNameMatcher.match("Perdeferx", names).type == MedicineNameMatchType.SUGGESTION, "unverified Perdeferx remains a suggestion")
    println("PASS: $checks medicine-name matching assertions")
}
