package com.example.rentals.ui

import android.content.Context

data class UiSettings(val dark:Boolean=false,val fontScale:Float=1f,val fontFamily:String="sans",val accent:String="teal",val compact:Boolean=false,val aiConsent:Boolean=false,val receiptsPerPage:Int=3,val marginMm:Float=5f,val lockOnBackground:Boolean=true)
class SettingsStore(context:Context){
 private val p=context.getSharedPreferences("ui_settings",Context.MODE_PRIVATE)
 fun read()=UiSettings(p.getBoolean("dark",false),p.getFloat("fontScale",1f),p.getString("fontFamily","sans")?:"sans",p.getString("accent","teal")?:"teal",p.getBoolean("compact",false),p.getBoolean("aiConsent",false),p.getInt("receiptsPerPage",3),p.getFloat("marginMm",5f),p.getBoolean("lockOnBackground",true))
 fun save(s:UiSettings){p.edit().putBoolean("dark",s.dark).putFloat("fontScale",s.fontScale).putString("fontFamily",s.fontFamily).putString("accent",s.accent).putBoolean("compact",s.compact).putBoolean("aiConsent",s.aiConsent).putInt("receiptsPerPage",s.receiptsPerPage).putFloat("marginMm",s.marginMm).putBoolean("lockOnBackground",s.lockOnBackground).apply()}
}
