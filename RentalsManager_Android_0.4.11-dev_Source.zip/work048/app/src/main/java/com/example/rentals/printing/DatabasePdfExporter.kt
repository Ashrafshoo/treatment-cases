package com.example.rentals.printing

import android.content.ContentResolver
import android.database.sqlite.SQLiteDatabase
import android.graphics.Paint
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.graphics.pdf.PdfDocument
import android.net.Uri

/** Generates a searchable-text PDF summary for all non-internal database tables. */
object DatabasePdfExporter {
    fun export(resolver: ContentResolver, uri: Uri, database: SQLiteDatabase) {
        val pdf = PdfDocument()
        val pageWidth = 595; val pageHeight = 842; val margin =  thirty
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 9f; typeface = Typeface.create("sans-serif", Typeface.NORMAL) }
        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 15f; typeface = Typeface.create("sans-serif", Typeface.BOLD) }
        var pageNo = 0; var page: PdfDocument.Page? = null; var canvas: android.graphics.Canvas? = null; var y = 0f
        fun drawRtl(text:String, p:TextPaint):Int { val c=canvas ?: return 0; val layout=StaticLayout.Builder.obtain(text,0,text.length,p,pageWidth-2*margin).setAlignment(Layout.Alignment.ALIGN_OPPOSITE).setTextDirection(TextDirectionHeuristics.RTL).setIncludePad(false).build(); c.save();c.translate(margin.toFloat(),y);layout.draw(c);c.restore();return layout.height }
        fun newPage() { page?.let { pdf.finishPage(it) }; pageNo++; page = pdf.startPage(PdfDocument.PageInfo.Builder(pageWidth,pageHeight,pageNo).create()); canvas=page!!.canvas; y=margin.toFloat(); y+=drawRtl("تقرير بيانات نظام إدارة الإيجارات",titlePaint)+12f }
        fun line(text:String, bold:Boolean=false) { if(page==null || y>pageHeight-margin){newPage()}; val p=if(bold) titlePaint else paint; val safe=text.replace("\n"," ").take(220); y+=drawRtl(safe,p)+if(bold)8f else 4f }
        newPage()
        database.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name",null).use { tables ->
            while(tables.moveToNext()) {
                val table=tables.getString(0); if(!table.matches(Regex("[A-Za-z0-9_]+"))) continue
                line("الجدول: $table",true)
                database.rawQuery("SELECT * FROM `$table`",null).use { c ->
                    line((0 until c.columnCount).joinToString(" | "){c.getColumnName(it)})
                    var count=0
                    while(c.moveToNext()) {
                        val values=(0 until c.columnCount).map { i -> if(c.isNull(i)) "—" else (c.getString(i) ?: "").replace("|","/") }
                        line(values.joinToString(" | ").take(115)); count++
                    }
                    if(count==0) line("لا توجد سجلات")
                }
                y+=8f
            }
        }
        page?.let { pdf.finishPage(it) }
        resolver.openOutputStream(uri,"w")!!.use { pdf.writeTo(it) }
        pdf.close()
    }

    /** Exports focused financial/operational reports using fixed, reviewed SQL statements. */
    fun exportReport(resolver: ContentResolver, uri: Uri, database: SQLiteDatabase, report: String, periodFilter: String = "", heirFilter: String = "") {
        val spec = when (report) {
            "units" -> Triple("كشف الوحدات والمستأجرين", "SELECT code AS 'كود الوحدة',property AS 'العقار',tenant AS 'المستأجر',unit_type AS 'النوع',rent AS 'الإيجار',status AS 'الحالة',notes AS 'ملاحظات' FROM units ORDER BY code", "الوحدات")
            "receipts" -> Triple("تقرير الإيصالات", "SELECT receipt_no AS 'رقم الإيصال',unit_code AS 'الوحدة',tenant AS 'المستأجر',amount AS 'المبلغ',paid_date AS 'تاريخ السداد',period AS 'الفترة',status AS 'الحالة',notes AS 'ملاحظات' FROM receipts ORDER BY period DESC,unit_code", "الإيصالات")
            "ledger" -> Triple("كشف حركة الحسابات", "SELECT entry_date AS 'التاريخ',period AS 'الفترة',unit_code AS 'الوحدة',tenant AS 'الاسم',entry_type AS 'نوع الحركة',debit AS 'مدين',credit AS 'دائن',receipt_no AS 'رقم الإيصال',notes AS 'ملاحظات' FROM ledger ORDER BY entry_date, id", "دفتر الحسابات")
            "expenses" -> Triple("تقرير المصروفات", "SELECT expense_date AS 'التاريخ',period AS 'الفترة',title AS 'البيان',category AS 'التصنيف',amount AS 'المبلغ',notes AS 'ملاحظات' FROM expenses ORDER BY expense_date DESC,id DESC", "المصروفات")
            "collections" -> Triple("تقرير استلامات المحصّل", "SELECT collector AS 'المحصّل',received_date AS 'تاريخ الاستلام',period AS 'الفترة',amount AS 'المبلغ المستلم',method AS 'طريقة الاستلام',expenses AS 'المصروفات',handed_over AS 'الموزع',remaining AS 'المتبقي',notes AS 'ملاحظات' FROM collection_batches ORDER BY received_date DESC,id DESC", "استلامات المحصّل")
            "heirs" -> Triple("تقرير أنصبة وتوزيعات الورثة", "SELECT h.name AS 'الوارث',h.share_numerator AS 'البسط',h.share_denominator AS 'المقام',p.amount AS 'مبلغ التوزيع الفعلي',p.pay_date AS 'تاريخ الدفع',p.method AS 'طريقة الدفع',p.period AS 'الفترة',p.notes AS 'ملاحظات' FROM heirs h LEFT JOIN heir_payouts p ON p.heir_id=h.id ORDER BY h.id,p.pay_date DESC", "الورثة والتوزيعات الفعلية")
            "financial" -> Triple("كشف الحركة المالية الموحد", """SELECT * FROM (
                SELECT entry_date AS 'التاريخ',period AS 'الفترة','دفتر الحسابات' AS 'المصدر',COALESCE(unit_code,'')||' / '||COALESCE(tenant,'')||' / '||COALESCE(entry_type,'') AS 'البيان',debit AS 'مدين/خصم',credit AS 'دائن/تحصيل',COALESCE(collector_method,'') AS 'الوسيلة',COALESCE(notes,'') AS 'ملاحظات' FROM ledger
                UNION ALL SELECT collected_date,period,'مبالغ لدى المحصل',collector||' — تحصيل لدى المحصل',0,amount,'',COALESCE(notes,'')||' — المسلّم: '||COALESCE(handed_over,0)||' — المتبقي لدى المحصل: '||COALESCE(balance,0) FROM collector_receivables
                UNION ALL SELECT received_date,period,'استلام من المحصل',COALESCE(collector,'')||' — إجمالي الاستلام',expenses,amount,'طريقة الاستلام: '||COALESCE(method,''),COALESCE(notes,'')||' — المتبقي غير الموزع: '||COALESCE(remaining,0) FROM collection_batches
                UNION ALL SELECT expense_date,period,'مصروف مباشر',COALESCE(title,'')||' — '||COALESCE(category,''),amount,0,'',COALESCE(notes,'') FROM expenses
                UNION ALL SELECT p.pay_date,p.period,'دفعة وارث',COALESCE(h.name,'')||' — توزيع فعلي',p.amount,0,COALESCE(p.method,''),COALESCE(p.notes,'') FROM heir_payouts p LEFT JOIN heirs h ON h.id=p.heir_id
            ) ORDER BY 1,3""", "كل مصادر الحركة المالية؛ المصروفات المخصومة داخل استلام المحصل تظهر ضمن سجل الاستلام ولا تكرر كسجل مصروف مباشر")
            "heir_statement" -> Triple("كشف حساب الورثة — الدفعات الفعلية", "SELECT h.name AS 'الوارث',p.pay_date AS 'تاريخ الدفع',p.period AS 'الفترة',p.amount AS 'المبلغ المدفوع فعليًا',p.method AS 'وسيلة الدفع',p.notes AS 'ملاحظات' FROM heir_payouts p JOIN heirs h ON h.id=p.heir_id ORDER BY h.name,p.pay_date,p.id", "لا يحتسب هذا الكشف مستحقات تقديرية؛ يعرض الدفعات المسجلة فعليًا فقط")
            else -> throw IllegalArgumentException("نوع التقرير غير معروف")
        }
        val periodAware = report in setOf("receipts", "ledger", "expenses", "collections", "heirs", "financial", "heir_statement")
        val filter = periodFilter.trim()
        require(filter.isEmpty() || filter == "غير محددة" || filter.matches(Regex("\\d{4}")) || runCatching { java.time.YearMonth.parse(filter) }.isSuccess) { "الفترة: اكتب سنة صحيحة YYYY أو شهرًا صحيحًا YYYY-MM أو غير محددة" }
        val filters = mutableListOf<String>()
        val args = mutableListOf<String>()
        if (periodAware && filter.isNotEmpty()) {
            if (filter == "غير محددة") filters += "(\"الفترة\" IS NULL OR \"الفترة\"='')"
            else { filters += "substr(COALESCE(\"الفترة\",''),1, length(?)) = ?"; args += filter; args += filter }
        }
        val selectedHeir = heirFilter.trim()
        if (report == "heir_statement" && selectedHeir.isNotEmpty()) {
            filters += "\"الوارث\" = ?"
            args += selectedHeir
        }
        val filteredSql = if (filters.isEmpty()) spec.second else "SELECT * FROM (${spec.second}) WHERE ${filters.joinToString(" AND ")}"
        val suffix = listOf(filter.takeIf { it.isNotEmpty() }, selectedHeir.takeIf { report == "heir_statement" && it.isNotEmpty() }).filterNotNull().joinToString(" — ")
        exportQuery(resolver, uri, database, spec.first + if (suffix.isNotEmpty()) " — $suffix" else "", filteredSql, spec.third, args.toTypedArray())
    }

    private fun exportQuery(resolver: ContentResolver, uri: Uri, database: SQLiteDatabase, title: String, sql: String, section: String, args: Array<String> = emptyArray()) {
        val pdf = PdfDocument()
        val pageWidth=595; val pageHeight=842; val margin=30
        val paint=TextPaint(Paint.ANTI_ALIAS_FLAG).apply{textSize=9f;typeface=Typeface.create("sans-serif",Typeface.NORMAL)}
        val titlePaint=TextPaint(Paint.ANTI_ALIAS_FLAG).apply{textSize=15f;typeface=Typeface.create("sans-serif",Typeface.BOLD)}
        var pageNo=0; var page:PdfDocument.Page?=null; var canvas:android.graphics.Canvas?=null; var y=0f
        fun draw(text:String,p:TextPaint):Int { val c=canvas?:return 0; val l=StaticLayout.Builder.obtain(text,0,text.length,p,pageWidth-2*margin).setAlignment(Layout.Alignment.ALIGN_OPPOSITE).setTextDirection(TextDirectionHeuristics.RTL).setIncludePad(false).build();c.save();c.translate(margin.toFloat(),y);l.draw(c);c.restore();return l.height }
        fun newPage(){page?.let{pdf.finishPage(it)};pageNo++;page=pdf.startPage(PdfDocument.PageInfo.Builder(pageWidth,pageHeight,pageNo).create());canvas=page!!.canvas;y=margin.toFloat();y+=draw("نظام إدارة الإيجارات — $title",titlePaint)+12f}
        fun line(t:String,b:Boolean=false){if(page==null||y>pageHeight-margin)newPage();y+=draw(t.replace("\n"," ").take(240),if(b)titlePaint else paint)+(if(b)8f else 4f)}
        newPage();line("القسم: $section",true)
        database.rawQuery(sql,args).use{c->
            if(c.count==0) line("لا توجد سجلات في هذا التقرير") else {
                line((0 until c.columnCount).joinToString(" | "){c.getColumnName(it)},true)
                while(c.moveToNext()){val row=(0 until c.columnCount).joinToString(" | "){i->if(c.isNull(i))"—" else (c.getString(i)?:"").replace("|","/")};line(row)}
            }
        }
        page?.let{pdf.finishPage(it)}
        try { resolver.openOutputStream(uri,"w")!!.use{pdf.writeTo(it)} } finally { pdf.close() }
    }

    private const val thirty = 30
}
