package com.medref.drugs

import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

/** أساس كل الشاشات: المظهر، الخط، الخلفية، منع اللقطات، واستقبال الملفات المختارة. */
open class BaseActivity : AppCompatActivity() {

    private var stamp = 0

    private val pickCsv = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) DataTools.importCsv(this, uri)
    }
    private val pickDb = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) DataTools.restoreBackup(this, uri)
    }
    private val pickImage = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) onImagePicked(uri)
    }

    open fun onImagePicked(uri: Uri) {}

    /** تُستدعى بعد استيراد/استعادة لتحديث العرض. */
    open fun onDataChanged() {}

    override fun onCreate(savedInstanceState: Bundle?) {
        Ui.applyTheme(this)
        super.onCreate(savedInstanceState)
        stamp = Prefs.stamp
        if (Prefs.secure) {
            window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        }
    }

    /** يُستدعى بعد بناء الواجهة (وبعد كل إعادة بناء لها). */
    protected fun finishUi() {
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        Ui.applyBackground(this)
        Ui.style(window.decorView)
    }

    override fun onResume() {
        super.onResume()
        if (stamp != Prefs.stamp) {
            stamp = Prefs.stamp
            recreate()
        }
    }

    fun openCsvPicker() { Lock.pause(); pickCsv.launch(arrayOf("*/*")) }
    fun openDbPicker() { Lock.pause(); pickDb.launch(arrayOf("*/*")) }
    fun openImagePicker() { Lock.pause(); pickImage.launch(arrayOf("image/*")) }
}
