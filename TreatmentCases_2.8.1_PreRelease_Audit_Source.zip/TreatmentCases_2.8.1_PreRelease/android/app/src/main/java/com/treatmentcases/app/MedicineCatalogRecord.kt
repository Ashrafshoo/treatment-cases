package com.treatmentcases.app

data class MedicineCatalogRecord(
    val name: String,
    val genericName: String = "",
    val specialty: String = "",
    val strengths: String = "",
    val dosageForm: String = "",
    val reviewStatus: String = "يحتاج مراجعة",
    val indications: String = "",
    val criticalClassification: String = "",
    val targetConditions: String = "",
    val medicalNotes: String = "",
    val sourceReference: String = "",
    val lastReviewed: String = "",
    val aliases: String = ""
)

data class MedicineStrengthRecord(val medicine: String, val strength: String)
