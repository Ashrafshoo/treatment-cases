import sqlite3
from pathlib import Path

root = Path(__file__).resolve().parents[1]
sql = (root / "database" / "001_initial_schema.sql").read_text(encoding="utf-8")
db = sqlite3.connect(":memory:")
db.executescript(sql)

tables = {r[0] for r in db.execute(
    "SELECT name FROM sqlite_master WHERE type='table'"
)}
required = {
    "owners", "ownership_shares", "property_groups", "properties", "units", "tenants",
    "leases", "rent_increases", "rent_history", "payments", "receipts",
    "expenses", "documents", "review_items", "users", "devices",
    "sync_operations", "audit_log", "notifications", "app_settings"
}
missing = required - tables
assert not missing, f"Missing tables: {missing}"

# Verify foreign keys are enabled and invalid review status is rejected.
assert db.execute("PRAGMA foreign_keys").fetchone()[0] == 1
try:
    db.execute("""INSERT INTO properties(id,name,review_status)
                  VALUES ('p1','Test','unknown')""")
except sqlite3.IntegrityError:
    pass
else:
    raise AssertionError("Review status CHECK constraint did not fire")

# Basic valid relational insert path.
db.execute("INSERT INTO properties(id,name) VALUES ('p1','Property')")
db.execute("INSERT INTO units(id,property_id,unit_number) VALUES ('u1','p1','1')")
db.execute("INSERT INTO tenants(id,full_name) VALUES ('t1','Tenant')")
db.execute("""INSERT INTO leases(id,unit_id,tenant_id,start_date,duration_value,duration_unit)
              VALUES ('l1','u1','t1','2026-01-01',12,'months')""")
db.commit()
print(f"PASS: {len(required)} business tables created; constraints and relations verified.")
