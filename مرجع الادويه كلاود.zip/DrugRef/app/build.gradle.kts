plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.medref.drugs"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.medref.drugs"
        minSdk = 26
        targetSdk = 34
        versionCode = 4
        versionName = "1.3.0"
    }

    // مفتاح توقيع ثابت داخل المشروع: يضمن أن كل نسخة جديدة تُثبَّت فوق القديمة
    // دون حذفها (وبالتالي دون فقدان تعديلاتك). اجعل المستودع Private.
    signingConfigs {
        create("shared") {
            storeFile = rootProject.file("keystore/drugref.jks")
            storePassword = "drugref123"
            keyAlias = "drugref"
            keyPassword = "drugref123"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("shared")
        }
        getByName("release") {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("shared")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.biometric:biometric:1.1.0")
    testImplementation("junit:junit:4.13.2")
}
