#!/usr/bin/env python3
from pathlib import Path
s=(Path(__file__).resolve().parents[1]/'app/src/main/java/com/example/rentals/printing/ReceiptPdfExporter.kt').read_text(encoding='utf-8')
assert 'resolver.openInputStream(uri)' in s
assert 'String(header, Charsets.US_ASCII) == "%PDF-"' in s
assert 'total >= 512L' in s
assert s.index('document.close()') < s.index('resolver.openInputStream(uri)')
print('PASS: standard receipt PDF is reopened and validated for PDF signature and non-empty payload')
