import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCHEMA = ROOT / 'android-app/src/main/assets/database/001_initial_schema.sql'
MIGRATION = ROOT / 'android-app/src/main/assets/database/007_law164_policy_separation.sql'
REPOSITORY = ROOT / 'android-app/src/main/java/com/familyproperties/app/PropertyRepository.kt'


def _database_at_v6():
    db = sqlite3.connect(':memory:')
    db.execute('PRAGMA foreign_keys=ON')
    schema_v6 = SCHEMA.read_text(encoding='utf-8').replace("  law_164_residential_rules INTEGER NOT NULL DEFAULT 0 CHECK (law_164_residential_rules IN (0,1)),\n", "").replace("-- Stage 23: separate legal applicability from residential calculation policy.\nINSERT OR IGNORE INTO schema_migrations(version, name) VALUES (7, 'stage23_law164_policy_separation');\n", "")
    db.executescript(schema_v6)
    db.execute("INSERT INTO properties(id,name) VALUES('p','Property')")
    db.execute("INSERT INTO tenants(id,full_name) VALUES('t','Tenant')")
    db.execute("INSERT INTO units(id,property_id,unit_number,unit_type) VALUES('ur','p','R','residential')")
    db.execute("INSERT INTO units(id,property_id,unit_number,unit_type) VALUES('uc','p','C','commercial')")
    db.execute("INSERT INTO leases(id,unit_id,tenant_id,start_date,law_164_2025_applies) VALUES('lr','ur','t','2025-09-01',1)")
    db.execute("INSERT INTO leases(id,unit_id,tenant_id,start_date,law_164_2025_applies) VALUES('lc','uc','t','2025-09-01',1)")
    return db


def test_migration_classifies_existing_lease_rules_by_unit_type_without_changing_applicability():
    db = _database_at_v6()
    db.executescript(MIGRATION.read_text(encoding='utf-8'))
    rows = db.execute('SELECT id,law_164_2025_applies,law_164_residential_rules FROM leases ORDER BY id').fetchall()
    assert rows == [('lc', 1, 0), ('lr', 1, 1)]


def test_new_schema_has_independent_legal_and_residential_policy_fields():
    db = sqlite3.connect(':memory:')
    db.executescript(SCHEMA.read_text(encoding='utf-8'))
    columns = {row[1] for row in db.execute('PRAGMA table_info(leases)')}
    assert {'law_164_2025_applies', 'law_164_residential_rules'} <= columns


def test_scheduled_engine_uses_persisted_residential_policy_not_legal_flag_alone():
    source = REPOSITORY.read_text(encoding='utf-8')
    method = source.split('fun applyDueRentIncreases(', 1)[1].split('fun addLease(', 1)[0]
    assert 'l.law_164_residential_rules' in method
    assert 'lease.residentialLaw164Rules' in method
    assert 'lease.law164 && lease.residential' not in method


def test_lease_creation_persists_separate_policy_and_preserves_legal_applicability():
    source = REPOSITORY.read_text(encoding='utf-8')
    method = source.split('fun addLease(', 1)[1].split('fun addExpense(', 1)[0]
    assert 'put("law_164_2025_applies", if (law164Applies) 1 else 0)' in method
    assert 'put("law_164_residential_rules", if (residentialLaw164) 1 else 0)' in method
    assert 'if (residentialLaw164) java.math.BigDecimal("15") else increasePercent' in method


def test_fresh_schema_records_current_version_seven():
    db = sqlite3.connect(':memory:')
    db.executescript(SCHEMA.read_text(encoding='utf-8'))
    assert db.execute('SELECT name FROM schema_migrations WHERE version=7').fetchone() == ('stage23_law164_policy_separation',)


def test_upgrade_records_version_seven_and_preserves_receipt_snapshot():
    db = _database_at_v6()
    db.execute("INSERT INTO receipts(id,receipt_number,issued_at,amount_minor,law_164_2025_snapshot,approved) VALUES('r','R-1','2026-01-01',25000,1,1)")
    db.executescript(MIGRATION.read_text(encoding='utf-8'))
    assert db.execute('SELECT name FROM schema_migrations WHERE version=7').fetchone() == ('stage23_law164_policy_separation',)
    assert db.execute("SELECT law_164_2025_snapshot,approved FROM receipts WHERE id=?", ("r",)).fetchone() == (1,1)


def test_database_helper_applies_version_seven_migration_on_upgrade():
    source = (ROOT / 'android-app/src/main/java/com/familyproperties/app/FamilyDatabase.kt').read_text(encoding='utf-8')
    assert 'private const val DATABASE_VERSION = 8' in source
    assert 'if (oldVersion < 7 && newVersion >= 7)' in source
    assert 'if (oldVersion < 8 && newVersion >= 8)' in source
    assert 'database/007_law164_policy_separation.sql' in source


def test_android_sql_asset_parser_applies_version_seven_ledger_entry():
    import re

    def split_like_android(script):
        statements, current, in_trigger = [], [], False
        for line in script.splitlines():
            trimmed = line.strip()
            if not trimmed or trimmed.startswith('--'):
                continue
            current.append(line)
            accumulated = '\n'.join(current).lstrip()
            if not in_trigger and re.search(r'(?i)^CREATE\s+TRIGGER\b', accumulated):
                in_trigger = True
            trigger_finished = in_trigger and (
                trimmed.lower() == 'end;' or
                ('begin' in trimmed.lower() and trimmed.lower().endswith('end;') and trimmed.count(';') >= 2)
            )
            if (not in_trigger and trimmed.endswith(';')) or trigger_finished:
                statements.append('\n'.join(current).strip().removesuffix(';').strip())
                current, in_trigger = [], False
        assert not current
        return statements

    db = _database_at_v6()
    for statement in split_like_android(MIGRATION.read_text(encoding='utf-8')):
        db.execute(statement)
    assert db.execute('SELECT version,name FROM schema_migrations WHERE version=7').fetchone() == (7,'stage23_law164_policy_separation')
