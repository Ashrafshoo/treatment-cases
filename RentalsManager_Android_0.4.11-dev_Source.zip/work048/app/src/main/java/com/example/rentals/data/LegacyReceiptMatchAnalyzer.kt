package com.example.rentals.data

import org.json.JSONObject
import java.math.BigDecimal

/** Exact-key, read-only matching of legacy unit rows to original receipt-source rows. */
object LegacyReceiptMatchAnalyzer {
    enum class MatchStatus { UNIQUE_SOURCE_MATCH, AMBIGUOUS_GROUP, MULTIPLE_RECEIPTS, NO_MATCH }

    data class Result(
        val unitCode: String,
        val tenant: String,
        val matchStatus: MatchStatus,
        val receiptRows: List<Int>,
        val matchingUnitCount: Int,
        val matchingReceiptCount: Int,
        /** Stable staging-row identity; unit codes are display labels and are not safe join keys. */
        val sourceImportId: Long
    )

    private data class Key(
        val tenant: String,
        val amount: String,
        val description: String,
        val address: String,
        val source: String
    )
    private data class ReceiptCandidate(val key: Key, val sourceRow: Int)

    fun analyze(records: List<LegacyImportRecord>): List<Result> {
        val units = records.filter { it.recordType == "unit_source" }.mapNotNull { record ->
            val j = runCatching { JSONObject(record.rawJson) }.getOrElse { JSONObject() }
            fun f(k: String) = j.optString(k, "").trim()
            if (f("حالة الوحدة التشغيلية").isNotBlank()) return@mapNotNull null
            if (!f("حالة الربط").contains("مرتبط بإيصال")) return@mapNotNull null
            val rent = decimal(f("القيمة الحالية (جنيه/شهر)")) ?: return@mapNotNull null
            val amount = decimal(f("قيمة الإيصال (جنيه)")) ?: return@mapNotNull null
            if (rent.signum() <= 0 || amount.signum() <= 0 || normalizedTenant(f("اسم المستأجر كما ورد")).isBlank()) return@mapNotNull null
            record to Key(normalizedTenant(f("اسم المستأجر كما ورد")), amount.stripTrailingZeros().toPlainString(), normalize(f("وصف العين من الإيصال")), normalize(f("العنوان كما ورد بالإيصال")), normalize(f("مصدر البيانات")))
        }
        val receipts = records.filter { it.recordType == "receipt_source" }.mapNotNull { record ->
            val j = runCatching { JSONObject(record.rawJson) }.getOrElse { JSONObject() }
            fun f(k: String) = j.optString(k, "").trim()
            if (f("حالة الإيصال") != "أصل/سجل مستقل") return@mapNotNull null
            val amount = decimal(f("القيمة")) ?: return@mapNotNull null
            val row = f("صف الإيصال").toIntOrNull() ?: record.sourceRow
            ReceiptCandidate(Key(normalizedTenant(f("المستأجر كما بالإيصال")), amount.stripTrailingZeros().toPlainString(), normalize(f("وصف العين")), normalize(f("العنوان/العقار")), normalize(f("الشيت المصدر"))), row)
        }
        val unitGroups = units.groupBy { it.second }
        return units.map { (record, key) ->
            val candidateRows = receipts.filter { it.key == key }.map { it.sourceRow }.distinct().sorted()
            val unitCount = unitGroups[key]?.size ?: 1
            val status = when {
                candidateRows.isEmpty() -> MatchStatus.NO_MATCH
                unitCount > 1 -> MatchStatus.AMBIGUOUS_GROUP
                candidateRows.size > 1 -> MatchStatus.MULTIPLE_RECEIPTS
                else -> MatchStatus.UNIQUE_SOURCE_MATCH
            }
            val j = runCatching { JSONObject(record.rawJson) }.getOrElse { JSONObject() }
            Result(record.sourceRecordId.ifBlank { j.optString("معرّف السجل", "") }, j.optString("اسم المستأجر كما ورد", ""), status, candidateRows, unitCount, candidateRows.size, record.id)
        }
    }

    private fun decimal(value: String): BigDecimal? = value.trim().replace(",", "").toBigDecimalOrNull()
    private fun normalize(value: String): String = value.trim().replace(Regex("\\s+"), " ")
    private fun normalizedTenant(value: String): String = normalize(value).removePrefix("-").trim()
}
