from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MAIN = (ROOT / "android-app/src/main/java/com/familyproperties/app/MainActivity.kt").read_text(encoding="utf-8")
EXPORTER = (ROOT / "android-app/src/main/java/com/familyproperties/app/MonthlyStatementPdfExporter.kt").read_text(encoding="utf-8")
RECEIPTS = (ROOT / "android-app/src/main/java/com/familyproperties/app/ReceiptPdfExporter.kt").read_text(encoding="utf-8")


def test_monthly_pdf_export_is_admin_only_in_screen():
    assert 'MonthlyStatementScreen(repository, session.isAdministrator' in MAIN
    assert 'if (isAdministrator)' in MAIN
    assert 'MonthlyStatementPdfExporter.create(context, month, rows)' in MAIN


def test_monthly_pdf_uses_repository_rows_and_aggregates():
    assert 'PropertyRepository.MonthlyStatementRow' in EXPORTER
    assert 'rows.sumOf { it.dueMinor }' in EXPORTER
    assert 'rows.sumOf { it.paidMinor }' in EXPORTER
    assert 'rows.sumOf { it.remainingMinor }' in EXPORTER
    assert 'chunked(22)' in EXPORTER


def test_monthly_pdf_validates_period_and_empty_data():
    assert 'month.matches(Regex("\\\\d{4}-\\\\d{2}"))' in EXPORTER
    assert 'require(rows.isNotEmpty())' in EXPORTER


def test_existing_receipt_pdf_keeps_three_receipts_per_page():
    assert 'receipts.chunked(3)' in RECEIPTS


def test_monthly_pdf_does_not_mutate_financial_history():
    # Exporter is read-only: it receives a snapshot list and contains no database/repository writes.
    assert 'PropertyRepository' in EXPORTER
    assert 'insertOrThrow' not in EXPORTER
    assert 'UPDATE ' not in EXPORTER
    assert 'DELETE ' not in EXPORTER
