#!/usr/bin/env python3
"""Static + SQLite migration checks for sync schema v6."""
from pathlib import Path
import sqlite3, uuid
root=Path(__file__).resolve().parents[1]
src=(root/'android/app/src/main/java/com/treatmentcases/app/LocalDb.kt').read_text(encoding='utf-8')
gradle=(root/'android/app/build.gradle').read_text(encoding='utf-8')
checks=[
 ('database schema version 11','treatment_cases_local.db",null,11' in src),
 ('additive upgrade to sync capture','if(oldVersion<6){ createSyncInfrastructure(db); backfillSyncIdentities(db); createSyncCaptureTriggers(db); enqueueInitialSyncSnapshot(db) }' in src),
 ('stable device UUID','CREATE TABLE IF NOT EXISTS sync_device' in src and 'UUID.randomUUID().toString()' in src),
 ('entity identity mapping','CREATE TABLE IF NOT EXISTS sync_entity_identity' in src),
 ('outbox and inbox tables','CREATE TABLE IF NOT EXISTS sync_outbox' in src and 'CREATE TABLE IF NOT EXISTS sync_inbox' in src),
 ('conflict ledger','CREATE TABLE IF NOT EXISTS sync_conflicts' in src),
 ('automatic change capture','private fun createSyncCaptureTriggers' in src and 'AFTER INSERT ON $table' in src and 'AFTER UPDATE ON $table' in src and 'BEFORE DELETE ON $table' in src),
 ('isolated development application id',"applicationId 'com.treatmentcases.app.preview275'" in gradle),
 ('development version label',"versionName '2.7.5-dev'" in gradle),
]
for name,ok in checks: print(('PASS' if ok else 'FAIL')+': '+name)
assert all(ok for _,ok in checks)
# Simulate a v5 database and additive v6 sync setup; existing data must remain.
db=sqlite3.connect(':memory:')
db.executescript('''CREATE TABLE cases(id INTEGER PRIMARY KEY,name TEXT);CREATE TABLE employees(id INTEGER PRIMARY KEY,name TEXT);CREATE TABLE medicines(id INTEGER PRIMARY KEY,name TEXT);CREATE TABLE strengths(id INTEGER PRIMARY KEY,medicine TEXT,strength TEXT);INSERT INTO cases VALUES(7,'sample case');INSERT INTO employees VALUES(9,'sample employee');INSERT INTO medicines VALUES(11,'sample medicine');INSERT INTO strengths VALUES(13,'sample medicine','10 mg');CREATE TABLE sync_entity_identity(entity_type TEXT,local_id INTEGER,entity_uuid TEXT UNIQUE,version INTEGER DEFAULT 1,updated_at TEXT DEFAULT CURRENT_TIMESTAMP,deleted_at TEXT,PRIMARY KEY(entity_type,local_id));CREATE TABLE sync_outbox(event_uuid TEXT PRIMARY KEY,entity_type TEXT,entity_uuid TEXT,operation TEXT,base_version INTEGER,new_version INTEGER,payload_json TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,delivery_state TEXT DEFAULT 'pending');''')
for table,typ in [('cases','case'),('employees','employee'),('medicines','medicine'),('strengths','strength')]:
 for (local_id,) in db.execute(f'SELECT id FROM {table}'):
  db.execute('INSERT INTO sync_entity_identity(entity_type,local_id,entity_uuid,version) VALUES(?,?,?,1)',(typ,local_id,str(uuid.uuid4())))
db.execute("INSERT INTO sync_outbox SELECT lower(hex(randomblob(16))),entity_type,entity_uuid,'upsert',0,version,'{}',CURRENT_TIMESTAMP,'pending' FROM sync_entity_identity")
assert db.execute('SELECT COUNT(*) FROM sync_entity_identity').fetchone()[0]==4
assert db.execute('SELECT COUNT(*) FROM sync_outbox').fetchone()[0]==4
assert db.execute("SELECT name FROM cases WHERE id=7").fetchone()[0]=='sample case'
assert db.execute("SELECT name FROM employees WHERE id=9").fetchone()[0]=='sample employee'
assert db.execute("SELECT name FROM medicines WHERE id=11").fetchone()[0]=='sample medicine'
assert db.execute("SELECT strength FROM strengths WHERE id=13").fetchone()[0]=='10 mg'
print('PASS: SQLite v5-to-v6 migration simulation preserves all business rows and queues initial snapshot')
