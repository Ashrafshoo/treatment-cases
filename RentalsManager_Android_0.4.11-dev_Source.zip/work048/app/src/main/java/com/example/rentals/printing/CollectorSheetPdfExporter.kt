package com.example.rentals.printing

import android.content.ContentResolver
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint

/** Creates an A4 Arabic collector sheet from the exact saved batch selection. */
object CollectorSheetPdfExporter {
    fun export(resolver: ContentResolver, uri: Uri, title: String, rows: List<Array<String>>) {
        val doc = PdfDocument()
        val pageW = 595
        val pageH = 842
        val margin = 34f
        val rowH = 42f
        val rowsPerPage = 16
        val pages = maxOf(1, (rows.size + rowsPerPage - 1) / rowsPerPage)
        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 17f; typeface = Typeface.create("sans-serif", Typeface.BOLD); color = 0xff17252d.toInt() }
        val bodyPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 10.5f; color = 0xff17252d.toInt() }
        val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xffdce8eb.toInt() }
        val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xffaab8bd.toInt(); strokeWidth = 0.7f }
        try {
            for (page in 0 until pages) {
                val info = PdfDocument.PageInfo.Builder(pageW, pageH, page + 1).create()
                val p = doc.startPage(info)
                val c = p.canvas
                drawRtl(c, title, pageW - margin, 28f, pageW - 2 * margin, titlePaint)
                drawRtl(c, "كشف تسليم للمحصّل – العناصر المحددة في هذه الدفعة فقط", pageW - margin, 58f, pageW - 2 * margin, bodyPaint)
                val top = 92f
                val widths = floatArrayOf(48f, 72f, 100f, 55f, 76f, 72f, 104f)
                val labels = listOf("الكود", "العقار", "المستأجر", "الإيجار", "نتيجة المرور", "المحصل فعليًا", "ملاحظات")
                var x = pageW - margin
                labels.forEachIndexed { i, label ->
                    val left = x - widths[i]
                    c.drawRect(left, top, x, top + rowH, headerPaint)
                    drawRtl(c, label, x - 5f, top + 13f, widths[i] - 10f, bodyPaint)
                    c.drawRect(left, top, x, top + rowH, linePaint)
                    x = left
                }
                val slice = rows.drop(page * rowsPerPage).take(rowsPerPage)
                slice.forEachIndexed { index, row ->
                    val y = top + rowH * (index + 1)
                    val values = listOf(row[0], row[1], row[2], row[3].ifBlank { "غير محدد" }, row[4].ifBlank { "لم يسجل" }, row[5].ifBlank { "—" }, row[6])
                    x = pageW - margin
                    values.forEachIndexed { i, value ->
                        val left = x - widths[i]
                        drawRtl(c, value, x - 5f, y + 13f, widths[i] - 10f, bodyPaint)
                        c.drawRect(left, y, x, y + rowH, linePaint)
                        x = left
                    }
                }
                drawRtl(c, "صفحة ${page + 1} من $pages  •  إجمالي الوحدات: ${rows.size}", pageW - margin, pageH - 28f, pageW - 2 * margin, bodyPaint)
                doc.finishPage(p)
            }
            resolver.openOutputStream(uri, "w")!!.use { doc.writeTo(it) }
        } finally { doc.close() }
    }

    private fun drawRtl(canvas: android.graphics.Canvas, text: String, right: Float, top: Float, width: Float, paint: TextPaint) {
        val safe = text.take(140)
        if (safe.isBlank()) return
        val layout = StaticLayout.Builder.obtain(safe, 0, safe.length, paint, width.toInt().coerceAtLeast(40))
            .setAlignment(Layout.Alignment.ALIGN_OPPOSITE).setTextDirection(TextDirectionHeuristics.RTL)
            .setIncludePad(false).setMaxLines(2).build()
        canvas.save(); canvas.translate(right - width, top); layout.draw(canvas); canvas.restore()
    }
}
