package com.treatmentcases.app

data class EmployeeRecord(
    val id: Long = 0,
    val performanceNo: String,
    val name: String = "",
    val job: String = "",
    val entity: String = "",
    val department: String = "",
    val nationalId: String = "",
    val phone1: String = "",
    val phone2: String = "",
    val gender: String = "",
    val notes: String = "",
    val birthDate: String = "",
    val age: Int? = null,
    val serviceStatus: String = "",
    val sourceRow: Int = 0
) {
    fun cells(): List<String> = listOf(performanceNo, name, job, entity, department, nationalId, phone1, phone2, gender, notes)
    companion object {
        val headers = listOf("رقم الأداء", "الاسم", "الوظيفة", "الجهة", "الإدارة", "رقم البطاقة", "رقم التليفون", "رقم التليفون الثاني", "النوع", "ملاحظات")
    }
}

data class EmployeeImportIssue(val row: Int, val performanceNo: String, val message: String)
data class EmployeeFieldChange(val field: String, val oldValue: String, val newValue: String)
data class EmployeeImportChange(val performanceNo: String, val name: String, val fields: List<EmployeeFieldChange>)
data class EmployeeImportPlan(
    val inserts: List<EmployeeRecord>,
    val updates: List<EmployeeRecord>,
    val unchanged: Int,
    val issues: List<EmployeeImportIssue>,
    val changes: List<EmployeeImportChange> = emptyList()
) {
    val canCommit: Boolean get() = issues.isEmpty()
}
