package com.example.rentals.features.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.rentals.data.RentalsDb
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
internal fun RecoveryRecordsDialog(db: RentalsDb, onClose: () -> Unit, onMessage: (String) -> Unit, onRestored: () -> Unit) {
    var refresh by remember { mutableIntStateOf(0) }
    var showHistory by remember { mutableStateOf(false) }
    val trash = remember(refresh) { db.trashEntries() }
    val history = remember(refresh) { db.auditHistory(limit = 250) }
    val date = remember { SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(if (showHistory) "سجل التعديلات" else "سلة المحذوفات") },
        text = {
            Column(Modifier.heightIn(max = 480.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { showHistory = false }) { Text("سلة المحذوفات (${trash.size})") }
                    OutlinedButton(onClick = { showHistory = true }) { Text("السجل التاريخي") }
                }
                if (!showHistory) {
                    Text("استعادة السجل تعيده بمعرّفه وبياناته الأصلية. إذا تعارض مع سجل حالي، ستفشل الاستعادة ويبقى محفوظًا في السلة.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (trash.isEmpty()) Text("سلة المحذوفات فارغة.")
                    trash.forEach { entry ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("${tableLabel(entry.tableName)} • #${entry.recordId}", style = MaterialTheme.typography.titleSmall)
                                Text("${date.format(Date(entry.deletedAt))} • ${entry.summary}", fontSize = 11.sp)
                                TextButton(onClick = {
                                    try { db.restoreFromTrash(entry.id); refresh++; onRestored(); onMessage("تمت استعادة السجل بنجاح") }
                                    catch (e: Exception) { onMessage("تعذرت الاستعادة، وظل السجل محفوظًا في السلة: ${e.message}") }
                                }) { Text("استعادة") }
                            }
                        }
                    }
                } else {
                    Text("آخر ${history.size} حركة مسجلة. السجل يوضح التغييرات التي تسجلها عمليات الحفظ والحذف والاستعادة في التطبيق.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (history.isEmpty()) Text("لا توجد حركات مسجلة بعد.")
                    history.forEach { item ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text("${tableLabel(item.recordType)} • ${item.recordId} • ${item.fieldName}", style = MaterialTheme.typography.titleSmall)
                                Text("${item.oldValue.ifBlank { "—" }} ← ${item.newValue.ifBlank { "—" }}", fontSize = 12.sp)
                                Text("${date.format(Date(item.createdAt))} • ${item.reason}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("إغلاق") } }
    )
}

private fun tableLabel(value: String): String = when (value) {
    "properties" -> "العقارات"
    "tenants" -> "المستأجرون"
    "leases" -> "العقود"
    "attachments" -> "المستندات"
    "personal_rent_expenses" -> "مصروفات الدفتر"
    "unit" -> "الوحدات"
    "deleted" -> "الحذف والاستعادة"
    else -> value
}
