package com.familyproperties.app

import android.os.Bundle
import androidx.fragment.app.FragmentActivity
import com.familyproperties.app.notifications.ReminderScheduler
import androidx.compose.ui.platform.LocalContext
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.familyproperties.app.security.BiometricLogin
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.runtime.CompositionLocalProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.math.BigDecimal
import java.math.RoundingMode

private val Navy: Color get() = when (AppUiPreferences.current.palette) {
    "emerald" -> Color(0xFF174A3A); "burgundy" -> Color(0xFF54283A); "slate" -> Color(0xFF263746); "dark" -> Color(0xFF101820); else -> Color(0xFF101D36)
}
private val NavyLight: Color get() = when (AppUiPreferences.current.palette) {
    "emerald" -> Color(0xFF26745A); "burgundy" -> Color(0xFF754057); "slate" -> Color(0xFF40586A); "dark" -> Color(0xFF243443); else -> Color(0xFF1D3154)
}
private val Gold: Color get() = if (AppUiPreferences.current.palette == "dark") Color(0xFFE0B65D) else Color(0xFFD6AD62)
private val Canvas: Color get() = when (AppUiPreferences.current.palette) {
    "emerald" -> Color(0xFFF1F6F2); "burgundy" -> Color(0xFFF8F2F4); "slate" -> Color(0xFFF1F4F6); "dark" -> Color(0xFF17212B); else -> Color(0xFFF3F5F9)
}

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        runCatching { ReminderScheduler.schedule(applicationContext) }
        val databaseResult = runCatching { FamilyDatabase.create(applicationContext) }
        AppUiPreferences.load(applicationContext)
        val initialBar = when (AppUiPreferences.current.palette) {
            "emerald" -> android.graphics.Color.rgb(23, 74, 58)
            "burgundy" -> android.graphics.Color.rgb(84, 40, 58)
            "slate" -> android.graphics.Color.rgb(38, 55, 70)
            "dark" -> android.graphics.Color.rgb(16, 24, 32)
            else -> android.graphics.Color.rgb(16, 29, 54)
        }
        window.statusBarColor = initialBar
        window.navigationBarColor = initialBar
        setContent {
            val database = databaseResult.getOrNull()
            if (database == null) DatabaseRecoveryScreen(databaseResult.exceptionOrNull()?.message)
            else FamilyPropertyRoot(AuthRepository(database), database)
        }
    }
}

@Composable
private fun FamilyPropertyRoot(auth: AuthRepository, database: FamilyDatabase) {
    var accountExists by remember { mutableStateOf<Boolean?>(null) }
    var session by remember { mutableStateOf<AuthSession?>(null) }
    var startupError by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(auth) {
        try {
            accountExists = withContext(Dispatchers.IO) { auth.hasAccounts() }
        } catch (error: Throwable) {
            startupError = error.message ?: "تعذر فتح قاعدة البيانات المشفرة."
        }
    }

    val prefs = AppUiPreferences.current
    val barColor = when (prefs.palette) {
        "emerald" -> android.graphics.Color.rgb(23, 74, 58)
        "burgundy" -> android.graphics.Color.rgb(84, 40, 58)
        "slate" -> android.graphics.Color.rgb(38, 55, 70)
        "dark" -> android.graphics.Color.rgb(16, 24, 32)
        else -> android.graphics.Color.rgb(16, 29, 54)
    }
    val activityContext = LocalContext.current
    SideEffect {
        (activityContext as? FragmentActivity)?.window?.let { window ->
            window.statusBarColor = barColor
            window.navigationBarColor = barColor
        }
    }
    val palette = when (prefs.palette) {
        "emerald" -> listOf(Color(0xFF174A3A), Color(0xFF26745A), Color(0xFFD9B86C), Color(0xFFF1F6F2))
        "burgundy" -> listOf(Color(0xFF54283A), Color(0xFF754057), Color(0xFFD8B36A), Color(0xFFF8F2F4))
        "slate" -> listOf(Color(0xFF263746), Color(0xFF40586A), Color(0xFFB9A16B), Color(0xFFF1F4F6))
        "dark" -> listOf(Color(0xFF101820), Color(0xFF243443), Color(0xFFE0B65D), Color(0xFF17212B))
        else -> listOf(Navy, NavyLight, Gold, Canvas)
    }
    val selectedFont = when (prefs.font) {
        "serif" -> FontFamily.Serif
        else -> FontFamily.SansSerif
    }
    val baseTypography = MaterialTheme.typography
    val adjustedTypography = androidx.compose.material3.Typography(
        displayLarge = baseTypography.displayLarge.copy(fontFamily = selectedFont, fontSize = baseTypography.displayLarge.fontSize * prefs.fontScale, fontWeight = if (prefs.boldText) FontWeight.Bold else baseTypography.displayLarge.fontWeight),
        displayMedium = baseTypography.displayMedium.copy(fontFamily = selectedFont, fontSize = baseTypography.displayMedium.fontSize * prefs.fontScale, fontWeight = if (prefs.boldText) FontWeight.Bold else baseTypography.displayMedium.fontWeight),
        displaySmall = baseTypography.displaySmall.copy(fontFamily = selectedFont, fontSize = baseTypography.displaySmall.fontSize * prefs.fontScale, fontWeight = if (prefs.boldText) FontWeight.Bold else baseTypography.displaySmall.fontWeight),
        headlineLarge = baseTypography.headlineLarge.copy(fontFamily = selectedFont, fontSize = baseTypography.headlineLarge.fontSize * prefs.fontScale, fontWeight = if (prefs.boldText) FontWeight.Bold else baseTypography.headlineLarge.fontWeight),
        headlineMedium = baseTypography.headlineMedium.copy(fontFamily = selectedFont, fontSize = baseTypography.headlineMedium.fontSize * prefs.fontScale, fontWeight = if (prefs.boldText) FontWeight.Bold else baseTypography.headlineMedium.fontWeight),
        headlineSmall = baseTypography.headlineSmall.copy(fontFamily = selectedFont, fontSize = baseTypography.headlineSmall.fontSize * prefs.fontScale, fontWeight = if (prefs.boldText) FontWeight.Bold else baseTypography.headlineSmall.fontWeight),
        titleLarge = baseTypography.titleLarge.copy(fontFamily = selectedFont, fontSize = baseTypography.titleLarge.fontSize * prefs.fontScale, fontWeight = if (prefs.boldText) FontWeight.Bold else baseTypography.titleLarge.fontWeight),
        titleMedium = baseTypography.titleMedium.copy(fontFamily = selectedFont, fontSize = baseTypography.titleMedium.fontSize * prefs.fontScale, fontWeight = if (prefs.boldText) FontWeight.Bold else baseTypography.titleMedium.fontWeight),
        titleSmall = baseTypography.titleSmall.copy(fontFamily = selectedFont, fontSize = baseTypography.titleSmall.fontSize * prefs.fontScale, fontWeight = if (prefs.boldText) FontWeight.Bold else baseTypography.titleSmall.fontWeight),
        bodyLarge = baseTypography.bodyLarge.copy(fontFamily = selectedFont, fontSize = baseTypography.bodyLarge.fontSize * prefs.fontScale, fontWeight = if (prefs.boldText) FontWeight.Bold else baseTypography.bodyLarge.fontWeight),
        bodyMedium = baseTypography.bodyMedium.copy(fontFamily = selectedFont, fontSize = baseTypography.bodyMedium.fontSize * prefs.fontScale, fontWeight = if (prefs.boldText) FontWeight.Bold else baseTypography.bodyMedium.fontWeight),
        bodySmall = baseTypography.bodySmall.copy(fontFamily = selectedFont, fontSize = baseTypography.bodySmall.fontSize * prefs.fontScale, fontWeight = if (prefs.boldText) FontWeight.Bold else baseTypography.bodySmall.fontWeight),
        labelLarge = baseTypography.labelLarge.copy(fontFamily = selectedFont, fontSize = baseTypography.labelLarge.fontSize * prefs.fontScale, fontWeight = if (prefs.boldText) FontWeight.Bold else baseTypography.labelLarge.fontWeight),
        labelMedium = baseTypography.labelMedium.copy(fontFamily = selectedFont, fontSize = baseTypography.labelMedium.fontSize * prefs.fontScale, fontWeight = if (prefs.boldText) FontWeight.Bold else baseTypography.labelMedium.fontWeight),
        labelSmall = baseTypography.labelSmall.copy(fontFamily = selectedFont, fontSize = baseTypography.labelSmall.fontSize * prefs.fontScale, fontWeight = if (prefs.boldText) FontWeight.Bold else baseTypography.labelSmall.fontWeight)
    )
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        val darkMode = prefs.palette == "dark"
        MaterialTheme(typography = adjustedTypography, colorScheme = if (darkMode) darkColorScheme(
            primary = palette[0], onPrimary = Color.White, secondary = palette[2],
            background = palette[3], surface = Color(0xFF202D39), onSurface = Color(0xFFF3F5F7)
        ) else lightColorScheme(
            primary = palette[0], onPrimary = Color.White, secondary = palette[2],
            background = palette[3], surface = Color.White, onSurface = Color(0xFF202733)
        )) {
            when {
                startupError != null -> DatabaseRecoveryScreen(startupError)
                accountExists == null -> LoadingScreen()
                session != null -> {
                    val current = session!!
                    val repository = remember(current) { PropertyRepository(database) { session } }
                    FamilyPropertyApp(current, repository, auth) { session = null }
                }
                accountExists == false -> FirstAdministratorScreen(
                    onCreate = { password -> auth.createInitialAdministrator(password) },
                    onAuthenticated = { newSession -> session = newSession; accountExists = true }
                )
                else -> LoginScreen(
                    onLogin = { username, password -> auth.login(username, password) },
                    onBiometricLogin = { userId -> auth.loginWithBiometric(userId) },
                    onAuthenticated = { newSession -> session = newSession }
                )
            }
        }
    }
}

@Composable
private fun DatabaseRecoveryScreen(message: String?) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(colorScheme = lightColorScheme(primary = Navy, secondary = Gold)) {
            Box(Modifier.fillMaxSize().background(Canvas).padding(24.dp), contentAlignment = Alignment.Center) {
                Card(Modifier.fillMaxWidth().widthIn(max = 480.dp), shape = RoundedCornerShape(24.dp)) {
                    Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Icon(Icons.Default.Lock, null, tint = Gold, modifier = Modifier.size(42.dp))
                        Text("تعذر فتح قاعدة البيانات بأمان", color = Navy, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("لم يحذف التطبيق أي ملف بيانات ولم يستبدل قاعدة البيانات. يلزم فحص آمن أو تنفيذ مسار استعادة معتمد قبل المتابعة.", color = Color.DarkGray)
                        if (!message.isNullOrBlank()) Text(message, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun LoadingScreen() {
    Box(Modifier.fillMaxSize().background(Canvas), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(color = Gold)
    }
}

@Composable
private fun FirstAdministratorScreen(
    onCreate: (CharArray) -> AuthSession,
    onAuthenticated: (AuthSession) -> Unit
) {
    val scope = rememberCoroutineScope()
    var password by remember { mutableStateOf("") }
    var confirmation by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    AuthGateCard(
        title = "إعداد حساب المدير",
        subtitle = "هذه أول مرة تفتح فيها التطبيق. أنشئ كلمة مرور المدير؛ لا توجد كلمة مرور افتراضية.",
        username = AuthRepository.ADMIN_USERNAME
    ) {
        OutlinedTextField(
            value = password, onValueChange = { password = it; error = null },
            label = { Text("كلمة مرور جديدة") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = confirmation, onValueChange = { confirmation = it; error = null },
            label = { Text("تأكيد كلمة المرور") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth()
        )
        Text("اختر كلمة مرور تناسبك؛ لا يوجد شرط لطول 10 أحرف أو لخلط الحروف والأرقام. يُفضّل اختيار كلمة يصعب تخمينها.",
            color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Button(
            enabled = !busy && password.isNotEmpty() && confirmation.isNotEmpty(),
            onClick = {
                if (password != confirmation) {
                    error = "كلمتا المرور غير متطابقتين."
                } else {
                    busy = true
                    val entered = password
                    scope.launch {
                        try {
                            val result = withContext(Dispatchers.IO) { onCreate(entered.toCharArray()) }
                            password = ""
                            confirmation = ""
                            onAuthenticated(result)
                        } catch (e: Exception) {
                            error = e.message ?: "تعذر إعداد الحساب."
                        } finally {
                            busy = false
                        }
                    }
                }
            }, modifier = Modifier.fillMaxWidth()
        ) { if (busy) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp) else Text("إنشاء حساب المدير") }
    }
}

@Composable
private fun LoginScreen(
    onLogin: (String, CharArray) -> AuthSession?,
    onBiometricLogin: (String) -> AuthSession?,
    onAuthenticated: (AuthSession) -> Unit
) {
    val scope = rememberCoroutineScope()
    var username by remember { mutableStateOf(AuthRepository.ADMIN_USERNAME) }
    var password by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    AuthGateCard(
        title = "تسجيل الدخول",
        subtitle = "أدخل بيانات حسابك للوصول إلى سجلات أملاك العائلة.",
        username = null
    ) {
        OutlinedTextField(value = username, onValueChange = { username = it; error = null },
            label = { Text("اسم المستخدم") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = password, onValueChange = { password = it; error = null },
            label = { Text("كلمة المرور") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Button(enabled = !busy && username.isNotBlank() && password.isNotEmpty(), onClick = {
            busy = true
            val entered = password
            scope.launch {
                try {
                    val authenticated = withContext(Dispatchers.IO) { onLogin(username, entered.toCharArray()) }
                    if (authenticated == null) error = "اسم المستخدم أو كلمة المرور غير صحيحة."
                    else onAuthenticated(authenticated)
                    password = ""
                } catch (e: Exception) {
                    error = e.message ?: "تعذر تسجيل الدخول."
                } finally { busy = false }
            }
        }, modifier = Modifier.fillMaxWidth()) {
            if (busy) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp) else Text("دخول")
        }
        val context = LocalContext.current
        val biometricPrefs = AppUiPreferences.current
        if (biometricPrefs.biometricEnabled && !biometricPrefs.biometricUserId.isNullOrBlank()) {
            OutlinedButton(enabled = !busy, onClick = {
                val activity = context as? FragmentActivity
                if (activity == null || !BiometricLogin.isAvailable(activity)) {
                    error = "البصمة غير متاحة حالياً؛ استخدم كلمة المرور."
                } else {
                    BiometricLogin.authenticate(activity,
                        onSuccess = {
                            scope.launch {
                                try {
                                    val restored = withContext(Dispatchers.IO) { onBiometricLogin(biometricPrefs.biometricUserId!!) }
                                    if (restored == null) {
                                        AppUiPreferences.update(context, biometricPrefs.copy(biometricEnabled = false, biometricUserId = null))
                                        error = "الحساب المرتبط بالبصمة لم يعد متاحاً. سجل الدخول بكلمة المرور وأعد تفعيلها."
                                    } else onAuthenticated(restored)
                                } catch (e: Exception) { error = e.message ?: "تعذر الدخول بالبصمة." }
                            }
                        },
                        onFailure = { error = it }
                    )
                }
            }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Fingerprint, null); Spacer(Modifier.width(8.dp)); Text("الدخول بالبصمة")
            }
        }
    }
}

@Composable
private fun AuthGateCard(
    title: String,
    subtitle: String,
    username: String?,
    content: @Composable ColumnScope.() -> Unit
) {
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Navy, NavyLight, Canvas))).padding(20.dp),
        contentAlignment = Alignment.Center) {
        Card(Modifier.fillMaxWidth().widthIn(max = 480.dp), shape = RoundedCornerShape(26.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(8.dp)) {
            Column(Modifier.fillMaxWidth().padding(22.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Icon(Icons.Default.Apartment, null, tint = Gold, modifier = Modifier.size(42.dp))
                Text("أملاكنا", color = Navy, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("أملاك العائلة... إدارة أسهل ومستقبل أكثر تنظيماً", color = Color.DarkGray, style = MaterialTheme.typography.bodySmall)
                Text(title, color = Navy, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(subtitle, color = Color.DarkGray, style = MaterialTheme.typography.bodyMedium)
                if (username != null) {
                    Surface(color = Canvas, shape = RoundedCornerShape(12.dp)) {
                        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("اسم المدير", color = Color.DarkGray)
                            Spacer(Modifier.weight(1f))
                            Text(username, color = Navy, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                content()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FamilyPropertyApp(session: AuthSession, repository: PropertyRepository, auth: AuthRepository, onLogout: () -> Unit) {
    LaunchedEffect(session, repository) {
        if (session.isAdministrator) runCatching {
            withContext(Dispatchers.IO) { repository.applyDueRentIncreases() }
        }
    }
    var selected by remember { mutableStateOf("الرئيسية") }
    val drawerScope = rememberCoroutineScope()
    val allItems = listOf(
        "الرئيسية" to Icons.Default.Dashboard, "العقارات" to Icons.Default.Apartment,
        "الوحدات" to Icons.Default.MeetingRoom, "المستأجرون" to Icons.Default.People,
        "العقود" to Icons.Default.Description, "التحصيلات والإيصالات" to Icons.Default.ReceiptLong,
        "التقارير" to Icons.Default.Assessment, "المصروفات" to Icons.Default.Payments,
        "مركز المراجعة" to Icons.Default.FolderOpen, "استيراد وتصدير Excel" to Icons.Default.TableView,
        "الإعدادات" to Icons.Default.Settings
    )
    val items = if (session.isAdministrator) allItems else allItems.filterNot { it.first == "استيراد وتصدير Excel" }
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(modifier = Modifier.width(300.dp), drawerContainerColor = Navy) {
                Spacer(Modifier.height(28.dp))
                Text("أملاكنا", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp))
                Text("أملاك العائلة... إدارة أسهل ومستقبل أكثر تنظيماً", color = Color.White.copy(alpha = .78f), fontSize = 11.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp))
                Text(if (session.isAdministrator) "المدير" else "مشاهدة فقط", color = Color.White.copy(alpha = .75f), modifier = Modifier.padding(horizontal = 20.dp))
                items.forEach { (label, icon) ->
                    NavigationDrawerItem(label = { Text(label, color = Color.White) }, icon = { Icon(icon, null, tint = Gold) },
                        selected = selected == label, onClick = {
                            selected = label
                            drawerScope.launch { drawerState.close() }
                        },
                        colors = NavigationDrawerItemDefaults.colors(selectedContainerColor = NavyLight, unselectedContainerColor = Navy))
                }
            }
        }
    ) {
        Scaffold(containerColor = Canvas, topBar = {
            CenterAlignedTopAppBar(
                title = { Text(selected, fontWeight = FontWeight.Bold, color = Color.White) },
                navigationIcon = { IconButton(onClick = { drawerScope.launch { drawerState.open() } }) { Icon(Icons.Default.Menu, null, tint = Gold) } },
                actions = {
                    IconButton(onClick = onLogout) { Icon(Icons.Default.Logout, "تسجيل الخروج", tint = Gold) }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = Navy)
            )
        }) { padding ->
            when (selected) {
                "الرئيسية" -> DashboardContent(repository, Modifier.padding(padding))
                "العقارات" -> PropertyListScreen(repository, session.isAdministrator, Modifier.padding(padding))
                "الوحدات" -> UnitListScreen(repository, session.isAdministrator, Modifier.padding(padding))
                "المستأجرون" -> TenantListScreen(repository, session.isAdministrator, Modifier.padding(padding))
                "العقود" -> LeaseListScreen(repository, session.isAdministrator, Modifier.padding(padding))
                "التحصيلات والإيصالات" -> PaymentListScreen(repository, session.isAdministrator, Modifier.padding(padding))
                "التقارير" -> MonthlyStatementScreen(repository, session.isAdministrator, Modifier.padding(padding))
                "الإعدادات" -> AuthSettingsScreen(auth, session, Modifier.padding(padding))
                "مركز المراجعة" -> ReviewCenterScreen(repository, session.isAdministrator, Modifier.padding(padding))
                "المصروفات" -> ExpenseListScreen(repository, session.isAdministrator, Modifier.padding(padding))
                "استيراد وتصدير Excel" -> ExcelInterchangeScreen(repository, Modifier.padding(padding))
                else -> SectionPlaceholder(selected, session.isAdministrator, Modifier.padding(padding))
            }
        }
    }
}

@Composable
private fun DashboardContent(repository: PropertyRepository, modifier: Modifier = Modifier) {
    var visible by remember { mutableStateOf(false) }
    var stats by remember { mutableStateOf<PropertyRepository.DashboardStats?>(null) }
    LaunchedEffect(Unit) { visible = true }
    LaunchedEffect(repository) {
        stats = withContext(Dispatchers.IO) { repository.dashboardStats() }
    }
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 16.dp), contentPadding = PaddingValues(vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            AnimatedVisibility(visible, enter = fadeIn() + slideInVertically()) {
                Box(Modifier.fillMaxWidth().height(190.dp).background(Brush.linearGradient(listOf(Navy, NavyLight)), RoundedCornerShape(24.dp)).padding(18.dp)) {
                    Column(Modifier.align(Alignment.CenterStart)) {
                        Text("مرحباً بك", color = Gold, fontSize = 15.sp)
                        Text("أملاكنا", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                        Text("أملاك العائلة... إدارة أسهل ومستقبل أكثر تنظيماً", color = Color.White.copy(alpha = .8f), fontSize = 12.sp)
                    }
                    Icon(Icons.Default.Apartment, null, tint = Gold.copy(alpha = .9f), modifier = Modifier.align(Alignment.CenterEnd).size(96.dp))
                }
            }
        }
        item { Text("نظرة عامة", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Navy) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("العقارات", stats?.properties?.toString() ?: "…", Icons.Default.Apartment, Color(0xFFEAF0FA), Modifier.weight(1f))
                MetricCard("الوحدات", stats?.units?.toString() ?: "…", Icons.Default.MeetingRoom, Color(0xFFFFF3DF), Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("التحصيلات", stats?.let { formatMinor(it.collected) } ?: "…", Icons.Default.Payments, Color(0xFFE7F5EF), Modifier.weight(1f))
                MetricCard("المصروفات", stats?.let { formatMinor(it.expenses) } ?: "…", Icons.Default.Receipt, Color(0xFFFCEBED), Modifier.weight(1f))
            }
        }
        item { Text("الوصول السريع", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Navy) }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                listOf("العقارات" to Icons.Default.Apartment, "التحصيلات والإيصالات" to Icons.Default.AddCard, "التقارير" to Icons.Default.InsertChart, "مركز المراجعة" to Icons.Default.FactCheck).forEach { (label, icon) ->
                    Surface(color = Color.White, shape = RoundedCornerShape(16.dp), shadowElevation = 2.dp) {
                        Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(icon, null, tint = Gold); Spacer(Modifier.width(12.dp)); Text(label, color = Navy, fontWeight = FontWeight.SemiBold); Spacer(Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null, tint = Navy)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PropertyListScreen(repository: PropertyRepository, isAdministrator: Boolean, modifier: Modifier = Modifier) {
    val scope = rememberCoroutineScope()
    var properties by remember { mutableStateOf<List<PropertyRepository.PropertyRow>>(emptyList()) }
    var refresh by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var editingProperty by remember { mutableStateOf<PropertyRepository.PropertyRow?>(null) }
    var archivePropertyCandidate by remember { mutableStateOf<PropertyRepository.PropertyRow?>(null) }
    var showEdit by remember { mutableStateOf(false) }
    var editName by remember { mutableStateOf("") }
    var editAddress by remember { mutableStateOf("") }
    var editNotes by remember { mutableStateOf("") }
    var editStatus by remember { mutableStateOf("needs_review") }
    var name by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(repository, refresh) {
        properties = withContext(Dispatchers.IO) { repository.listProperties() }
    }

    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("سجل العقارات", color = Navy, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("${properties.size} عقار مسجل", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
            }
            if (isAdministrator) Button(onClick = { showAdd = true; error = null }) {
                Icon(Icons.Default.Add, null); Spacer(Modifier.width(4.dp)); Text("إضافة")
            }
        }
        if (properties.isEmpty()) {
            EmptySectionCard("لا توجد عقارات بعد", "ابدأ بإضافة العقار الأول ليكون أساس ربط الوحدات والعقود.")
        } else {
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(properties, key = { it.id }) { property ->
                    val stateColor = reviewColor(property.reviewStatus)
                    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = if (property.highlighted) Color(0xFFFFF7E5) else Color.White)) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(property.name, Modifier.weight(1f), color = Navy, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                Surface(color = stateColor.copy(alpha = .12f), shape = RoundedCornerShape(20.dp)) {
                                    Text(reviewLabel(property.reviewStatus), color = stateColor, modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp), style = MaterialTheme.typography.labelSmall)
                                }
                                if (isAdministrator) {
                                    IconButton(onClick = {
                                        editingProperty = property
                                        editName = property.name
                                        editAddress = property.address.orEmpty()
                                        editNotes = property.notes.orEmpty()
                                        editStatus = property.reviewStatus
                                        error = null
                                        showEdit = true
                                    }) { Icon(Icons.Default.Edit, "تعديل العقار", tint = Navy) }
                                    IconButton(onClick = {
                                        scope.launch {
                                            withContext(Dispatchers.IO) { repository.setPropertyHighlighted(property.id, !property.highlighted) }
                                            refresh++
                                        }
                                    }) { Icon(if (property.highlighted) Icons.Default.Star else Icons.Default.StarBorder, "تمييز العقار", tint = Gold) }
                                }
                            }
                            if (!property.address.isNullOrBlank()) Text(property.address, color = Color.DarkGray, style = MaterialTheme.typography.bodyMedium)
                            if (!property.notes.isNullOrBlank()) Text(property.notes, color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                            if (property.modifiedUnreviewed) {
                                Text("معدل — يحتاج مراجعة المدير", color = Color(0xFF9A6A13), style = MaterialTheme.typography.labelSmall)
                                if (isAdministrator) TextButton(onClick = {
                                    scope.launch { withContext(Dispatchers.IO) { repository.clearModifiedMarker(property.id) }; refresh++ }
                                }) { Text("إزالة علامة التعديل") }
                            }
                            if (isAdministrator) TextButton(onClick = { archivePropertyCandidate = property }) {
                                Icon(Icons.Default.Archive, null); Spacer(Modifier.width(5.dp)); Text("أرشفة العقار")
                            }
                        }
                    }
                }
            }
        }
    }

    archivePropertyCandidate?.let { candidate ->
        AlertDialog(
            onDismissRequest = { if (!busy) archivePropertyCandidate = null },
            title = { Text("تأكيد أرشفة العقار") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("سيتم إخفاء العقار من القوائم النشطة مع الاحتفاظ بسجلاته. يجب أرشفة وحداته أولاً، ولا تُحذف الإيصالات أو العقود التاريخية.\n\n${candidate.name}")
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            } },
            confirmButton = {
                Button(enabled = !busy, onClick = {
                    busy = true
                    scope.launch {
                        try { withContext(Dispatchers.IO) { repository.archiveProperty(candidate.id) }; archivePropertyCandidate = null; refresh++ }
                        catch (e: Exception) { error = e.message ?: "تعذر أرشفة العقار." }
                        finally { busy = false }
                    }
                }) { Text(if (busy) "جارٍ الأرشفة…" else "تأكيد الأرشفة") }
            },
            dismissButton = { TextButton(onClick = { archivePropertyCandidate = null }, enabled = !busy) { Text("إلغاء") } }
        )
    }

    if (showAdd) {
        AlertDialog(
            onDismissRequest = { if (!busy) showAdd = false },
            title = { Text("إضافة عقار") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(name, { name = it; error = null }, label = { Text("اسم العقار") }, singleLine = true)
                    OutlinedTextField(address, { address = it }, label = { Text("العنوان") }, minLines = 2)
                    error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            },
            confirmButton = {
                Button(enabled = !busy && name.isNotBlank(), onClick = {
                    busy = true
                    val enteredName = name; val enteredAddress = address
                    scope.launch {
                        try {
                            withContext(Dispatchers.IO) { repository.addProperty(enteredName, enteredAddress) }
                            name = ""; address = ""; showAdd = false; refresh++
                        } catch (e: Exception) { error = e.message ?: "تعذر حفظ العقار." }
                        finally { busy = false }
                    }
                }) { Text(if (busy) "جارٍ الحفظ…" else "حفظ") }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }, enabled = !busy) { Text("إلغاء") } }
        )
    }

    if (showEdit && editingProperty != null) {
        AlertDialog(
            onDismissRequest = { if (!busy) { showEdit = false; editingProperty = null } },
            title = { Text("تعديل بيانات العقار") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(editName, { editName = it; error = null }, label = { Text("اسم العقار") }, singleLine = true)
                    OutlinedTextField(editAddress, { editAddress = it }, label = { Text("العنوان") }, minLines = 2)
                    OutlinedTextField(editNotes, { editNotes = it }, label = { Text("ملاحظات") }, minLines = 2)
                    Text("حالة المراجعة", color = Navy, fontWeight = FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(selected = editStatus == "sound", onClick = { editStatus = "sound" }, label = { Text("سليم") })
                        FilterChip(selected = editStatus == "needs_review", onClick = { editStatus = "needs_review" }, label = { Text("تحت المراجعة") })
                        FilterChip(selected = editStatus == "incorrect", onClick = { editStatus = "incorrect" }, label = { Text("خاطئ") })
                    }
                    error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            },
            confirmButton = {
                Button(enabled = !busy && editName.isNotBlank(), onClick = {
                    busy = true
                    val id = editingProperty!!.id
                    scope.launch {
                        try {
                            withContext(Dispatchers.IO) { repository.updateProperty(id, editName, editAddress, editNotes, editStatus) }
                            showEdit = false; editingProperty = null; refresh++
                        } catch (e: Exception) { error = e.message ?: "تعذر تعديل العقار." }
                        finally { busy = false }
                    }
                }) { Text(if (busy) "جارٍ الحفظ…" else "حفظ التعديلات") }
            },
            dismissButton = { TextButton(onClick = { showEdit = false; editingProperty = null }, enabled = !busy) { Text("إلغاء") } }
        )
    }
}

@Composable
private fun UnitListScreen(repository: PropertyRepository, isAdministrator: Boolean, modifier: Modifier = Modifier) {
    val scope = rememberCoroutineScope()
    var units by remember { mutableStateOf<List<PropertyRepository.UnitRow>>(emptyList()) }
    var properties by remember { mutableStateOf<List<PropertyRepository.PropertyRow>>(emptyList()) }
    var refresh by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var archiveUnitCandidate by remember { mutableStateOf<PropertyRepository.UnitRow?>(null) }
    var selectedProperty by remember { mutableStateOf<String?>(null) }
    var unitNumber by remember { mutableStateOf("") }
    var unitType by remember { mutableStateOf("residential") }
    var propertyMenu by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(repository, refresh) {
        val loaded = withContext(Dispatchers.IO) { repository.listProperties() to repository.listUnits() }
        properties = loaded.first; units = loaded.second
        if (selectedProperty == null) selectedProperty = properties.firstOrNull()?.id
    }

    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("سجل الوحدات", color = Navy, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("${units.size} وحدة مسجلة", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
            }
            if (isAdministrator) Button(onClick = { showAdd = true; error = null }) {
                Icon(Icons.Default.Add, null); Spacer(Modifier.width(4.dp)); Text("إضافة")
            }
        }
        if (units.isEmpty()) EmptySectionCard("لا توجد وحدات بعد", "أضف العقارات أولاً، ثم اربط كل وحدة بالعقار المناسب.")
        else LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(units, key = { it.id }) { unit ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text("${unit.propertyName} — وحدة ${unit.number}", color = Navy, fontWeight = FontWeight.Bold)
                        Text(if (unit.type == "commercial") "تجارية" else "سكنية", color = Color.DarkGray)
                        Text("الإشغال: ${unit.occupancy}  •  المستأجر: ${unit.tenantName ?: "غير محدد"}", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                        if (unit.law164Applies) Text("إيجار قديم – قانون 164 لسنة 2025", color = Color(0xFF9A6A13), style = MaterialTheme.typography.labelSmall)
                        if (unit.modifiedUnreviewed) Text("معدل — يحتاج مراجعة", color = Color(0xFF9A6A13), style = MaterialTheme.typography.labelSmall)
                        if (isAdministrator) TextButton(onClick = { archiveUnitCandidate = unit }) {
                            Icon(Icons.Default.Archive, null); Spacer(Modifier.width(5.dp)); Text("أرشفة الوحدة")
                        }
                    }
                }
            }
        }
    }

    archiveUnitCandidate?.let { candidate ->
        AlertDialog(
            onDismissRequest = { if (!busy) archiveUnitCandidate = null },
            title = { Text("تأكيد أرشفة الوحدة") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("سيتم إخفاء الوحدة من القوائم النشطة مع الاحتفاظ بتاريخها وسجلاتها. لا يمكن الأرشفة ما دام لها عقد نشط.\n\n${candidate.propertyName} — وحدة ${candidate.number}")
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            } },
            confirmButton = {
                Button(enabled = !busy, onClick = {
                    busy = true
                    scope.launch {
                        try { withContext(Dispatchers.IO) { repository.archiveUnit(candidate.id) }; archiveUnitCandidate = null; refresh++ }
                        catch (e: Exception) { error = e.message ?: "تعذر أرشفة الوحدة." }
                        finally { busy = false }
                    }
                }) { Text(if (busy) "جارٍ الأرشفة…" else "تأكيد الأرشفة") }
            },
            dismissButton = { TextButton(onClick = { archiveUnitCandidate = null }, enabled = !busy) { Text("إلغاء") } }
        )
    }

    if (showAdd) AlertDialog(
        onDismissRequest = { if (!busy) showAdd = false },
        title = { Text("إضافة وحدة") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Box {
                    OutlinedButton(onClick = { propertyMenu = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(properties.firstOrNull { it.id == selectedProperty }?.name ?: "اختر العقار")
                    }
                    DropdownMenu(expanded = propertyMenu, onDismissRequest = { propertyMenu = false }) {
                        properties.forEach { property ->
                            DropdownMenuItem(text = { Text(property.name) }, onClick = { selectedProperty = property.id; propertyMenu = false })
                        }
                    }
                }
                OutlinedTextField(unitNumber, { unitNumber = it; error = null }, label = { Text("رقم الوحدة") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = unitType == "residential", onClick = { unitType = "residential" }, label = { Text("سكنية") })
                    FilterChip(selected = unitType == "commercial", onClick = { unitType = "commercial" }, label = { Text("تجارية") })
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            Button(enabled = !busy && selectedProperty != null && unitNumber.isNotBlank(), onClick = {
                busy = true
                val propertyId = selectedProperty!!; val number = unitNumber; val type = unitType
                scope.launch {
                    try {
                        withContext(Dispatchers.IO) { repository.addUnit(propertyId, number, type) }
                        unitNumber = ""; showAdd = false; refresh++
                    } catch (e: Exception) { error = e.message ?: "تعذر حفظ الوحدة." }
                    finally { busy = false }
                }
            }) { Text(if (busy) "جارٍ الحفظ…" else "حفظ") }
        },
        dismissButton = { TextButton(onClick = { showAdd = false }, enabled = !busy) { Text("إلغاء") } }
    )
}

@Composable
private fun TenantListScreen(repository: PropertyRepository, isAdministrator: Boolean, modifier: Modifier = Modifier) {
    val scope = rememberCoroutineScope()
    var tenants by remember { mutableStateOf<List<PropertyRepository.TenantRow>>(emptyList()) }
    var refresh by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(repository, refresh) { tenants = withContext(Dispatchers.IO) { repository.listTenants() } }
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("سجل المستأجرين", color = Navy, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("${tenants.size} مستأجر مسجل", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
            }
            if (isAdministrator) Button(onClick = { showAdd = true; error = null }) {
                Icon(Icons.Default.Add, null); Spacer(Modifier.width(4.dp)); Text("إضافة")
            }
        }
        if (tenants.isEmpty()) EmptySectionCard("لا يوجد مستأجرون بعد", "يمكن إضافة المستأجرين الآن وربطهم بالوحدات والعقود لاحقاً.")
        else LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(tenants, key = { it.id }) { tenant ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text(tenant.name, color = Navy, fontWeight = FontWeight.Bold)
                        if (!tenant.phone.isNullOrBlank()) Text(tenant.phone, color = Color.DarkGray)
                        if (!tenant.notes.isNullOrBlank()) Text(tenant.notes, color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
    if (showAdd) AlertDialog(
        onDismissRequest = { if (!busy) showAdd = false },
        title = { Text("إضافة مستأجر") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(name, { name = it; error = null }, label = { Text("اسم المستأجر") }, singleLine = true)
                OutlinedTextField(phone, { phone = it }, label = { Text("رقم الهاتف") }, singleLine = true)
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            Button(enabled = !busy && name.isNotBlank(), onClick = {
                busy = true
                val enteredName = name; val enteredPhone = phone
                scope.launch {
                    try {
                        withContext(Dispatchers.IO) { repository.addTenant(enteredName, enteredPhone) }
                        name = ""; phone = ""; showAdd = false; refresh++
                    } catch (e: Exception) { error = e.message ?: "تعذر حفظ المستأجر." }
                    finally { busy = false }
                }
            }) { Text(if (busy) "جارٍ الحفظ…" else "حفظ") }
        },
        dismissButton = { TextButton(onClick = { showAdd = false }, enabled = !busy) { Text("إلغاء") } }
    )
}

@Composable
private fun ReviewCenterScreen(repository: PropertyRepository, isAdministrator: Boolean, modifier: Modifier = Modifier) {
    val reviewScope = rememberCoroutineScope()
    var properties by remember { mutableStateOf<List<PropertyRepository.PropertyRow>>(emptyList()) }
    var units by remember { mutableStateOf<List<PropertyRepository.UnitRow>>(emptyList()) }
    var rentQueue by remember { mutableStateOf<List<PropertyRepository.RentReviewRow>>(emptyList()) }
    var reviewMessage by remember { mutableStateOf<String?>(null) }
    var refresh by remember { mutableIntStateOf(0) }
    LaunchedEffect(repository, refresh) {
        val result = withContext(Dispatchers.IO) {
            Triple(repository.listProperties(), repository.listUnits(), repository.listImportedRentsUnderReview())
        }
        properties = result.first
        units = result.second
        rentQueue = result.third
    }
    val propertyQueue = properties.filter { it.reviewStatus != "sound" || it.modifiedUnreviewed }
    val unitQueue = units.filter { it.reviewStatus != "sound" || it.modifiedUnreviewed }
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("مركز المراجعة", color = Navy, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricCard("عقارات للمراجعة", propertyQueue.size.toString(), Icons.Default.Apartment, Color(0xFFFFF3DF), Modifier.weight(1f))
            MetricCard("وحدات للمراجعة", unitQueue.size.toString(), Icons.Default.MeetingRoom, Color(0xFFFCEBED), Modifier.weight(1f))
            MetricCard("إيجارات معلقة", rentQueue.size.toString(), Icons.Default.Payments, Color(0xFFEAF1FB), Modifier.weight(1f))
        }
        if (reviewMessage != null) Text(reviewMessage!!, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
        if (propertyQueue.isEmpty() && unitQueue.isEmpty() && rentQueue.isEmpty()) EmptySectionCard("لا توجد عناصر معلقة", "كل العقارات والوحدات والإيجارات المستوردة تمت مراجعتها.")
        else LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            if (propertyQueue.isNotEmpty()) item { Text("العقارات", color = Navy, fontWeight = FontWeight.Bold) }
            items(propertyQueue, key = { "p-${it.id}" }) { item ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(item.name, color = Navy, fontWeight = FontWeight.Bold)
                        Text("الحالة: ${reviewLabel(item.reviewStatus)}${if (item.modifiedUnreviewed) " • معدل ويحتاج اعتماد المدير" else ""}", color = reviewColor(item.reviewStatus), style = MaterialTheme.typography.bodySmall)
                        if (!item.address.isNullOrBlank()) Text(item.address, color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            if (unitQueue.isNotEmpty()) item { Text("الوحدات", color = Navy, fontWeight = FontWeight.Bold) }
            items(unitQueue, key = { "u-${it.id}" }) { item ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("${item.propertyName} — وحدة ${item.number}", color = Navy, fontWeight = FontWeight.Bold)
                        Text("${if (item.type == "commercial") "تجارية" else "سكنية"} • ${reviewLabel(item.reviewStatus)}${if (item.modifiedUnreviewed) " • معدل" else ""}", color = reviewColor(item.reviewStatus), style = MaterialTheme.typography.bodySmall)
                        Text("المستأجر: ${item.tenantName ?: "غير محدد"}", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            if (rentQueue.isNotEmpty()) item { Text("الإيجارات الابتدائية المستوردة", color = Navy, fontWeight = FontWeight.Bold) }
            items(rentQueue, key = { "r-${it.id}" }) { item ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text("${item.propertyName} — وحدة ${item.unitNumber}", color = Navy, fontWeight = FontWeight.Bold)
                        Text("المستأجر: ${item.tenantName} • من ${item.validFrom}", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                        Text("الإيجار المسجل: ${String.format(java.util.Locale.US, "%.2f", item.amountMinor / 100.0)} جنيه شهرياً", color = Gold, fontWeight = FontWeight.SemiBold)
                        if (isAdministrator) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = {
                                reviewScope.launch {
                                    val result = runCatching { withContext(Dispatchers.IO) { repository.reviewImportedRent(item.id, true) } }
                                    reviewMessage = result.fold({ "تم اعتماد الإيجار بعد مراجعتك." }, { it.message ?: "تعذر اعتماد الإيجار." })
                                    if (result.isSuccess) refresh++
                                }
                            }) { Text("اعتماد الإيجار") }
                            TextButton(onClick = {
                                reviewScope.launch {
                                    val result = runCatching { withContext(Dispatchers.IO) { repository.reviewImportedRent(item.id, false) } }
                                    reviewMessage = result.fold({ "تم رفض الإيجار المستورد." }, { it.message ?: "تعذر رفض الإيجار." })
                                    if (result.isSuccess) refresh++
                                }
                            }) { Text("رفض") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AuthSettingsScreen(auth: AuthRepository, session: AuthSession, modifier: Modifier = Modifier) {
    val scope = rememberCoroutineScope()
    var showPasswordDialog by remember { mutableStateOf(false) }
    var showViewerDialog by remember { mutableStateOf(false) }
    var newPassword by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var viewerUsername by remember { mutableStateOf("") }
    var viewerName by remember { mutableStateOf("") }
    var viewerPassword by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("الأمان والحسابات", color = Navy, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("الحساب الحالي", color = Navy, fontWeight = FontWeight.Bold)
                Text("${session.username} • ${if (session.isAdministrator) "مدير النظام" else "مشاهدة فقط"}")
                Text("قاعدة البيانات مشفرة محلياً، ولا توجد مزامنة سحابية أو خادم مركزي في النسخة الحالية.", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
            }
        }
        Button(onClick = { showPasswordDialog = true; error = null; message = null }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Password, null); Spacer(Modifier.width(8.dp)); Text("تغيير كلمة المرور")
        }
        if (session.isAdministrator) {
            OutlinedButton(onClick = { showViewerDialog = true; error = null; message = null }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.PersonAdd, null); Spacer(Modifier.width(8.dp)); Text("إنشاء حساب فرد من العائلة")
            }
            Text("حسابات العائلة الجديدة بصلاحية المشاهدة فقط، ولا يمكنها التعديل أو الطباعة أو التصدير.", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
        }
        val context = LocalContext.current
        val prefs = AppUiPreferences.current
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("تخصيص شكل التطبيق", color = Navy, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Text("اختيار التصميم", color = Color.DarkGray, style = MaterialTheme.typography.bodySmall)
                listOf("classic" to "أزرق وذهبي", "emerald" to "أخضر زمردي", "burgundy" to "عنابي", "slate" to "رمادي أنيق", "dark" to "داكن").forEach { (key, label) ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = prefs.palette == key, onClick = { AppUiPreferences.update(context, prefs.copy(palette = key)) })
                        Text(label)
                    }
                }
                Divider()
                Text("نوع الخط", color = Color.DarkGray, style = MaterialTheme.typography.bodySmall)
                listOf("sans" to "حديث (مناسب للعربية)", "serif" to "كلاسيكي (مناسب للعربية)").forEach { (key, label) ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = prefs.font == key, onClick = { AppUiPreferences.update(context, prefs.copy(font = key)) })
                        Text(label)
                    }
                }
                Divider()
                Text("حجم الخط: ${(prefs.fontScale * 100).toInt()}%", color = Color.DarkGray)
                Slider(value = prefs.fontScale, onValueChange = { AppUiPreferences.update(context, prefs.copy(fontScale = it)) }, valueRange = .85f..1.35f)
                Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                    Text("معاينة الخط العربي — أملاك العائلة... إدارة أسهل ومستقبل أكثر تنظيماً", modifier = Modifier.padding(12.dp), style = MaterialTheme.typography.bodyLarge)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("خط عريض", fontWeight = FontWeight.SemiBold)
                        Text("تغليظ النصوص في أنحاء التطبيق", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                    }
                    Switch(checked = prefs.boldText, onCheckedChange = { AppUiPreferences.update(context, prefs.copy(boldText = it)) })
                }
                Divider()
                val biometricAvailable = remember(context) { (context as? FragmentActivity)?.let { activity ->
                    BiometricLogin.isAvailable(activity)
                } ?: false }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("تفعيل البصمة لتسجيل الدخول", fontWeight = FontWeight.SemiBold)
                        Text(if (biometricAvailable) "بعد التفعيل يمكنك فتح حسابك بالبصمة دون حفظ كلمة المرور." else "يلزم إعداد بصمة قوية أو وسيلة تحقق مدعومة في إعدادات الجهاز.", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                    }
                    Switch(checked = prefs.biometricEnabled, enabled = biometricAvailable, onCheckedChange = { enabled ->
                        val activity = context as? FragmentActivity
                        if (enabled && activity != null) {
                            BiometricLogin.authenticate(activity, title = "تأكيد تفعيل بصمة أملاكنا",
                                onSuccess = { AppUiPreferences.update(context, prefs.copy(biometricEnabled = true, biometricUserId = session.userId)); message = "تم تفعيل الدخول بالبصمة لهذا الحساب على هذا الجهاز." },
                                onFailure = { error = it })
                        } else AppUiPreferences.update(context, prefs.copy(biometricEnabled = false, biometricUserId = null))
                    })
                }
                Text("تُحفظ اختيارات التصميم والخط والحجم على هذا الجهاز فقط.", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                OutlinedButton(onClick = {
                    AppUiPreferences.update(context, prefs.copy(palette = "classic", font = "sans", fontScale = 1.0f, boldText = false))
                    message = "تمت استعادة إعدادات العرض الافتراضية، مع الإبقاء على إعداد البصمة كما هو."
                    error = null
                }, modifier = Modifier.fillMaxWidth()) { Text("استعادة الإعدادات الافتراضية") }
            }
        }
        message?.let { Text(it, color = Color(0xFF2E7D52)) }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    }

    if (showPasswordDialog) AlertDialog(
        onDismissRequest = { if (!busy) showPasswordDialog = false },
        title = { Text("تغيير كلمة المرور") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                OutlinedTextField(newPassword, { newPassword = it; error = null }, label = { Text("كلمة المرور الجديدة") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
                OutlinedTextField(confirmPassword, { confirmPassword = it; error = null }, label = { Text("تأكيد كلمة المرور") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
                Text("لا يوجد حد إلزامي لطول كلمة المرور أو لنوع رموزها؛ اختر كلمة يصعب تخمينها.", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            Button(enabled = !busy && newPassword.isNotEmpty() && confirmPassword.isNotEmpty(), onClick = {
                if (newPassword != confirmPassword) { error = "كلمتا المرور غير متطابقتين."; return@Button }
                busy = true
                val password = newPassword
                scope.launch {
                    try {
                        withContext(Dispatchers.IO) { auth.changePassword(session, password.toCharArray()) }
                        showPasswordDialog = false; newPassword = ""; confirmPassword = ""; message = "تم تحديث كلمة المرور بنجاح."
                    } catch (e: Exception) { error = e.message ?: "تعذر تغيير كلمة المرور." }
                    finally { busy = false }
                }
            }) { Text(if (busy) "جارٍ الحفظ…" else "حفظ") }
        },
        dismissButton = { TextButton(onClick = { showPasswordDialog = false }, enabled = !busy) { Text("إلغاء") } }
    )

    if (showViewerDialog) AlertDialog(
        onDismissRequest = { if (!busy) showViewerDialog = false },
        title = { Text("حساب مشاهدة للعائلة") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(viewerUsername, { viewerUsername = it; error = null }, label = { Text("اسم المستخدم") }, singleLine = true)
                OutlinedTextField(viewerName, { viewerName = it; error = null }, label = { Text("الاسم الظاهر") }, singleLine = true)
                OutlinedTextField(viewerPassword, { viewerPassword = it; error = null }, label = { Text("كلمة المرور") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            Button(enabled = !busy && viewerUsername.isNotBlank() && viewerName.isNotBlank() && viewerPassword.isNotBlank(), onClick = {
                busy = true
                val username = viewerUsername; val display = viewerName; val password = viewerPassword
                scope.launch {
                    try {
                        withContext(Dispatchers.IO) { auth.createFamilyViewer(session, username, display, password.toCharArray()) }
                        showViewerDialog = false; viewerUsername = ""; viewerName = ""; viewerPassword = ""; message = "تم إنشاء حساب المشاهدة بنجاح."
                    } catch (e: Exception) { error = e.message ?: "تعذر إنشاء الحساب؛ تحقق من عدم تكرار اسم المستخدم." }
                    finally { busy = false }
                }
            }) { Text(if (busy) "جارٍ الإنشاء…" else "إنشاء الحساب") }
        },
        dismissButton = { TextButton(onClick = { showViewerDialog = false }, enabled = !busy) { Text("إلغاء") } }
    )
}

@Composable
private fun MonthlyStatementScreen(repository: PropertyRepository, isAdministrator: Boolean, modifier: Modifier = Modifier) {
    var month by remember { mutableStateOf(java.time.YearMonth.now().toString()) }
    var rows by remember { mutableStateOf<List<PropertyRepository.MonthlyStatementRow>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    var exporting by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    LaunchedEffect(repository, month) {
        loading = true
        try {
            rows = withContext(Dispatchers.IO) { repository.monthlyStatement(month) }
            error = null
        } catch (e: Exception) {
            rows = emptyList()
            error = "أدخل الشهر بصيغة YYYY-MM."
        } finally { loading = false }
    }
    val dueTotal = rows.sumOf { it.dueMinor }
    val paidTotal = rows.sumOf { it.paidMinor }
    val remainingTotal = rows.sumOf { it.remainingMinor }
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("الكشف الشهري المجمع", color = Navy, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        OutlinedTextField(
            value = month, onValueChange = { month = it }, label = { Text("شهر الكشف YYYY-MM") },
            singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        if (isAdministrator) {
            OutlinedButton(enabled = !exporting && !loading && rows.isNotEmpty(), onClick = {
                exporting = true
                scope.launch {
                    try {
                        val pdf = withContext(Dispatchers.IO) { MonthlyStatementPdfExporter.create(context, month, rows) }
                        context.startActivity(android.content.Intent.createChooser(
                            MonthlyStatementPdfExporter.shareIntent(context, pdf), "طباعة أو مشاركة الكشف الشهري"))
                    } catch (e: Exception) { error = e.message ?: "تعذر إنشاء PDF للكشف." }
                    finally { exporting = false }
                }
            }, modifier = Modifier.fillMaxWidth()) {
                Text(if (exporting) "جارٍ تجهيز الكشف PDF…" else "تصدير الكشف الشهري PDF")
            }
        }
        if (error != null) Text(error!!, color = MaterialTheme.colorScheme.error)
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Gold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricCard("المستحق", formatMinor(dueTotal.toString()), Icons.Default.Assessment, Color(0xFFFFF3DF), Modifier.weight(1f))
            MetricCard("المحصل", formatMinor(paidTotal.toString()), Icons.Default.Payments, Color(0xFFE7F5EF), Modifier.weight(1f))
        }
        MetricCard("المتبقي", formatMinor(remainingTotal.toString()), Icons.Default.AccountBalanceWallet, Color(0xFFFCEBED), Modifier.fillMaxWidth())
        if (!loading && rows.isEmpty() && error == null) EmptySectionCard("لا توجد عقود خلال هذا الشهر", "ستظهر الوحدات التي يغطي عقدها الشهر المحدد هنا.")
        else LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            items(rows, key = { it.leaseId }) { row ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text(row.propertyName, color = Navy, fontWeight = FontWeight.Bold)
                        Text("الوحدة ${row.unitNumber} • ${row.tenantName}", color = Color.DarkGray)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("المستحق: ${formatMinor(row.dueMinor.toString())}", style = MaterialTheme.typography.bodySmall)
                                Text("المحصل: ${formatMinor(row.paidMinor.toString())}", color = Color(0xFF2E7D52), style = MaterialTheme.typography.bodySmall)
                            }
                            Text("متبقي ${formatMinor(row.remainingMinor.toString())}", color = if (row.remainingMinor > 0) Color(0xFFB23A48) else Color(0xFF2E7D52), fontWeight = FontWeight.Bold)
                        }
                        if (row.law164) Text("إيجار قديم – قانون 164 لسنة 2025", color = Color(0xFF8A5A12), style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun PaymentListScreen(repository: PropertyRepository, isAdministrator: Boolean, modifier: Modifier = Modifier) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var exportingPdf by remember { mutableStateOf(false) }
    var payments by remember { mutableStateOf<List<PropertyRepository.PaymentRow>>(emptyList()) }
    var leases by remember { mutableStateOf<List<PropertyRepository.LeaseRow>>(emptyList()) }
    var refresh by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var selectedLeaseId by remember { mutableStateOf("") }
    var leaseMenu by remember { mutableStateOf(false) }
    var paidAt by remember { mutableStateOf(java.time.LocalDate.now().toString()) }
    var periodMonth by remember { mutableStateOf(java.time.YearMonth.now().toString()) }
    var amount by remember { mutableStateOf("") }
    var method by remember { mutableStateOf("نقدي") }
    var methodMenu by remember { mutableStateOf(false) }
    var notes by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(repository, refresh) {
        val result = withContext(Dispatchers.IO) { Pair(repository.listPayments(), repository.listLeases()) }
        payments = result.first; leases = result.second
    }
    val selectedLease = leases.firstOrNull { it.id == selectedLeaseId }

    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("التحصيلات والإيصالات", color = Navy, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("${payments.size} عملية تحصيل", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
            }
            if (isAdministrator) Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Button(onClick = { showAdd = true; error = null }) {
                    Icon(Icons.Default.Add, null); Spacer(Modifier.width(4.dp)); Text("تسجيل تحصيل")
                }
                TextButton(enabled = !exportingPdf, onClick = {
                    exportingPdf = true
                    scope.launch {
                        try {
                            val pdf = withContext(Dispatchers.IO) {
                                ReceiptPdfExporter.create(context, repository.listApprovedReceiptsForPrint())
                            }
                            context.startActivity(android.content.Intent.createChooser(
                                ReceiptPdfExporter.shareIntent(context, pdf), "طباعة أو مشاركة إيصالات الإيجار"
                            ))
                        } catch (e: Exception) {
                            error = e.message ?: "تعذر تجهيز ملف الإيصالات PDF."
                        } finally { exportingPdf = false }
                    }
                }) { Text(if (exportingPdf) "جارٍ تجهيز PDF…" else "PDF للإيصالات المعتمدة") }
            }
        }
        if (payments.isEmpty()) EmptySectionCard("لا توجد تحصيلات بعد", "سجّل التحصيل على عقد نشط، وسيُنشأ إيصال مسودة مرتبط به تلقائياً.")
        else LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(payments, key = { it.id }) { payment ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(payment.receiptNumber ?: "تحصيل بدون إيصال", Modifier.weight(1f), color = Navy, fontWeight = FontWeight.Bold)
                            Surface(color = if (payment.receiptApproved) Color(0xFFE7F5EF) else Color(0xFFFFF3DF), shape = RoundedCornerShape(16.dp)) {
                                Text(if (payment.receiptId == null) "لا يوجد إيصال" else if (payment.receiptApproved) "إيصال معتمد" else "مسودة للمراجعة", color = if (payment.receiptApproved) Color(0xFF2E7D52) else Color(0xFF8A5A12), modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp), style = MaterialTheme.typography.labelSmall)
                            }
                        }
                        Text("${payment.propertyName} — وحدة ${payment.unitNumber}", color = Navy, fontWeight = FontWeight.SemiBold)
                        Text("المستأجر: ${payment.tenantName}", color = Color.DarkGray)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(formatMinor(payment.amountMinor.toString()), color = Color(0xFF2E7D52), fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Text("${payment.paidAt} • ${payment.period ?: ""}", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                        }
                        payment.remainingMinor?.let { Text("المتبقي من إيجار الشهر: ${formatMinor(it.toString())}", color = Color.Gray, style = MaterialTheme.typography.bodySmall) }
                        if (isAdministrator && payment.receiptId != null && !payment.receiptApproved) {
                            TextButton(enabled = !busy, onClick = {
                                busy = true
                                val receiptId = payment.receiptId
                                scope.launch {
                                    try { withContext(Dispatchers.IO) { repository.approveReceipt(receiptId) }; refresh++ }
                                    catch (e: Exception) { error = e.message ?: "تعذر اعتماد الإيصال." }
                                    finally { busy = false }
                                }
                            }) { Text("اعتماد الإيصال وقفل بياناته") }
                        }
                    }
                }
            }
        }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    }

    if (showAdd) AlertDialog(
        onDismissRequest = { if (!busy) showAdd = false },
        title = { Text("تسجيل تحصيل إيجار") },
        text = {
            Column(Modifier.fillMaxWidth().heightIn(max = 500.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Box {
                    OutlinedButton(onClick = { leaseMenu = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(selectedLease?.let { "${it.propertyName} — ${it.unitNumber} — ${it.tenantName}" } ?: "اختر العقد النشط")
                    }
                    DropdownMenu(expanded = leaseMenu, onDismissRequest = { leaseMenu = false }) {
                        leases.filter { it.status in setOf("active", "ending_soon", "open_ended") }.forEach { lease ->
                            DropdownMenuItem(text = { Text("${lease.propertyName} — ${lease.unitNumber} — ${lease.tenantName}") }, onClick = { selectedLeaseId = lease.id; leaseMenu = false })
                        }
                    }
                }
                OutlinedTextField(paidAt, { paidAt = it; error = null }, label = { Text("تاريخ التحصيل YYYY-MM-DD") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(periodMonth, { periodMonth = it; error = null }, label = { Text("شهر الإيجار YYYY-MM") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(amount, { amount = it; error = null }, label = { Text("المبلغ المحصل بالجنيه") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Box {
                    OutlinedButton(onClick = { methodMenu = true }, modifier = Modifier.fillMaxWidth()) { Text("طريقة الدفع: $method") }
                    DropdownMenu(expanded = methodMenu, onDismissRequest = { methodMenu = false }) {
                        listOf("نقدي", "تحويل بنكي", "محفظة إلكترونية", "شيك", "أخرى").forEach { item ->
                            DropdownMenuItem(text = { Text(item) }, onClick = { method = item; methodMenu = false })
                        }
                    }
                }
                OutlinedTextField(notes, { notes = it }, label = { Text("ملاحظات") }, minLines = 2, modifier = Modifier.fillMaxWidth())
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            Button(enabled = !busy && selectedLeaseId.isNotBlank() && paidAt.isNotBlank() && periodMonth.isNotBlank() && amount.isNotBlank(), onClick = {
                busy = true
                val leaseId = selectedLeaseId; val dateValue = paidAt; val monthValue = periodMonth
                val amountValue = amount; val methodValue = method; val notesValue = notes
                scope.launch {
                    try {
                        withContext(Dispatchers.IO) { repository.recordPayment(leaseId, dateValue, amountValue, monthValue, methodValue, notesValue) }
                        showAdd = false; amount = ""; notes = ""; refresh++
                    } catch (e: Exception) { error = e.message ?: "تحقق من بيانات التحصيل والشهر." }
                    finally { busy = false }
                }
            }) { Text(if (busy) "جارٍ الحفظ…" else "حفظ التحصيل") }
        },
        dismissButton = { TextButton(onClick = { showAdd = false }, enabled = !busy) { Text("إلغاء") } }
    )
}

@Composable
private fun LeaseListScreen(repository: PropertyRepository, isAdministrator: Boolean, modifier: Modifier = Modifier) {
    val scope = rememberCoroutineScope()
    var leases by remember { mutableStateOf<List<PropertyRepository.LeaseRow>>(emptyList()) }
    var units by remember { mutableStateOf<List<PropertyRepository.UnitRow>>(emptyList()) }
    var tenants by remember { mutableStateOf<List<PropertyRepository.TenantRow>>(emptyList()) }
    var refresh by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var selectedUnitId by remember { mutableStateOf("") }
    var selectedTenantId by remember { mutableStateOf("") }
    var unitMenu by remember { mutableStateOf(false) }
    var tenantMenu by remember { mutableStateOf(false) }
    var startDate by remember { mutableStateOf(java.time.LocalDate.now().toString()) }
    var duration by remember { mutableStateOf("1") }
    var durationUnit by remember { mutableStateOf("years") }
    var durationMenu by remember { mutableStateOf(false) }
    var rent by remember { mutableStateOf("") }
    var increase by remember { mutableStateOf("") }
    var law164 by remember { mutableStateOf(false) }
    var notes by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(repository, refresh) {
        val result = withContext(Dispatchers.IO) {
            Triple(repository.listLeases(), repository.listUnits(), repository.listTenants())
        }
        leases = result.first; units = result.second; tenants = result.third
    }
    val selectedUnit = units.firstOrNull { it.id == selectedUnitId }
    val selectedTenant = tenants.firstOrNull { it.id == selectedTenantId }

    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("سجل العقود", color = Navy, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("${leases.size} عقد مسجل", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
            }
            if (isAdministrator) Button(onClick = { showAdd = true; error = null }) {
                Icon(Icons.Default.Add, null); Spacer(Modifier.width(4.dp)); Text("عقد جديد")
            }
        }
        if (leases.isEmpty()) EmptySectionCard("لا توجد عقود بعد", "أنشئ عقداً لربط الوحدة بالمستأجر وتسجيل الإيجار وتاريخ الاستحقاق.")
        else LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(leases, key = { it.id }) { lease ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("${lease.propertyName} — وحدة ${lease.unitNumber}", Modifier.weight(1f), color = Navy, fontWeight = FontWeight.Bold)
                            if (lease.law164Applies) Surface(color = Color(0xFFFFF3DF), shape = RoundedCornerShape(16.dp)) {
                                Text("إيجار قديم – قانون 164 لسنة 2025", color = Color(0xFF8A5A12), modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), style = MaterialTheme.typography.labelSmall)
                            }
                        }
                        Text("المستأجر: ${lease.tenantName}", color = Color.DarkGray)
                        Text("بداية العقد: ${lease.startDate}", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                        Text("نهاية العقد: ${lease.manualEndDate ?: lease.calculatedEndDate ?: "مفتوح المدة"}", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                        lease.rentMinor?.let { Text("الإيجار المسجل: ${formatMinor(it.toString())}", color = Navy, fontWeight = FontWeight.SemiBold) }
                    }
                }
            }
        }
    }

    if (showAdd) AlertDialog(
        onDismissRequest = { if (!busy) showAdd = false },
        title = { Text("إضافة عقد إيجار") },
        text = {
            Column(Modifier.fillMaxWidth().heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Box {
                    OutlinedButton(onClick = { unitMenu = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(selectedUnit?.let { "${it.propertyName} — وحدة ${it.number}" } ?: "اختر الوحدة")
                    }
                    DropdownMenu(expanded = unitMenu, onDismissRequest = { unitMenu = false }) {
                        units.forEach { unit -> DropdownMenuItem(
                            text = { Text("${unit.propertyName} — وحدة ${unit.number} (${if (unit.type == "commercial") "تجاري" else "سكني"})") },
                            onClick = { selectedUnitId = unit.id; unitMenu = false }
                        ) }
                    }
                }
                Box {
                    OutlinedButton(onClick = { tenantMenu = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(selectedTenant?.name ?: "اختر المستأجر")
                    }
                    DropdownMenu(expanded = tenantMenu, onDismissRequest = { tenantMenu = false }) {
                        tenants.forEach { tenant -> DropdownMenuItem(text = { Text(tenant.name) }, onClick = { selectedTenantId = tenant.id; tenantMenu = false }) }
                    }
                }
                OutlinedTextField(startDate, { startDate = it; error = null }, label = { Text("تاريخ بداية العقد YYYY-MM-DD") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(duration, { duration = it; error = null }, label = { Text("مدة العقد (اتركها فارغة لعقد مفتوح)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Box {
                    OutlinedButton(onClick = { durationMenu = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(when (durationUnit) { "days" -> "أيام"; "months" -> "شهور"; else -> "سنوات" })
                    }
                    DropdownMenu(expanded = durationMenu, onDismissRequest = { durationMenu = false }) {
                        listOf("days" to "أيام", "months" to "شهور", "years" to "سنوات").forEach { (value, label) ->
                            DropdownMenuItem(text = { Text(label) }, onClick = { durationUnit = value; durationMenu = false })
                        }
                    }
                }
                OutlinedTextField(rent, { rent = it; error = null }, label = { Text("الإيجار الشهري بالجنيه") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(increase, { increase = it; error = null }, label = { Text("الزيادة السنوية % (اختياري)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = law164, onCheckedChange = { law164 = it })
                    Text("خاضع لقانون 164 لسنة 2025")
                }
                if (law164 && selectedUnit?.type == "residential") Text("سيتم إعداد زيادة 15% في سبتمبر وفق القاعدة المعتمدة للعقود السكنية.", color = Color(0xFF8A5A12), style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(notes, { notes = it }, label = { Text("ملاحظات") }, minLines = 2, modifier = Modifier.fillMaxWidth())
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            Button(enabled = !busy && selectedUnitId.isNotBlank() && selectedTenantId.isNotBlank() && startDate.isNotBlank() && rent.isNotBlank(), onClick = {
                busy = true
                val unitId = selectedUnitId; val tenantId = selectedTenantId; val enteredStart = startDate
                val enteredDuration = duration.trim().takeIf(String::isNotEmpty)?.toIntOrNull()
                val enteredUnit = if (duration.isBlank()) null else durationUnit
                val enteredRent = rent; val enteredIncrease = increase; val enteredLaw = law164; val enteredNotes = notes
                scope.launch {
                    try {
                        if (duration.isNotBlank() && enteredDuration == null) {
                            error = "مدة العقد يجب أن تكون رقماً صحيحاً."
                        } else {
                            withContext(Dispatchers.IO) {
                                repository.addLease(unitId, tenantId, enteredStart, enteredDuration, enteredUnit, enteredRent, enteredIncrease, enteredLaw, enteredNotes)
                            }
                            showAdd = false; selectedUnitId = ""; selectedTenantId = ""; rent = ""; increase = ""; notes = ""; refresh++
                        }
                    } catch (e: Exception) { error = e.message ?: "تعذر حفظ العقد." }
                    finally { busy = false }
                }
            }) { Text(if (busy) "جارٍ الحفظ…" else "حفظ العقد") }
        },
        dismissButton = { TextButton(onClick = { showAdd = false }, enabled = !busy) { Text("إلغاء") } }
    )
}

@Composable
private fun ExpenseListScreen(repository: PropertyRepository, isAdministrator: Boolean, modifier: Modifier = Modifier) {
    val scope = rememberCoroutineScope()
    var expenses by remember { mutableStateOf<List<PropertyRepository.ExpenseRow>>(emptyList()) }
    var refresh by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var expenseDate by remember { mutableStateOf(java.time.LocalDate.now().toString()) }
    var notes by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(repository, refresh) { expenses = withContext(Dispatchers.IO) { repository.listExpenses() } }
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("المصروفات العامة", color = Navy, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("${expenses.size} مصروف مسجل", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
            }
            if (isAdministrator) Button(onClick = { showAdd = true; error = null }) {
                Icon(Icons.Default.Add, null); Spacer(Modifier.width(4.dp)); Text("إضافة")
            }
        }
        if (expenses.isEmpty()) EmptySectionCard("لا توجد مصروفات بعد", "أضف المرتبات أو الفواتير أو الإصلاحات مع توضيح الغرض في الملاحظات.")
        else LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(expenses, key = { it.id }) { expense ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(expense.name, Modifier.weight(1f), color = Navy, fontWeight = FontWeight.Bold)
                            Text(formatMinor(expense.amountMinor.toString()), color = Color(0xFF9B3542), fontWeight = FontWeight.Bold)
                        }
                        Text(expense.expenseDate, color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                        if (!expense.notes.isNullOrBlank()) Text(expense.notes, color = Color.DarkGray, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
    if (showAdd) AlertDialog(
        onDismissRequest = { if (!busy) showAdd = false },
        title = { Text("إضافة مصروف عام") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(name, { name = it; error = null }, label = { Text("اسم المصروف") }, singleLine = true)
                OutlinedTextField(amount, { amount = it; error = null }, label = { Text("القيمة بالجنيه") }, singleLine = true)
                OutlinedTextField(expenseDate, { expenseDate = it; error = null }, label = { Text("التاريخ YYYY-MM-DD") }, singleLine = true)
                OutlinedTextField(notes, { notes = it }, label = { Text("ملاحظات / الغرض") }, minLines = 2)
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            Button(enabled = !busy && name.isNotBlank() && amount.isNotBlank(), onClick = {
                busy = true
                val enteredName = name; val enteredAmount = amount; val enteredDate = expenseDate; val enteredNotes = notes
                scope.launch {
                    try {
                        withContext(Dispatchers.IO) { repository.addExpense(enteredName, enteredAmount, enteredDate, enteredNotes) }
                        name = ""; amount = ""; notes = ""; showAdd = false; refresh++
                    } catch (e: Exception) { error = e.message ?: "تحقق من قيمة المصروف والتاريخ." }
                    finally { busy = false }
                }
            }) { Text(if (busy) "جارٍ الحفظ…" else "حفظ") }
        },
        dismissButton = { TextButton(onClick = { showAdd = false }, enabled = !busy) { Text("إلغاء") } }
    )
}

@Composable
private fun EmptySectionCard(title: String, description: String) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.fillMaxWidth().padding(22.dp), verticalArrangement = Arrangement.spacedBy(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.Inbox, null, tint = Gold, modifier = Modifier.size(36.dp))
            Text(title, color = Navy, fontWeight = FontWeight.Bold)
            Text(description, color = Color.Gray, style = MaterialTheme.typography.bodySmall)
        }
    }
}

private fun reviewColor(status: String): Color = when (status) {
    "sound" -> Color(0xFF2E7D52)
    "incorrect" -> Color(0xFFB23A48)
    else -> Color(0xFFB7791F)
}

private fun reviewLabel(status: String): String = when (status) {
    "sound" -> "سليم"
    "incorrect" -> "خاطئ"
    else -> "تحت المراجعة"
}

private fun formatMinor(value: String): String = try {
    val amount = BigDecimal(value).divide(BigDecimal("100"), 2, RoundingMode.HALF_UP)
    "${amount.toPlainString()} ج.م"
} catch (_: NumberFormatException) { "0.00 ج.م" }

@Composable
private fun MetricCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color, modifier: Modifier = Modifier) {
    Surface(modifier, color = Color.White, shape = RoundedCornerShape(18.dp), shadowElevation = 2.dp) {
        Column(Modifier.padding(14.dp)) {
            Icon(icon, null, tint = Gold, modifier = Modifier.size(25.dp))
            Spacer(Modifier.height(10.dp)); Text(value, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Navy)
            Text(title, color = Color.DarkGray, fontSize = 13.sp)
            Spacer(Modifier.height(4.dp)); Box(Modifier.fillMaxWidth().height(3.dp).background(tint, RoundedCornerShape(4.dp)))
        }
    }
}

@Composable
private fun ExcelInterchangeScreen(repository: PropertyRepository, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var previews by remember { mutableStateOf<List<ExcelInterchange.Preview>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("اختر ملف Excel لمعاينة البيانات والتحقق منها قبل أي استيراد.") }
    var error by remember { mutableStateOf<String?>(null) }
    var confirmImport by remember { mutableStateOf(false) }
    var importSummary by remember { mutableStateOf<String?>(null) }
    var legacySheets by remember { mutableStateOf<List<ExcelInterchange.LegacySheet>>(emptyList()) }
    var legacyMessage by remember { mutableStateOf<String?>(null) }
    val importReady = previews.isNotEmpty() && previews.all { it.headersValid && it.issues.isEmpty() }

    val openWorkbook = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            busy = true
            error = null
            previews = emptyList()
            legacySheets = emptyList()
            legacyMessage = null
            importSummary = null
            scope.launch {
                try {
                    val result = withContext(Dispatchers.IO) {
                        context.contentResolver.openInputStream(uri)?.use { ExcelInterchange.preview(it) }
                            ?: throw IllegalStateException("تعذر فتح الملف المحدد")
                    }
                    previews = result
                    val rowCount = result.sumOf { it.rows.size }
                    val issueCount = result.sumOf { it.issues.size }
                    message = "اكتملت المعاينة: $rowCount صفاً، و$issueCount ملاحظة تحقق. لم يتم تعديل قاعدة البيانات."
                } catch (e: Exception) {
                    error = e.message ?: "تعذرت قراءة ملف Excel."
                    message = "لم تكتمل المعاينة."
                } finally {
                    busy = false
                }
            }
        }
    }

    val openLegacyWorkbook = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            busy = true
            legacySheets = emptyList()
            legacyMessage = null
            previews = emptyList()
            importSummary = null
            scope.launch {
                try {
                    val result = withContext(Dispatchers.IO) {
                        context.contentResolver.openInputStream(uri)?.use { ExcelInterchange.previewLegacy(it) }
                            ?: throw IllegalStateException("تعذر فتح الملف العائلي القديم")
                    }
                    legacySheets = result
                    legacyMessage = "تم تحليل ${result.size} أوراق و${result.sumOf { it.rows.size }} صفوف. هذه قراءة خام فقط؛ لم يتم تعديل أي بيانات."
                } catch (e: Exception) {
                    error = e.message ?: "تعذر تحليل الملف القديم."
                } finally { busy = false }
            }
        }
    }

    val exportWorkbook = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    ) { uri ->
        if (uri != null) {
            busy = true
            error = null
            scope.launch {
                try {
                    withContext(Dispatchers.IO) {
                        val data = repository.exportExcelData()
                        context.contentResolver.openOutputStream(uri)?.use { ExcelInterchange.writeWorkbook(it, data) }
                            ?: throw IllegalStateException("تعذر إنشاء ملف التصدير")
                    }
                    message = "تم تصدير البيانات النشطة وسجل التحصيلات إلى Excel."
                } catch (e: Exception) {
                    error = e.message ?: "تعذر تصدير البيانات."
                } finally { busy = false }
            }
        }
    }

    val createTemplate = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    ) { uri ->
        if (uri != null) {
            busy = true
            error = null
            scope.launch {
                try {
                    withContext(Dispatchers.IO) {
                        context.contentResolver.openOutputStream(uri)?.use { ExcelInterchange.writeBlankTemplate(it) }
                            ?: throw IllegalStateException("تعذر إنشاء ملف القالب")
                    }
                    message = "تم حفظ قالب Excel الفارغ."
                } catch (e: Exception) {
                    error = e.message ?: "تعذر حفظ القالب."
                } finally {
                    busy = false
                }
            }
        }
    }

    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.TableView, null, tint = Gold, modifier = Modifier.size(30.dp))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("استيراد وتصدير Excel", color = Navy, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("قوالب موحدة ومعاينة آمنة قبل الاستيراد", color = Color.DarkGray, fontSize = 12.sp)
                    }
                }
                Button(
                    onClick = { openWorkbook.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/vnd.ms-excel")) },
                    enabled = !busy, modifier = Modifier.fillMaxWidth()
                ) { Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text("اختيار ملف Excel للمعاينة") }
                OutlinedButton(
                    onClick = { createTemplate.launch("Amlakna_Excel_Template.xlsx") },
                    enabled = !busy, modifier = Modifier.fillMaxWidth()
                ) { Icon(Icons.Default.FileDownload, null); Spacer(Modifier.width(8.dp)); Text("إنشاء قالب Excel فارغ") }
                OutlinedButton(
                    onClick = { exportWorkbook.launch("Amlakna_Export_${java.time.LocalDate.now()}.xlsx") },
                    enabled = !busy, modifier = Modifier.fillMaxWidth()
                ) { Icon(Icons.Default.FileDownload, null); Spacer(Modifier.width(8.dp)); Text("تصدير بيانات أملاكنا إلى Excel") }
                OutlinedButton(
                    onClick = { openLegacyWorkbook.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/vnd.ms-excel")) },
                    enabled = !busy, modifier = Modifier.fillMaxWidth()
                ) { Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(8.dp)); Text("تحليل ملف Excel العائلي القديم") }
                legacyMessage?.let { Text(it, color = Navy, style = MaterialTheme.typography.bodySmall) }
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Gold)
                Text(message, color = Color.DarkGray, style = MaterialTheme.typography.bodySmall)
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                Text(
                    "حماية الاستيراد: الإدخال يضيف سجلات جديدة فقط، ولا يعدل سجلاً قائماً. أي معرف مكرر أو مرجع مفقود أو تجاوز لحصص الملكية يوقف العملية كاملة.",
                    color = Navy, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium
                )
                if (previews.isNotEmpty()) {
                    OutlinedButton(
                        onClick = { confirmImport = true }, enabled = !busy && importReady,
                        modifier = Modifier.fillMaxWidth()
                    ) { Icon(Icons.Default.CloudUpload, null); Spacer(Modifier.width(8.dp)); Text("مراجعة واعتماد إدخال ${previews.sumOf { it.rows.size }} صفاً") }
                    if (!importReady) Text("لا يمكن الاعتماد قبل إصلاح جميع أخطاء العناوين والصفوف.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
                importSummary?.let { Text(it, color = Color(0xFF237A4B), style = MaterialTheme.typography.bodySmall) }
            }
        }
        if (legacySheets.isNotEmpty()) {
            Text("تحليل خام للملف العائلي القديم", color = Navy, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("تم الحفاظ على أسماء الأوراق وأرقام الصفوف وعناوين الخلايا كما ظهرت. لا توجد مطابقة أو تصحيحات تلقائية.", color = Color.DarkGray, style = MaterialTheme.typography.bodySmall)
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.weight(1f)) {
                items(legacySheets) { sheet ->
                    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(14.dp)) {
                        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(sheet.name, color = Navy, fontWeight = FontWeight.Bold)
                            Text("${sheet.rows.size} صفوف تحتوي بيانات", color = Gold, style = MaterialTheme.typography.labelMedium)
                            sheet.rows.take(12).forEach { row ->
                                Text("صف ${row.rowNumber}: " + row.cells.take(8).joinToString("  |  ") { "${it.address}=${it.value.take(48)}" }, color = Color.DarkGray, style = MaterialTheme.typography.bodySmall)
                            }
                            if (sheet.rows.size > 12) Text("... ${sheet.rows.size - 12} صفوف أخرى", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
        if (previews.isNotEmpty()) {
            Text("نتيجة المعاينة", color = Navy, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.weight(1f)) {
                items(previews) { preview ->
                    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(14.dp)) {
                        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(preview.sheet, color = Navy, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                Text(if (preview.headersValid) "العناوين سليمة" else "عناوين غير مطابقة",
                                    color = if (preview.headersValid) Color(0xFF237A4B) else MaterialTheme.colorScheme.error,
                                    style = MaterialTheme.typography.labelMedium)
                            }
                            Text("عدد الصفوف: ${preview.rows.size}  •  ملاحظات: ${preview.issues.size}", color = Color.DarkGray, style = MaterialTheme.typography.bodySmall)
                            if (preview.issues.isNotEmpty()) {
                                Text("كل أخطاء هذه الورقة (لن يتم الاستيراد قبل إصلاحها):", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
                                preview.issues.forEachIndexed { issueIndex, issue ->
                                    Text("${issueIndex + 1}. الصف ${issue.rowNumber}: ${issue.message}", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                            preview.rows.take(3).forEachIndexed { index, row ->
                                Divider(color = Color(0xFFE8EBF0))
                                Text("معاينة الصف ${index + 1}", color = Gold, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelMedium)
                                Text(row.entries.filter { it.value.isNotBlank() }.take(4).joinToString("  |  ") { "${it.key}: ${it.value}" },
                                    color = Color.DarkGray, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        } else {
            Spacer(Modifier.weight(1f))
            Text("القوالب المدعومة: العقارات، الوحدات، الملاك والحصص، المستأجرون، العقود، التحصيلات، المصروفات.", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
        }
    }
    if (confirmImport) {
        AlertDialog(
            onDismissRequest = { confirmImport = false },
            title = { Text("تأكيد استيراد البيانات") },
            text = { Text("سيتم إضافة ${previews.sumOf { it.rows.size }} صفاً جديداً في معاملة واحدة. لن يتم تعديل السجلات الموجودة. إذا ظهر أي تعارض أثناء الحفظ فسيتم التراجع عن العملية كاملة. هل تعتمد الاستيراد؟") },
            confirmButton = {
                TextButton(onClick = {
                    confirmImport = false
                    busy = true
                    error = null
                    scope.launch {
                        try {
                            val counts = withContext(Dispatchers.IO) { repository.applyExcelImport(previews) }
                            importSummary = "تم الاستيراد بنجاح: " + counts.entries.joinToString("، ") { "${it.key}: ${it.value}" }
                            message = "اكتمل الاستيراد في معاملة واحدة. راجع السجلات المستوردة قبل اعتمادها تشغيلياً."
                            previews = emptyList()
                        } catch (e: Exception) {
                            error = e.message ?: "تعذر اعتماد الاستيراد. لم تُحفظ بيانات جزئية."
                        } finally { busy = false }
                    }
                }) { Text("اعتماد الاستيراد") }
            },
            dismissButton = { TextButton(onClick = { confirmImport = false }) { Text("إلغاء") } }
        )
    }
}

@Composable
private fun SectionPlaceholder(title: String, isAdministrator: Boolean, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(Icons.Default.Construction, null, tint = Gold, modifier = Modifier.size(54.dp))
        Spacer(Modifier.height(12.dp)); Text(title, color = Navy, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Text(if (isAdministrator) "تم تجهيز مدخل القسم. يجري استكمال وظائفه وربطها بقاعدة البيانات." else "هذا القسم متاح للعرض فقط، وستظهر بياناته بعد اكتمال ربط الوظائف.", color = Color.Gray)
    }
}
