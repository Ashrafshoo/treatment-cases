# Family Property Management — Android foundation

This is the first technical foundation package for the approved Android-first project.
It is **not yet a finished Android application or installable APK**.

## Current scope
- Flutter/Dart is the planned application framework.
- SQLite with Drift is the planned local persistence layer.
- Android is the current delivery target.
- iPhone and desktop are deferred, while keeping the architecture portable.
- No central property-data server is planned.

## Contents
- `database/001_initial_schema.sql`: initial relational schema.
- `docs/data_dictionary.md`: table purpose and important rules.
- `docs/security_and_architecture.md`: security and architecture decisions.
- `docs/import_and_review.md`: safe Excel/receipt import rules.
- `tests/schema_smoke_test.py`: verifies schema creation and key constraints.

## Important
The SQL schema is a reviewed starting point, not a substitute for application-level
authorization, encryption, migration testing, backup/restore testing, or security review.
Do not place real tenant/property data in source control or cloud build services.
The application must encrypt the database at rest using a vetted SQLite encryption
solution; ordinary SQLite files are not encrypted automatically.

## Run schema smoke test
```bash
python3 tests/schema_smoke_test.py
```
