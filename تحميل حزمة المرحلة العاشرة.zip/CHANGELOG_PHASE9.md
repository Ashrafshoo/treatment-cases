# المرحلة التاسعة — Docker والأسرار والنسخ الاحتياطي وGitHub Actions

- إضافة Dockerfile متعدد الخطوات؟ لا؛ صورة مبنية على Python slim مع مستخدم غير root وفحص صحة.
- إضافة compose.yaml مع تخزين دائم منفصل للبيانات والنسخ، وربط المنفذ محليًا فقط.
- فصل الإعدادات عن المصدر عبر متغيرات البيئة وملف `.env.example` آمن.
- إضافة `backup_restore.py`: SQLite online backup لقاعدتي العلاج والمصادقة، integrity_check، SHA-256 manifest، سياسة احتفاظ، واستعادة مع نسخة أمان تلقائية.
- تحديث GitHub Actions للاختبارات وفحص Docker Compose، وإضافة نشر إصدار Docker إلى GHCR عند Tag إصدار.
- لا توجد أسرار أو قواعد بيانات شخصية في الحزمة.
