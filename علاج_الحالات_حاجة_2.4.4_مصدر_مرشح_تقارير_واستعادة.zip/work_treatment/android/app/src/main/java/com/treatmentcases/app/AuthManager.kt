package com.treatmentcases.app

import android.content.Context
import android.util.Base64
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** Local first-run administrator gate. Passwords are stored as salted PBKDF2 hashes, never plaintext. */
class AuthManager(context: Context) {
    private val prefs = context.getSharedPreferences("local_auth", Context.MODE_PRIVATE)
    fun isConfigured(): Boolean = prefs.contains("salt") && prefs.contains("hash")
    fun createAdmin(password: String): Boolean {
        if (password.length < 8) return false
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val hash = derive(password, salt)
        prefs.edit().putString("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("hash", Base64.encodeToString(hash, Base64.NO_WRAP))
            .putString("role", "ADMIN").apply()
        return true
    }
    fun verify(password: String): Boolean {
        val salt = prefs.getString("salt", null) ?: return false
        val expected = prefs.getString("hash", null) ?: return false
        return try {
            val actual = derive(password, Base64.decode(salt, Base64.NO_WRAP))
            java.security.MessageDigest.isEqual(actual, Base64.decode(expected, Base64.NO_WRAP))
        } catch (_: Exception) { false }
    }
    private fun derive(password: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(password.toCharArray(), salt, 160_000, 256)
        return try { SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded }
        finally { spec.clearPassword() }
    }
}
