package com.familyproperties.app

import java.math.BigDecimal
import java.math.RoundingMode
import java.time.LocalDate

/** Pure domain rules; no UI or persistence side effects. */
object RentRules {
    fun law164ResidentialRent(
        currentRent: BigDecimal,
        effectiveDate: LocalDate,
        lastIncreaseAppliedDate: LocalDate? = null
    ): BigDecimal {
        require(currentRent >= BigDecimal.ZERO) { "Rent cannot be negative" }
        val residentialMinimum = currentRent.max(BigDecimal("250"))
        val septemberStart = LocalDate.of(effectiveDate.year, 9, 1)
        val increaseDue = !effectiveDate.isBefore(septemberStart) &&
            (lastIncreaseAppliedDate == null || lastIncreaseAppliedDate.isBefore(septemberStart))
        val result = if (increaseDue) residentialMinimum.multiply(BigDecimal("1.15")) else residentialMinimum
        return result.setScale(2, RoundingMode.HALF_UP)
    }

    /** Commercial units are deliberately not assigned the residential minimum or automatic 15% rule. */
    fun commercialRent(currentRent: BigDecimal): BigDecimal {
        require(currentRent >= BigDecimal.ZERO) { "Rent cannot be negative" }
        return currentRent.setScale(2, RoundingMode.HALF_UP)
    }

    fun remaining(due: BigDecimal, paid: BigDecimal): BigDecimal {
        require(due >= BigDecimal.ZERO && paid >= BigDecimal.ZERO) { "Amounts cannot be negative" }
        return due.subtract(paid).max(BigDecimal.ZERO).setScale(2, RoundingMode.HALF_UP)
    }

    fun netIncome(collected: BigDecimal, expenses: BigDecimal): BigDecimal {
        require(collected >= BigDecimal.ZERO && expenses >= BigDecimal.ZERO) { "Amounts cannot be negative" }
        return collected.subtract(expenses).setScale(2, RoundingMode.HALF_UP)
    }
}
