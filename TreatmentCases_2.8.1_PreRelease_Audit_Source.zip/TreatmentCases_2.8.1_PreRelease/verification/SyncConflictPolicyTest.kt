package com.treatmentcases.app

fun main() {
    check(SyncConflictPolicy.decide(null, 0, 1, false) is SyncApplyDecision.Apply)
    check(SyncConflictPolicy.decide(3, 3, 4, false) is SyncApplyDecision.Apply)
    check(SyncConflictPolicy.decide(4, 3, 4, false) is SyncApplyDecision.Conflict)
    check(SyncConflictPolicy.decide(1, 0, 0, false) is SyncApplyDecision.Conflict)
    val duplicate = SyncConflictPolicy.decide(4, 3, 4, true)
    check(duplicate is SyncApplyDecision.IgnoreDuplicate)
    println("5 sync conflict policy assertions passed")
}
