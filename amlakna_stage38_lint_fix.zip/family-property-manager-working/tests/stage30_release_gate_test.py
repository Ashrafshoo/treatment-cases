from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]


def test_release_gate_does_not_claim_unfinished_android_build_or_features():
    report = (ROOT / 'docs/STAGE30_INTEGRATION_AUDIT_AR.md').read_text()
    assert 'غير معتمد للإصدار النهائي' in report
    assert 'لا APK' in report
    assert 'SectionPlaceholder' in report
    assert 'ليست نقل بيانات إلى هاتف آخر' in report


def test_workflow_runs_tests_lint_and_apk_build():
    workflow = (ROOT / '.github/workflows/android-apk.yml').read_text()
    assert ':android-app:testDebugUnitTest' in workflow
    assert ':android-app:lintDebug' in workflow
    assert ':android-app:assembleDebug' in workflow
