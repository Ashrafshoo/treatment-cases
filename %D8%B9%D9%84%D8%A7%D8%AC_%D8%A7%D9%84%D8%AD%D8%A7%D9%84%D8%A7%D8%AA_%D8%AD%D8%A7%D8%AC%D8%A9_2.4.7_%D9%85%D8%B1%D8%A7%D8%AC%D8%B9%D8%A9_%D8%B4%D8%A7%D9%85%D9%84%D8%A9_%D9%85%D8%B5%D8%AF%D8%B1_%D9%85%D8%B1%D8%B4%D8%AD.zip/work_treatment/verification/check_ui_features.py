from pathlib import Path
src = Path("android/app/src/main/java/com/treatmentcases/app/MainActivity.kt").read_text()
checks = {
    "dropdown font family": "PreferenceDropdown(\"نوع الخط\"" in src,
    "eight palette options": all(f'"{x}" to' in src for x in ["blue","green","purple","teal","indigo","rose","amber","slate"]),
    "ten font choices": all(f'"{x}" to' in src for x in ["sans","naskh","serif","mono","cursive","condensed","rounded","light","medium","black"]),
    "background dropdown": "PreferenceDropdown(\"لون خلفية التطبيق\"" in src,
    "continuous spacing slider": "spacing_level" in src and "valueRange=0f..100f" in src,
    "font scale range 40-140": "valueRange=0.4f..1.4f" in src,
    "font family applied inside MaterialTheme": src.index("MaterialTheme(typography=") < src.index("LocalTextStyle provides"),
    "factory reset options": all(x in src for x in ["مسح جميع سجلات الحالات فقط", "مسح دليل العاملين فقط", "إعادة ضبط بيانات البرنامج بالكامل"]),
    "reset password and phrase guard": "auth.verify(resetPassword)" in src and "resetPhrase.trim()==requiredPhrase" in src,
    "distinct backgrounds": all(f'"{x}" to' in src for x in ["white","sky","mint","lavender","cream","rose","slate","aqua"]),
    "factory reset database transaction": "fun factoryResetData()" in Path("android/app/src/main/java/com/treatmentcases/app/LocalDb.kt").read_text(),
    "seed dictionary deduplicated": len({r["name"].strip().casefold() for r in __import__("json").loads(Path("android/app/src/main/assets/medicines_seed.json").read_text())}) == len(__import__("json").loads(Path("android/app/src/main/assets/medicines_seed.json").read_text())),
    "visible reports tab": '"التقارير"' in src and "تصدير PDF" in src and "تصدير Excel" in src,
    "single/multiple/all report selection": "اختيار الكل" in src and "selectedReportMeds" in src,
    "biometric prompt": "BiometricPrompt" in src and "BIOMETRIC_STRONG" in src,
    "fingerprint login entry": "الدخول بالبصمة" in src,
}
for label, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + label)
if not all(checks.values()): raise SystemExit(1)
