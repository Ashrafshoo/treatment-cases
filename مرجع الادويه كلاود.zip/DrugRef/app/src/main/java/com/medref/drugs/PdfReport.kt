package com.medref.drugs

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** تقرير PDF: ملخص التقدم + آخر التعديلات. النص العربي يُرسم بـ StaticLayout لضمان الاتجاه والتشكيل. */
object PdfReport {

    private const val W = 595
    private const val H = 842
    private const val M = 40

    fun build(ctx: Context, db: Db): File {
        val doc = PdfDocument()
        val normal = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 11f; color = Color.BLACK }
        val bold = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 14f; color = Color.BLACK; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val muted = TextPaint(normal).apply { color = Color.DKGRAY; textSize = 10f }

        var page: PdfDocument.Page? = null
        var canvas: Canvas? = null
        var y = 0f
        var no = 0

        fun newPage() {
            page?.let { doc.finishPage(it) }
            no++
            val p = doc.startPage(PdfDocument.PageInfo.Builder(W, H, no).create())
            page = p
            canvas = p.canvas
            y = M.toFloat()
        }

        fun line(text: String, tp: TextPaint, gap: Float = 4f) {
            val layout = StaticLayout.Builder.obtain(text, 0, text.length, tp, W - 2 * M)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setTextDirection(TextDirectionHeuristics.FIRSTSTRONG_RTL)
                .build()
            if (y + layout.height > H - M) newPage()
            val c = canvas!!
            c.save()
            c.translate(M.toFloat(), y)
            layout.draw(c)
            c.restore()
            y += layout.height + gap
        }

        newPage()
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
        line("تقرير مراجعة — مرجع الأدوية", bold.apply { textSize = 18f }, 6f)
        line("أُنشئ في ${fmt.format(Date())}", muted, 10f)

        val d = db.dashboard()
        bold.textSize = 14f
        line("ملخص التقدم", bold)
        fun v(k: String) = d[k] ?: 0
        line("إجمالي الأكواد: ${v("total")} • في القوائم: ${v("live")} • محذوفة (محفوظة بأكوادها): ${v("removed")}", normal)
        line("حُذف مكررًا مطابقًا: ${v("removed_exact")} • تقريبيًا: ${v("removed_near")} • متشابه بانتظار القرار: ${v("similar")}", normal)
        line("الأسماء العربية: معتمدة ${v("names_done")} • مقترحة بانتظار الاعتماد ${v("names_auto")}", normal)
        line("التصنيف العلاجي: مصنّف ${v("class_done")} • مقترح ${v("class_auto")} • غير محدد ${v("class_none")}", normal)
        line("الأجهزة: مؤكدة ${v("dev_orig")} • مقترحة ${v("dev_auto")}", normal)
        line("بانتظار القرار: ${v("pending")} • تعارض اسمين للمراجعة: ${v("flag")} • أكواد ناقصة من التسلسل: ${v("missing")}", normal, 12f)

        bold.textSize = 14f
        line("آخر التعديلات (حتى 300)", bold)
        val acts = db.allActivities().filter { it[1] != "comment" || it[5].isNotBlank() }.takeLast(300).reversed()
        for (a in acts) {
            val field = Labels.field[a[2]] ?: a[2]
            val what = if (a[1] == "comment") a[5]
            else "$field: ${a[3].ifBlank { "—" }} ← ${a[4].ifBlank { "—" }}" + if (a[5].isNotBlank()) " (${a[5]})" else ""
            line("${a[0]} • ${Labels.action[a[1]] ?: a[1]} • ${fmt.format(Date(a[6].toLong()))}\n$what", normal, 6f)
        }
        page?.let { doc.finishPage(it) }

        val out = File(File(ctx.cacheDir, "shared").apply { mkdirs() }, "DrugRef-report.pdf")
        out.outputStream().use { doc.writeTo(it) }
        doc.close()
        return out
    }
}
