from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_lease_rules_are_part_of_android_source_and_unit_suite():
    source = ROOT / "android-app/src/main/java/com/familyproperties/app/LeaseRules.kt"
    tests = ROOT / "android-app/src/test/java/com/familyproperties/app/LeaseRulesTest.kt"
    assert source.exists() and tests.exists()
    code = source.read_text(encoding="utf-8")
    assert "calculateEndDate" in code
    assert "effectiveEndDate" in code
    assert "egpToMinorUnits" in code
    assert "longValueExact" in code


def test_contract_schema_supports_manual_override_and_open_ended_terms():
    schema = (ROOT / "android-app/src/main/assets/database/001_initial_schema.sql").read_text(encoding="utf-8")
    leases = schema.split("CREATE TABLE leases (", 1)[1].split("\n);", 1)[0]
    assert "calculated_end_date TEXT" in leases
    assert "manual_end_date TEXT" in leases
    assert "end_date_override_reason TEXT" in leases
    assert "duration_value INTEGER" in leases
    assert "duration_unit TEXT" in leases


def test_lease_creation_is_transactional_and_admin_guarded():
    source = (ROOT / "android-app/src/main/java/com/familyproperties/app/PropertyRepository.kt").read_text(encoding="utf-8")
    lease_method = source.split("fun addLease(", 1)[1].split("fun addExpense(", 1)[0]
    assert "requireAdministrator()" in lease_method
    assert "db.beginTransaction()" in lease_method
    assert "db.setTransactionSuccessful()" in lease_method
    assert 'db.insertOrThrow("rent_history"' in lease_method
    assert 'appendAudit(db, session, "create", "lease"' in lease_method


def test_lease_screen_is_connected_to_navigation():
    source = (ROOT / "android-app/src/main/java/com/familyproperties/app/MainActivity.kt").read_text(encoding="utf-8")
    assert '"العقود" -> LeaseListScreen' in source
    assert 'private fun LeaseListScreen' in source
    assert 'repository.addLease(' in source


def test_database_blocks_overlapping_active_leases_for_the_same_unit():
    import sqlite3
    db = sqlite3.connect(":memory:")
    db.execute("PRAGMA foreign_keys=ON")
    db.executescript((ROOT / "android-app/src/main/assets/database/001_initial_schema.sql").read_text(encoding="utf-8"))
    db.executescript((ROOT / "android-app/src/main/assets/database/005_relationship_financial_integrity.sql").read_text(encoding="utf-8"))
    migration = ROOT / "android-app/src/main/assets/database/006_active_lease_integrity.sql"
    db.executescript(migration.read_text(encoding="utf-8"))
    db.execute("INSERT INTO properties(id,name) VALUES('p','عقار')")
    db.execute("INSERT INTO units(id,property_id,unit_number) VALUES('u','p','1')")
    db.execute("INSERT INTO tenants(id,full_name) VALUES('t1','مستأجر 1')")
    db.execute("INSERT INTO tenants(id,full_name) VALUES('t2','مستأجر 2')")
    db.execute("INSERT INTO leases(id,unit_id,tenant_id,start_date,calculated_end_date,status) VALUES('l1','u','t1','2026-01-01','2026-12-31','active')")
    try:
        db.execute("INSERT INTO leases(id,unit_id,tenant_id,start_date,calculated_end_date,status) VALUES('l2','u','t2','2026-06-01','2027-05-31','active')")
        assert False, "overlapping active leases for one unit must be blocked"
    except sqlite3.IntegrityError as exc:
        assert "unit_already_has_overlapping_active_lease" in str(exc)
    db.execute("INSERT INTO leases(id,unit_id,tenant_id,start_date,calculated_end_date,status) VALUES('l3','u','t2','2027-01-01','2027-12-31','active')")
    db.close()


def test_database_version_six_migration_is_registered():
    import sqlite3
    db = sqlite3.connect(":memory:")
    db.executescript((ROOT / "android-app/src/main/assets/database/001_initial_schema.sql").read_text(encoding="utf-8"))
    db.executescript((ROOT / "android-app/src/main/assets/database/005_relationship_financial_integrity.sql").read_text(encoding="utf-8"))
    db.executescript((ROOT / "android-app/src/main/assets/database/006_active_lease_integrity.sql").read_text(encoding="utf-8"))
    assert db.execute("SELECT name FROM schema_migrations WHERE version=6").fetchone() == ("stage18_active_lease_overlap_constraints",)
    db.close()


def test_android_asset_sql_line_parser_keeps_multiline_triggers_intact():
    import sqlite3
    import re

    def split_like_android(script):
        statements, current, in_trigger = [], [], False
        for line in script.splitlines():
            trimmed = line.strip()
            if not trimmed or trimmed.startswith("--"):
                continue
            current.append(line)
            accumulated = "\n".join(current).lstrip()
            if not in_trigger and re.search(r"(?i)^CREATE\s+TRIGGER\b", accumulated):
                in_trigger = True
            trigger_finished = in_trigger and (
                trimmed.lower() == "end;" or
                ("begin" in trimmed.lower() and trimmed.lower().endswith("end;") and trimmed.count(";") >= 2)
            )
            if (not in_trigger and trimmed.endswith(";")) or trigger_finished:
                statements.append("\n".join(current).strip().removesuffix(";").strip())
                current, in_trigger = [], False
        assert not current, "Android SQL parser would leave an incomplete statement"
        return statements

    db = sqlite3.connect(":memory:")
    db.execute("PRAGMA foreign_keys=ON")
    for path in [
        ROOT / "android-app/src/main/assets/database/001_initial_schema.sql",
        ROOT / "android-app/src/main/assets/database/005_relationship_financial_integrity.sql",
        ROOT / "android-app/src/main/assets/database/006_active_lease_integrity.sql",
    ]:
        for statement in split_like_android(path.read_text(encoding="utf-8")):
            db.execute(statement)
    triggers = {row[0] for row in db.execute("SELECT name FROM sqlite_master WHERE type='trigger'")}
    assert "one_active_lease_per_unit_insert" in triggers
    assert "one_active_lease_per_unit_update" in triggers
    assert "receipt_payment_lease_match_insert" in triggers
    db.close()


def test_payment_and_receipt_workflow_is_admin_gated_and_atomic():
    repository = (ROOT / "android-app/src/main/java/com/familyproperties/app/PropertyRepository.kt").read_text(encoding="utf-8")
    ui = (ROOT / "android-app/src/main/java/com/familyproperties/app/MainActivity.kt").read_text(encoding="utf-8")
    method = repository.split("fun recordPayment(", 1)[1].split("fun approveReceipt(", 1)[0]
    assert "requireAdministrator()" in method
    assert "db.beginTransaction()" in method and "db.setTransactionSuccessful()" in method
    assert 'db.insertOrThrow("payments"' in method
    assert 'db.insertOrThrow("receipts"' in method
    assert 'appendAudit(db, session, "create", "payment"' in method
    assert 'appendAudit(db, session, "create", "receipt"' in method
    assert "fun approveReceipt(" in repository
    assert '"التحصيلات والإيصالات" -> PaymentListScreen' in ui
    assert 'repository.recordPayment(' in ui
    assert 'repository.approveReceipt(' in ui


def test_payment_receipt_snapshot_columns_and_immutability_exist():
    import sqlite3
    db = sqlite3.connect(":memory:")
    db.execute("PRAGMA foreign_keys=ON")
    schema = (ROOT / "android-app/src/main/assets/database/001_initial_schema.sql").read_text(encoding="utf-8")
    db.executescript(schema)
    payment_cols = {r[1] for r in db.execute("PRAGMA table_info(payments)")}
    receipt_cols = {r[1] for r in db.execute("PRAGMA table_info(receipts)")}
    assert {"lease_id", "paid_at", "amount_minor", "period_start", "period_end", "payment_method"} <= payment_cols
    assert {"payment_id", "lease_id", "receipt_number", "tenant_snapshot", "property_snapshot", "unit_snapshot", "amount_minor", "remaining_minor", "approved"} <= receipt_cols
    db.close()


def test_receipt_amount_in_arabic_words_is_snapshotted_from_minor_units():
    source = (ROOT / "android-app/src/main/java/com/familyproperties/app/ArabicAmountWords.kt").read_text(encoding="utf-8")
    tests = (ROOT / "android-app/src/test/java/com/familyproperties/app/ArabicAmountWordsTest.kt").read_text(encoding="utf-8")
    repository = (ROOT / "android-app/src/main/java/com/familyproperties/app/PropertyRepository.kt").read_text(encoding="utf-8")
    assert "forEgpMinorUnits" in source and "قرشاً" in source and "جنيهاً مصرياً" in source
    assert "ArabicAmountWords.forEgpMinorUnits(amountMinor)" in repository
    assert "convertsEgpAndPiastresForReceipt" in tests


def test_payment_period_is_checked_against_lease_term_and_open_end_is_null_safe():
    source = (ROOT / "android-app/src/main/java/com/familyproperties/app/PropertyRepository.kt").read_text(encoding="utf-8")
    payment_method = source.split("fun recordPayment(", 1)[1].split("fun approveReceipt(", 1)[0]
    assert "شهر التحصيل يسبق تاريخ بداية العقد" in payment_method
    assert "شهر التحصيل يلي نهاية العقد" in payment_method
    assert "COALESCE(l.manual_end_date,l.calculated_end_date,'')" in payment_method


def test_android_branding_resources_and_manifest_references_are_valid_xml():
    import xml.etree.ElementTree as ET
    manifest = ROOT / "android-app/src/main/AndroidManifest.xml"
    resources = [
        ROOT / "android-app/src/main/res/drawable/ic_launcher_background.xml",
        ROOT / "android-app/src/main/res/drawable/ic_launcher_foreground.xml",
        ROOT / "android-app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml",
        ROOT / "android-app/src/main/res/values/colors.xml",
        ROOT / "android-app/src/main/res/values/styles.xml",
    ]
    for path in [manifest, *resources]:
        ET.parse(path)
    content = manifest.read_text(encoding="utf-8")
    assert '@mipmap/ic_launcher' in content and '@style/FamilyPropertiesTheme' in content
    icon = resources[1].read_text(encoding="utf-8")
    assert "#D6AD62" in icon and "#101D36" in icon
