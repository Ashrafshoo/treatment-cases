# حزمة المصدر — علاج الحالات حاجة 2.7.0-dev

هذه حزمة تطوير مبنية على 2.6.9-dev. افتح مجلد `android` في Android Studio لبناء نسخة التطوير عند توفر Android SDK وGradle.

## المجلدات المهمة
- `android/`: مشروع Android.
- `verification/`: اختبارات قواعد البيانات والأدوية والواجهة وطبقة التقاط المزامنة.
- `RELEASE_NOTES_2.7.0_DEV_AR.md`: ملخص التغييرات والحدود ونتائج الاختبارات.

## المزامنة في هذا الإصدار
يتم التقاط تغييرات الحالات والعاملين والأدوية والعيارات محلياً في outbox، وتجهيزها في envelopes. لا يوجد خادم سحابي مربوط بعد، لذلك لا تنتقل البيانات إلى جهاز آخر في هذا الإصدار. لا تضع بيانات تشغيل حقيقية في أي خادم قبل إعداد المصادقة والتشفير وقواعد صلاحيات المدير والمستخدمين المفوضين.

## تشغيل الاختبارات
من جذر الحزمة:

```bash
python3 verification/check_sync_capture_270.py
python3 verification/check_sync_foundation.py
python3 verification/check_restore_safety_269.py
bash verification/run_case_rules_tests.sh
bash verification/run_medicine_matcher_tests.sh
bash verification/run_medicine_strength_tests.sh
bash verification/run_sync_policy_tests.sh
```

## تنبيه
هذه حزمة مصدر تطويرية وليست APK مثبتاً أو إصداراً إنتاجياً. يجب بناء APK واختباره على جهاز فعلي قبل اعتماده.
