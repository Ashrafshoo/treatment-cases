package com.medref.drugs

import android.app.Activity
import android.app.Application
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatDelegate
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

object Lock {
    @Volatile
    var locked = false
    private var leftAt = -1L
    private var ignoreOnce = false

    fun enabled(): Boolean = Prefs.lockEnabled && Prefs.pinHash.isNotEmpty()

    fun init() { locked = enabled() }

    /** قبل فتح منتقي ملفات أو نافذة مشاركة حتى لا يُعدّ ذلك خروجًا من التطبيق. */
    fun pause() { ignoreOnce = true }

    fun onBackground() {
        if (ignoreOnce) { ignoreOnce = false; leftAt = -1L; return }
        leftAt = SystemClock.elapsedRealtime()
    }

    fun onForeground() {
        if (enabled() && leftAt >= 0 && SystemClock.elapsedRealtime() - leftAt >= Prefs.lockTimeout * 1000L) {
            locked = true
        }
        leftAt = -1L
    }

    fun unlock() { locked = false }

    private fun hash(pin: String, salt: ByteArray): String {
        val spec = PBEKeySpec(pin.toCharArray(), salt, 20000, 256)
        val key = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        return Base64.encodeToString(key, Base64.NO_WRAP)
    }

    fun setPin(pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        Prefs.pinSalt = Base64.encodeToString(salt, Base64.NO_WRAP)
        Prefs.pinHash = hash(pin, salt)
        Prefs.pinLen = pin.length
        Prefs.failCount = 0
        Prefs.lockoutUntil = 0L
    }

    fun verify(pin: String): Boolean {
        if (Prefs.pinHash.isEmpty()) return false
        val salt = Base64.decode(Prefs.pinSalt, Base64.NO_WRAP)
        return hash(pin, salt) == Prefs.pinHash
    }

    fun clear() {
        Prefs.lockEnabled = false
        Prefs.biometric = false
        Prefs.pinHash = ""
        Prefs.pinSalt = ""
        locked = false
    }

    fun biometricAvailable(ctx: Context): Boolean =
        BiometricManager.from(ctx).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) ==
            BiometricManager.BIOMETRIC_SUCCESS
}

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        AppCompatDelegate.setDefaultNightMode(Prefs.nightMode())
        Lock.init()
        registerActivityLifecycleCallbacks(object : Application.ActivityLifecycleCallbacks {
            private var started = 0

            override fun onActivityStarted(activity: Activity) {
                if (started == 0) Lock.onForeground()
                started++
                if (Lock.locked && activity !is LockActivity) {
                    activity.startActivity(Intent(activity, LockActivity::class.java))
                }
            }

            override fun onActivityStopped(activity: Activity) {
                started--
                if (started <= 0 && !activity.isChangingConfigurations) {
                    started = 0
                    Lock.onBackground()
                }
            }

            override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}
            override fun onActivityResumed(activity: Activity) {}
            override fun onActivityPaused(activity: Activity) {}
            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
            override fun onActivityDestroyed(activity: Activity) {}
        })
    }
}

/** شاشة القفل: رمز رقمي + بصمة اختيارية. */
class LockActivity : BaseActivity() {

    private val pin = StringBuilder()
    private lateinit var dots: TextView
    private lateinit var msg: TextView
    private val handler = Handler(Looper.getMainLooper())

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { moveTaskToBack(true) }
        })
        if (Prefs.biometric && Lock.biometricAvailable(this)) showBiometric()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
        }
        root.addView(TextView(this).apply {
            text = "مرجع الأدوية"
            textSize = 24f
            gravity = Gravity.CENTER
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        msg = TextView(this).apply {
            text = "أدخل رمز الدخول"
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(8))
        }
        root.addView(msg)
        dots = TextView(this).apply {
            textSize = 28f
            gravity = Gravity.CENTER
            textDirection = View.TEXT_DIRECTION_LTR
            setPadding(0, dp(4), 0, dp(16))
        }
        root.addView(dots)

        val rows = listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"), listOf("bio", "0", "del"))
        for (r in rows) {
            val line = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                layoutDirection = View.LAYOUT_DIRECTION_LTR
            }
            for (k in r) {
                val label = when (k) { "bio" -> "☝"; "del" -> "⌫"; else -> k }
                val b = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
                    text = label
                    textSize = 22f
                    insetTop = 0
                    insetBottom = 0
                    layoutParams = LinearLayout.LayoutParams(dp(84), dp(64)).apply { setMargins(dp(6), dp(6), dp(6), dp(6)) }
                    if (k == "bio" && !(Prefs.biometric && Lock.biometricAvailable(this@LockActivity))) visibility = View.INVISIBLE
                    setOnClickListener {
                        when (k) {
                            "bio" -> showBiometric()
                            "del" -> { if (pin.isNotEmpty()) pin.deleteCharAt(pin.length - 1); refreshDots() }
                            else -> onDigit(k)
                        }
                    }
                }
                line.addView(b)
            }
            root.addView(line)
        }
        setContentView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        refreshDots()
        finishUi()
    }

    private fun refreshDots() {
        val n = Prefs.pinLen
        dots.text = (0 until n).joinToString(" ") { if (it < pin.length) "●" else "○" }
    }

    private fun onDigit(d: String) {
        val wait = Prefs.lockoutUntil - System.currentTimeMillis()
        if (wait > 0) { msg.text = "محاولات كثيرة — انتظر ${wait / 1000 + 1} ثانية"; return }
        if (pin.length >= Prefs.pinLen) return
        pin.append(d)
        refreshDots()
        if (pin.length == Prefs.pinLen) {
            if (Lock.verify(pin.toString())) {
                Prefs.failCount = 0
                Lock.unlock()
                finish()
            } else {
                val f = Prefs.failCount + 1
                Prefs.failCount = f
                pin.setLength(0)
                if (f >= 5) {
                    Prefs.lockoutUntil = System.currentTimeMillis() + 30_000L
                    msg.text = "محاولات كثيرة — انتظر 30 ثانية"
                } else {
                    msg.text = "رمز خاطئ — المحاولات المتبقية ${5 - f}"
                }
                handler.postDelayed({ refreshDots() }, 150)
                refreshDots()
            }
        }
    }

    private fun showBiometric() {
        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    Lock.unlock()
                    finish()
                }
            })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("فتح مرجع الأدوية")
            .setSubtitle("استخدم البصمة أو الوجه")
            .setNegativeButtonText("استخدم الرمز")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK)
            .build()
        prompt.authenticate(info)
    }
}
