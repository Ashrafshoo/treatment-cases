#!/usr/bin/env python3
"""Source regression for Arabic date normalization across receipt rendering paths."""
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
fmt = (ROOT / 'app/src/main/java/com/example/rentals/printing/ReceiptDateFormat.kt').read_text(encoding='utf-8')
pdf = (ROOT / 'app/src/main/java/com/example/rentals/printing/AggregateReceiptPdfExporter.kt').read_text(encoding='utf-8')
printer = (ROOT / 'app/src/main/java/com/example/rentals/printing/AggregateReceiptPrintAdapter.kt').read_text(encoding='utf-8')
panel = (ROOT / 'app/src/main/java/com/example/rentals/features/printing/AggregateStatementsPanel.kt').read_text(encoding='utf-8')
assert 'DateTimeFormatter.ofPattern("yyyy/MM/dd"' in fmt
assert 'arabicDigits[index]' in fmt and 'replace(\'/\', \'-\')' in fmt
assert 'ReceiptDateFormat.toSheet(ReceiptDateFormat.toStorage(issuedDate))' in pdf
assert 'ReceiptDateFormat.toSheet(ReceiptDateFormat.toStorage(issuedDate))' in printer
assert 'normalizedPreviewDate' in panel and 'toStorage(issuedDate)' in panel
print('PASS: date validation and Arabic yyyy/MM/dd normalization are wired into preview, print and PDF')
