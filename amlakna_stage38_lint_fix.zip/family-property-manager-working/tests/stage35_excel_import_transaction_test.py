from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT / "android-app/src/main/java/com/familyproperties/app/PropertyRepository.kt"
MAIN = ROOT / "android-app/src/main/java/com/familyproperties/app/MainActivity.kt"
EXCEL = ROOT / "android-app/src/main/java/com/familyproperties/app/ExcelInterchange.kt"


def test_import_is_admin_gated_and_single_transaction():
    source = REPO.read_text(encoding="utf-8")
    method = source.split("fun applyExcelImport", 1)[1].split("fun dashboardStats", 1)[0]
    assert "val session = requireAdministrator()" in method
    assert "db.beginTransaction()" in method
    assert "db.setTransactionSuccessful()" in method
    assert "finally { db.endTransaction() }" in method
    assert 'put("action", "import")' in method


def test_import_is_insert_only_and_rejects_existing_ids():
    source = REPO.read_text(encoding="utf-8")
    method = source.split("fun applyExcelImport", 1)[1].split("fun dashboardStats", 1)[0]
    assert "SELECT 1 FROM $table WHERE id=? LIMIT 1" in method
    assert "لن يتم تحديثه" in method
    assert "db.insertOrThrow" in method
    assert "UPDATE $table" not in method


def test_import_checks_all_foreign_key_relationships():
    source = REPO.read_text(encoding="utf-8")
    for token in (
        'requireRef("الوحدات", "property_id", "properties", "العقارات")',
        'requireRef("حصص_الملكية", "owner_id", "owners", "الملاك")',
        'requireRef("العقود", "unit_id", "units", "الوحدات")',
        'requireRef("العقود", "tenant_id", "tenants", "المستأجرون")',
        'requireRef("التحصيلات", "lease_id", "leases", "العقود")',
    ):
        assert token in source


def test_import_checks_unit_collisions_owner_share_limit_and_dates():
    source = REPO.read_text(encoding="utf-8")
    assert "unit_number=? AND archived_at IS NULL" in source
    trigger = (ROOT / "android-app/src/main/assets/database/005_relationship_financial_integrity.sql").read_text(encoding="utf-8")
    assert "ownership_share_limit_insert" in trigger and "ownership_share_total_exceeds_100" in trigger
    assert "manualEnd.isBefore(start)" in source
    assert "end.isBefore(start)" in source


def test_import_marks_imported_property_and_unit_for_review_and_audits_each_row():
    source = REPO.read_text(encoding="utf-8")
    assert 'put("review_status","needs_review")' in source
    assert 'put("source_status","excel")' in source
    assert 'put("action", "import")' in source


def test_ui_requires_explicit_confirmation_and_blocks_invalid_preview():
    source = MAIN.read_text(encoding="utf-8")
    screen = source.split("private fun ExcelInterchangeScreen", 1)[1].split("private fun SectionPlaceholder", 1)[0]
    assert "importReady = previews.isNotEmpty() && previews.all { it.headersValid && it.issues.isEmpty() }" in screen
    assert "confirmImport = true" in screen
    assert "AlertDialog(" in screen
    assert "repository.applyExcelImport(previews)" in screen


def test_preview_validates_ids_dates_enums_and_positive_amounts():
    source = EXCEL.read_text(encoding="utf-8")
    assert "required(schemas.getValue(sheet).first())" in source
    assert "java.time.LocalDate.parse(raw)" in source
    assert '"occupied", "vacant", "closed", "unknown"' in source
    assert "amount <= java.math.BigDecimal.ZERO" in source
    assert '"old_law_164_2025"' in source
    assert '"law_164_2025_applies"' in source
    assert '"increase_rule"' in source
    assert 'check(existingType == "residential")' in REPO.read_text(encoding="utf-8")
