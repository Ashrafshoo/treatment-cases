#!/usr/bin/env python3
"""Never silently assign the first workbook template to a new tenant."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
PANEL=(ROOT/'app/src/main/java/com/example/rentals/features/printing/AggregateStatementsPanel.kt').read_text(encoding='utf-8')
assert 'mutableStateOf(initial?.templateId.orEmpty())' in PANEL
assert '?: "T001"' not in PANEL
assert 'النموذج الافتراضي T001' not in PANEL
assert 'selectedTemplatesReady' in PANEL
assert 'enabled = selectedTemplatesReady' in PANEL
assert 'يمكنك حفظ الاسم والقيمة الآن واستكمال اختيار القالب لاحقًا' in PANEL
assert 'templateOptions.any { it.first == row.templateId }' in PANEL
print('PASS: no arbitrary default receipt template; save remains available while print/PDF require valid per-row template selection')
