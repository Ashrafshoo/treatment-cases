package com.medref.drugs

import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.util.TypedValue
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.progressindicator.LinearProgressIndicator

/** قوائم المراجعة الموجّهة: نوع القائمة ← عنوانها. */
object Review {
    val kinds = linkedMapOf(
        "pending" to "بانتظار القرار",
        "names" to "أسماء عربية مقترحة",
        "class" to "تصنيفات علاجية مقترحة",
        "device" to "أجهزة مقترحة بالبحث الشامل",
        "similar" to "متشابهة / تكرار تقريبي",
        "flag" to "تعارض الاسم العربي والأجنبي"
    )

    /** يفتح القائمة الموجّهة: الصنف الأول ثم «اعتماد وتالي». */
    fun open(a: BaseActivity, kind: String) {
        Thread {
            val codes = Db.get(a).queue(kind)
            a.runOnUiThread {
                if (codes.isEmpty()) {
                    Toast.makeText(a, "لا شيء للمراجعة في «${kinds[kind]}»", Toast.LENGTH_SHORT).show()
                } else {
                    a.startActivity(
                        Intent(a, DetailActivity::class.java)
                            .putExtra("queue", codes.toIntArray()).putExtra("qkind", kind).putExtra("qpos", 0)
                    )
                }
            }
        }.start()
    }

    fun pick(a: BaseActivity) {
        Thread {
            val db = Db.get(a)
            val labels = kinds.map { (k, v) -> "$v  (${db.queueCount(k)})" }.toTypedArray()
            a.runOnUiThread {
                MaterialAlertDialogBuilder(a)
                    .setTitle("مراجعة موجّهة")
                    .setItems(labels) { _, i -> open(a, kinds.keys.toList()[i]) }
                    .setNegativeButton("إلغاء", null)
                    .showStyled()
            }
        }.start()
    }
}

class ProgressActivity : BaseActivity() {

    private lateinit var root: LinearLayout
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "لوحة التقدم"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(28))
        }
        setContentView(ScrollView(this).apply { addView(root) })
        finishUi()
    }

    override fun onResume() {
        super.onResume()
        load()
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    private fun load() {
        Thread {
            val d = Db.get(this).dashboard()
            runOnUiThread { render(d) }
        }.start()
    }

    private fun card(onClick: (() -> Unit)?): LinearLayout {
        val c = MaterialCardView(this).apply {
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(10) }
        }
        Ui.styleCard(c)
        val inner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        c.addView(inner)
        if (onClick != null) {
            c.isClickable = true
            c.setOnClickListener { onClick() }
        }
        root.addView(c)
        return inner
    }

    private fun text(parent: LinearLayout, t: String, size: Float, bold: Boolean = false, alpha: Float = 1f) {
        parent.addView(TextView(this).apply {
            text = t
            setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            this.alpha = alpha
            setPadding(0, dp(2), 0, dp(2))
        })
    }

    private fun bar(title: String, done: Int, total: Int, sub: String, onClick: (() -> Unit)?) {
        val c = card(onClick)
        text(c, title, 15f, true)
        c.addView(LinearProgressIndicator(this).apply {
            max = total.coerceAtLeast(1)
            progress = done.coerceAtMost(total)
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6); bottomMargin = dp(6) }
        })
        text(c, sub, 12f, false, 0.8f)
        if (onClick != null) text(c, "اضغط لبدء المراجعة الموجّهة ›", 11f, false, 0.6f)
    }

    private fun render(d: Map<String, Int>) {
        root.removeAllViews()
        fun v(k: String) = d[k] ?: 0
        val head = card(null)
        text(head, "إجمالي الأكواد: ${v("total")}", 16f, true)
        text(head, "في القوائم الحالية: ${v("live")} • محذوفة (أكوادها محفوظة): ${v("removed")}", 12f, false, 0.8f)

        bar("الأسماء العربية", v("names_done"), v("names_done") + v("names_auto"),
            "معتمد ${v("names_done")} • مقترح بانتظار الاعتماد ${v("names_auto")}",
            if (v("names_auto") > 0) ({ Review.open(this, "names") }) else null)
        bar("التصنيف العلاجي (الأدوية)", v("class_done"), v("class_done") + v("class_auto") + v("class_none"),
            "مصنّف ${v("class_done")} • مقترح ${v("class_auto")} • غير محدد ${v("class_none")}",
            if (v("class_auto") > 0) ({ Review.open(this, "class") }) else null)
        bar("الأجهزة التعويضية", v("dev_orig"), v("dev_orig") + v("dev_auto"),
            "مؤكدة ${v("dev_orig")} • مقترحة بالبحث الشامل ${v("dev_auto")}",
            if (v("dev_auto") > 0) ({ Review.open(this, "device") }) else null)
        bar("التكرار", v("removed_exact") + v("removed_near"), v("removed_exact") + v("removed_near") + v("similar"),
            "حُذف مطابقًا ${v("removed_exact")} • تقريبيًا ${v("removed_near")} • متشابه بانتظار القرار ${v("similar")}",
            if (v("similar") > 0) ({ Review.open(this, "similar") }) else null)
        bar("تعارض الاسم العربي والأجنبي", 0, v("flag").coerceAtLeast(1),
            "بانتظار التحقق: ${v("flag")}",
            if (v("flag") > 0) ({ Review.open(this, "flag") }) else null)
        bar("القرارات", v("decided"), v("decided") + v("pending"),
            "تم القرار ${v("decided")} • بانتظار القرار ${v("pending")}",
            if (v("pending") > 0) ({ Review.open(this, "pending") }) else null)

        val m = card(null)
        text(m, "الأكواد الناقصة من التسلسل: ${v("missing")}", 15f, true)
        text(m, "هذه أكواد بين 1 وآخر كود لا وجود لها في الشيت المصدَّر. تحقّق من سببها في النظام الأصلي؛ لا يُخمَّن لها شيء.", 12f, false, 0.8f)
        m.addView(MaterialButton(this).apply {
            text = "تصدير القائمة"
            setOnClickListener {
                Thread {
                    try {
                        val f = Share.exportMissing(this@ProgressActivity, Db.get(this@ProgressActivity))
                        runOnUiThread { Share.file(this@ProgressActivity, f, "text/csv", "الأكواد الناقصة") }
                    } catch (e: Exception) {
                        runOnUiThread { Toast.makeText(this@ProgressActivity, "تعذر التصدير", Toast.LENGTH_SHORT).show() }
                    }
                }.start()
            }
        })
        finishUi()
    }
}
