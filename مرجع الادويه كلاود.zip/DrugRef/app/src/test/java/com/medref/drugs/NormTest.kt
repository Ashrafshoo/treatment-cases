package com.medref.drugs

import org.junit.Assert.assertEquals
import org.junit.Test

/** القيم المتوقعة مولَّدة من tools/build_db.py::norm — تضمن تطابق منطق البحث بين Python وKotlin. */
class NormTest {
    @Test
    fun matchesPython() {
        assertEquals("كرسي متحرك", Norm.of("كرسى متحرك"))
        assertEquals("cipro 500 mg", Norm.of("  CIPRO   500 mg "))
        assertEquals("ادويه اسبرين", Norm.of("أدوية إسبرين"))
        assertEquals("مرحبا", Norm.of("مَرْحَبًا"))
        assertEquals("الحمي ه", Norm.of("الحُمَّى ة"))
        assertEquals("tamiflu 75 mg", Norm.of("TAMIFLU 75 MG"))
        assertEquals("30 كبسول", Norm.of("٣٠ كبسول"))
        assertEquals("اسيا 20 مجم", Norm.of("آسيا ٢٠ مجم"))
        assertEquals("ئيء", Norm.of("ئيء"))
        assertEquals("étude 5", Norm.of("Étude 5"))
        assertEquals("", Norm.of(" "))
    }

    @Test
    fun nullAndBlank() {
        assertEquals("", Norm.of(null))
        assertEquals("", Norm.of("   "))
    }
}
