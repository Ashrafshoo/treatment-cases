package com.treatmentcases.app

data class CaseRecord(
 val id:Long=0, val region:String="", val sector:String="", val name:String="", val performanceNo:String="",
 val medicine:String="", val strength:String="", val extra1:String="", val extra2:String="", val duration:String="",
 val dosage:String="", val condition:String="", val approvalDate:String="", val approvalExpiry:String=""
) {
 fun cells()=listOf(region,sector,name,performanceNo,medicine,strength,extra1,extra2,duration,dosage,condition,approvalDate,approvalExpiry)
 companion object {
  val headers=listOf("المنطقة","القطاع","الاسم","رقم الأداء","اسم الدواء","التركيز/العيار","بيان إضافي 1","بيان إضافي 2","مدة الصرف","الجرعة","الحالة المرضية","تاريخ الموافقة","انتهاء الموافقة")
  fun from(c:List<String>)=CaseRecord(region=c.getOrElse(0){""},sector=c.getOrElse(1){""},name=c.getOrElse(2){""},performanceNo=c.getOrElse(3){""},medicine=c.getOrElse(4){""},strength=c.getOrElse(5){""},extra1=c.getOrElse(6){""},extra2=c.getOrElse(7){""},duration=c.getOrElse(8){""},dosage=c.getOrElse(9){""},condition=c.getOrElse(10){""},approvalDate=c.getOrElse(11){""},approvalExpiry=c.getOrElse(12){""})
 }
}
