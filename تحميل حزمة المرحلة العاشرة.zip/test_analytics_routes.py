import http.client, tempfile, threading, unittest, sqlite3
from pathlib import Path
from http.server import ThreadingHTTPServer
from urllib.parse import urlencode
import app, security, management
from test_fixtures import create_test_db

class AnalyticsRouteTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.old_db=app.DB; self.old_auth=app.AUTH_DB
        app.DB=create_test_db(Path(self.tmp.name)/'med.db'); app.AUTH_DB=Path(self.tmp.name)/'auth.sqlite3'
        c=sqlite3.connect(app.DB)
        c.executescript("CREATE TABLE Medicine_Dictionary(medicine_id INTEGER PRIMARY KEY,medicine_name TEXT); CREATE TABLE Medicine_Name_Aliases(raw_alias TEXT,medicine_id INTEGER);")
        c.execute("INSERT INTO Medicine_Dictionary(medicine_name) VALUES('دواء تجريبي')"); c.commit(); c.close()
        management.initialize(app.DB); security.initialize(app.AUTH_DB)
        security.create_user(app.AUTH_DB,'manager','مدير','Strong-Manager-Password-2026','manager')
        self.server=ThreadingHTTPServer(('127.0.0.1',0),app.Handler)
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True); self.thread.start()
        self.conn=http.client.HTTPConnection('127.0.0.1',self.server.server_port)
        body=urlencode({'username':'manager','password':'Strong-Manager-Password-2026'})
        self.conn.request('POST','/login',body,{'Content-Type':'application/x-www-form-urlencoded'})
        r=self.conn.getresponse(); self.cookie=r.getheader('Set-Cookie').split(';',1)[0]; r.read()
    def tearDown(self):
        self.conn.close(); self.server.shutdown(); self.server.server_close(); self.thread.join(timeout=2)
        app.DB=self.old_db; app.AUTH_DB=self.old_auth; self.tmp.cleanup()
    def test_analytics_page(self):
        self.conn.request('GET','/analytics',headers={'Cookie':self.cookie})
        r=self.conn.getresponse(); body=r.read(); self.assertEqual(r.status,200); self.assertIn('مركز الإحصائيات'.encode(),body)
    def test_alerts_page(self):
        self.conn.request('GET','/alerts',headers={'Cookie':self.cookie})
        r=self.conn.getresponse(); body=r.read(); self.assertEqual(r.status,200); self.assertIn('مركز التنبيهات'.encode(),body)
    def test_analytics_excel_export(self):
        self.conn.request('GET','/analytics.xlsx',headers={'Cookie':self.cookie})
        r=self.conn.getresponse(); body=r.read(); self.assertEqual(r.status,200)
        self.assertIn('spreadsheetml',r.getheader('Content-Type')); self.assertTrue(body.startswith(b'PK'))

if __name__=='__main__': unittest.main()
