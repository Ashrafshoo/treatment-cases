from pathlib import Path
import sqlite3

ROOT = Path(__file__).resolve().parents[1]
SCHEMA = ROOT / "android-app/src/main/assets/database/001_initial_schema.sql"
INTEGRITY = ROOT / "android-app/src/main/assets/database/005_relationship_financial_integrity.sql"
LEASE_INTEGRITY = ROOT / "android-app/src/main/assets/database/006_active_lease_integrity.sql"


def database():
    db = sqlite3.connect(":memory:")
    db.execute("PRAGMA foreign_keys=ON")
    db.executescript(SCHEMA.read_text(encoding="utf-8"))
    db.executescript(INTEGRITY.read_text(encoding="utf-8"))
    db.executescript(LEASE_INTEGRITY.read_text(encoding="utf-8"))
    db.execute("INSERT INTO properties(id,name) VALUES('p','عقار تجريبي')")
    db.execute("INSERT INTO units(id,property_id,unit_number) VALUES('u','p','1')")
    db.execute("INSERT INTO tenants(id,full_name) VALUES('t','مستأجر تجريبي')")
    db.execute("INSERT INTO leases(id,unit_id,tenant_id,start_date) VALUES('l','u','t','2026-01-01')")
    return db


def test_stage14_ownership_share_overlap_is_blocked_but_adjacent_period_is_allowed():
    db = database()
    db.execute("INSERT INTO owners(id,full_name) VALUES('o1','مالك 1')")
    db.execute("INSERT INTO owners(id,full_name) VALUES('o2','مالك 2')")
    db.execute("INSERT INTO ownership_shares(id,property_id,owner_id,share_percent,valid_from,valid_to) VALUES('s1','p','o1',60,'2026-01-01','2026-12-31')")
    try:
        db.execute("INSERT INTO ownership_shares(id,property_id,owner_id,share_percent,valid_from,valid_to) VALUES('s2','p','o2',50,'2026-06-01','2027-01-01')")
        assert False, "overlapping ownership shares above 100% must be rejected"
    except sqlite3.IntegrityError as exc:
        assert "ownership_share_total_exceeds_100" in str(exc)
    db.execute("INSERT INTO ownership_shares(id,property_id,owner_id,share_percent,valid_from,valid_to) VALUES('s3','p','o2',50,'2027-01-01','2027-12-31')")
    db.close()


def test_approved_rent_history_periods_cannot_overlap():
    db = database()
    db.execute("INSERT INTO rent_history(id,lease_id,amount_minor,valid_from,valid_to,approval_status) VALUES('rh1','l',100000,'2026-01-01','2026-06-30','approved')")
    try:
        db.execute("INSERT INTO rent_history(id,lease_id,amount_minor,valid_from,approval_status) VALUES('rh2','l',110000,'2026-06-30','approved')")
        assert False, "overlapping approved rent periods must be rejected"
    except sqlite3.IntegrityError as exc:
        assert "approved_rent_history_period_overlap" in str(exc)
    db.execute("INSERT INTO rent_history(id,lease_id,amount_minor,valid_from,approval_status) VALUES('rh3','l',110000,'2026-07-01','approved')")
    db.close()


def test_negative_rent_history_is_rejected():
    db = database()
    try:
        db.execute("INSERT INTO rent_history(id,lease_id,amount_minor,valid_from) VALUES('bad','l',-1,'2026-01-01')")
        assert False, "negative rent history must be rejected"
    except sqlite3.IntegrityError as exc:
        assert "rent_amount_must_be_nonnegative" in str(exc)
    db.close()


def test_payment_period_must_be_valid():
    db = database()
    for start, end in [(None, "2026-01-31"), ("2026-02-01", "2026-01-31")]:
        try:
            db.execute("INSERT INTO payments(id,lease_id,paid_at,amount_minor,period_start,period_end) VALUES(?,?,?,?,?,?)",
                       (f"bad-{start}", "l", "2026-01-01", 100, start, end))
            assert False, "invalid payment period must be rejected"
        except sqlite3.IntegrityError as exc:
            assert "invalid_payment_period" in str(exc)
    db.execute("INSERT INTO payments(id,lease_id,paid_at,amount_minor,period_start,period_end) VALUES('ok','l','2026-01-01',100,'2026-01-01','2026-01-31')")
    db.close()


def test_receipt_must_match_its_payment_lease():
    db = database()
    db.execute("INSERT INTO payments(id,lease_id,paid_at,amount_minor) VALUES('pay','l','2026-01-01',100)")
    db.execute("INSERT INTO units(id,property_id,unit_number) VALUES('u2','p','2')")
    db.execute("INSERT INTO tenants(id,full_name) VALUES('t2','مستأجر آخر')")
    db.execute("INSERT INTO leases(id,unit_id,tenant_id,start_date) VALUES('l2','u2','t2','2026-01-01')")
    try:
        db.execute("INSERT INTO receipts(id,payment_id,lease_id,receipt_number,issued_at,amount_minor) VALUES('r','pay','l2','R1','2026-01-01',100)")
        assert False, "receipt/payment lease mismatch must be rejected"
    except sqlite3.IntegrityError as exc:
        assert "receipt_payment_lease_mismatch" in str(exc)
    db.execute("INSERT INTO receipts(id,payment_id,lease_id,receipt_number,issued_at,amount_minor) VALUES('r2','pay','l','R2','2026-01-01',100)")
    db.close()


def test_database_encryption_is_wired_and_plaintext_database_is_not_overwritten():
    db_source = (ROOT / "android-app/src/main/java/com/familyproperties/app/FamilyDatabase.kt").read_text(encoding="utf-8")
    key_source = (ROOT / "android-app/src/main/java/com/familyproperties/app/security/DatabaseKeyStore.kt").read_text(encoding="utf-8")
    repo_source = (ROOT / "android-app/src/main/java/com/familyproperties/app/PropertyRepository.kt").read_text(encoding="utf-8")
    gradle = (ROOT / "android-app/build.gradle.kts").read_text(encoding="utf-8")
    assert "net.zetetic.database.sqlcipher.SQLiteOpenHelper" in db_source
    assert 'System.loadLibrary("sqlcipher")' in db_source
    assert "isPlaintextSqlite" in db_source and "has not been changed or deleted" in db_source
    assert "AndroidKeyStore" in key_source and "AES/GCM/NoPadding" in key_source
    assert "net.zetetic.database.sqlcipher.SQLiteDatabase" in repo_source
    assert "net.zetetic:sqlcipher-android:4.19.1@aar" in gradle
    assert "androidx.sqlite:sqlite:2.7.0" in gradle


def test_integrity_migration_is_registered():
    db = database()
    row = db.execute("SELECT name FROM schema_migrations WHERE version=5").fetchone()
    assert row == ("stage14_relationship_and_financial_integrity_constraints",)
    db.execute("INSERT INTO users(id,username,display_name,role) VALUES('admin','Ashrafshoo','مدير','administrator')")
    try:
        db.execute("INSERT INTO users(id,username,display_name,role) VALUES('duplicate','ashrafshoo','مكرر','family_viewer')")
        assert False, "usernames must be unique regardless of case"
    except sqlite3.IntegrityError:
        pass
    db.close()


def test_first_run_admin_has_no_default_password_and_viewer_role_is_explicit():
    auth = (ROOT / "android-app/src/main/java/com/familyproperties/app/AuthRepository.kt").read_text(encoding="utf-8")
    ui = (ROOT / "android-app/src/main/java/com/familyproperties/app/MainActivity.kt").read_text(encoding="utf-8")
    assert 'const val ADMIN_USERNAME = "Ashrafshoo"' in auth
    assert "createInitialAdministrator" in auth
    assert "family_viewer" in auth and "administrator" in auth
    assert "PBKDF2WithHmacSHA256" in auth and "SecureRandom" in auth
    assert "لا توجد كلمة مرور افتراضية" in ui
    assert "filterNot { it.first == \"استيراد وتصدير Excel\" }" in ui


def test_property_mutations_require_admin_and_write_audit_in_same_transaction():
    repository = (ROOT / "android-app/src/main/java/com/familyproperties/app/PropertyRepository.kt").read_text(encoding="utf-8")
    assert "private fun requireAdministrator()" in repository
    assert "check(session.isAdministrator)" in repository
    assert "db.beginTransaction()" in repository
    assert "appendAudit(db, session" in repository
    assert 'db.insertOrThrow("audit_log"' in repository


def test_key_loss_and_legacy_plaintext_database_fail_closed():
    key_source = (ROOT / "android-app/src/main/java/com/familyproperties/app/security/DatabaseKeyStore.kt").read_text(encoding="utf-8")
    db_source = (ROOT / "android-app/src/main/java/com/familyproperties/app/FamilyDatabase.kt").read_text(encoding="utf-8")
    assert "getExistingWrappingKey" in key_source
    assert "The Android Keystore key is missing" in key_source
    assert "isPlaintextSqlite" in db_source
    assert "a verified encrypted migration is required" in db_source
    assert "onDowngrade" in db_source and "Database downgrade is blocked" in db_source


def test_integrity_update_triggers_reject_invalid_mutations():
    db = database()
    db.execute("INSERT INTO owners(id,full_name) VALUES('o1','مالك 1')")
    db.execute("INSERT INTO owners(id,full_name) VALUES('o2','مالك 2')")
    db.execute("INSERT INTO ownership_shares(id,property_id,owner_id,share_percent,valid_from,valid_to) VALUES('s1','p','o1',60,'2026-01-01','2026-12-31')")
    db.execute("INSERT INTO ownership_shares(id,property_id,owner_id,share_percent,valid_from,valid_to) VALUES('s2','p','o2',30,'2026-01-01','2026-12-31')")
    try:
        db.execute("UPDATE ownership_shares SET share_percent=50 WHERE id='s2'")
        assert False, "share update that exceeds 100% must be rejected"
    except sqlite3.IntegrityError as exc:
        assert "ownership_share_total_exceeds_100" in str(exc)

    db.execute("INSERT INTO rent_history(id,lease_id,amount_minor,valid_from,valid_to,approval_status) VALUES('rh1','l',100000,'2026-01-01','2026-06-30','approved')")
    db.execute("INSERT INTO rent_history(id,lease_id,amount_minor,valid_from,approval_status) VALUES('rh2','l',110000,'2026-07-01','approved')")
    try:
        db.execute("UPDATE rent_history SET valid_from='2026-06-30' WHERE id='rh2'")
        assert False, "rent-history update that overlaps must be rejected"
    except sqlite3.IntegrityError as exc:
        assert "approved_rent_history_period_overlap" in str(exc)
    db.close()


def test_payment_and_receipt_update_triggers_reject_invalid_mutations():
    db = database()
    db.execute("INSERT INTO payments(id,lease_id,paid_at,amount_minor,period_start,period_end) VALUES('pay1','l','2026-01-01',100,'2026-01-01','2026-01-31')")
    try:
        db.execute("UPDATE payments SET period_end='2025-12-31' WHERE id='pay1'")
        assert False, "reversed payment period update must be rejected"
    except sqlite3.IntegrityError as exc:
        assert "invalid_payment_period" in str(exc)

    db.execute("INSERT INTO units(id,property_id,unit_number) VALUES('u2','p','2')")
    db.execute("INSERT INTO tenants(id,full_name) VALUES('t2','مستأجر آخر')")
    db.execute("INSERT INTO leases(id,unit_id,tenant_id,start_date) VALUES('l2','u2','t2','2026-01-01')")
    db.execute("INSERT INTO receipts(id,payment_id,lease_id,receipt_number,issued_at,amount_minor) VALUES('r','pay1','l','R1','2026-01-01',100)")
    try:
        db.execute("UPDATE receipts SET lease_id='l2' WHERE id='r'")
        assert False, "receipt update that points to a different lease must be rejected"
    except sqlite3.IntegrityError as exc:
        assert "receipt_payment_lease_mismatch" in str(exc)
    db.close()


def test_rent_increase_uses_last_applied_date_to_prevent_double_application():
    source = (ROOT / "android-app/src/main/java/com/familyproperties/app/RentRules.kt").read_text(encoding="utf-8")
    assert "lastIncreaseAppliedDate" in source
    assert "lastIncreaseAppliedDate.isBefore(septemberStart)" in source
    assert "LocalDate.of(effectiveDate.year, 9, 1)" in source


def test_property_unit_and_tenant_lists_are_bound_to_repository_data():
    repository = (ROOT / "android-app/src/main/java/com/familyproperties/app/PropertyRepository.kt").read_text(encoding="utf-8")
    ui = (ROOT / "android-app/src/main/java/com/familyproperties/app/MainActivity.kt").read_text(encoding="utf-8")
    for method in ("listProperties", "listUnits", "listTenants", "updateProperty", "clearModifiedMarker"):
        assert f"fun {method}" in repository
    for screen in ("PropertyListScreen", "UnitListScreen", "TenantListScreen"):
        assert f"fun {screen}" in ui
    assert '"العقارات" -> PropertyListScreen' in ui
    assert '"الوحدات" -> UnitListScreen' in ui
    assert '"المستأجرون" -> TenantListScreen' in ui


def test_property_updates_keep_modified_marker_until_admin_clears_it():
    repository = (ROOT / "android-app/src/main/java/com/familyproperties/app/PropertyRepository.kt").read_text(encoding="utf-8")
    assert 'put("modified_unreviewed", 1)' in repository
    assert 'put("modified_unreviewed", 0)' in repository
    assert 'appendAudit(db, session, "update", "property"' in repository
    assert 'appendAudit(db, session, "archive", "property"' in repository


def test_property_unit_tenant_repository_queries_match_schema_columns():
    db = database()
    property_columns = {row[1] for row in db.execute("PRAGMA table_info(properties)")}
    unit_columns = {row[1] for row in db.execute("PRAGMA table_info(units)")}
    tenant_columns = {row[1] for row in db.execute("PRAGMA table_info(tenants)")}
    assert {"address_text", "notes", "review_status", "modified_unreviewed", "is_highlighted", "archived_at"} <= property_columns
    assert {"unit_number", "unit_type", "occupancy_status", "current_tenant_id", "old_law_164_2025", "modified_unreviewed"} <= unit_columns
    assert {"full_name", "phone", "notes", "archived_at"} <= tenant_columns
    unit_query = db.execute(
        "SELECT u.id, u.property_id, p.name, COALESCE(u.unit_number,''), COALESCE(u.unit_type,''), "
        "u.occupancy_status, t.full_name, u.review_status, u.old_law_164_2025, u.modified_unreviewed "
        "FROM units u JOIN properties p ON p.id = u.property_id "
        "LEFT JOIN tenants t ON t.id = u.current_tenant_id "
        "WHERE u.archived_at IS NULL AND p.archived_at IS NULL ORDER BY p.name COLLATE NOCASE, u.unit_number"
    ).fetchone()
    assert unit_query[0] == "u" and unit_query[2] == "عقار تجريبي"
    db.close()


def test_property_review_highlight_and_modified_markers_are_stored_independently():
    db = database()
    db.execute("UPDATE properties SET review_status='sound', is_highlighted=1, modified_unreviewed=1 WHERE id='p'")
    row = db.execute("SELECT review_status,is_highlighted,modified_unreviewed FROM properties WHERE id='p'").fetchone()
    assert row == ("sound", 1, 1)
    db.execute("UPDATE properties SET modified_unreviewed=0 WHERE id='p'")
    row = db.execute("SELECT review_status,is_highlighted,modified_unreviewed FROM properties WHERE id='p'").fetchone()
    assert row == ("sound", 1, 0)
    db.close()


def test_general_expense_module_uses_integer_minor_units_and_is_admin_gated():
    repository = (ROOT / "android-app/src/main/java/com/familyproperties/app/PropertyRepository.kt").read_text(encoding="utf-8")
    ui = (ROOT / "android-app/src/main/java/com/familyproperties/app/MainActivity.kt").read_text(encoding="utf-8")
    assert "fun listExpenses()" in repository and "fun addExpense(" in repository
    assert "LeaseRules.egpToMinorUnits(amountEgp)" in repository
    assert 'insertChecked("expenses"' in repository
    assert '"المصروفات" -> ExpenseListScreen' in ui
    assert "ExpenseListScreen" in ui and "التاريخ YYYY-MM-DD" in ui


def test_expense_schema_rejects_negative_values_and_stores_general_fields():
    db = database()
    columns = {row[1] for row in db.execute("PRAGMA table_info(expenses)")}
    assert {"name", "amount_minor", "expense_date", "notes", "archived_at"} <= columns
    db.execute("INSERT INTO expenses(id,name,amount_minor,expense_date,notes) VALUES('e1','فاتورة',12550,'2026-11-01','فاتورة كهرباء')")
    assert db.execute("SELECT amount_minor,notes FROM expenses WHERE id='e1'").fetchone() == (12550, "فاتورة كهرباء")
    try:
        db.execute("INSERT INTO expenses(id,name,amount_minor,expense_date) VALUES('e2','قيمة سالبة',-1,'2026-11-01')")
        assert False, "negative expenses must be rejected"
    except sqlite3.IntegrityError:
        pass
    db.close()
