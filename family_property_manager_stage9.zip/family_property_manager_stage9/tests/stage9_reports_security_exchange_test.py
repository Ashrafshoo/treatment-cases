import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCHEMA = ROOT / 'app' / 'assets' / 'database' / '001_initial_schema.sql'


def db_with_sample():
    db = sqlite3.connect(':memory:')
    db.execute('PRAGMA foreign_keys=ON')
    for statement in SCHEMA.read_text(encoding='utf-8').split(';'):
        if statement.strip():
            db.execute(statement)
    db.execute("CREATE TRIGGER approved_receipt_no_update BEFORE UPDATE ON receipts WHEN OLD.approved=1 BEGIN SELECT RAISE(ABORT, 'approved_receipt_is_immutable'); END")
    db.execute("CREATE TRIGGER approved_receipt_no_delete BEFORE DELETE ON receipts WHEN OLD.approved=1 BEGIN SELECT RAISE(ABORT, 'approved_receipt_is_immutable'); END")
    db.execute("INSERT INTO properties(id,name) VALUES('p1','عقار تجريبي')")
    db.execute("INSERT INTO tenants(id,full_name) VALUES('t1','مستأجر تجريبي')")
    db.execute("INSERT INTO units(id,property_id,unit_number,unit_type,current_tenant_id) VALUES('u1','p1','1','سكني','t1')")
    db.execute("INSERT INTO leases(id,unit_id,tenant_id,start_date,initial_rent_minor,status) VALUES('l1','u1','t1','2026-01-01',100000,'active')")
    db.execute("INSERT INTO rent_history(id,lease_id,amount_minor,valid_from) VALUES('rh1','l1',100000,'2026-01-01')")
    return db


def test_stage9_schema_has_receipt_snapshot_and_indexes():
    db = db_with_sample()
    cols = {r[1] for r in db.execute('PRAGMA table_info(receipts)')}
    assert 'law_164_2025_snapshot' in cols
    indexes = {r[1] for r in db.execute("SELECT * FROM sqlite_master WHERE type='index'")}
    assert {'idx_payments_paid_at', 'idx_expenses_month', 'idx_increases_lease_date', 'idx_notifications_entity_due', 'idx_receipts_issued_at'} <= indexes
    assert db.execute('PRAGMA foreign_key_check').fetchall() == []


def test_reports_period_totals_and_net_income():
    db = db_with_sample()
    db.execute("INSERT INTO payments(id,lease_id,paid_at,amount_minor) VALUES('pay1','l1','2026-02-05',75000)")
    db.execute("INSERT INTO expenses(id,name,amount_minor,expense_date) VALUES('e1','فاتورة تجريبية',15000,'2026-02-07')")
    row = db.execute('''SELECT
      COALESCE((SELECT SUM(amount_minor) FROM payments WHERE paid_at BETWEEN ? AND ?),0),
      COALESCE((SELECT SUM(amount_minor) FROM expenses WHERE archived_at IS NULL AND expense_date BETWEEN ? AND ?),0)
    ''', ('2026-02-01','2026-02-28','2026-02-01','2026-02-28')).fetchone()
    collected, expenses = row
    assert collected == 75000
    assert expenses == 15000
    assert collected - expenses == 60000


def test_receipt_snapshots_preserve_law_marker_and_approved_immutability():
    db = db_with_sample()
    db.execute("UPDATE leases SET law_164_2025_applies=1 WHERE id='l1'")
    law = db.execute('SELECT law_164_2025_applies FROM leases WHERE id=?', ('l1',)).fetchone()[0]
    db.execute("INSERT INTO receipts(id,lease_id,receipt_number,issued_at,amount_minor,law_164_2025_snapshot,approved) VALUES('r1','l1','R-1','2026-02-05',75000,?,1)", (law,))
    assert db.execute("SELECT law_164_2025_snapshot FROM receipts WHERE id='r1'").fetchone()[0] == 1
    try:
        db.execute("UPDATE receipts SET amount_minor=1 WHERE id='r1'")
    except sqlite3.IntegrityError:
        pass
    else:
        raise AssertionError('Approved receipt was editable')


def test_rent_increase_history_keeps_old_value():
    db = db_with_sample()
    db.execute("UPDATE rent_history SET valid_to='2026-08-31' WHERE id='rh1'")
    db.execute("INSERT INTO rent_history(id,lease_id,amount_minor,valid_from,source_type) VALUES('rh2','l1',115000,'2026-09-01','increase')")
    rows = db.execute("SELECT amount_minor,valid_from,valid_to FROM rent_history WHERE lease_id='l1' ORDER BY valid_from").fetchall()
    assert rows == [(100000, '2026-01-01', '2026-08-31'), (115000, '2026-09-01', None)]


def test_stage9_security_and_features_are_wired_not_placeholder():
    auth = (ROOT / 'app/lib/features/auth/data/auth_repository.dart').read_text()
    session = (ROOT / 'app/lib/features/auth/data/app_session.dart').read_text()
    payments = (ROOT / 'app/lib/features/payments/services/receipt_print_service.dart').read_text()
    exchange = (ROOT / 'app/lib/features/data_exchange/data/excel_exchange_repository.dart').read_text()
    assert 'Pbkdf2' in auth and '210000' in auth
    assert 'requireAdmin' in session
    assert 'PdfPageFormat.a4' in payments and 'take(3)' in payments
    assert 'Excel.decodeBytes' in exchange and 'exportAll' in exchange


if __name__ == '__main__':
    for test in [test_stage9_schema_has_receipt_snapshot_and_indexes,
                 test_reports_period_totals_and_net_income,
                 test_receipt_snapshots_preserve_law_marker_and_approved_immutability,
                 test_rent_increase_history_keeps_old_value,
                 test_stage9_security_and_features_are_wired_not_placeholder]:
        test()
    print('Stage 9 tests: 5/5 passed')


def test_ownership_share_overlap_validation_math():
    db = db_with_sample()
    db.execute("INSERT INTO owners(id,full_name) VALUES('o1','مالك 1')")
    db.execute("INSERT INTO owners(id,full_name) VALUES('o2','مالك 2')")
    db.execute("INSERT INTO ownership_shares(id,property_id,owner_id,share_percent,valid_from,valid_to) VALUES('s1','p1','o1',60,'2020-01-01',NULL)")
    overlapping = db.execute("SELECT COALESCE(SUM(share_percent),0) FROM ownership_shares WHERE property_id=? AND (valid_to IS NULL OR valid_to>=?) AND (? IS NULL OR valid_from IS NULL OR valid_from<=?)", ('p1','2025-01-01',None,'9999-12-31')).fetchone()[0]
    assert overlapping == 60
    assert overlapping + 40 == 100
    assert overlapping + 45 > 100


def test_monthly_rent_statement_uses_approved_rent_and_payments():
    db = db_with_sample()
    db.execute("INSERT INTO payments(id,lease_id,paid_at,amount_minor) VALUES('pay2','l1','2026-02-10',40000)")
    row = db.execute('''
      SELECT p.name,u.unit_number,t.full_name,
        COALESCE((SELECT rh.amount_minor FROM rent_history rh WHERE rh.lease_id=l.id AND rh.approval_status='approved' AND rh.valid_from<=? AND (rh.valid_to IS NULL OR rh.valid_to>=?) ORDER BY rh.valid_from DESC LIMIT 1),l.initial_rent_minor,0) AS due,
        COALESCE((SELECT SUM(pay.amount_minor) FROM payments pay WHERE pay.lease_id=l.id AND pay.paid_at BETWEEN ? AND ?),0) AS paid
      FROM leases l JOIN units u ON u.id=l.unit_id JOIN properties p ON p.id=u.property_id JOIN tenants t ON t.id=l.tenant_id
      WHERE l.start_date<=? AND (COALESCE(l.manual_end_date,l.calculated_end_date) IS NULL OR COALESCE(l.manual_end_date,l.calculated_end_date)>=?)
    ''', ('2026-02-28','2026-02-01','2026-02-01','2026-02-28','2026-02-28','2026-02-01')).fetchone()
    assert row == ('عقار تجريبي','1','مستأجر تجريبي',100000,40000)


def test_project_has_group_and_owner_management_wired():
    records = (ROOT / 'app/lib/features/records/data/records_repository.dart').read_text()
    screen = (ROOT / 'app/lib/features/records/presentation/records_screen.dart').read_text()
    assert 'savePropertyGroup' in records and 'saveOwnershipShare' in records
    assert "Tab(text: 'الملاك')" in screen and "Tab(text: 'حصص الملكية')" in screen


def test_encrypted_backup_includes_database_and_archive_files():
    backup = (ROOT / 'app/lib/features/settings/data/backup_repository.dart').read_text()
    assert 'AesGcm.with256bits()' in backup
    assert 'ZipEncoder' in backup and 'ZipDecoder' in backup
    assert "'property_archive/'" in backup
    assert 'PRAGMA quick_check' in backup and 'PRAGMA foreign_key_check' in backup


def test_receipt_pdf_has_a4_three_per_page_and_arabic_font():
    service = (ROOT / 'app/lib/features/payments/services/receipt_print_service.dart').read_text()
    font = ROOT / 'app/assets/fonts/NotoSansArabic-Regular.ttf'
    assert font.exists() and font.stat().st_size > 10000
    assert 'PdfPageFormat.a4' in service and 'start+=3' in service and 'take(3)' in service


def test_excel_import_is_transactional_and_routes_existing_changes_to_review():
    exchange = (ROOT / 'app/lib/features/data_exchange/data/excel_exchange_repository.dart').read_text()
    assert 'db.transaction' in exchange
    assert "tx.insert('review_items'" in exchange
    assert "'under_review'" in exchange
    assert "'rent_history'" in exchange and "'rent_increases'" in exchange


def test_auth_repository_and_all_write_repositories_require_admin():
    for relative in [
        'app/lib/features/records/data/records_repository.dart',
        'app/lib/features/leases/data/leases_repository.dart',
        'app/lib/features/payments/data/payments_repository.dart',
        'app/lib/features/expenses/data/expenses_repository.dart',
        'app/lib/features/archive_review/data/archive_review_repository.dart',
        'app/lib/features/notifications/data/lease_schedule_service.dart',
        'app/lib/features/settings/data/backup_repository.dart',
    ]:
        source = (ROOT / relative).read_text()
        assert 'requireAdmin' in source, relative


def test_modified_flags_exist_for_all_editable_record_types():
    db = db_with_sample()
    for table in ['properties','units','tenants','owners','ownership_shares','leases','expenses']:
        columns = {r[1] for r in db.execute(f'PRAGMA table_info({table})')}
        assert 'modified_unreviewed' in columns, table
    assert db.execute('SELECT MAX(version) FROM schema_migrations').fetchone()[0] == 4


def test_archive_and_review_source_supports_manual_clear_and_modified_state():
    records = (ROOT / 'app/lib/features/records/data/records_repository.dart').read_text()
    review = (ROOT / 'app/lib/features/archive_review/data/archive_review_repository.dart').read_text()
    assert 'clearModifiedFlag' in records
    assert "'review_status':'needs_review'" in records
    assert "'modified_unreviewed':rejected>0?1:0" in review


def test_monthly_statement_keeps_approved_due_when_review_is_pending():
    db = db_with_sample()
    db.execute("INSERT INTO rent_history(id,lease_id,amount_minor,valid_from,approval_status) VALUES('rh-pending','l1',125000,'2026-02-01','under_review')")
    row = db.execute('''
      SELECT COALESCE((SELECT rh.amount_minor FROM rent_history rh
        WHERE rh.lease_id=l.id AND rh.approval_status='approved'
          AND rh.valid_from<=? AND (rh.valid_to IS NULL OR rh.valid_to>=?)
        ORDER BY rh.valid_from DESC LIMIT 1),l.initial_rent_minor,0) AS due_minor,
        CASE WHEN EXISTS(SELECT 1 FROM rent_history pending
          WHERE pending.lease_id=l.id AND pending.approval_status='under_review')
          THEN 1 ELSE 0 END AS has_pending_rent_review
      FROM leases l WHERE l.id='l1'
    ''', ('2026-02-28','2026-02-01')).fetchone()
    assert row == (100000, 1)


def test_historical_statement_includes_ended_and_terminated_leases_by_dates():
    db = db_with_sample()
    db.execute("UPDATE leases SET status='ended',calculated_end_date='2026-02-15' WHERE id='l1'")
    historical = db.execute('''SELECT COUNT(*) FROM leases l
      WHERE l.start_date<=? AND (COALESCE(l.manual_end_date,l.calculated_end_date) IS NULL
        OR COALESCE(l.manual_end_date,l.calculated_end_date)>=?)
        AND l.status<>'suspended' ''', ('2026-02-28','2026-02-01')).fetchone()[0]
    future_month = db.execute('''SELECT COUNT(*) FROM leases l
      WHERE l.start_date<=? AND (COALESCE(l.manual_end_date,l.calculated_end_date) IS NULL
        OR COALESCE(l.manual_end_date,l.calculated_end_date)>=?)
        AND l.status<>'suspended' ''', ('2026-03-31','2026-03-01')).fetchone()[0]
    assert historical == 1
    assert future_month == 0
    db.execute("UPDATE leases SET status='terminated' WHERE id='l1'")
    terminated_historical = db.execute("SELECT COUNT(*) FROM leases WHERE status<>'suspended' AND start_date<='2026-02-28' AND calculated_end_date>='2026-02-01'").fetchone()[0]
    assert terminated_historical == 1


def test_law164_residential_rule_is_not_blocked_and_commercial_is_not_forced_to_15():
    source = (ROOT / 'app/lib/features/notifications/data/lease_schedule_service.dart').read_text(encoding='utf-8')
    ui = (ROOT / 'app/lib/features/leases/presentation/leases_screen.dart').read_text(encoding='utf-8')
    assert "(!automaticLaw164&&(rule=='none'||rule=='manual_dates'))" in source
    assert 'final automaticLaw164=law164&&residential;' in source
    assert "final percent=automaticLaw164?15.0:(lease['annual_increase_percent'] as num?)?.toDouble();" in source
    assert "final _increase = TextEditingController();" in ui
    assert 'if (_law164 && _residential)' in ui
    assert "else { _increase.clear(); _increaseRule = 'none'; }" in ui


def test_monthly_report_source_exposes_review_flag_without_zeroing_due():
    source = (ROOT / 'app/lib/features/reports/data/reports_repository.dart').read_text(encoding='utf-8')
    assert 'AS has_pending_rent_review' in source
    assert "l.status <> 'suspended'" in source
    assert "l.status NOT IN ('terminated','suspended','ended')" not in source
    statement = source[source.index('monthlyRentStatement'):source.index('Future<List<Map<String, Object?>>> annual')]
    assert "rh.approval_status='approved'" in statement
    assert "pending.approval_status='under_review'" in statement
    assert 'CASE WHEN EXISTS' in statement and 'THEN 0 ELSE l.initial_rent_minor' in statement
