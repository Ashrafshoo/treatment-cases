# طريقة البناء عبر GitHub Actions

## بنية المستودع المطلوبة

يبقى التطبيق نفسه مضغوطاً في ملف ZIP واحد في جذر المستودع، مثلاً:

- `family_property_manager_stage12.zip`
- `.github/workflows/android-build.yml`

لا يحتاج المستودع إلى فك ملفات التطبيق داخله. يقوم GitHub Actions بفك الأرشيف داخل مجلد مؤقت في بيئة البناء.

## ما ينفذه Action

1. تنزيل المستودع.
2. التحقق من وجود الأرشيف المحدد `family_property_manager_stage12.zip` في جذر المستودع (يمكن إبقاء ملفات ZIP القديمة دون استخدامها).
3. فك الأرشيف واكتشاف مجلد `app` الذي يحتوي `pubspec.yaml`.
4. إنشاء ملفات Android الأساسية عند عدم وجودها.
5. ضبط `FlutterFragmentActivity` وأذونات البصمة ومنع Android Auto Backup ورفع الحد الأدنى إلى API 23.
6. تشغيل `flutter pub get` و`dart format` و`flutter analyze` و`flutter test`.
7. بناء APK تجريبي Debug ورفعه كـ GitHub Actions Artifact.

## حدود النسخة

- ملف APK الناتج تجريبي Debug، وليس إصداراً إنتاجياً موقعاً بمفتاح نشر خاص.
- لا يتم رفع بيانات العائلة أو ملفات Excel الحقيقية أو المستندات إلى GitHub.
- نجاح الاختبارات المساندة في Python لا يغني عن نجاح Dart/Flutter Action أو اختبار الهاتف.
- إصدار Release موقّع يحتاج إعداد مفتاح توقيع Android بأسرار GitHub، دون وضع المفتاح داخل المستودع.
