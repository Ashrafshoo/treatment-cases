import 'package:flutter_test/flutter_test.dart';
import 'package:family_property_manager/app.dart';

void main() {
  testWidgets('shows Arabic login screen', (tester) async {
    await tester.pumpWidget(const FamilyPropertyApp());

    expect(find.text('إدارة أملاك العائلة'), findsOneWidget);
    expect(find.text('تسجيل الدخول إلى حسابك'), findsOneWidget);
  });
}
