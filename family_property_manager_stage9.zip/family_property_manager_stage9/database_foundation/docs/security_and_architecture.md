# Architecture and privacy requirements

1. Android first; keep domain/data layers platform-neutral for later iOS/desktop clients.
2. Flutter presentation layer must not access SQLite directly. Use repositories/use-cases.
3. Drift owns typed database access and versioned migrations.
4. Encrypt the database at rest with a vetted SQLCipher-compatible integration. SQLite alone is not encryption.
5. Store encryption keys using Android Keystore-backed secure storage; never hard-code keys.
6. Hash passwords with a modern password-hashing scheme (Argon2id or platform-appropriate vetted equivalent); never store plaintext passwords.
7. Use Android biometric APIs only as an unlock convenience; biometric templates remain with Android.
8. Keep property/tenant data and backups out of Git repositories and cloud build services.
9. Encrypt exported update packages; include device ID, package ID, schema version, creation time, and integrity/authentication metadata.
10. Preview imports, create a backup, detect duplicates/conflicts, then apply transactionally.
11. Do not auto-resolve concurrent edits. Present both versions for administrator decision.
12. Use archive/soft-delete for important records. Preserve receipts, payments, contracts and audit history.
13. Family viewers are read-only and cannot print/export/import or manage accounts.
14. Add automated tests for migrations, financial calculations, access control, import idempotency, and backup/restore.
