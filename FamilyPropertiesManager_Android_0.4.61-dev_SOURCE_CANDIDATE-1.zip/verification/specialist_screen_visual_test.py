from pathlib import Path
root = Path(__file__).resolve().parents[1]
components = (root / 'app/src/main/java/com/example/rentals/ui/components/PropertyComponents.kt').read_text()
assert 'fun PremiumScreenHeader(' in components
assert 'RoundedCornerShape(24.dp)' in components
assert 'primaryContainer' in components and 'onPrimaryContainer' in components
screens = {
    'units': ('features/units/UnitsScreen.kt', 'PremiumScreenHeader("الوحدات والعقارات"'),
    'contracts': ('features/contracts/ContractsArchiveScreen.kt', 'PremiumScreenHeader("العقود والمستندات"'),
    'finance': ('features/finance/FinanceScreen.kt', 'PremiumScreenHeader("الدفتر المالي"'),
    'collection': ('features/printing/MonthlyCollectionScreen.kt', 'PremiumScreenHeader("التحصيل الشهري والإيصالات"'),
    'settings': ('features/settings/SettingsScreen.kt', 'PremiumScreenHeader("الإعدادات والتخصيص"'),
}
for name, (path, token) in screens.items():
    source = (root / 'app/src/main/java/com/example/rentals' / path).read_text()
    assert token in source, f'{name} screen missing shared premium header'
collection = (root / 'app/src/main/java/com/example/rentals/features/printing/MonthlyCollectionScreen.kt').read_text()
assert 'إنشاء الدفعة لا يثبت السداد الفعلي ولا ينشئ قيدًا ماليًا' in collection
assert 'تسجيل النتيجة لا ينشئ إيصال سداد أو قيدًا ماليًا تلقائيًا' in collection
print('PASS: shared premium headers applied to all five specialist screens; collection safeguards retained.')
