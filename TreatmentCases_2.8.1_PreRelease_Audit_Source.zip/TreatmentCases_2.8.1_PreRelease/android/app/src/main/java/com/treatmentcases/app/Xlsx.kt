package com.treatmentcases.app

import android.content.ContentResolver
import android.net.Uri
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Strict XLSX interchange for the app-issued critical-cases template only. */
object Xlsx {
    private const val MAX_FILE_BYTES = 32 * 1024 * 1024
    private const val MAX_EXPANDED_BYTES = 64 * 1024 * 1024
    private const val TEMPLATE_MARKER = "قالب الحالات الحرجة - علاج الحالات حاجة"

    fun read(cr: ContentResolver, uri: Uri): List<CaseRecord> {
        val raw = cr.openInputStream(uri)?.use { input -> readBounded(input, MAX_FILE_BYTES) } ?: error("تعذر فتح الملف")
        require(raw.size in 4..MAX_FILE_BYTES) { "حجم الملف غير صالح أو أكبر من 32 ميجابايت." }
        require(raw[0] == 'P'.code.toByte() && raw[1] == 'K'.code.toByte()) {
            "الملف ليس XLSX صالحاً. استخدم نموذج الحالات الحرجة الصادر من التطبيق."
        }
        val parts = mutableMapOf<String, ByteArray>()
        var expanded = 0L
        ZipInputStream(ByteArrayInputStream(raw)).use { zip ->
            var entries = 0
            while (true) {
                val entry = zip.nextEntry ?: break
                entries++
                require(entries <= 1000) { "ملف Excel يحتوي على عدد غير طبيعي من المكونات." }
                require(!entry.name.startsWith("/") && !entry.name.contains("../") && !entry.name.contains("\\")) {
                    "يحتوي الملف على مسار داخلي غير آمن."
                }
                val remaining = (MAX_EXPANDED_BYTES - expanded).coerceAtLeast(0).toInt()
                val bytes = readBounded(zip, remaining)
                expanded += bytes.size
                parts[entry.name] = bytes
            }
        }
        val workbook = parts["xl/workbook.xml"]?.toString(Charsets.UTF_8)
            ?: error("ملف Excel لا يحتوي على بنية مصنف صحيحة.")
        val rels = parts["xl/_rels/workbook.xml.rels"]?.toString(Charsets.UTF_8)
            ?: error("تعذر قراءة روابط أوراق العمل.")
        val sheetTag = Regex("""<sheet\b[^>]*>""").find(workbook)?.value
            ?: error("لا توجد ورقة بيانات داخل الملف.")
        val relId = Regex("""r:id=[\"']([^\"']+)[\"']""").find(sheetTag)?.groupValues?.get(1)
            ?: error("تعذر تحديد ورقة البيانات.")
        val relation = Regex("""<Relationship\b(?=[^>]*Id=[\"']${Regex.escape(relId)}[\"'])[^>]*/?>""")
            .find(rels)?.value ?: error("رابط ورقة البيانات غير صالح.")
        val target = Regex("""Target=[\"']([^\"']+)[\"']""").find(relation)?.groupValues?.get(1)
            ?: error("مسار ورقة البيانات غير موجود.")
        val sheetPath = if (target.startsWith("/")) target.removePrefix("/") else "xl/${target.removePrefix("./")}" 
        val sheetBytes = parts[sheetPath] ?: error("تعذر العثور على ورقة البيانات.")
        val shared = parts["xl/sharedStrings.xml"]?.let(::readSharedStrings) ?: emptyList()
        val rows = readSheet(sheetBytes, shared)
        require(rows.firstOrNull()?.firstOrNull()?.startsWith(TEMPLATE_MARKER) == true) {
            "هذا ليس نموذج الحالات الحرجة المعتمد. صدّر النموذج الفارغ من داخل التطبيق أولاً."
        }
        val headerIndex = rows.indexOfFirst { row -> row.any { it.trim() == "رقم الأداء" } }
        require(headerIndex >= 0) { "صف عناوين الأعمدة غير موجود." }
        val headers = rows[headerIndex].map { it.trim() }
        require(headers == CaseRecord.headers) {
            "عناوين الأعمدة أو ترتيبها تغير. أعد تصدير النموذج الرسمي ولا تعدّل أسماء الأعمدة."
        }
        val records = rows.drop(headerIndex + 1).mapNotNull { row ->
            val cells = CaseRecord.headers.indices.map { row.getOrElse(it) { "" }.trim() }.toMutableList()
            if (cells.all { it.isBlank() }) return@mapNotNull null
            for (index in listOf(11, 12)) {
                if (cells[index].matches(Regex("\\d+(\\.\\d+)?"))) {
                    val serial = cells[index].toDoubleOrNull()
                    if (serial != null && serial > 1) {
                        val formatter = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).apply {
                            timeZone = java.util.TimeZone.getTimeZone("UTC")
                        }
                        cells[index] = formatter.format(java.util.Date(((serial - 25569.0) * 86400000.0).toLong()))
                    }
                }
            }
            CaseRecord.from(cells)
        }
        require(records.isNotEmpty()) { "النموذج لا يحتوي على سجلات. املأ صفاً واحداً على الأقل قبل الاستيراد." }
        require(records.size <= 10000) { "عدد السجلات يتجاوز الحد الآمن للدفعة الواحدة (10000). قسّم الملف إلى دفعات." }
        return records
    }

    fun writeTemplate(cr: ContentResolver, uri: Uri) {
        val matrix = listOf(
            listOf(TEMPLATE_MARKER, "إصدار 1"),
            listOf("تعليمات الاستخدام", "املأ الصفوف أسفل العناوين فقط. لا تغيّر أسماء الأعمدة أو ترتيبها."),
            listOf("تنسيق التواريخ", "اكتب التاريخ بصيغة yyyy-MM-dd مثل 2026-11-12. اترك الخانة فارغة إذا لم تتوفر المعلومة."),
            CaseRecord.headers
        ) + List(500) { List(CaseRecord.headers.size) { "" } }
        writeMatrix(matrix, 3, cr, uri)
    }

    fun write(rows: List<CaseRecord>, cr: ContentResolver, uri: Uri) {
        val matrix = listOf(
            listOf(TEMPLATE_MARKER, "تصدير بيانات الحالات - إصدار 1"),
            listOf("عدد السجلات", rows.size.toString()),
            listOf("تنسيق التواريخ", "yyyy-MM-dd"),
            CaseRecord.headers
        ) + rows.map { it.cells() }
        writeMatrix(matrix, 3, cr, uri)
    }

    private fun writeMatrix(matrix: List<List<String>>, headerRowIndex: Int, cr: ContentResolver, uri: Uri) {
        val sheetXml = buildString {
            append("<?xml version=\"1.0\" encoding=\"UTF-8\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"4\" topLeftCell=\"A5\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews><cols>")
            val widths = listOf(18,18,28,18,28,18,22,22,16,18,26,18,18)
            widths.forEachIndexed { index, width -> append("<col min=\"${index + 1}\" max=\"${index + 1}\" width=\"$width\" customWidth=\"1\"/>") }
            append("</cols><sheetData>")
            matrix.forEachIndexed { rowIndex, row ->
                append("<row r=\"${rowIndex + 1}\">")
                row.forEachIndexed { colIndex, value ->
                    val style = when { rowIndex == headerRowIndex -> 2; colIndex == 3 -> 1; else -> 0 }
                    append("<c r=\"${columnName(colIndex)}${rowIndex + 1}\" s=\"$style\" t=\"inlineStr\"><is><t xml:space=\"preserve\">${escapeXml(value)}</t></is></c>")
                }
                append("</row>")
            }
            append("</sheetData><autoFilter ref=\"A${headerRowIndex + 1}:M${matrix.size}\"/></worksheet>")
        }
        val bytes = ByteArrayOutputStream()
        ZipOutputStream(bytes).use { zip ->
            fun put(path: String, content: String) {
                zip.putNextEntry(ZipEntry(path))
                zip.write(content.toByteArray(Charsets.UTF_8))
                zip.closeEntry()
            }
            put("[Content_Types].xml", """<?xml version="1.0"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>""")
            put("_rels/.rels", """<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""")
            put("xl/workbook.xml", """<?xml version="1.0"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="الحالات الحرجة" sheetId="1" r:id="rId1"/></sheets></workbook>""")
            put("xl/_rels/workbook.xml.rels", """<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>""")
            put("xl/styles.xml", """<?xml version="1.0"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><numFmts count="1"><numFmt numFmtId="164" formatCode="@"/></numFmts><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><color rgb="FFFFFFFF"/><sz val="11"/><name val="Calibri"/></font></fonts><fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF0759C7"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="0" fontId="1" fillId="1" borderId="0" xfId="0" applyFont="1" applyFill="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles><dxfs count="0"/><tableStyles count="0" defaultTableStyle="TableStyleMedium2" defaultPivotStyle="PivotStyleLight16"/></styleSheet>""")
            put("xl/worksheets/sheet1.xml", sheetXml)
        }
        cr.openOutputStream(uri)?.use { it.write(bytes.toByteArray()) } ?: error("تعذر حفظ ملف Excel")
    }

    private fun readBounded(input: java.io.InputStream, limit: Int): ByteArray {
        val output = ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        var total = 0
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            total += count
            require(total <= limit) { "حجم الملف أو محتوياته أكبر من الحد المسموح." }
            output.write(buffer, 0, count)
        }
        return output.toByteArray()
    }

    private fun readSharedStrings(bytes: ByteArray): List<String> {
        val parser = Xml.newPullParser(); parser.setInput(ByteArrayInputStream(bytes), "UTF-8")
        val result = mutableListOf<String>(); var inItem = false; var value = ""
        while (parser.eventType != XmlPullParser.END_DOCUMENT) {
            when (parser.eventType) {
                XmlPullParser.START_TAG -> if (parser.name == "si") { inItem = true; value = "" }
                XmlPullParser.TEXT -> if (inItem) value += parser.text
                XmlPullParser.END_TAG -> if (parser.name == "si") { result += value; inItem = false }
            }
            parser.next()
        }
        return result
    }

    private fun readSheet(bytes: ByteArray, shared: List<String>): List<List<String>> {
        val parser = Xml.newPullParser(); parser.setInput(ByteArrayInputStream(bytes), "UTF-8")
        val result = mutableListOf<List<String>>(); var row = mutableListOf<String>()
        var reference = "A1"; var type = ""; var value = ""; var active = false
        while (parser.eventType != XmlPullParser.END_DOCUMENT) {
            when (parser.eventType) {
                XmlPullParser.START_TAG -> when (parser.name) {
                    "row" -> row = mutableListOf()
                    "c" -> { reference = parser.getAttributeValue(null, "r") ?: "A1"; type = parser.getAttributeValue(null, "t") ?: ""; value = "" }
                    "v", "t" -> active = true
                }
                XmlPullParser.TEXT -> if (active) value += parser.text
                XmlPullParser.END_TAG -> when (parser.name) {
                    "v", "t" -> active = false
                    "c" -> {
                        val letters = reference.takeWhile { it.isLetter() }
                        var index = 0; letters.forEach { index = index * 26 + (it.uppercaseChar() - 'A' + 1) }; index = (index - 1).coerceAtLeast(0)
                        while (row.size <= index) row.add("")
                        row[index] = if (type == "s") shared.getOrElse(value.toIntOrNull() ?: -1) { "" } else value
                    }
                    "row" -> result += row.toList()
                }
            }
            parser.next()
        }
        return result
    }

    private fun columnName(index: Int): String {
        var n = index + 1; var result = ""
        while (n > 0) { result = ('A' + (n - 1) % 26) + result; n = (n - 1) / 26 }
        return result
    }
    private fun escapeXml(value: String) = value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&apos;")
}
