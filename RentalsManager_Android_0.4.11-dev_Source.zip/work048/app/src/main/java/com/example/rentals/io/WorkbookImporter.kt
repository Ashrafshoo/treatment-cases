package com.example.rentals.io

import android.content.ContentResolver
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.util.zip.ZipInputStream

/** Strict round-trip importer for workbooks produced by WorkbookExporter.
 * It is append-only: existing rows are never updated or deleted. Any PK/UNIQUE/FK conflict
 * aborts the whole transaction, leaving the database unchanged.
 */
object WorkbookImporter {
    data class Preview(val tables: Map<String, Int>, val ignoredSheets: List<String>) {
        val totalRows: Int get() = tables.values.sum()
    }
    private data class Sheet(val name: String, val headers: List<String>, val rows: List<List<String>>)
    private val importOrder = listOf("properties","tenants","units","heirs","leases","ledger","collector_receivables","collection_batches","expenses","heir_payouts","attachments","audit_log","receipts","legacy_import_records")
    private val allowed = importOrder.toSet()

    fun preview(resolver: ContentResolver, uri: Uri, db: SQLiteDatabase): Preview {
        val parsed = readWorkbook(resolver, uri)
        val counts = linkedMapOf<String,Int>()
        val ignored = mutableListOf<String>()
        parsed.sortedBy { importOrder.indexOf(if (it.name == "الوحدات") "units" else it.name).let { n -> if (n < 0) Int.MAX_VALUE else n } }.forEach { s ->
            val table = if (s.name == "الوحدات") "units" else s.name
            if (table !in allowed) { ignored += s.name; return@forEach }
            val actual = columns(db, table).map { it.first }
            require(s.headers == actual) { "أعمدة ورقة ${s.name} لا تطابق بنية جدول $table. صدّر قالبًا جديدًا من التطبيق ولا تغيّر أسماء الأعمدة." }
            require(s.rows.all { it.size <= actual.size }) { "عدد أعمدة غير صحيح في ورقة ${s.name}" }
            counts[table] = s.rows.count { row -> row.any { it.isNotBlank() } }
        }
        require(counts.isNotEmpty()) { "لم يتم العثور على أوراق بيانات معروفة في الملف" }
        return Preview(counts, ignored)
    }

    fun importAppend(resolver: ContentResolver, uri: Uri, db: SQLiteDatabase): Preview {
        val parsed = readWorkbook(resolver, uri)
        val preview = preview(resolver, uri, db)
        db.beginTransaction()
        try {
            parsed.sortedBy { importOrder.indexOf(if (it.name == "الوحدات") "units" else it.name).let { n -> if (n < 0) Int.MAX_VALUE else n } }.forEach { s ->
                val table = if (s.name == "الوحدات") "units" else s.name
                if (table !in allowed) return@forEach
                val cols = columns(db, table)
                val expected = cols.map { it.first }
                require(s.headers == expected) { "تغيرت بنية ورقة $table أثناء الاستيراد" }
                s.rows.forEachIndexed { rowIndex, row ->
                    if (row.none { it.isNotBlank() }) return@forEachIndexed
                    val values = row + List((expected.size-row.size).coerceAtLeast(0)) { "" }
                    val names = mutableListOf<String>()
                    val args = mutableListOf<Any?>()
                    cols.forEachIndexed { i, col ->
                        val value = values.getOrElse(i) { "" }
                        // Empty cells stay NULL for nullable columns; preserve empty text for required text columns.
                        if (!(value.isBlank() && !col.second && !col.third.equals("INTEGER PRIMARY KEY", true))) {
                            names += "`" + col.first + "`"
                            args += if (value.isBlank() && !col.second) null else convert(value, col.third)
                        }
                    }
                    val pk = cols.firstOrNull { it.primary }
                    val pkIndex = pk?.let { expected.indexOf(it.first) } ?: -1
                    val pkValue = if (pkIndex >= 0) values.getOrElse(pkIndex) { "" } else ""
                    if (pkIndex >= 0 && pkValue.isNotBlank()) {
                        val existing = db.rawQuery("SELECT * FROM `$table` WHERE `${pk!!.first}`=?", arrayOf(pkValue)).use { c ->
                            if (!c.moveToFirst()) null else (0 until c.columnCount).map { i -> if (c.isNull(i)) null else c.getString(i) }
                        }
                        if (existing != null) {
                            val same = cols.indices.all { i ->
                                val incoming = values.getOrElse(i) { "" }
                                val stored = existing.getOrNull(i)
                                if (incoming.isBlank() && !cols[i].second) stored == null
                                else when {
                                    cols[i].third.contains("INT", true) -> incoming.toLongOrNull()?.toString() == stored?.toLongOrNull()?.toString()
                                    cols[i].third.contains("REAL", true) || cols[i].third.contains("DOUB", true) || cols[i].third.contains("FLOA", true) -> incoming.replace(",", "").toDoubleOrNull() == stored?.toDoubleOrNull()
                                    else -> incoming == stored
                                }
                            }
                            if (same) return@forEachIndexed
                            throw IllegalArgumentException("تعارض في المعرّف $pkValue داخل جدول $table. السجل الموجود مختلف؛ لم يتم اعتماد أي جزء من الملف.")
                        }
                    }
                    val placeholders = names.joinToString(",") { "?" }
                    val sql = "INSERT INTO `$table` (${names.joinToString(",")}) VALUES ($placeholders)"
                    try { db.execSQL(sql, args.toTypedArray()) }
                    catch (e: Exception) { throw IllegalArgumentException("تعذر إدخال صف ${rowIndex+2} في ورقة $table. غالبًا يوجد معرّف أو سجل فريد مكرر. لم يتم اعتماد أي جزء من الملف. التفاصيل: ${e.message}") }
                }
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        return preview
    }

    private data class Col(val first:String,val second:Boolean,val third:String,val primary:Boolean)
    private fun columns(db:SQLiteDatabase, table:String):List<Col> {
        require(table in allowed)
        val out=mutableListOf<Col>()
        db.rawQuery("PRAGMA table_info(`$table`)",null).use { c -> while(c.moveToNext()) out += Col(c.getString(1),c.getInt(3)!=0,c.getString(2)?:"TEXT",c.getInt(5)!=0) }
        require(out.isNotEmpty()) { "الجدول $table غير موجود في إصدار قاعدة البيانات الحالي" }
        return out
    }
    private fun convert(v:String, type:String):Any = when {
        type.contains("INT",true) -> v.toLongOrNull() ?: throw IllegalArgumentException("قيمة عدد صحيح غير صالحة: $v")
        type.contains("REAL",true) || type.contains("FLOA",true) || type.contains("DOUB",true) || type.contains("NUM",true) -> v.replace(",","").toDoubleOrNull() ?: throw IllegalArgumentException("قيمة رقمية غير صالحة: $v")
        else -> v
    }
    private fun readWorkbook(resolver:ContentResolver,uri:Uri):List<Sheet> {
        val entries=mutableMapOf<String,ByteArray>()
        ZipInputStream(resolver.openInputStream(uri) ?: error("تعذر فتح الملف")).use { z -> while(true){val e=z.nextEntry?:break; if(!e.isDirectory) entries[e.name]=z.readBytes()} }
        val wb=entries["xl/workbook.xml"]?:error("الملف ليس مصنف XLSX صالحًا")
        val rel=entries["xl/_rels/workbook.xml.rels"]?:error("ملف علاقات أوراق Excel مفقود")
        val shared=parseShared(entries["xl/sharedStrings.xml"])
        val sheets=mutableListOf<Pair<String,String>>()
        val p=Xml.newPullParser();p.setInput(wb.inputStream(),"UTF-8");var e=p.eventType
        while(e!=XmlPullParser.END_DOCUMENT){if(e==XmlPullParser.START_TAG&&p.name=="sheet"){val n=p.getAttributeValue(null,"name")?:"";val id=p.getAttributeValue("http://schemas.openxmlformats.org/officeDocument/2006/relationships","id")?:"";sheets+=n to id};e=p.next()}
        val relations=mutableMapOf<String,String>();val rp=Xml.newPullParser();rp.setInput(rel.inputStream(),"UTF-8");e=rp.eventType
        while(e!=XmlPullParser.END_DOCUMENT){if(e==XmlPullParser.START_TAG&&rp.name=="Relationship"){relations[rp.getAttributeValue(null,"Id")?:""]=rp.getAttributeValue(null,"Target")?:""};e=rp.next()}
        return sheets.mapNotNull { (name,id) ->
            val target=relations[id]?:return@mapNotNull null
            val path=if(target.startsWith("/"))target.removePrefix("/") else "xl/"+target.removePrefix("xl/")
            val bytes=entries[path]?:return@mapNotNull null
            val rows=parseSheet(bytes,shared)
            if(rows.isEmpty()) null else Sheet(name,rows.first(),rows.drop(1))
        }
    }
    private fun parseShared(bytes:ByteArray?):List<String>{if(bytes==null)return emptyList();val p=Xml.newPullParser();p.setInput(bytes.inputStream(),"UTF-8");val out=mutableListOf<String>();var inSi=false;val b=StringBuilder();var e=p.eventType;while(e!=XmlPullParser.END_DOCUMENT){if(e==XmlPullParser.START_TAG&&p.name=="si"){inSi=true;b.setLength(0)}else if(e==XmlPullParser.START_TAG&&p.name=="t"&&inSi)b.append(p.nextText())else if(e==XmlPullParser.END_TAG&&p.name=="si"){out+=b.toString();inSi=false};e=p.next()};return out}
    private fun parseSheet(bytes:ByteArray,shared:List<String>):List<List<String>>{val p=Xml.newPullParser();p.setInput(bytes.inputStream(),"UTF-8");val out=mutableListOf<List<String>>();var row=mutableMapOf<Int,String>();var col=0;var type="";var value="";var e=p.eventType;while(e!=XmlPullParser.END_DOCUMENT){if(e==XmlPullParser.START_TAG&&p.name=="row")row=mutableMapOf() else if(e==XmlPullParser.START_TAG&&p.name=="c"){type=p.getAttributeValue(null,"t")?:"";col=columnIndex(p.getAttributeValue(null,"r")?:"A1");value=""}else if(e==XmlPullParser.START_TAG&&p.name=="v")value=p.nextText() else if(e==XmlPullParser.START_TAG&&p.name=="t"&&type=="inlineStr")value=p.nextText() else if(e==XmlPullParser.END_TAG&&p.name=="c")row[col]=if(type=="s")shared.getOrNull(value.toIntOrNull()?:-1).orEmpty()else value else if(e==XmlPullParser.END_TAG&&p.name=="row"){if(row.isNotEmpty())out+=((0..(row.keys.maxOrNull()?:0)).map{row[it].orEmpty()})};e=p.next()};return out}
    private fun columnIndex(ref:String):Int{var n=0;ref.takeWhile{it.isLetter()}.forEach{n=n*26+(it.uppercaseChar()-'A'+1)};return n-1}
}
