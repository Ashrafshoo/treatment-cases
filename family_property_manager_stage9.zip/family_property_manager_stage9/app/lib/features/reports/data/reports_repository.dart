import 'package:sqflite_sqlcipher/sqflite.dart';
import '../../../core/database/app_database.dart';

class ReportsRepository {
  Future<Database> get _db async => AppDatabase.instance.database;

  Future<Map<String, Object?>> summary({required DateTime from, required DateTime to}) async {
    final db = await _db;
    final start = _date(from), end = _date(to);
    final rows = await db.rawQuery('''
      SELECT
        COALESCE((SELECT SUM(amount_minor) FROM payments WHERE paid_at BETWEEN ? AND ?),0) AS collected,
        COALESCE((SELECT SUM(amount_minor) FROM expenses WHERE archived_at IS NULL AND expense_date BETWEEN ? AND ?),0) AS expenses,
        (SELECT COUNT(*) FROM properties WHERE archived_at IS NULL) AS properties_count,
        (SELECT COUNT(*) FROM units WHERE archived_at IS NULL) AS units_count,
        (SELECT COUNT(*) FROM leases WHERE archived_at IS NULL AND status IN ('active','ending_soon','open_ended')) AS active_leases,
        (SELECT COUNT(*) FROM receipts WHERE issued_at BETWEEN ? AND ?) AS receipts_count
    ''', [start, end, start, end, start, end]);
    final row = rows.first;
    final collected = (row['collected'] as num).toInt();
    final expenses = (row['expenses'] as num).toInt();
    return {...row, 'net_income': collected - expenses, 'period_start': start, 'period_end': end};
  }

  Future<List<Map<String, Object?>>> monthly({required DateTime from, required DateTime to}) async {
    final db = await _db;
    return db.rawQuery('''
      SELECT strftime('%Y-%m', paid_at) AS month,
             COALESCE(SUM(amount_minor),0) AS collected,
             (SELECT COALESCE(SUM(e.amount_minor),0) FROM expenses e
               WHERE e.archived_at IS NULL AND e.expense_date BETWEEN ? AND ?
                 AND strftime('%Y-%m',e.expense_date)=strftime('%Y-%m',p.paid_at)) AS expenses
      FROM payments p WHERE paid_at BETWEEN ? AND ? GROUP BY strftime('%Y-%m',paid_at)
      UNION
      SELECT strftime('%Y-%m', expense_date) AS month, 0 AS collected,
             SUM(amount_minor) AS expenses FROM expenses
      WHERE archived_at IS NULL AND expense_date BETWEEN ? AND ?
        AND strftime('%Y-%m',expense_date) NOT IN
          (SELECT strftime('%Y-%m',paid_at) FROM payments WHERE paid_at BETWEEN ? AND ?)
      GROUP BY strftime('%Y-%m',expense_date)
      ORDER BY month DESC
    ''', [_date(from), _date(to), _date(from), _date(to), _date(from), _date(to), _date(from), _date(to)]);
  }

  Future<List<Map<String, Object?>>> propertyStatement({required DateTime from, required DateTime to}) async {
    final db = await _db;
    return db.rawQuery('''
      SELECT p.id AS property_id, p.name AS property_name,
        COUNT(DISTINCT u.id) AS units_count,
        COALESCE(SUM(pay.amount_minor),0) AS collected,
        COUNT(DISTINCT pay.id) AS payment_count
      FROM properties p
      LEFT JOIN units u ON u.property_id=p.id AND u.archived_at IS NULL
      LEFT JOIN leases l ON l.unit_id=u.id AND l.archived_at IS NULL
      LEFT JOIN payments pay ON pay.lease_id=l.id AND pay.paid_at BETWEEN ? AND ?
      WHERE p.archived_at IS NULL
      GROUP BY p.id,p.name ORDER BY p.name COLLATE NOCASE
    ''', [_date(from), _date(to)]);
  }


  Future<List<Map<String, Object?>>> monthlyRentStatement(DateTime month) async {
    final db = await _db;
    final start = DateTime(month.year, month.month, 1);
    final end = DateTime(month.year, month.month + 1, 0);
    return db.rawQuery('''
      SELECT p.name AS property_name, u.unit_number, t.full_name AS tenant_name,
        l.id AS lease_id,
        COALESCE((SELECT rh.amount_minor FROM rent_history rh
          WHERE rh.lease_id=l.id AND rh.approval_status='approved'
            AND rh.valid_from<=? AND (rh.valid_to IS NULL OR rh.valid_to>=?)
          ORDER BY rh.valid_from DESC LIMIT 1),
          CASE WHEN EXISTS(SELECT 1 FROM rent_history pending
            WHERE pending.lease_id=l.id AND pending.approval_status='under_review'
              AND pending.valid_from<=? AND (pending.valid_to IS NULL OR pending.valid_to>=?)
          ) THEN 0 ELSE l.initial_rent_minor END,0) AS due_minor,
        CASE WHEN EXISTS(SELECT 1 FROM rent_history pending
          WHERE pending.lease_id=l.id AND pending.approval_status='under_review'
            AND pending.valid_from<=? AND (pending.valid_to IS NULL OR pending.valid_to>=?))
          THEN 1 ELSE 0 END AS has_pending_rent_review,
        COALESCE((SELECT SUM(pay.amount_minor) FROM payments pay
          WHERE pay.lease_id=l.id AND COALESCE(pay.period_start,pay.paid_at) BETWEEN ? AND ?),0) AS paid_minor
      FROM leases l JOIN units u ON u.id=l.unit_id
      JOIN properties p ON p.id=u.property_id JOIN tenants t ON t.id=l.tenant_id
      WHERE l.archived_at IS NULL AND u.archived_at IS NULL AND p.archived_at IS NULL
        AND l.start_date<=? AND (COALESCE(l.manual_end_date,l.calculated_end_date) IS NULL
          OR COALESCE(l.manual_end_date,l.calculated_end_date)>=?)
        -- Historical statements are date-driven: ended/terminated leases remain
        -- visible for months in which their contractual dates overlap. Suspended
        -- leases remain excluded because no suspension effective dates are stored.
        AND l.status <> 'suspended'
      ORDER BY p.name COLLATE NOCASE,u.unit_number,t.full_name
    ''', [_date(end),_date(start),_date(end),_date(start),_date(end),_date(start),_date(start),_date(end),_date(end),_date(start)]);
  }

  Future<List<Map<String, Object?>>> annual() async {
    final db = await _db;
    return db.rawQuery('''
      SELECT y.year,
        COALESCE((SELECT SUM(amount_minor) FROM payments p WHERE substr(p.paid_at,1,4)=y.year),0) AS collected,
        COALESCE((SELECT SUM(amount_minor) FROM expenses e WHERE e.archived_at IS NULL AND substr(e.expense_date,1,4)=y.year),0) AS expenses
      FROM (SELECT substr(paid_at,1,4) AS year FROM payments UNION SELECT substr(expense_date,1,4) AS year FROM expenses WHERE archived_at IS NULL) y
      ORDER BY y.year DESC
    ''');
  }

  static String _date(DateTime d) => '${d.year.toString().padLeft(4,'0')}-${d.month.toString().padLeft(2,'0')}-${d.day.toString().padLeft(2,'0')}';
}
