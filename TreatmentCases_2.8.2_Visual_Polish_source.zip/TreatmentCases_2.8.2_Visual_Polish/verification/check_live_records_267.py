#!/usr/bin/env python3
from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'android/app/src/main/java/com/treatmentcases/app/MainActivity.kt').read_text(encoding='utf-8')
g=(root/'android/app/build.gradle').read_text(encoding='utf-8')
checks={
 'isolated preview package': "applicationId 'com.treatmentcases.app.preview275'" in g,
 'version increment': "versionName '2.8.2-visual-polish'" in g and 'versionCode 34' in g,
 'records card expands with animation': 'AnimatedVisibility(visible=expanded)' in s and 'animateContentSize().clickable' in s,
 'record card supports bilingual labels': 'Employee No.' in s and 'Active ingredient:' in s and 'حذف السجل؟' in s,
 'edit form has bilingual field labels': 'val labelsEn = listOf("Region", "Sector", "Name"' in s,
 'edit dialog receives language state': 'isEnglish: Boolean = false' in s and '},isEnglish)' in s,
 'medicine and strength selection preserved': 'strengthOptions(values[4])' in s and 'values[5] = strength' in s,
 'existing validation remains': 'CaseDataRules.validate(listOf(record))' in s,
 'no database migration': 'CREATE TABLE' not in s and 'ALTER TABLE' not in s,
 'localized app label': 'Treatment Cases Haja' in (root/'android/app/src/main/res/values-en/strings.xml').read_text(encoding='utf-8'),
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+': '+k)
assert all(checks.values())
print(f'PASS: {len(checks)} live records assertions')
