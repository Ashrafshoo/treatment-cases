package com.example.rentals.data

data class UnitRecord(
    val id: Long = 0,
    val code: String = "",
    val property: String = "",
    val tenant: String = "",
    val unitType: String = "غير محدد",
    val rent: Double? = null,
    val status: String = "نشطة",
    val description: String = "",
    val notes: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)

data class AuditRecord(
    val id: Long = 0, val recordType: String, val recordId: String,
    val fieldName: String, val oldValue: String?, val newValue: String?,
    val reason: String, val createdAt: Long = System.currentTimeMillis()
)


data class ReceiptRecord(
    val id: Long = 0,
    val receiptNo: String,
    val unitId: Long,
    val unitCode: String,
    val tenant: String,
    val property: String,
    val amount: Double?,
    val paidDate: String,
    val period: String,
    val template: String = "old",
    val notes: String = "",
    val status: String = "paid"
)


data class ReviewFlag(val unitCode: String, val tenant: String, val issue: String)


data class PropertyRecord(
    val id: Long = 0, val name: String, val address: String = "",
    val notes: String = "", val createdAt: Long = System.currentTimeMillis(),
    val linkedUnits: Int = 0
)

data class TenantRecord(
    val id: Long = 0, val name: String, val phone: String = "",
    val notes: String = "", val createdAt: Long = System.currentTimeMillis(),
    val linkedUnits: Int = 0, val linkedLeases: Int = 0
)
