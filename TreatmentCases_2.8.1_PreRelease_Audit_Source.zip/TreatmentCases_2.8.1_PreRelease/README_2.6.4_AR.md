# علاج الحالات حاجة — حزمة التطوير 2.6.4

ابدأ بقراءة:
1. `DESIGN_AND_IMPLEMENTATION_2.6.4_AR.md`
2. `RELEASE_NOTES_2.6.4_DEV_AR.md`

المصدر داخل `android/`، واختبارات التحقق داخل `verification/`.

هذه حزمة مصدر تطوير مستقلة وليست ملف APK. لا تثبّتها فوق النسخة المعتمدة؛ لها معرّف تطبيق منفصل `com.treatmentcases.app.preview264`.
