package com.treatmentcases.app

import java.text.ParsePosition
import java.text.SimpleDateFormat
import java.util.Locale

/** Pure validation and identity rules shared by preview, import and backup restore. */
object CaseDataRules {
    fun normalizeDigits(value: String): String = value.map { ch ->
        when (ch) {
            in '٠'..'٩' -> '0' + (ch - '٠')
            in '۰'..'۹' -> '0' + (ch - '۰')
            else -> ch
        }
    }.joinToString("")

    fun normalizePerformanceNo(value: String): String = normalizeDigits(value)
        .trim().filterNot { it.isWhitespace() }

    private fun normalized(value: String): String = value.trim()
        .replace(Regex("\\s+"), " ").lowercase(Locale.ROOT)

    fun signature(record: CaseRecord): String = record.cells().mapIndexed { index, value ->
        if (index == 3) normalizePerformanceNo(value).lowercase(Locale.ROOT) else normalized(value)
    }.joinToString("\u001f")

    fun isValidIsoDate(value: String): Boolean {
        if (!value.matches(Regex("\\d{4}-\\d{2}-\\d{2}"))) return false
        val format = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { isLenient = false }
        val position = ParsePosition(0)
        val parsed = format.parse(value, position)
        return parsed != null && position.index == value.length
    }

    fun validate(rows: List<CaseRecord>): List<String> {
        val issues = mutableListOf<String>()
        val namesByPerformance = mutableMapOf<String, String>()
        rows.forEachIndexed { index, record ->
            val rowNo = index + 5
            val performance = normalizePerformanceNo(record.performanceNo)
            val name = record.name.trim()
            val medicine = record.medicine.trim()
            if (name.isBlank()) issues += "صف $rowNo: اسم العامل مطلوب."
            if (performance.isBlank()) issues += "صف $rowNo: رقم الأداء مطلوب."
            if (medicine.isBlank()) issues += "صف $rowNo: اسم الدواء مطلوب."
            if (name.length > 200) issues += "صف $rowNo: اسم العامل أطول من الحد المسموح (200 حرف)."
            if (performance.length > 64) issues += "صف $rowNo: رقم الأداء أطول من الحد المسموح (64 حرفاً)."
            if (medicine.length > 200) issues += "صف $rowNo: اسم الدواء أطول من الحد المسموح (200 حرف)."
            if (record.strength.length > 120) issues += "صف $rowNo: وصف التركيز/العيار أطول من الحد المسموح (120 حرفاً)."
            if (record.approvalDate.isNotBlank() && !isValidIsoDate(record.approvalDate)) {
                issues += "صف $rowNo: تاريخ الموافقة غير صحيح؛ استخدم yyyy-MM-dd."
            }
            if (record.approvalExpiry.isNotBlank() && !isValidIsoDate(record.approvalExpiry)) {
                issues += "صف $rowNo: تاريخ انتهاء الموافقة غير صحيح؛ استخدم yyyy-MM-dd."
            }
            if (isValidIsoDate(record.approvalDate) && isValidIsoDate(record.approvalExpiry) &&
                record.approvalExpiry < record.approvalDate) {
                issues += "صف $rowNo: تاريخ انتهاء الموافقة يسبق تاريخ إصدارها."
            }
            if (performance.isNotBlank() && name.isNotBlank()) {
                val previous = namesByPerformance.putIfAbsent(performance, name)
                if (previous != null && !previous.equals(name, ignoreCase = true)) {
                    issues += "صف $rowNo: رقم الأداء $performance مرتبط باسمين مختلفين داخل الملف."
                }
            }
        }
        return issues.distinct()
    }

    fun normalizeForImport(record: CaseRecord): CaseRecord = record.copy(
        name = record.name.trim(),
        performanceNo = normalizePerformanceNo(record.performanceNo),
        medicine = record.medicine.trim().replace(Regex("\\s+"), " "),
        strength = record.strength.trim(),
        approvalDate = record.approvalDate.trim(),
        approvalExpiry = record.approvalExpiry.trim()
    )
}
