import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCHEMA = ROOT / 'app' / 'assets' / 'database' / '001_initial_schema.sql'


def db_with_lease():
    db = sqlite3.connect(':memory:')
    db.execute('PRAGMA foreign_keys=ON')
    for statement in SCHEMA.read_text(encoding='utf-8').split(';'):
        if statement.strip():
            db.execute(statement)
    db.execute("INSERT INTO properties(id,name) VALUES('p','عقار اختبار')")
    db.execute("INSERT INTO tenants(id,full_name) VALUES('t','مستأجر اختبار')")
    db.execute("INSERT INTO units(id,property_id,unit_number,unit_type) VALUES('u','p','1','سكني')")
    db.execute("INSERT INTO leases(id,unit_id,tenant_id,start_date,initial_rent_minor) VALUES('l','u','t','2026-01-01',100000)")
    return db


def test_unapproved_initial_rent_is_not_counted_as_due():
    db = db_with_lease()
    db.execute("INSERT INTO rent_history(id,lease_id,amount_minor,valid_from,approval_status) VALUES('rh-p','l',125000,'2026-01-01','under_review')")
    due = db.execute('''SELECT COALESCE((SELECT rh.amount_minor FROM rent_history rh
        WHERE rh.lease_id=l.id AND rh.approval_status='approved'
          AND rh.valid_from<=? AND (rh.valid_to IS NULL OR rh.valid_to>=?)
        ORDER BY rh.valid_from DESC LIMIT 1),
        CASE WHEN EXISTS(SELECT 1 FROM rent_history pending
          WHERE pending.lease_id=l.id AND pending.approval_status='under_review'
            AND pending.valid_from<=? AND (pending.valid_to IS NULL OR pending.valid_to>=?)
        ) THEN 0 ELSE l.initial_rent_minor END,0)
        FROM leases l WHERE l.id='l' ''',
        ('2026-01-31', '2026-01-01', '2026-01-31', '2026-01-01')).fetchone()[0]
    assert due == 0
    db.close()


def test_approved_rent_remains_due_when_new_value_is_under_review():
    db = db_with_lease()
    db.execute("INSERT INTO rent_history(id,lease_id,amount_minor,valid_from,approval_status) VALUES('rh-a','l',100000,'2026-01-01','approved')")
    db.execute("INSERT INTO rent_history(id,lease_id,amount_minor,valid_from,approval_status) VALUES('rh-p','l',125000,'2026-01-01','under_review')")
    due = db.execute('''SELECT COALESCE((SELECT rh.amount_minor FROM rent_history rh
        WHERE rh.lease_id=l.id AND rh.approval_status='approved'
          AND rh.valid_from<=? AND (rh.valid_to IS NULL OR rh.valid_to>=?)
        ORDER BY rh.valid_from DESC LIMIT 1),
        CASE WHEN EXISTS(SELECT 1 FROM rent_history pending
          WHERE pending.lease_id=l.id AND pending.approval_status='under_review'
            AND pending.valid_from<=? AND (pending.valid_to IS NULL OR pending.valid_to>=?)
        ) THEN 0 ELSE l.initial_rent_minor END,0)
        FROM leases l WHERE l.id='l' ''',
        ('2026-01-31', '2026-01-01', '2026-01-31', '2026-01-01')).fetchone()[0]
    assert due == 100000
    db.close()


def test_monthly_expenses_respect_partial_date_range():
    db = db_with_lease()
    db.execute("INSERT INTO payments(id,lease_id,paid_at,amount_minor) VALUES('pay','l','2026-01-20',10000)")
    db.execute("INSERT INTO expenses(id,name,amount_minor,expense_date) VALUES('before','قبل النطاق',7000,'2026-01-05')")
    db.execute("INSERT INTO expenses(id,name,amount_minor,expense_date) VALUES('inside','داخل النطاق',3000,'2026-01-22')")
    row = db.execute('''SELECT strftime('%Y-%m', paid_at),
        (SELECT COALESCE(SUM(e.amount_minor),0) FROM expenses e
         WHERE e.archived_at IS NULL AND e.expense_date BETWEEN ? AND ?
           AND strftime('%Y-%m',e.expense_date)=strftime('%Y-%m',p.paid_at))
        FROM payments p WHERE paid_at BETWEEN ? AND ? GROUP BY strftime('%Y-%m',paid_at)''',
        ('2026-01-15','2026-01-31','2026-01-15','2026-01-31')).fetchone()
    assert row == ('2026-01', 3000)
    db.close()


def test_dart_wiring_contains_the_regression_fixes_and_navy_gold_defaults():
    payments = (ROOT / 'app/lib/features/payments/data/payments_repository.dart').read_text()
    reports = (ROOT / 'app/lib/features/reports/data/reports_repository.dart').read_text()
    leases_ui = (ROOT / 'app/lib/features/leases/presentation/leases_screen.dart').read_text()
    prefs = (ROOT / 'app/lib/core/theme/app_preferences.dart').read_text()
    theme = (ROOT / 'app/lib/core/theme/app_theme.dart').read_text()
    records = (ROOT / 'app/lib/features/records/data/records_repository.dart').read_text()
    exchange = (ROOT / 'app/lib/features/data_exchange/data/excel_exchange_repository.dart').read_text()
    exchange_ui = (ROOT / 'app/lib/features/data_exchange/presentation/data_exchange_screen.dart').read_text()
    backup = (ROOT / 'app/lib/features/settings/data/backup_repository.dart').read_text()
    leases_ui = (ROOT / 'app/lib/features/leases/presentation/leases_screen.dart').read_text()
    leases_repo = (ROOT / 'app/lib/features/leases/data/leases_repository.dart').read_text()
    assert 'l.initial_rent_minor' in payments and "pending.approval_status='under_review'" in payments
    assert 'e.expense_date BETWEEN ? AND ?' in reports
    assert "final _increase = TextEditingController();" in leases_ui
    assert "if (_law164 && _residential)" in leases_ui
    assert 'الوحدات التجارية لا يطبق عليها حد 250 جنيه ولا تُفرض عليها زيادة 15% تلقائياً' in leases_ui
    assert '0xFFD6A84F' in prefs and '0xFF17324D' in theme
    assert "final entityType=switch(table)" in records
    assert "after['review_status']='sound'" not in records
    assert 'AppSession.instance.requireAdmin();' in exchange
    assert 'قسم الاستيراد والتصدير متاح للمدير فقط' in exchange_ui
    assert 'wal_checkpoint(FULL)' in backup and 'localDeviceSettings' in backup
    assert 'Future<void> _editLease' in leases_ui and 'record: row' in leases_ui
    assert 'u.unit_type' in leases_repo


def test_exact_dart_monthly_report_sql_has_matching_parameters():
    source = (ROOT / 'app/lib/features/reports/data/reports_repository.dart').read_text(encoding='utf-8')
    section = source[source.index('Future<List<Map<String, Object?>>> monthly('):source.index('Future<List<Map<String, Object?>>> propertyStatement')]
    import re
    sql = re.search(r"return db\.rawQuery\('''(.*?)'''", section, re.S).group(1)
    params = ('2026-01-15','2026-01-31','2026-01-15','2026-01-31',
              '2026-01-15','2026-01-31','2026-01-15','2026-01-31')
    assert sql.count('?') == len(params)
    db = db_with_lease()
    db.execute("INSERT INTO payments(id,lease_id,paid_at,amount_minor) VALUES('pay','l','2026-01-20',10000)")
    db.execute("INSERT INTO expenses(id,name,amount_minor,expense_date) VALUES('old','قديم',7000,'2026-01-05')")
    db.execute("INSERT INTO expenses(id,name,amount_minor,expense_date) VALUES('in','داخل',3000,'2026-01-22')")
    result = db.execute(sql, params).fetchall()
    assert result == [('2026-01', 10000, 3000)]
    db.close()


def test_exact_dart_monthly_rent_statement_sql_has_matching_parameters():
    source = (ROOT / 'app/lib/features/reports/data/reports_repository.dart').read_text(encoding='utf-8')
    section = source[source.index('Future<List<Map<String, Object?>>> monthlyRentStatement'):source.index('Future<List<Map<String, Object?>>> annual')]
    import re
    sql = re.search(r"return db\.rawQuery\('''(.*?)'''", section, re.S).group(1)
    params = ('2026-01-31','2026-01-01','2026-01-31','2026-01-01',
              '2026-01-31','2026-01-01','2026-01-01','2026-01-31',
              '2026-01-31','2026-01-01')
    assert sql.count('?') == len(params)
    db = db_with_lease()
    db.execute("INSERT INTO rent_history(id,lease_id,amount_minor,valid_from,approval_status) VALUES('pending','l',125000,'2026-01-01','under_review')")
    result = db.execute(sql, params).fetchone()
    assert result[4] == 0 and result[5] == 1
    db.execute("INSERT INTO rent_history(id,lease_id,amount_minor,valid_from,approval_status) VALUES('approved','l',100000,'2026-01-01','approved')")
    result = db.execute(sql, params).fetchone()
    assert result[4] == 100000 and result[5] == 1
    db.close()


if __name__ == '__main__':
    for test in [test_unapproved_initial_rent_is_not_counted_as_due,
                 test_approved_rent_remains_due_when_new_value_is_under_review,
                 test_monthly_expenses_respect_partial_date_range,
                 test_dart_wiring_contains_the_regression_fixes_and_navy_gold_defaults,
                 test_exact_dart_monthly_report_sql_has_matching_parameters,
                 test_exact_dart_monthly_rent_statement_sql_has_matching_parameters]:
        test()
    print('Integration audit regressions: 6/6 passed')


def test_database_is_sqlcipher_encrypted_and_key_is_keystore_backed():
    database = (ROOT / 'app/lib/core/database/app_database.dart').read_text()
    pubspec = (ROOT / 'app/pubspec.yaml').read_text()
    assert 'sqflite_sqlcipher' in pubspec
    assert 'flutter_secure_storage' in pubspec
    assert "password: key" in database
    assert "family_properties_sqlcipher_key_v1" in database
    assert 'ATTACH DATABASE ? AS encrypted KEY' in database
    assert "sqlcipher_export('encrypted')" in database
    assert 'plaintext_backup' in database
    assert 'PRAGMA quick_check' in database


def test_biometric_login_is_opt_in_and_does_not_store_passwords():
    biometric = (ROOT / 'app/lib/features/auth/data/biometric_auth_service.dart').read_text()
    auth = (ROOT / 'app/lib/features/auth/data/auth_repository.dart').read_text()
    assert 'biometric_login_enabled_v1' in biometric
    assert 'biometric_login_username_v1' in biometric
    assert 'AuthenticationOptions(biometricOnly: true' in biometric
    assert 'password' not in biometric.lower()
    assert 'role=?' in auth and "'administrator'" in auth
    assert 'signInWithBiometric' in auth


def test_encrypted_backup_contains_wrapped_database_key_and_validates_before_restore():
    backup = (ROOT / 'app/lib/features/settings/data/backup_repository.dart').read_text()
    assert "ArchiveFile('database_key.txt'" in backup
    assert 'importedDatabaseKey' in backup
    assert "openDatabase(validationFile.path, password: importedDatabaseKey" in backup
    assert 'writeEncryptionKey(importedDatabaseKey)' in backup
    assert 'writeEncryptionKey(currentDatabaseKey)' in backup



def test_codemagic_android_security_scaffolding_is_configured():
    workflow = (ROOT / 'codemagic.yaml').read_text()
    assert 'FlutterFragmentActivity' in workflow
    assert 'USE_BIOMETRIC' in workflow
    assert 'allowBackup' in workflow and 'false' in workflow
    assert 'minSdk = 23' in workflow
    assert 'Theme.AppCompat.DayNight' in workflow
    assert 'net.sqlcipher.**' in workflow
