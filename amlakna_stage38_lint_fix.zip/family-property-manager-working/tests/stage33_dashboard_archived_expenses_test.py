from pathlib import Path
import sqlite3

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT / "android-app/src/main/java/com/familyproperties/app/PropertyRepository.kt"


def test_dashboard_uses_only_active_expenses():
    source = REPO.read_text(encoding="utf-8")
    assert "sumActiveExpenses(db)" in source
    assert "FROM expenses WHERE archived_at IS NULL" in source


def test_active_expense_total_excludes_soft_archived_rows():
    db = sqlite3.connect(":memory:")
    db.execute("CREATE TABLE expenses (amount_minor INTEGER NOT NULL, archived_at TEXT)")
    db.executemany(
        "INSERT INTO expenses(amount_minor, archived_at) VALUES (?, ?)",
        [(125000, None), (50000, "2026-11-10")],
    )
    total = db.execute(
        "SELECT COALESCE(SUM(amount_minor),0) FROM expenses WHERE archived_at IS NULL"
    ).fetchone()[0]
    assert total == 125000
