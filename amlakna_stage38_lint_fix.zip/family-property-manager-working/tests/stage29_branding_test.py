from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / 'android-app/src/main'


def test_amlakna_name_and_approved_slogan_are_used_in_primary_ui():
    source = (APP / 'java/com/familyproperties/app/MainActivity.kt').read_text()
    assert 'Text("أملاكنا"' in source
    assert 'أملاك العائلة... إدارة أسهل ومستقبل أكثر تنظيماً' in source
    manifest = (APP / 'AndroidManifest.xml').read_text()
    assert 'android:label="أملاكنا"' in manifest


def test_navy_gold_brand_palette_is_consistent():
    colors = (APP / 'res/values/colors.xml').read_text()
    assert '#101D36' in colors and '#D6AD62' in colors
    assert '#F3F5F9' in colors
