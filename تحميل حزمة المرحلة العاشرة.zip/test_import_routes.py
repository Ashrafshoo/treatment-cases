import http.client, tempfile, shutil, threading, unittest, hashlib, sqlite3
from pathlib import Path
from http.server import ThreadingHTTPServer
from urllib.parse import urlencode
from io import BytesIO
from openpyxl import Workbook
import app, security, management, import_update_engine

from test_fixtures import create_test_db

class ImportRouteTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.old_auth=app.AUTH_DB; self.old_db=app.DB; self.old_backup=app._BACKUP_CREATED
        app.AUTH_DB=Path(self.tmp.name)/'auth.sqlite3'; app.DB=Path(self.tmp.name)/'med.db'; app._BACKUP_CREATED=False
        create_test_db(app.DB); import_update_engine.migrate(app.DB); management.initialize(app.DB)
        security.initialize(app.AUTH_DB)
        security.create_user(app.AUTH_DB,'admin','مدير','Strong-Admin-Password-2026','manager')
        security.create_user(app.AUTH_DB,'viewer','قارئ','Strong-Viewer-Password-2026','viewer')
        self.server=ThreadingHTTPServer(('127.0.0.1',0),app.Handler)
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True); self.thread.start()
        self.conn=http.client.HTTPConnection('127.0.0.1',self.server.server_port)
        self.admin_cookie=self.login('admin','Strong-Admin-Password-2026')
        token=self.admin_cookie.split('=',1)[1]
        self.csrf=hashlib.sha256(('csrf:'+token).encode()).hexdigest()

    def tearDown(self):
        self.conn.close(); self.server.shutdown(); self.server.server_close(); self.thread.join(timeout=2)
        app.AUTH_DB=self.old_auth; app.DB=self.old_db; app._BACKUP_CREATED=self.old_backup; self.tmp.cleanup()

    def login(self,user,pw):
        body=urlencode({'username':user,'password':pw})
        self.conn.request('POST','/login',body,{'Content-Type':'application/x-www-form-urlencoded'})
        r=self.conn.getresponse(); self.assertEqual(r.status,303); cookie=r.getheader('Set-Cookie').split(';',1)[0]; r.read(); return cookie

    def multipart(self, fields, filename, content):
        boundary='----ImportBoundary7MA4YWxkTrZu0gW'
        chunks=[]
        for key,value in fields.items():
            chunks += [f'--{boundary}\r\nContent-Disposition: form-data; name="{key}"\r\n\r\n{value}\r\n'.encode()]
        chunks += [f'--{boundary}\r\nContent-Disposition: form-data; name="workbook"; filename="{filename}"\r\nContent-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet\r\n\r\n'.encode(),content,f'\r\n--{boundary}--\r\n'.encode()]
        return boundary,b''.join(chunks)

    def book(self, title, headers, rows):
        w=Workbook(); s=w.active; s.title=title; s.append(headers)
        for row in rows:s.append(row)
        b=BytesIO(); w.save(b); return b.getvalue()

    def test_manager_can_preview_and_approve_personnel_import(self):
        payload=self.book('بيانات العاملين',['رقم الأداء','الاســـم','الوظيفة','المنطقة','الإدارة','المحمول','المحمول2','الرقم القومى','النوع'],[['IMPORT-777','مستفيد اختبار','فني','القاهرة','إدارة أ','','','','ذكر']])
        boundary,body=self.multipart({'csrf':self.csrf,'import_type':'personnel','mode':'PARTIAL_UPDATE'},'batch.xlsx',payload)
        self.conn.request('POST','/imports/upload',body,{'Content-Type':f'multipart/form-data; boundary={boundary}','Cookie':self.admin_cookie})
        r=self.conn.getresponse(); self.assertEqual(r.status,303); location=r.getheader('Location'); r.read()
        self.conn.request('GET',location,headers={'Cookie':self.admin_cookie}); r=self.conn.getresponse(); page=r.read().decode(); self.assertEqual(r.status,200); self.assertIn('IMPORT-777',page)
        c=sqlite3.connect(app.DB); self.assertIsNone(c.execute('SELECT 1 FROM Personnel WHERE performance_number=?',('IMPORT-777',)).fetchone()); c.close()
        batch_id=int(location.rsplit('/',1)[1])
        c=sqlite3.connect(app.DB); digest=c.execute('SELECT source_sha256 FROM Import_Batches_Ext WHERE batch_id=?',(batch_id,)).fetchone()[0]; c.close()
        self.assertEqual(len(digest),64)
        form=urlencode({'csrf':self.csrf,'batch_id':batch_id})
        self.conn.request('POST','/imports/approve',form,{'Content-Type':'application/x-www-form-urlencoded','Cookie':self.admin_cookie})
        r=self.conn.getresponse(); self.assertEqual(r.status,200); r.read()
        c=sqlite3.connect(app.DB); self.assertEqual(c.execute('SELECT full_name FROM Personnel WHERE performance_number=?',('IMPORT-777',)).fetchone()[0],'مستفيد اختبار'); c.close()

    def test_manager_can_download_blank_template(self):
        self.conn.request('GET','/imports/template',headers={'Cookie':self.admin_cookie})
        r=self.conn.getresponse(); data=r.read()
        self.assertEqual(r.status,200)
        self.assertIn('attachment',r.getheader('Content-Disposition'))
        self.assertTrue(data.startswith(b'PK'))

    def test_viewer_cannot_open_import_center(self):
        viewer=self.login('viewer','Strong-Viewer-Password-2026')
        self.conn.request('GET','/imports',headers={'Cookie':viewer}); r=self.conn.getresponse(); self.assertEqual(r.status,403); r.read()

    def test_manager_can_review_and_map_medicine_alias(self):
        mid=management.save_medicine(app.DB,'الدواء المعتمد','مادة فعالة','أقراص','تخصص','5 mg','admin')
        c=sqlite3.connect(app.DB)
        cur=c.execute("INSERT INTO Import_Batches_Ext(batch_type,source_file,import_mode,submitted_by) VALUES('CRITICAL_CASES','review.xlsx','PARTIAL_UPDATE','admin')")
        batch=cur.lastrowid
        c.execute("INSERT INTO Medicine_Review_Queue(batch_id,medicine_name_raw,first_seen_row) VALUES(?,?,?)",(batch,'اسم بديل',4))
        c.commit(); c.close()
        self.conn.request('GET','/medicine-review',headers={'Cookie':self.admin_cookie})
        r=self.conn.getresponse(); self.assertEqual(r.status,200); self.assertIn('اسم بديل'.encode(),r.read())
        form=urlencode({'csrf':self.csrf,'alias':'اسم بديل','medicine_id':mid})
        self.conn.request('POST','/medicine-alias',form,{'Content-Type':'application/x-www-form-urlencoded','Cookie':self.admin_cookie})
        r=self.conn.getresponse(); self.assertEqual(r.status,200); self.assertIn('تم ربط الاسم'.encode(),r.read())
        c=sqlite3.connect(app.DB)
        self.assertEqual(c.execute('SELECT medicine_id FROM Medicine_Name_Aliases WHERE raw_alias=?',('اسم بديل',)).fetchone()[0],mid)
        self.assertEqual(c.execute('SELECT review_status FROM Medicine_Review_Queue WHERE batch_id=?',(batch,)).fetchone()[0],'APPROVED')
        c.close()

    def test_snapshot_archival_requires_explicit_checkbox(self):
        payload=self.book('الحالات الحرجة',['رقم الأداء','العلاج','التركيز','مدة الصرف','الجرعة','الحالة المرضية','تاريخ الموافقة','ملاحظات'],[])
        boundary,body=self.multipart({'csrf':self.csrf,'import_type':'cases','mode':'FULL_SNAPSHOT'},'snapshot.xlsx',payload)
        self.conn.request('POST','/imports/upload',body,{'Content-Type':f'multipart/form-data; boundary={boundary}','Cookie':self.admin_cookie})
        r=self.conn.getresponse(); self.assertEqual(r.status,303); location=r.getheader('Location'); r.read()
        c=sqlite3.connect(app.DB); before=c.execute("SELECT count(*) FROM Treatments WHERE status='ACTIVE'").fetchone()[0]; c.close(); self.assertGreater(before,0)
        batch_id=int(location.rsplit('/',1)[1]); form=urlencode({'csrf':self.csrf,'batch_id':batch_id})
        self.conn.request('POST','/imports/approve',form,{'Content-Type':'application/x-www-form-urlencoded','Cookie':self.admin_cookie})
        r=self.conn.getresponse(); self.assertEqual(r.status,200); r.read()
        c=sqlite3.connect(app.DB); after=c.execute("SELECT count(*) FROM Treatments WHERE status='ACTIVE'").fetchone()[0]; skipped=c.execute("SELECT count(*) FROM Import_Run_Details WHERE batch_id=? AND decision='SKIPPED'",(batch_id,)).fetchone()[0]; c.close()
        self.assertEqual(after,before); self.assertGreater(skipped,0)

if __name__=='__main__': unittest.main()
