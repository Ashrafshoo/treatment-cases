import 'dart:convert';

import 'package:sqflite_sqlcipher/sqflite.dart';

import '../../../core/database/app_database.dart';
import '../../auth/data/app_session.dart';

class ArchiveReviewRepository {
  Future<Database> get _db async => AppDatabase.instance.database;
  String _id() => DateTime.now().microsecondsSinceEpoch.toString();

  Future<List<Map<String, Object?>>> pendingReviews() async {
    final db = await _db;
    return db.rawQuery('''
      SELECT r.*, COALESCE(pg.name, p.name, u.unit_number, t.full_name, o.full_name, e.name, l.id, rh.lease_id, ri.lease_id) AS entity_label
      FROM review_items r
      LEFT JOIN property_groups pg ON r.entity_type='property_group' AND pg.id=r.entity_id
      LEFT JOIN properties p ON r.entity_type='property' AND p.id=r.entity_id
      LEFT JOIN units u ON r.entity_type='unit' AND u.id=r.entity_id
      LEFT JOIN tenants t ON r.entity_type='tenant' AND t.id=r.entity_id
      LEFT JOIN owners o ON r.entity_type='owner' AND o.id=r.entity_id
      LEFT JOIN expenses e ON r.entity_type='expense' AND e.id=r.entity_id
      LEFT JOIN leases l ON r.entity_type='lease' AND l.id=r.entity_id
      LEFT JOIN rent_history rh ON r.entity_type='rent_history' AND rh.id=r.entity_id
      LEFT JOIN rent_increases ri ON r.entity_type='rent_increase' AND ri.id=r.entity_id
      WHERE r.status='pending'
      ORDER BY r.created_at DESC
    ''');
  }

  Future<List<Map<String, Object?>>> documents() async {
    final db = await _db;
    return db.query('documents', where: 'archived_at IS NULL', orderBy: 'created_at DESC');
  }

  Future<void> addDocument({
    required String entityType,
    required String entityId,
    required String title,
    required String relativePath,
    String? documentType,
    String? mimeType,
    String sourceType = 'manual',
  }) async {
    AppSession.instance.requireAdmin();
    if (title.trim().isEmpty || relativePath.trim().isEmpty) {
      throw ArgumentError('اسم المستند ومساره مطلوبان');
    }
    if (!const {'property','unit','tenant','lease','receipt','owner'}.contains(entityType)) {
      throw ArgumentError('نوع السجل غير مدعوم');
    }
    final db = await _db;
    const entityTables = {'property':'properties','unit':'units','tenant':'tenants','lease':'leases','receipt':'receipts','owner':'owners'};
    final table = entityTables[entityType]!;
    final existingEntity = await db.query(table, columns:['id'], where:'id=?', whereArgs:[entityId], limit:1);
    if (existingEntity.isEmpty) throw StateError('السجل المرتبط غير موجود');
    await db.transaction((tx) async {
      final id = _id();
      final values = <String, Object?>{
        'id': id, 'entity_type': entityType, 'entity_id': entityId,
        'document_type': documentType, 'title': title.trim(),
        'relative_path': relativePath.trim(), 'mime_type': mimeType,
        'source_type': sourceType,
      };
      await tx.insert('documents', values);
      await tx.insert('audit_log', {
        'id': _id(), 'user_id': AppSession.instance.userId, 'entity_type': 'document', 'entity_id': id,
        'action': 'create', 'after_json': jsonEncode(values),
      });
    });
  }

  Future<void> archiveDocument(String id) async {
    AppSession.instance.requireAdmin();
    final db = await _db;
    await db.transaction((tx) async {
      final rows = await tx.query('documents', where: 'id=? AND archived_at IS NULL', whereArgs: [id], limit: 1);
      if (rows.isEmpty) return;
      final now = DateTime.now().toIso8601String();
      await tx.update('documents', {'archived_at': now}, where: 'id=?', whereArgs: [id]);
      await tx.insert('audit_log', {
        'id': _id(), 'user_id': AppSession.instance.userId, 'entity_type': 'document', 'entity_id': id,
        'action': 'archive', 'before_json': jsonEncode(rows.first),
        'after_json': jsonEncode({'archived_at': now}),
      });
    });
  }

  Future<void> resolveReview(String id, {required bool approve, String? reviewer}) async {
    AppSession.instance.requireAdmin();
    final db = await _db;
    await db.transaction((tx) async {
      final rows = await tx.query('review_items', where: 'id=? AND status=?', whereArgs: [id, 'pending'], limit: 1);
      if (rows.isEmpty) throw StateError('عنصر المراجعة غير موجود أو تمت مراجعته');
      final item = rows.first;
      final entityType = item['entity_type'] as String;
      final entityId = item['entity_id'] as String;
      final field = item['field_name'] as String?;
      final proposed = item['proposed_value'];
      if (approve && field != null && proposed != null) {
        const allowed = <String, Set<String>>{
          'property': {'group_id','name','address_text','city','district','property_type','notes','review_status'},
          'property_group': {'name','description'},
          'unit': {'property_id','unit_number','floor_label','unit_type','area','occupancy_status','address_details','current_tenant_id','old_law_164_2025','notes','review_status'},
          'tenant': {'full_name','phone','national_id_last4','notes'},
          'owner': {'full_name','phone','notes'},
          'expense': {'name','amount_minor','expense_date','notes'},
          'lease': {'start_date','duration_value','duration_unit','calculated_end_date','manual_end_date','end_date_override_reason','initial_rent_minor','annual_increase_percent','increase_rule','increase_month','increase_day','law_164_2025_applies','status','notes'},
          'rent_history': {'amount_minor','valid_from','valid_to','approval_status'},
          'rent_increase': {'effective_date','percentage','previous_rent_minor','new_rent_minor','calculation_method','status','notes'},
        };
        final table = allowed.containsKey(entityType) ? entityType == 'property' ? 'properties' : entityType == 'property_group' ? 'property_groups' : entityType == 'unit' ? 'units' : entityType == 'tenant' ? 'tenants' : entityType == 'owner' ? 'owners' : entityType == 'expense' ? 'expenses' : entityType == 'rent_history' ? 'rent_history' : entityType == 'rent_increase' ? 'rent_increases' : 'leases' : null;
        if (table != null && allowed[entityType]!.contains(field)) {
          final updateValues=<String,Object?>{field:proposed};
          if (!{'rent_history','rent_increases'}.contains(table)) updateValues['updated_at']=DateTime.now().toIso8601String();
          await tx.update(table, updateValues, where: 'id=?', whereArgs: [entityId]);
          if(entityType=='lease'&&field=='initial_rent_minor'){
            final amount=int.tryParse(proposed.toString());
            if(amount==null||amount<0)throw StateError('قيمة الإيجار المقترحة غير صحيحة');
            final leaseRows=await tx.rawQuery('SELECT l.law_164_2025_applies,u.unit_type FROM leases l JOIN units u ON u.id=l.unit_id WHERE l.id=?',[entityId]);
            if(leaseRows.isNotEmpty&&(leaseRows.first['law_164_2025_applies'] as num?)?.toInt()==1){
              final type=(leaseRows.first['unit_type'] as String? ?? '').toLowerCase();
              if((type.contains('سكن')||type.contains('شقة')||type.contains('residential'))&&amount<25000)throw StateError('الحد الأدنى السكني المعتمد في إعدادات المشروع هو 250 جنيهاً');
            }
            final history=await tx.query('rent_history',where:'lease_id=? AND approval_status=? AND valid_to IS NULL',whereArgs:[entityId,'approved'],orderBy:'valid_from DESC',limit:1);
            final today=DateTime.now();final todayText='${today.year.toString().padLeft(4,'0')}-${today.month.toString().padLeft(2,'0')}-${today.day.toString().padLeft(2,'0')}';
            var changedToday=false;
            if(history.isNotEmpty){final start=DateTime.tryParse(history.first['valid_from'] as String? ?? '');if(start!=null&&start.year==today.year&&start.month==today.month&&start.day==today.day){await tx.update('rent_history',{'amount_minor':amount},where:'id=?',whereArgs:[history.first['id']]);changedToday=true;}else if(start!=null){final close=today.subtract(const Duration(days:1));if(!close.isBefore(start)){final closeText='${close.year.toString().padLeft(4,'0')}-${close.month.toString().padLeft(2,'0')}-${close.day.toString().padLeft(2,'0')}';await tx.update('rent_history',{'valid_to':closeText},where:'id=?',whereArgs:[history.first['id']]);}}}
            if(!changedToday)await tx.insert('rent_history',{'id':DateTime.now().microsecondsSinceEpoch.toString(),'lease_id':entityId,'amount_minor':amount,'currency_code':'EGP','valid_from':todayText,'source_type':'manual','approval_status':'approved'});
          }
        }
      }
      final now = DateTime.now().toIso8601String();
      await tx.update('review_items', {
        'status': approve ? 'approved' : 'rejected',
        'reviewed_by': reviewer ?? AppSession.instance.username,
        'reviewed_at': now,
      }, where: 'id=?', whereArgs: [id]);
      if (entityType == 'property' || entityType == 'unit') {
        final pending = Sqflite.firstIntValue(await tx.rawQuery('SELECT COUNT(*) FROM review_items WHERE entity_type=? AND entity_id=? AND status=?',[entityType,entityId,'pending'])) ?? 0;
        if (pending == 0) {
          final rejected = Sqflite.firstIntValue(await tx.rawQuery('SELECT COUNT(*) FROM review_items WHERE entity_type=? AND entity_id=? AND status=?',[entityType,entityId,'rejected'])) ?? 0;
          final table = entityType == 'property' ? 'properties' : 'units';
          await tx.update(table, {'modified_unreviewed':rejected>0?1:0,'review_status':rejected>0?'incorrect':'sound','updated_at':now}, where:'id=?',whereArgs:[entityId]);
        }
      } else if ({'tenant','owner','lease','expense'}.contains(entityType)) {
        final table = entityType == 'tenant' ? 'tenants' : entityType == 'owner' ? 'owners' : entityType == 'lease' ? 'leases' : 'expenses';
        final pending = Sqflite.firstIntValue(await tx.rawQuery('SELECT COUNT(*) FROM review_items WHERE entity_type=? AND entity_id=? AND status=?',[entityType,entityId,'pending'])) ?? 0;
        if (pending == 0) {
          final rejected = Sqflite.firstIntValue(await tx.rawQuery('SELECT COUNT(*) FROM review_items WHERE entity_type=? AND entity_id=? AND status=?',[entityType,entityId,'rejected'])) ?? 0;
          final updateValues=<String,Object?>{'modified_unreviewed':rejected>0?1:0};
          if(table!='ownership_shares')updateValues['updated_at']=now;
          await tx.update(table,updateValues,where:'id=?',whereArgs:[entityId]);
        }
      }
      await tx.insert('audit_log', {
        'id': _id(), 'user_id': AppSession.instance.userId, 'entity_type': 'review_item', 'entity_id': id,
        'action': approve ? 'approve' : 'reject',
        'before_json': jsonEncode(item),
        'after_json': jsonEncode({'status': approve ? 'approved' : 'rejected', 'reviewed_at': now}),
      });
    });
  }

  Future<void> createReviewItem({
    required String entityType,
    required String entityId,
    String? fieldName,
    String? originalValue,
    String? proposedValue,
    String? sourceDescription,
    double? confidence,
  }) async {
    AppSession.instance.requireAdmin();
    if (confidence != null && (confidence < 0 || confidence > 1)) {
      throw ArgumentError('درجة الثقة يجب أن تكون بين صفر وواحد');
    }
    final db = await _db;
    if(entityType=='property'||entityType=='unit'){final table=entityType=='property'?'properties':'units';await db.update(table,{'modified_unreviewed':1,'review_status':'needs_review','updated_at':DateTime.now().toIso8601String()},where:'id=?',whereArgs:[entityId]);}
    else if({'tenant','owner','lease','expense'}.contains(entityType)){final table=entityType=='tenant'?'tenants':entityType=='owner'?'owners':entityType=='lease'?'leases':'expenses';await db.update(table,{'modified_unreviewed':1,'updated_at':DateTime.now().toIso8601String()},where:'id=?',whereArgs:[entityId]);}
    await db.insert('review_items', {
      'id': _id(), 'entity_type': entityType, 'entity_id': entityId,
      'field_name': fieldName, 'original_value': originalValue,
      'proposed_value': proposedValue, 'source_description': sourceDescription,
      'confidence': confidence, 'status': 'pending',
    });
  }
}
