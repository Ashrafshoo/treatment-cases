#!/usr/bin/env python3
"""Static UI/visual regression checks for Treatment Cases 2.8.2."""
from pathlib import Path
root = Path(__file__).resolve().parents[1]
s = (root / "android/app/src/main/java/com/treatmentcases/app/MainActivity.kt").read_text(encoding="utf-8")
g = (root / "android/app/build.gradle").read_text(encoding="utf-8")
checks = {
    "release identity increments without changing preview application id": "versionCode 34" in g and "2.8.2-visual-polish" in g and "com.treatmentcases.app.preview275" in g,
    "blue medical top bar has white high-contrast content": "containerColor=MaterialTheme.colorScheme.primary" in s and "titleContentColor=Color.White" in s and "navigationIconContentColor=Color.White" in s,
    "refined theme includes palette-specific soft containers": "val primarySoft=when(paletteChoice)" in s and "val secondarySoft=when(paletteChoice)" in s,
    "rounded component geometry is consistent": "RoundedCornerShape(14.dp),medium=RoundedCornerShape(20.dp),large=RoundedCornerShape(26.dp)" in s,
    "dashboard is one vertical lazy list": '"الرئيسية"->{\n  LazyColumn(' in s,
    "dashboard quality review is inside the scroll container": 'Data Quality Review' in s and 'مراجعة جودة البيانات' in s and s.index('مراجعة جودة البيانات', s.index('"الرئيسية"->{\n  LazyColumn(')) < s.index('"السجلات"->{', s.index('"الرئيسية"->{\n  LazyColumn(')),
    "dashboard medicine results are part of the same lazy list": 'items(meds,key={it})' in s,
    "dashboard shortcut cards use distinct approved accent colors": all(x in s for x in ['Color(0xFF1769D2)','Color(0xFF0F8D83)','Color(0xFF6B55B5)','Color(0xFFCA7A20)']),
    "zero-alert state is visually explicit and green": 'Color(0xFFE1F4E8)' in s and 'Icons.Default.CheckCircle' in s,
    "drawer navigation and Arabic/English direction remain": 'ModalNavigationDrawer' in s and 'LayoutDirection.Rtl' in s and 'LayoutDirection.Ltr' in s,
    "approved medical hero illustration is still used": 'R.drawable.medical_hero' in s,
}
for label, ok in checks.items():
    print(("PASS: " if ok else "FAIL: ") + label)
assert all(checks.values()), "One or more 2.8.2 visual checks failed"
print(f"{len(checks)} visual UI assertions passed (static source checks only).")
