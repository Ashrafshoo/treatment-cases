package com.example.rentals.features.printing

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.graphics.RectF
import java.text.NumberFormat
import java.util.Locale
import androidx.compose.ui.platform.LocalContext
import com.example.rentals.printing.OriginalReceiptTemplateRenderer
import com.example.rentals.data.AggregateReceiptItem
import com.example.rentals.domain.collection.MonthlyCollectionRepository

private fun aggregateArabicDigits(value: String): String = value.map { ch -> when(ch) { in '0'..'9' -> ('٠'.code + (ch - '0')).toChar(); else -> ch } }.joinToString("")
private fun parseAggregateAmount(value: String): Double? = value.trim().map { ch -> when(ch) { in '٠'..'٩' -> ('0'.code + (ch - '٠')).toChar(); '٫' -> '.'; '٬' -> ','; else -> ch } }.joinToString("").replace(",", "").toDoubleOrNull()
private fun formatAggregateAmount(value: Double): String = aggregateArabicDigits(NumberFormat.getNumberInstance(Locale.US).format(value))

private val aggregateTypes = listOf(
    "factories" to "مجمع المصانع",
    "homes" to "مجمع البيوت",
    "villa_mayor" to "فيلا وعمارة العمدة"
)

@Composable
internal fun AggregateStatementsPanel(
    period: String,
    issuedDate: String,
    repository: MonthlyCollectionRepository,
    refreshKey: Int,
    onChanged: () -> Unit,
    onPrepareSelected: (List<AggregateReceiptItem>) -> Unit,
    onExportSelectedPdf: (List<AggregateReceiptItem>) -> Unit,
    onExportSelectedExcel: (List<AggregateReceiptItem>) -> Unit
) {
    var selectedType by remember { mutableStateOf("factories") }
    var statementId by remember(period, selectedType, refreshKey) { mutableStateOf<Long?>(null) }
    var rows by remember(period, selectedType, refreshKey) { mutableStateOf(emptyList<AggregateReceiptItem>()) }
    var editor by remember { mutableStateOf<AggregateReceiptItem?>(null) }
    var adding by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var previewItem by remember { mutableStateOf<AggregateReceiptItem?>(null) }
    var selectedIds by remember(period, selectedType, refreshKey) { mutableStateOf<Set<Long>>(emptySet()) }
    val context = LocalContext.current
    val templateOptions = remember { runCatching { OriginalReceiptTemplateRenderer(context).templateIds(monthlyOnly = true) }.getOrDefault(emptyList()) }
    val selectedRows = rows.filter { it.id in selectedIds }
    val selectedTemplatesReady = selectedRows.isNotEmpty() && selectedRows.all { row -> templateOptions.any { it.first == row.templateId } }

    LaunchedEffect(period, selectedType, refreshKey) {
        runCatching {
            val id = repository.getOrCreateAggregateStatement(period, selectedType, runCatching { com.example.rentals.printing.ReceiptDateFormat.toStorage(issuedDate) }.getOrDefault(issuedDate))
            statementId = id
            rows = repository.getAggregateStatements(period).firstOrNull { it.id == id }?.items.orEmpty()
            selectedIds = selectedIds.intersect(rows.map { it.id }.toSet())
        }.onFailure { message = it.message ?: "تعذر تحميل الكشف المجمع" }
    }

    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text("الكشوف المجمعة الشهرية", fontWeight = FontWeight.Bold)
            Text("أضف الاسم والقيمة الإيجارية، ثم أكمل أي بيانات أخرى متاحة. رقم الشارع ورقم الوحدة غير إلزاميين.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                aggregateTypes.forEach { (key, label) ->
                    FilterChip(selected = selectedType == key, onClick = { selectedType = key }, label = { Text(label, fontSize = 11.sp) })
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = rows.isNotEmpty() && rows.all { it.id in selectedIds }, onCheckedChange = { checked -> selectedIds = if (checked) rows.map { it.id }.toSet() else emptySet() })
                Text("تحديد الكل", fontSize = 12.sp)
                Spacer(Modifier.weight(1f))
                Text("${aggregateArabicDigits(rows.size.toString())} سجل", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.width(6.dp))
                Button(onClick = { editor = null; adding = true }, enabled = statementId != null) {
                    Icon(Icons.Default.Add, null); Spacer(Modifier.width(4.dp)); Text("إضافة اسم")
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(onClick = { onPrepareSelected(selectedRows) }, enabled = selectedTemplatesReady, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.Print, null); Spacer(Modifier.width(4.dp)); Text("طباعة")
                }
                OutlinedButton(onClick = { onExportSelectedPdf(selectedRows) }, enabled = selectedTemplatesReady, modifier = Modifier.weight(1f)) {
                    Text("PDF")
                }
                OutlinedButton(onClick = { onExportSelectedExcel(rows.filter { it.id in selectedIds }) }, enabled = selectedIds.isNotEmpty(), modifier = Modifier.weight(1f)) {
                    Text("Excel")
                }
            }
            Text("المحدد: ${aggregateArabicDigits(selectedIds.size.toString())}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (selectedRows.isNotEmpty() && !selectedTemplatesReady) {
                Text("اختر نموذج نوفمبر الصحيح لكل سجل محدد قبل المعاينة أو الطباعة أو PDF. يمكنك حفظ الاسم والقيمة الآن واستكمال اختيار القالب لاحقًا.", color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
            }
            if (rows.isEmpty()) Text("لا توجد أسماء في هذا الكشف لهذا الشهر بعد.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            rows.forEach { row ->
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 9.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = row.id in selectedIds, onCheckedChange = { checked -> selectedIds = if (checked) selectedIds + row.id else selectedIds - row.id })
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(row.tenant, fontWeight = FontWeight.SemiBold)
                            Text("${formatAggregateAmount(row.amount)} جنيه${row.property.takeIf { it.isNotBlank() }?.let { " • $it" }.orEmpty()}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            val details = listOf(row.unitCode, row.address, row.description, "القالب ${row.templateId.ifBlank { "غير محدد" }}").filter { it.isNotBlank() }.joinToString(" • ")
                            if (details.isNotBlank()) Text(details, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        TextButton(onClick = { previewItem = row }) { Text("معاينة", fontSize = 11.sp) }
                        IconButton(onClick = { editor = row; adding = true }) { Icon(Icons.Default.Edit, "تعديل") }
                        IconButton(onClick = {
                            runCatching { repository.deleteAggregateReceiptItem(row.statementId, row.id); onChanged() }
                                .onFailure { message = it.message ?: "تعذر حذف السجل" }
                        }) { Icon(Icons.Default.Delete, "حذف") }
                    }
                }
            }
            if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
            Text("هذه بيانات كشف شهري مستقلة؛ لا تُنشئ إيصال سداد أو قيدًا ماليًا بمجرد إضافتها أو تعديلها.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }

    if (adding) AggregateReceiptItemDialog(
        initial = editor,
        templateOptions = templateOptions,
        onDismiss = { adding = false; editor = null },
        onSave = { tenant, amount, property, unitCode, description, address, templateId, notes ->
            val id = statementId ?: error("الكشف غير جاهز")
            if (editor == null) repository.addAggregateReceiptItem(id, AggregateReceiptItem(statementId = id, tenant = tenant, amount = amount, property = property, unitCode = unitCode, description = description, address = address, templateId = templateId, notes = notes))
            else repository.updateAggregateReceiptItem(editor!!.copy(tenant = tenant, amount = amount, property = property, unitCode = unitCode, description = description, address = address, templateId = templateId, notes = notes))
            adding = false; editor = null; onChanged()
        }
    )

    previewItem?.let { item ->
        AlertDialog(
            onDismissRequest = { previewItem = null },
            title = { Text("معاينة إيصال — ${item.tenant}") },
            text = {
                val normalizedPreviewDate = remember(issuedDate) {
                    runCatching { com.example.rentals.printing.ReceiptDateFormat.toSheet(com.example.rentals.printing.ReceiptDateFormat.toStorage(issuedDate)) }.getOrNull()
                }
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("القالب: ${item.templateId.ifBlank { "غير محدد" }} • القيمة: ${formatAggregateAmount(item.amount)} جنيه", fontSize = 12.sp)
                    if (item.templateId.isBlank() || templateOptions.none { it.first == item.templateId }) {
                        Text("قالب الإيصال غير محدد أو غير موجود ضمن القوالب الشهرية؛ راجع اختيار النموذج.", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                    } else if (normalizedPreviewDate == null) {
                        Text("تاريخ الإصدار غير صحيح؛ استخدم صيغة سنة/شهر/يوم.", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                    } else {
                        Canvas(Modifier.fillMaxWidth().height(230.dp).background(Color.White)) {
                            drawIntoCanvas { composeCanvas ->
                                OriginalReceiptTemplateRenderer(context).draw(
                                    composeCanvas.nativeCanvas,
                                    RectF(0f, 0f, size.width, size.height),
                                    item,
                                    normalizedPreviewDate
                                )
                            }
                        }
                    }
                    Text("هذه معاينة لنفس محرك الإيصال المستخدم في الطباعة وPDF.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            confirmButton = { TextButton(onClick = { previewItem = null }) { Text("إغلاق") } }
        )
    }
}

@Composable
private fun AggregateReceiptItemDialog(
    initial: AggregateReceiptItem?,
    templateOptions: List<Pair<String, String>>,
    onDismiss: () -> Unit,
    onSave: (String, Double, String, String, String, String, String, String) -> Unit
) {
    var tenant by remember(initial?.id) { mutableStateOf(initial?.tenant.orEmpty()) }
    var amount by remember(initial?.id) { mutableStateOf(initial?.amount?.toString().orEmpty()) }
    var property by remember(initial?.id) { mutableStateOf(initial?.property.orEmpty()) }
    var unitCode by remember(initial?.id) { mutableStateOf(initial?.unitCode.orEmpty()) }
    var description by remember(initial?.id) { mutableStateOf(initial?.description.orEmpty()) }
    var address by remember(initial?.id) { mutableStateOf(initial?.address.orEmpty()) }
    var templateId by remember(initial?.id) { mutableStateOf(initial?.templateId.orEmpty()) }
    var notes by remember(initial?.id) { mutableStateOf(initial?.notes.orEmpty()) }
    var error by remember { mutableStateOf("") }
    var templateMenu by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "إضافة اسم للكشف" else "تعديل بيانات الكشف") },
        text = {
            Column(Modifier.heightIn(max = 520.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("الاسم والقيمة الإيجارية فقط إلزاميان. اختر نموذج نوفمبر المطابق للإيصال؛ لا يُختار نموذج افتراضي حتى لا يُطبع إيصال بتصميم أو بيانات عقار خاطئة. باقي البيانات اختيارية.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                androidx.compose.foundation.rememberScrollState().let { scroll ->
                    Column(Modifier.fillMaxWidth().verticalScroll(scroll), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedTextField(tenant, { tenant = it }, label = { Text("اسم المستأجر / صاحب الإيصال *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(amount, { amount = it }, label = { Text("القيمة الإيجارية بالجنيه *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(property, { property = it }, label = { Text("العقار / المجموعة") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(unitCode, { unitCode = it }, label = { Text("رقم الوحدة (اختياري)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(description, { description = it }, label = { Text("وصف العين") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(address, { address = it }, label = { Text("العنوان / الشارع (اختياري)") }, modifier = Modifier.fillMaxWidth())
                        Box(Modifier.fillMaxWidth()) {
                            OutlinedButton(onClick = { templateMenu = true }, modifier = Modifier.fillMaxWidth()) {
                                Text(templateOptions.firstOrNull { it.first == templateId }?.second ?: if (templateId.isBlank()) "اختيار نموذج إيصال نوفمبر (اختياري)" else "قالب: $templateId")
                            }
                            DropdownMenu(expanded = templateMenu, onDismissRequest = { templateMenu = false }) {
                                templateOptions.forEach { option -> DropdownMenuItem(text = { Text(option.second, fontSize = 11.sp) }, onClick = { templateId = option.first; templateMenu = false }) }
                            }
                        }
                        OutlinedTextField(notes, { notes = it }, label = { Text("ملاحظات / بيانات إضافية") }, minLines = 2, modifier = Modifier.fillMaxWidth())
                    }
                }
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
            }
        },
        confirmButton = { TextButton(onClick = {
            val parsed = parseAggregateAmount(amount)
            if (tenant.isBlank()) error = "أدخل الاسم أولًا"
            else if (parsed == null || !parsed.isFinite() || parsed <= 0.0) error = "أدخل قيمة إيجارية صحيحة أكبر من صفر"
            else { onSave(tenant.trim(), parsed, property.trim(), unitCode.trim(), description.trim(), address.trim(), templateId.trim(), notes.trim()) }
        }) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}
