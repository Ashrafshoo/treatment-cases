package com.medref.drugs

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase

enum class Scope(val label: String) {
    CURATED("المحدّثة"),
    ORIGINAL("الأصلية"),
    DEVICES("الأجهزة"),
    REMOVED("المحذوفة"),
    PENDING("للمراجعة"),
    FAVORITES("المفضلة")
}

data class Item(
    val code: Int,
    val nameAr: String,
    val nameEn: String,
    val concentration: String,
    val dosageForm: String,
    val therapeuticClass: String,
    val isDevice: Boolean,
    val deviceType: String,
    val status: String,
    val reviewGroup: String,
    val decision: String,
    val removalReason: String,
    val correctedName: String,
    val reviewerNote: String,
    val nameSrc: String,
    val family: String,
    val variant: String,
    val classSrc: String,
    val devSrc: String,
    val flag: String,
    val fav: Boolean,
    val tag: String,
    val strength: String = "",
    val pack: String = "",
    val generic: String = "",
    val rel: Int = 0
)

data class Rule(val id: Int, val keyword: String, val cls: String)

data class Family(val name: String, val count: Int, val cls: String)

data class Link(
    val kind: String, val note: String, val iAmKeeper: Boolean,
    val otherCode: Int, val otherEn: String, val otherAr: String,
    val otherStatus: String, val otherDecision: String
)

data class ImportResult(
    val updated: Int, val unchanged: Int, val rejected: Int,
    val unknown: Int, val invalid: Int, val rejectedCodes: List<Int>
)

data class Activity(
    val id: Long,
    val action: String,
    val field: String,
    val oldValue: String,
    val newValue: String,
    val note: String,
    val ts: Long
)

object Labels {
    val status = linkedMapOf(
        "ok" to "سليم",
        "duplicate" to "مكرر",
        "concentration" to "تركيز مختلف",
        "missing_name" to "اسم أجنبي ناقص",
        "device" to "جهاز تعويضي",
        "similar" to "متشابه / مكرر تقريبي"
    )
    val decision = linkedMapOf(
        "pending" to "بانتظار المراجعة",
        "keep" to "مُبقى",
        "remove" to "محذوف من المحدّثة",
        "rename" to "اسم مصحّح",
        "merge" to "مدموج"
    )
    val field = mapOf(
        "name_ar" to "الاسم العربي",
        "name_en" to "الاسم الأجنبي",
        "concentration" to "التركيز",
        "dosage_form" to "الشكل الدوائي",
        "therapeutic_class" to "التصنيف العلاجي",
        "device_type" to "نوع الجهاز",
        "decision" to "القرار",
        "removal_reason" to "سبب الحذف",
        "corrected_name" to "الاسم الصحيح",
        "is_device" to "القسم",
        "status" to "الحالة",
        "tag" to "الوسم"
    )
    val action = mapOf(
        "comment" to "تعليق",
        "edit" to "تعديل",
        "decision" to "قرار",
        "undo" to "تراجع"
    )
    val kind = mapOf(
        "dup_exact" to "تكرار مطابق",
        "dup_near" to "تكرار تقريبي",
        "similar" to "متشابه إملائيًا"
    )
    fun isAuto(src: String) = src == "auto_dict" || src == "auto_translit"
    fun isAutoClass(src: String) = src == "auto_generic" || src == "auto_family" || src == "auto_eda" || src == "auto_rule"
    fun classHow(src: String) = when (src) {
        "auto_generic" -> "من المادة الفعّالة في الاسم"
        "auto_family" -> "من أشقاء نفس الدواء المصنّفين"
        "auto_eda" -> "من قاعدة الأدوية المصرية"
        "auto_rule" -> "من قاعدة تصنيف أضفتها"
        else -> ""
    }
}

/** نفس منطق tools/build_db.py — يجب أن يبقيا متطابقين. */
object Norm {
    private val diacritics = Regex("[\\u064B-\\u065F\\u0670\\u0640]")
    private val spaces = Regex("\\s+")

    fun of(s: String?): String {
        if (s.isNullOrBlank()) return ""
        val t = diacritics.replace(s.lowercase(), "")
        val sb = StringBuilder(t.length)
        for (c in t) {
            sb.append(
                when (c) {
                    'أ', 'إ', 'آ', 'ٱ' -> 'ا'
                    'ى' -> 'ي'
                    'ة' -> 'ه'
                    in '٠'..'٩' -> '0' + (c - '٠')
                    else -> c
                }
            )
        }
        return spaces.replace(sb.toString(), " ").trim()
    }
}

class Db private constructor(private val sql: SQLiteDatabase) {

    companion object {
        private const val FILE = "drugs.db"
        private val EDITABLE = listOf(
            "name_ar", "name_en", "concentration", "dosage_form",
            "therapeutic_class", "device_type", "decision", "removal_reason", "corrected_name", "tag"
        )
        private val UNDOABLE = setOf(
            "name_ar", "concentration", "dosage_form", "therapeutic_class", "device_type",
            "decision", "removal_reason", "corrected_name", "status", "is_device", "tag"
        )

        @Volatile
        private var inst: Db? = null

        fun get(ctx: Context): Db = inst ?: synchronized(this) {
            inst ?: open(ctx.applicationContext).also { inst = it }
        }

        private fun open(ctx: Context): Db {
            val f = ctx.getDatabasePath(FILE)
            if (!f.exists()) {
                f.parentFile?.mkdirs()
                ctx.assets.open(FILE).use { input -> f.outputStream().use { out -> input.copyTo(out) } }
            }
            val d = SQLiteDatabase.openDatabase(f.path, null, SQLiteDatabase.OPEN_READWRITE)
            migrate(d)
            return Db(d)
        }

        /** يضيف أعمدة/جداول الإصدارات الأحدث لقاعدة قديمة دون فقد تعديلات المستخدم. */
        private fun migrate(d: SQLiteDatabase) {
            val cols = listOf(
                "name_src TEXT NOT NULL DEFAULT 'original'", "family TEXT NOT NULL DEFAULT ''",
                "variant TEXT NOT NULL DEFAULT ''", "class_src TEXT NOT NULL DEFAULT ''",
                "dev_src TEXT NOT NULL DEFAULT ''", "flag TEXT NOT NULL DEFAULT ''",
                "fav INTEGER NOT NULL DEFAULT 0", "tag TEXT NOT NULL DEFAULT ''",
                "strength TEXT NOT NULL DEFAULT ''", "pack TEXT NOT NULL DEFAULT ''", "generic TEXT NOT NULL DEFAULT ''"
            )
            for (t in listOf("items", "original_items")) {
                val have = HashSet<String>()
                d.rawQuery("PRAGMA table_info($t)", null).use { c -> while (c.moveToNext()) have.add(c.getString(1)) }
                for (def in cols) if (def.substringBefore(' ') !in have) d.execSQL("ALTER TABLE $t ADD COLUMN $def")
            }
            d.execSQL("CREATE TABLE IF NOT EXISTS links (id INTEGER PRIMARY KEY AUTOINCREMENT, code INTEGER NOT NULL, related INTEGER NOT NULL, kind TEXT NOT NULL, note TEXT NOT NULL DEFAULT '')")
            d.execSQL("CREATE TABLE IF NOT EXISTS missing_codes (code INTEGER PRIMARY KEY)")
            d.execSQL("CREATE TABLE IF NOT EXISTS rules (id INTEGER PRIMARY KEY AUTOINCREMENT, keyword TEXT NOT NULL, cls TEXT NOT NULL)")
        }

        fun canUndo(a: Activity): Boolean = a.action != "comment" && a.action != "undo" && a.field in UNDOABLE

        fun dbFile(ctx: Context): java.io.File = ctx.getDatabasePath(FILE)

        /** يستبدل القاعدة بنسخة احتياطية بعد التأكد من سلامة بنيتها. */
        fun replaceWith(ctx: Context, src: java.io.File): Boolean {
            try {
                val test = SQLiteDatabase.openDatabase(src.path, null, SQLiteDatabase.OPEN_READONLY)
                try {
                    var ok = false
                    test.rawQuery("SELECT COUNT(*) FROM items", null).use { c -> c.moveToFirst(); ok = c.getInt(0) > 0 }
                    test.rawQuery("SELECT COUNT(*) FROM original_items", null).use { c -> c.moveToFirst() }
                    test.rawQuery("SELECT COUNT(*) FROM activity", null).use { c -> c.moveToFirst() }
                    test.rawQuery("SELECT name_src FROM items LIMIT 1", null).use { c -> c.moveToFirst() }
                    if (!ok) return false
                } finally {
                    test.close()
                }
            } catch (e: Exception) {
                return false
            }
            synchronized(this) {
                inst?.sql?.close()
                inst = null
                src.copyTo(ctx.getDatabasePath(FILE), overwrite = true)
            }
            return true
        }

        /** يمسح كل التعديلات ويعيد النسخة الأصلية المرفقة مع التطبيق. */
        fun reset(ctx: Context) {
            synchronized(this) {
                inst?.sql?.close()
                inst = null
                ctx.getDatabasePath(FILE).delete()
            }
        }
    }

    private fun table(scope: Scope) = if (scope == Scope.ORIGINAL) "original_items" else "items"

    private fun where(scope: Scope, q: String, status: String?, args: MutableList<String>): String {
        val w = ArrayList<String>()
        when (scope) {
            Scope.CURATED -> w += "decision != 'remove' AND is_device = 0"
            Scope.DEVICES -> w += "is_device = 1 AND decision != 'remove'"
            Scope.REMOVED -> w += "decision = 'remove'"
            Scope.PENDING -> w += "decision = 'pending' AND is_device = 0"
            Scope.FAVORITES -> w += "fav = 1 AND decision != 'remove'"
            Scope.ORIGINAL -> {}
        }
        when (status) {
            null, "" -> {}
            "auto_ar" -> w += "name_src IN ('auto_dict', 'auto_translit')"
            "auto_cls" -> w += "class_src IN ('auto_generic', 'auto_family', 'auto_eda', 'auto_rule')"
            "auto_dev" -> w += "dev_src = 'auto'"
            "flag" -> w += "flag != ''"
            else -> { w += "status = ?"; args += status }
        }
        val tokens = Norm.of(q).replace("%", "").replace("_", "").split(" ").filter { it.isNotEmpty() }
        for (tok in tokens) {
            w += "(search LIKE ? OR CAST(code AS TEXT) LIKE ?)"
            args += "%$tok%"
            args += "%$tok%"
        }
        return if (w.isEmpty()) "" else " WHERE " + w.joinToString(" AND ")
    }

    /** هل استُخدم تسامح إملائي في آخر بحث؟ (لعرض «نتائج تقريبية»). */
    @Volatile
    var loose = false

    private fun loosen(q: String): String =
        Norm.of(q).split(" ").filter { it.isNotEmpty() }.joinToString(" ") { if (it.length >= 5) it.dropLast(1) else it }

    private fun runSearch(scope: Scope, q: String, status: String?, limit: Int, offset: Int): List<Item> {
        val args = ArrayList<String>()
        val w = where(scope, q, status, args)
        val n = Norm.of(q).replace("%", "").replace("_", "")
        args += n
        args += "$n%"
        args += "% $n%"
        val text = "SELECT * FROM ${table(scope)}$w " +
            "ORDER BY CASE WHEN CAST(code AS TEXT) = ? THEN 0 WHEN search LIKE ? THEN 1 WHEN search LIKE ? THEN 2 ELSE 3 END, code " +
            "LIMIT $limit OFFSET $offset"
        sql.rawQuery(text, args.toTypedArray()).use { c ->
            val out = ArrayList<Item>()
            while (c.moveToNext()) out += read(c)
            return out
        }
    }

    /** ترتيب بالصلة (كود مطابق ← بداية الاسم ← احتواؤه)، وإن لم توجد نتائج يُخفَّف البحث درجة. */
    fun search(scope: Scope, q: String, status: String?, limit: Int, offset: Int): List<Item> {
        val r = runSearch(scope, q, status, limit, offset)
        if (offset == 0) loose = false
        if (r.isEmpty() && offset == 0 && q.isNotBlank()) {
            val l = loosen(q)
            if (l != Norm.of(q)) {
                val r2 = runSearch(scope, l, status, limit, offset)
                if (r2.isNotEmpty()) loose = true
                return r2
            }
        }
        return r
    }

    fun count(scope: Scope, q: String, status: String?): Int {
        val n = rawCount(scope, q, status)
        if (n == 0 && q.isNotBlank()) {
            val l = loosen(q)
            if (l != Norm.of(q)) return rawCount(scope, l, status)
        }
        return n
    }

    private fun rawCount(scope: Scope, q: String, status: String?): Int {
        val args = ArrayList<String>()
        val w = where(scope, q, status, args)
        sql.rawQuery("SELECT COUNT(*) FROM ${table(scope)}$w", args.toTypedArray()).use { c ->
            c.moveToFirst()
            return c.getInt(0)
        }
    }

    // ---------- الدواء ← التركيز ----------
    fun families(scope: Scope, q: String, status: String?, limit: Int, offset: Int): List<Family> {
        val args = ArrayList<String>()
        val w = where(scope, q, status, args)
        val text = "SELECT family, COUNT(*) n, " +
            "MIN(CASE WHEN therapeutic_class NOT IN ('', 'غير محدد') THEN therapeutic_class END) cls " +
            "FROM ${table(scope)}$w GROUP BY family ORDER BY family LIMIT $limit OFFSET $offset"
        sql.rawQuery(text, args.toTypedArray()).use { c ->
            val out = ArrayList<Family>()
            while (c.moveToNext()) out += Family(c.getString(0) ?: "", c.getInt(1), c.getString(2) ?: "")
            return out
        }
    }

    fun countFamilies(scope: Scope, q: String, status: String?): Int {
        val args = ArrayList<String>()
        val w = where(scope, q, status, args)
        sql.rawQuery("SELECT COUNT(DISTINCT family) FROM ${table(scope)}$w", args.toTypedArray()).use { c ->
            c.moveToFirst()
            return c.getInt(0)
        }
    }

    /** تراكيز/عبوات دواء واحد (للأقسام المعروضة فقط) مع عدد المرتبطات بكل منها. */
    fun variants(family: String, scope: Scope, q: String): List<Item> {
        val wargs = ArrayList<String>()
        val w = where(scope, q, null, wargs)
        val cond = if (w.isEmpty()) " WHERE family = ?" else w.replaceFirst(" WHERE ", " WHERE family = ? AND ")
        val args = ArrayList<String>()
        args += family
        args.addAll(wargs)
        val text = "SELECT *, (SELECT COUNT(*) FROM links l WHERE l.code = items.code OR l.related = items.code) rel " +
            "FROM items$cond ORDER BY variant, code"
        sql.rawQuery(text, args.toTypedArray()).use { c ->
            val out = ArrayList<Item>()
            while (c.moveToNext()) out += read(c)
            return out
        }
    }

    fun get(code: Int, original: Boolean = false): Item? {
        val t = if (original) "original_items" else "items"
        sql.rawQuery("SELECT * FROM $t WHERE code = ?", arrayOf(code.toString())).use { c ->
            return if (c.moveToFirst()) read(c) else null
        }
    }

    /** ما ارتبط بالصنف وما حدث: الصحيح ⇄ المحذوف المكرر/التقريبي ⇄ المتشابه. */
    fun linksFor(code: Int): List<Link> {
        val c0 = code.toString()
        sql.rawQuery(
            "SELECT l.kind, l.note, l.code, i.code, i.name_en, i.name_ar, i.status, i.decision " +
                "FROM links l JOIN items i ON i.code = CASE WHEN l.code = ? THEN l.related ELSE l.code END " +
                "WHERE l.code = ? OR l.related = ? ORDER BY l.kind, i.code",
            arrayOf(c0, c0, c0)
        ).use { c ->
            val out = ArrayList<Link>()
            while (c.moveToNext()) {
                out += Link(
                    c.getString(0), c.getString(1) ?: "", c.getInt(2) == code,
                    c.getInt(3), c.getString(4) ?: "", c.getString(5) ?: "",
                    c.getString(6) ?: "", c.getString(7) ?: ""
                )
            }
            return out
        }
    }

    /** بدائل: المادة الفعّالة والقوة نفسهما (والشكل نفسه إن عُرف)، من أدوية أخرى غير محذوفة. */
    fun alternatives(item: Item): List<Item> {
        if (item.generic.isBlank() || item.strength.isBlank()) return emptyList()
        sql.rawQuery(
            "SELECT * FROM items WHERE generic = ? AND strength = ? AND code != ? AND decision != 'remove' AND is_device = 0 " +
                "AND (? = '' OR dosage_form = '' OR dosage_form = ?) ORDER BY family, code LIMIT 40",
            arrayOf(item.generic, item.strength, item.code.toString(), item.dosageForm, item.dosageForm)
        ).use { c ->
            val out = ArrayList<Item>()
            while (c.moveToNext()) out += read(c)
            return out
        }
    }

    /** قيم القوة المتاحة لدواء (للشرائح السريعة)، مرتّبة رقميًا. */
    fun strengths(family: String): List<String> {
        sql.rawQuery("SELECT DISTINCT strength FROM items WHERE family = ? AND strength != '' AND decision != 'remove'", arrayOf(family)).use { c ->
            val out = ArrayList<String>()
            while (c.moveToNext()) out += c.getString(0)
            return out.sortedBy { it.substringBefore(' ').substringBefore('/').toDoubleOrNull() ?: Double.MAX_VALUE }
        }
    }

    fun forms(): List<String> {
        sql.rawQuery("SELECT DISTINCT dosage_form FROM items WHERE dosage_form != '' ORDER BY 1", null).use { c ->
            val out = ArrayList<String>()
            while (c.moveToNext()) out += c.getString(0)
            return out
        }
    }

    /** التصنيفات المستخدمة حاليًا (للاختيار عند التعديل). */
    fun classes(): List<String> {
        sql.rawQuery("SELECT DISTINCT therapeutic_class FROM items WHERE therapeutic_class != '' ORDER BY 1", null).use { c ->
            val out = ArrayList<String>()
            while (c.moveToNext()) out += c.getString(0)
            return out
        }
    }

    fun familyCount(family: String): Int {
        sql.rawQuery("SELECT COUNT(*) FROM items WHERE family = ? AND decision != 'remove'", arrayOf(family)).use { c ->
            c.moveToFirst()
            return c.getInt(0)
        }
    }

    fun isMissingCode(code: Int): Boolean {
        sql.rawQuery("SELECT 1 FROM missing_codes WHERE code = ?", arrayOf(code.toString())).use { c -> return c.moveToFirst() }
    }

    fun missingCodes(): List<Int> {
        sql.rawQuery("SELECT code FROM missing_codes ORDER BY code", null).use { c ->
            val out = ArrayList<Int>()
            while (c.moveToNext()) out += c.getInt(0)
            return out
        }
    }

    /** تعلّم من قرارك: يعمّم تصنيف الصنف على أشقائه غير المصنّفين كاقتراح. */
    fun propagateClass(code: Int): Int {
        val cur = get(code) ?: return 0
        if (cur.isDevice || cur.family.isBlank() || cur.therapeuticClass.isBlank() || cur.therapeuticClass == "غير محدد") return 0
        val w = "family = ? AND code != ? AND therapeutic_class IN ('', 'غير محدد') AND is_device = 0 AND decision != 'remove'"
        val a = arrayOf(cur.family, code.toString())
        var n = 0
        sql.rawQuery("SELECT COUNT(*) FROM items WHERE $w", a).use { c -> c.moveToFirst(); n = c.getInt(0) }
        if (n == 0) return 0
        sql.beginTransaction()
        try {
            sql.execSQL(
                "INSERT INTO activity(code, action, field, old_value, new_value, note, ts) " +
                    "SELECT code, 'edit', 'therapeutic_class', 'غير محدد', ?, ?, ? FROM items WHERE $w",
                arrayOf<Any>(cur.therapeuticClass, "عُمّم من تصنيف الصنف $code الذي اعتمدته", System.currentTimeMillis(), cur.family, code.toString())
            )
            sql.execSQL(
                "UPDATE items SET therapeutic_class = ?, class_src = 'auto_family' WHERE $w",
                arrayOf<Any>(cur.therapeuticClass, cur.family, code.toString())
            )
            sql.setTransactionSuccessful()
        } finally {
            sql.endTransaction()
        }
        return n
    }

    // ---------- قواعد التصنيف القابلة للتعديل ----------
    fun rules(): List<Rule> {
        sql.rawQuery("SELECT id, keyword, cls FROM rules ORDER BY id", null).use { c ->
            val out = ArrayList<Rule>()
            while (c.moveToNext()) out += Rule(c.getInt(0), c.getString(1), c.getString(2))
            return out
        }
    }

    fun addRule(keyword: String, cls: String) {
        if (keyword.isBlank() || cls.isBlank()) return
        val cv = ContentValues()
        cv.put("keyword", keyword.trim())
        cv.put("cls", cls)
        sql.insert("rules", null, cv)
    }

    fun deleteRule(id: Int) {
        sql.delete("rules", "id = ?", arrayOf(id.toString()))
    }

    /** يطبّق كل القواعد على الأدوية غير المصنّفة كاقتراحات (auto_rule). */
    fun applyRules(): Int {
        var total = 0
        sql.beginTransaction()
        try {
            for (r in rules()) {
                val k = Norm.of(r.keyword).replace("%", "").replace("_", "")
                if (k.isEmpty()) continue
                val w = "therapeutic_class IN ('', 'غير محدد') AND is_device = 0 AND decision != 'remove' AND search LIKE ?"
                val like = "%$k%"
                var n = 0
                sql.rawQuery("SELECT COUNT(*) FROM items WHERE $w", arrayOf(like)).use { c -> c.moveToFirst(); n = c.getInt(0) }
                if (n == 0) continue
                sql.execSQL(
                    "INSERT INTO activity(code, action, field, old_value, new_value, note, ts) " +
                        "SELECT code, 'edit', 'therapeutic_class', 'غير محدد', ?, ?, ? FROM items WHERE $w",
                    arrayOf<Any>(r.cls, "قاعدة: «${r.keyword}»", System.currentTimeMillis(), like)
                )
                sql.execSQL(
                    "UPDATE items SET therapeutic_class = ?, class_src = 'auto_rule' WHERE $w",
                    arrayOf<Any>(r.cls, like)
                )
                total += n
            }
            sql.setTransactionSuccessful()
        } finally {
            sql.endTransaction()
        }
        return total
    }

    // ---------- إجراءات جماعية على قائمة أكواد ----------
    /** op: tag | class | decision | device | drug | fav. يعيد عدد الأصناف التي تغيّرت. */
    fun applyToCodes(codes: List<Int>, op: String, value: String): Int {
        var n = 0
        sql.beginTransaction()
        try {
            when (op) {
                "device" -> n = moveItems(codes, true)
                "drug" -> n = moveItems(codes, false)
                "fav" -> { for (c in codes) setFav(c, value == "1"); n = codes.size }
                else -> {
                    val key = when (op) { "tag" -> "tag"; "class" -> "therapeutic_class"; else -> "decision" }
                    for (c in codes) n += update(c, mapOf(key to value))
                }
            }
            sql.setTransactionSuccessful()
        } finally {
            sql.endTransaction()
        }
        return n
    }

    /** بحث واستبدال في الأسماء العربية لقائمة أكواد. */
    fun findReplaceAr(codes: List<Int>, find: String, repl: String): Int {
        if (find.isEmpty()) return 0
        var n = 0
        sql.beginTransaction()
        try {
            for (c in codes) {
                val cur = get(c) ?: continue
                if (cur.nameAr.contains(find)) n += update(c, mapOf("name_ar" to cur.nameAr.replace(find, repl)))
            }
            sql.setTransactionSuccessful()
        } finally {
            sql.endTransaction()
        }
        return n
    }

    // ---------- التعديل ----------
    /** يعدّل الحقول المتغيّرة فقط ويسجّل كل تغيير. لا يوجد حذف للأكواد إطلاقًا. */
    fun update(code: Int, newValues: Map<String, String>): Int {
        val cur = get(code) ?: return 0
        val curMap = mapOf(
            "name_ar" to cur.nameAr, "name_en" to cur.nameEn,
            "concentration" to cur.concentration, "dosage_form" to cur.dosageForm,
            "therapeutic_class" to cur.therapeuticClass, "device_type" to cur.deviceType,
            "decision" to cur.decision, "removal_reason" to cur.removalReason,
            "corrected_name" to cur.correctedName, "tag" to cur.tag
        )
        val cv = ContentValues()
        var changed = 0
        sql.beginTransaction()
        try {
            for (k in EDITABLE) {
                val nv = newValues[k]?.trim() ?: continue
                // الاسم الأجنبي ملتصق بالكود: لا يُغيَّر، ويُكمَل فقط إن كان فارغًا.
                if (k == "name_en" && cur.nameEn.isNotBlank()) continue
                if (k == "name_ar" && nv.isBlank()) continue
                val old = curMap[k] ?: ""
                if (nv == old) continue
                cv.put(k, nv)
                log(code, if (k == "decision") "decision" else "edit", k, old, nv, "")
                changed++
            }
            if (changed > 0) {
                if (cv.containsKey("name_ar")) cv.put("name_src", "manual")
                if (cv.containsKey("therapeutic_class")) cv.put("class_src", "manual")
                if (cv.containsKey("name_en") && cur.status == "missing_name") {
                    cv.put("status", "ok")
                    log(code, "edit", "status", "اسم أجنبي ناقص", "سليم", "اكتمل الاسم الأجنبي")
                }
                val na = cv.getAsString("name_ar") ?: cur.nameAr
                val ne = cv.getAsString("name_en") ?: cur.nameEn
                val co = cv.getAsString("concentration") ?: cur.concentration
                val tg = cv.getAsString("tag") ?: cur.tag
                cv.put("search", Norm.of("$na $ne $co $tg"))
                sql.update("items", cv, "code = ?", arrayOf(code.toString()))
            }
            sql.setTransactionSuccessful()
        } finally {
            sql.endTransaction()
        }
        return changed
    }

    /** نقل بين الأدوية والأجهزة مع الحفاظ على حالة (مكرر/تركيز…) إن وُجدت. */
    fun moveItems(codes: Collection<Int>, toDevice: Boolean): Int {
        var n = 0
        sql.beginTransaction()
        try {
            for (code in codes) {
                val item = get(code) ?: continue
                if (item.isDevice == toDevice) continue
                val newStatus = if (toDevice) {
                    if (item.status == "ok") "device" else item.status
                } else {
                    if (item.status == "device") "ok" else item.status
                }
                val cv = ContentValues()
                cv.put("is_device", if (toDevice) 1 else 0)
                cv.put("status", newStatus)
                cv.put("dev_src", if (toDevice) "approved" else "")
                val isDevClass = item.therapeuticClass.startsWith("أجهزة")
                if (toDevice && (item.therapeuticClass.isBlank() || item.therapeuticClass == "غير محدد")) {
                    cv.put("therapeutic_class", "أجهزة تعويضية"); cv.put("class_src", "manual")
                }
                if (!toDevice && isDevClass) {
                    cv.put("therapeutic_class", "غير محدد"); cv.put("class_src", "")
                }
                sql.update("items", cv, "code = ?", arrayOf(code.toString()))
                log(
                    code, "decision", "is_device",
                    if (item.isDevice) "جهاز تعويضي" else "دواء",
                    if (toDevice) "جهاز تعويضي" else "دواء", ""
                )
                n++
            }
            sql.setTransactionSuccessful()
        } finally {
            sql.endTransaction()
        }
        return n
    }

    fun setFav(code: Int, on: Boolean) {
        val cv = ContentValues()
        cv.put("fav", if (on) 1 else 0)
        sql.update("items", cv, "code = ?", arrayOf(code.toString()))
    }

    // ---------- اعتماد المقترحات ----------
    fun approveName(code: Int) = approveCol(code, "name_src", "name_ar", "IN ('auto_dict', 'auto_translit')", "مقترح آليًا")
    fun approveClass(code: Int) = approveCol(code, "class_src", "therapeutic_class", "IN ('auto_generic', 'auto_family', 'auto_eda', 'auto_rule')", "مقترح آليًا")
    fun approveDevice(code: Int) = approveCol(code, "dev_src", "is_device", "= 'auto'", "مقترح بالبحث")

    private fun approveCol(code: Int, col: String, field: String, cond: String, oldLabel: String) {
        val cv = ContentValues()
        cv.put(col, "approved")
        sql.beginTransaction()
        try {
            val n = sql.update("items", cv, "code = ? AND $col $cond", arrayOf(code.toString()))
            if (n > 0) log(code, "decision", field, oldLabel, "معتمد", "")
            sql.setTransactionSuccessful()
        } finally {
            sql.endTransaction()
        }
    }

    /** اعتماد جماعي: kind = names | class | device. */
    fun approveAll(kind: String): Int {
        val (col, cond, field, old) = when (kind) {
            "names" -> listOf("name_src", "IN ('auto_dict', 'auto_translit')", "name_ar", "مقترح آليًا")
            "class" -> listOf("class_src", "IN ('auto_generic', 'auto_family', 'auto_eda', 'auto_rule')", "therapeutic_class", "مقترح آليًا")
            else -> listOf("dev_src", "= 'auto'", "is_device", "مقترح بالبحث")
        }
        sql.rawQuery("SELECT COUNT(*) FROM items WHERE $col $cond", null).use { c ->
            c.moveToFirst()
            val n = c.getInt(0)
            if (n == 0) return 0
            sql.beginTransaction()
            try {
                sql.execSQL(
                    "INSERT INTO activity(code, action, field, old_value, new_value, note, ts) " +
                        "SELECT code, 'decision', ?, ?, 'معتمد', 'اعتماد جماعي', ? FROM items WHERE $col $cond",
                    arrayOf<Any>(field, old, System.currentTimeMillis())
                )
                sql.execSQL("UPDATE items SET $col = 'approved' WHERE $col $cond")
                sql.setTransactionSuccessful()
            } finally {
                sql.endTransaction()
            }
            return n
        }
    }

    fun countAutoNames(): Int = scalar("SELECT COUNT(*) FROM items WHERE name_src IN ('auto_dict', 'auto_translit')")

    // ---------- قوائم المراجعة الموجّهة ----------
    private fun queueWhere(kind: String): String = when (kind) {
        "names" -> "name_src IN ('auto_dict', 'auto_translit') AND decision != 'remove'"
        "class" -> "class_src IN ('auto_generic', 'auto_family', 'auto_eda', 'auto_rule') AND decision != 'remove'"
        "device" -> "dev_src = 'auto' AND decision != 'remove'"
        "similar" -> "status = 'similar' AND decision != 'remove'"
        "flag" -> "flag != '' AND decision != 'remove'"
        else -> "decision = 'pending' AND is_device = 0"
    }

    fun queue(kind: String): List<Int> {
        sql.rawQuery("SELECT code FROM items WHERE ${queueWhere(kind)} ORDER BY code", null).use { c ->
            val out = ArrayList<Int>(c.count)
            while (c.moveToNext()) out += c.getInt(0)
            return out
        }
    }

    fun queueCount(kind: String): Int = scalar("SELECT COUNT(*) FROM items WHERE ${queueWhere(kind)}")

    /** إجراء «اعتماد» في وضع المراجعة الموجّهة حسب نوع القائمة. */
    fun approveFor(kind: String, code: Int) {
        when (kind) {
            "names" -> approveName(code)
            "class" -> approveClass(code)
            "device" -> approveDevice(code)
            "similar" -> setStatusOk(code, "ليسا نفس الدواء — تم التحقق")
            "flag" -> {
                val cv = ContentValues(); cv.put("flag", "")
                sql.update("items", cv, "code = ?", arrayOf(code.toString()))
                log(code, "decision", "name_ar", "تعارض", "تم التحقق", "")
            }
            else -> update(code, mapOf("decision" to "keep"))
        }
    }

    private fun setStatusOk(code: Int, note: String) {
        val cur = get(code) ?: return
        if (cur.status == "ok") return
        val cv = ContentValues(); cv.put("status", "ok")
        sql.update("items", cv, "code = ?", arrayOf(code.toString()))
        log(code, "edit", "status", Labels.status[cur.status] ?: cur.status, "سليم", note)
    }

    // ---------- لوحة التقدم ----------
    private fun scalar(q: String): Int {
        sql.rawQuery(q, null).use { c -> c.moveToFirst(); return c.getInt(0) }
    }

    fun dashboard(): Map<String, Int> {
        val live = "decision != 'remove'"
        val drug = "$live AND is_device = 0"
        return linkedMapOf(
            "total" to scalar("SELECT COUNT(*) FROM items"),
            "live" to scalar("SELECT COUNT(*) FROM items WHERE $live"),
            "removed" to scalar("SELECT COUNT(*) FROM items WHERE decision = 'remove'"),
            "removed_exact" to scalar("SELECT COUNT(*) FROM items WHERE decision = 'remove' AND status = 'duplicate'"),
            "removed_near" to scalar("SELECT COUNT(*) FROM items WHERE decision = 'remove' AND status = 'similar'"),
            "names_auto" to scalar("SELECT COUNT(*) FROM items WHERE name_src IN ('auto_dict', 'auto_translit') AND $live"),
            "names_done" to scalar("SELECT COUNT(*) FROM items WHERE name_src IN ('approved', 'manual') AND $live"),
            "class_auto" to scalar("SELECT COUNT(*) FROM items WHERE class_src IN ('auto_generic', 'auto_family', 'auto_eda', 'auto_rule') AND $drug"),
            "class_done" to scalar("SELECT COUNT(*) FROM items WHERE therapeutic_class NOT IN ('', 'غير محدد') AND (class_src IN ('original', 'approved', 'manual')) AND $drug"),
            "class_none" to scalar("SELECT COUNT(*) FROM items WHERE therapeutic_class IN ('', 'غير محدد') AND $drug"),
            "dev_orig" to scalar("SELECT COUNT(*) FROM items WHERE is_device = 1 AND dev_src IN ('original', 'approved') AND $live"),
            "dev_auto" to scalar("SELECT COUNT(*) FROM items WHERE dev_src = 'auto' AND $live"),
            "similar" to scalar("SELECT COUNT(*) FROM items WHERE status = 'similar' AND $live"),
            "flag" to scalar("SELECT COUNT(*) FROM items WHERE flag != '' AND $live"),
            "pending" to scalar("SELECT COUNT(*) FROM items WHERE decision = 'pending' AND is_device = 0"),
            "decided" to scalar("SELECT COUNT(*) FROM items WHERE decision != 'pending' AND $live AND is_device = 0"),
            "missing" to scalar("SELECT COUNT(*) FROM missing_codes")
        )
    }

    // ---------- التراجع ----------
    /** يعيد null عند النجاح أو رسالة سبب الفشل. */
    fun undo(activityId: Long): String? {
        var code = 0; var action = ""; var field = ""; var oldV = ""; var newV = ""
        sql.rawQuery("SELECT code, action, field, old_value, new_value FROM activity WHERE id = ?", arrayOf(activityId.toString())).use { c ->
            if (!c.moveToFirst()) return "السجل غير موجود"
            code = c.getInt(0); action = c.getString(1); field = c.getString(2)
            oldV = c.getString(3) ?: ""; newV = c.getString(4) ?: ""
        }
        if (action == "comment" || action == "undo" || field !in UNDOABLE) return "هذا الإجراء لا يُتراجع عنه"
        val cur = get(code) ?: return "الصنف غير موجود"
        if (field == "is_device") {
            val nowLabel = if (cur.isDevice) "جهاز تعويضي" else "دواء"
            if (nowLabel != newV) return "تغيّرت القيمة بعد هذا الإجراء"
            moveItems(listOf(code), oldV == "جهاز تعويضي")
            return null
        }
        val current = when (field) {
            "name_ar" -> cur.nameAr; "concentration" -> cur.concentration; "dosage_form" -> cur.dosageForm
            "therapeutic_class" -> cur.therapeuticClass; "device_type" -> cur.deviceType
            "decision" -> cur.decision; "removal_reason" -> cur.removalReason
            "corrected_name" -> cur.correctedName; "status" -> cur.status; "tag" -> cur.tag
            else -> return "غير مدعوم"
        }
        // حقل القرار/الحالة يُسجَّل أحيانًا بتسمية عربية
        val cmp = when (field) {
            "status" -> Labels.status[current] ?: current
            else -> current
        }
        if (cmp != newV && current != newV) return "تغيّرت القيمة بعد هذا الإجراء"
        val restore = if (field == "status") (Labels.status.entries.firstOrNull { it.value == oldV }?.key ?: oldV) else oldV
        val cv = ContentValues()
        cv.put(field, restore)
        if (field == "therapeutic_class") cv.put("class_src", "")
        if (field == "name_ar") cv.put("name_src", "original")
        if (field == "name_ar" || field == "tag") {
            val na = if (field == "name_ar") restore else cur.nameAr
            val tg = if (field == "tag") restore else cur.tag
            cv.put("search", Norm.of("$na ${cur.nameEn} ${cur.concentration} $tg"))
        }
        sql.beginTransaction()
        try {
            sql.update("items", cv, "code = ?", arrayOf(code.toString()))
            log(code, "undo", field, newV, oldV, "تراجع عن تعديل #$activityId")
            sql.setTransactionSuccessful()
        } finally {
            sql.endTransaction()
        }
        return null
    }

    // ---------- الاستيراد ----------
    /** كل القائمة العاملة (للتصدير القابل للاستيراد). */
    fun allCurrent(): List<Item> {
        sql.rawQuery("SELECT * FROM items ORDER BY code", null).use { c ->
            val out = ArrayList<Item>(c.count)
            while (c.moveToNext()) out += read(c)
            return out
        }
    }

    /**
     * يطبّق صفوف CSV المعدّلة. المفتاح هو (الكود + الاسم الأجنبي): إن لم يتطابق الاسم الأجنبي مع كوده
     * يُرفض الصف كاملًا. الحقول غير الموجودة في الملف لا تُمس.
     */
    fun importRows(rows: List<Map<String, String>>): ImportResult {
        var updated = 0
        var unchanged = 0
        var rejected = 0
        var unknown = 0
        var invalid = 0
        val rej = ArrayList<Int>()
        sql.beginTransaction()
        try {
            for (r in rows) {
                val code = r["item_code"]?.trim()?.toIntOrNull()
                if (code == null) { invalid++; continue }
                val cur = get(code)
                if (cur == null) { unknown++; continue }
                val en = r["name_en"]?.trim() ?: ""
                if (en.isNotEmpty() && cur.nameEn.isNotEmpty() && en != cur.nameEn) {
                    rejected++
                    if (rej.size < 8) rej += code
                    continue
                }
                val m = HashMap<String, String>()
                for (k in listOf("name_ar", "concentration", "dosage_form", "therapeutic_class",
                    "device_type", "removal_reason", "corrected_name", "tag")) {
                    val v = r[k] ?: continue
                    m[k] = v
                }
                if (cur.nameEn.isEmpty() && en.isNotEmpty()) m["name_en"] = en
                val dec = r["decision"]?.trim() ?: ""
                if (dec.isNotEmpty()) {
                    val key = if (Labels.decision.containsKey(dec)) dec
                    else Labels.decision.entries.firstOrNull { it.value == dec }?.key
                    if (key != null) m["decision"] = key else invalid++
                }
                var n = update(code, m)
                val dev = r["is_device"]?.trim() ?: ""
                if (dev == "1" || dev == "0") {
                    val want = dev == "1"
                    if (want != cur.isDevice) n += moveItems(listOf(code), want)
                }
                val fv = r["fav"]?.trim() ?: ""
                if ((fv == "1" || fv == "0") && (fv == "1") != cur.fav) { setFav(code, fv == "1"); n++ }
                if (n > 0) updated++ else unchanged++
            }
            sql.setTransactionSuccessful()
        } finally {
            sql.endTransaction()
        }
        return ImportResult(updated, unchanged, rejected, unknown, invalid, rej)
    }

    // ---------- السجل ----------
    fun addComment(code: Int, note: String) {
        if (note.isBlank()) return
        log(code, "comment", "", "", "", note.trim())
    }

    fun activities(code: Int): List<Activity> {
        sql.rawQuery(
            "SELECT id, action, field, old_value, new_value, note, ts FROM activity " +
                "WHERE code = ? ORDER BY id DESC LIMIT 100",
            arrayOf(code.toString())
        ).use { c ->
            val out = ArrayList<Activity>()
            while (c.moveToNext()) {
                out += Activity(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4), c.getString(5), c.getLong(6))
            }
            return out
        }
    }

    /** كل السجل لأغراض التصدير: (code, action, field, old, new, note, ts). */
    fun allActivities(): List<List<String>> {
        sql.rawQuery(
            "SELECT code, action, field, old_value, new_value, note, ts FROM activity ORDER BY id",
            null
        ).use { c ->
            val out = ArrayList<List<String>>()
            while (c.moveToNext()) {
                out += (0..6).map { c.getString(it) ?: "" }
            }
            return out
        }
    }

    private fun log(code: Int, action: String, field: String, oldV: String, newV: String, note: String) {
        val cv = ContentValues()
        cv.put("code", code)
        cv.put("action", action)
        cv.put("field", field)
        cv.put("old_value", oldV)
        cv.put("new_value", newV)
        cv.put("note", note)
        cv.put("ts", System.currentTimeMillis())
        sql.insert("activity", null, cv)
    }

    private fun read(c: Cursor): Item {
        fun s(n: String): String = c.getString(c.getColumnIndexOrThrow(n)) ?: ""
        val relIdx = c.getColumnIndex("rel")
        return Item(
            code = c.getInt(c.getColumnIndexOrThrow("code")),
            nameAr = s("name_ar"), nameEn = s("name_en"),
            concentration = s("concentration"), dosageForm = s("dosage_form"),
            therapeuticClass = s("therapeutic_class"),
            isDevice = c.getInt(c.getColumnIndexOrThrow("is_device")) == 1,
            deviceType = s("device_type"), status = s("status"),
            reviewGroup = s("review_group"), decision = s("decision"),
            removalReason = s("removal_reason"), correctedName = s("corrected_name"),
            reviewerNote = s("reviewer_note"), nameSrc = s("name_src"),
            family = s("family"), variant = s("variant"), classSrc = s("class_src"),
            devSrc = s("dev_src"), flag = s("flag"),
            fav = c.getInt(c.getColumnIndexOrThrow("fav")) == 1, tag = s("tag"),
            strength = s("strength"), pack = s("pack"), generic = s("generic"),
            rel = if (relIdx >= 0) c.getInt(relIdx) else 0
        )
    }
}
