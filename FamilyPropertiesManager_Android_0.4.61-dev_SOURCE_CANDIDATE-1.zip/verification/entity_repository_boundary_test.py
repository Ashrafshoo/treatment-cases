from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
repo = (ROOT / 'app/src/main/java/com/example/rentals/domain/entities/EntityRepository.kt').read_text()
usecases = (ROOT / 'app/src/main/java/com/example/rentals/domain/entities/EntityUseCases.kt').read_text()
adapter = (ROOT / 'app/src/main/java/com/example/rentals/data/repository/SqliteEntityRepository.kt').read_text()
screen = (ROOT / 'app/src/main/java/com/example/rentals/features/entities/EntityManagementScreen.kt').read_text()
main = (ROOT / 'app/src/main/java/com/example/rentals/MainActivity.kt').read_text()
assert 'interface EntityRepository' in repo
for name in ('GetEntityDirectory', 'SaveProperty', 'SaveTenant', 'DeleteProperty', 'DeleteTenant'):
    assert f'class {name}' in usecases
for method in ('properties()', 'tenants()', 'saveProperty(item)', 'saveTenant(item)', 'deleteProperty(id)', 'deleteTenant(id)'):
    assert method in adapter
assert 'EntityManagementScreen(repository: EntityRepository)' in screen
assert 'db.' not in screen
assert 'SqliteEntityRepository(db)' in main and 'EntityManagementScreen(entityRepository)' in main
assert 'require(item.name.isNotBlank())' in usecases
print('Entity repository boundary: PASS')
