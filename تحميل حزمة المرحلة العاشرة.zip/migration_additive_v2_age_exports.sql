-- Additive migration v2: identity-derived birth date and export views.
-- Age is calculated dynamically by the application from birth_date, not stored as a fixed number.
ALTER TABLE Personnel ADD COLUMN birth_date TEXT;
ALTER TABLE Personnel ADD COLUMN national_id_validation_status TEXT NOT NULL DEFAULT 'NOT_CHECKED';

CREATE INDEX IF NOT EXISTS idx_personnel_national_id ON Personnel(national_id);

-- Unified export source: one row per person-treatment entry.
CREATE VIEW IF NOT EXISTS v_Treatment_Export AS
SELECT
  b.beneficiary_id,
  COALESCE(p.performance_number,b.performance_number) AS performance_number,
  COALESCE(p.full_name,b.full_name) AS full_name,
  p.job_title, COALESCE(p.region,b.region) AS region,
  COALESCE(p.department,b.department) AS department,
  p.mobile1, p.mobile2, p.national_id, p.gender, p.birth_date,
  te.treatment_order, te.medicine_name_raw, te.strength_raw,
  b.dispensing_duration, b.dosage_text, b.medical_condition,
  b.approval_date,
  'ACTIVE_OR_SOURCE_CURRENT' AS record_status
FROM Beneficiaries b
JOIN Treatment_Entries te ON te.beneficiary_id=b.beneficiary_id
LEFT JOIN Personnel p ON p.performance_number=b.performance_number;

-- Historical export source; archived/stopped treatments remain available but separately labelled.
CREATE VIEW IF NOT EXISTS v_Treatment_History_Export AS
SELECT
  b.beneficiary_id,
  COALESCE(p.performance_number,b.performance_number) AS performance_number,
  COALESCE(p.full_name,b.full_name) AS full_name,
  p.job_title, COALESCE(p.region,b.region) AS region,
  COALESCE(p.department,b.department) AS department,
  p.mobile1, p.mobile2, p.national_id, p.gender, p.birth_date,
  h.treatment_order, h.medicine_name_raw, h.strength_raw,
  h.dispensing_duration, h.dosage_text, h.medical_condition,
  h.approval_date, h.treatment_status AS record_status,
  h.status_note, h.started_or_imported_at, h.stopped_at
FROM Treatment_History h
JOIN Beneficiaries b ON b.beneficiary_id=h.beneficiary_id
LEFT JOIN Personnel p ON p.performance_number=b.performance_number;
