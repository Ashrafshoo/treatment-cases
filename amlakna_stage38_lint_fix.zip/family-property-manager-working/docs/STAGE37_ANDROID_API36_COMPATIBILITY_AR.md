# المرحلة 37 – توافق Android API 36

## سبب التعديل
أظهر سجل GitHub Actions في المرحلة السابقة أن مكتبة `net.zetetic:sqlcipher-android:4.19.1`
تتطلب `compileSdk` 36 أو أحدث، بينما كان المشروع مضبوطاً على API 35.
كما كان Android Gradle Plugin على 8.7.3 وGradle على 8.9.

## التغييرات
- Android Gradle Plugin: `8.7.3` ← `8.10.1`.
- Gradle في Workflow: `8.9` ← `8.11.1`.
- `compileSdk`: `35` ← `36`.
- منصة Android SDK المثبتة في Workflow: `android-35` ← `android-36`.
- `android-actions/setup-android`: `v3` ← `v4`.
- الإبقاء على Java 17 و`minSdk = 26` و`targetSdk = 35` ومكتبة SQLCipher `4.19.1`.

## نتائج التحقق المنفذ
- اختبارات Python: **105 ناجحة**.
- تحليل ملف Workflow YAML: ناجح.
- لم يتوفر Gradle أو Android SDK أو ADB في بيئة الفحص؛ لذلك لم يتم تنفيذ Gradle/JUnit/Android Lint
  أو بناء APK، ولا يُعد هذا الملف APK نهائياً.

## تنبيه النشر
GitHub Actions ينفذ ملف Workflow الموجود في المستودع نفسه، وليس الملف الموجود داخل
`project-source.zip` بعد فك الضغط. لذلك يجب تحديث
`.github/workflows/android-apk.yml` في المستودع إلى النسخة المرفقة المنفصلة
`android-apk-stage37.yml`، ثم رفع `project-source.zip` الجديد وتشغيل Workflow.
