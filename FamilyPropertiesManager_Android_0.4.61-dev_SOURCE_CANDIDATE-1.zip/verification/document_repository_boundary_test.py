from pathlib import Path
import subprocess
import tempfile

root = Path(__file__).resolve().parents[1]
domain = root / 'app/src/main/java/com/example/rentals/domain/contracts'
adapter = root / 'app/src/main/java/com/example/rentals/data/repository/SqliteDocumentRepository.kt'
program = r'''import com.example.rentals.data.RentalsDb
import com.example.rentals.data.repository.SqliteDocumentRepository
import com.example.rentals.domain.contracts.*
fun main() {
 val db = RentalsDb(); val repo = SqliteDocumentRepository(db)
 val add = AddOwnerDocument(repo); val get = GetOwnerDocuments(repo)
 add("unit", "7", "content://persisted", "lease.pdf", "application/pdf", "original", "عقد أساسي")
 check(get("unit", "7").single().name == "lease.pdf")
 check(get("unit", "8").isEmpty())
 check(get("unit", "7").single().notes == "original")
 RemoveOwnerDocumentIndex(repo)(4L)
 check(db.deletedIndex == 4L)
 check(!db.fileDeleteCalled) { "Removing metadata must never delete file bytes" }
 println("PASS: document repository filters owner, preserves metadata and removes index only")
}'''
stub = '''package com.example.rentals.data
class RentalsDb {
 data class AttachmentRow(val id:Long,val ownerType:String,val ownerId:String,val uri:String,val name:String,val mime:String,val createdAt:Long,val notes:String,val category:String)
 val rows = mutableListOf<AttachmentRow>(); var deletedIndex=0L; var fileDeleteCalled=false
 fun attachments()=rows.toList()
 fun addAttachment(ownerType:String,ownerId:String,uri:String,name:String,mime:String,notes:String,category:String){ rows += AttachmentRow(3,ownerType,ownerId,uri,name,mime,1L,notes,category) }
 fun deleteAttachment(id:Long){deletedIndex=id}
}'''
with tempfile.TemporaryDirectory() as td:
 td=Path(td); (td/'Db.kt').write_text(stub); (td/'Test.kt').write_text(program); jar=td/'test.jar'
 r=subprocess.run(['kotlinc',str(domain/'ContractModels.kt'),str(domain/'DocumentRepository.kt'),str(domain/'DocumentUseCases.kt'),str(adapter),str(td/'Db.kt'),str(td/'Test.kt'),'-include-runtime','-d',str(jar)],capture_output=True,text=True)
 if r.returncode: raise RuntimeError(r.stderr)
 r=subprocess.run(['java','-jar',str(jar)],capture_output=True,text=True,check=True); print(r.stdout.strip())
