package com.medref.drugs

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** نسخ احتياطي تلقائي أسبوعي (يحتفظ بآخر 3 نسخ). يُستدعى من خيط خلفي. */
object Backup {
    private fun dir(ctx: Context): File =
        File(ctx.getExternalFilesDir("backups") ?: File(ctx.filesDir, "backups"), "").apply { mkdirs() }

    fun auto(ctx: Context) {
        try {
            if (!Prefs.autoBackup) return
            val now = System.currentTimeMillis()
            if (now - Prefs.lastBackup < 7L * 24 * 3600 * 1000) return
            val src = Db.dbFile(ctx)
            if (!src.exists()) return
            val stamp = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date(now))
            src.copyTo(File(dir(ctx), "DrugRef-auto-$stamp.db"), overwrite = true)
            Prefs.lastBackup = now
            dir(ctx).listFiles { f -> f.name.startsWith("DrugRef-auto-") }
                ?.sortedByDescending { it.name }?.drop(3)?.forEach { it.delete() }
        } catch (e: Exception) { /* النسخ التلقائي لا يجب أن يعطّل التطبيق */ }
    }

    fun latest(ctx: Context): File? =
        dir(ctx).listFiles { f -> f.name.startsWith("DrugRef-auto-") }?.maxByOrNull { it.name }
}
