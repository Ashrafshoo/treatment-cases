from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def repository():
    return (ROOT / "android-app/src/main/java/com/familyproperties/app/PropertyRepository.kt").read_text(encoding="utf-8")


def test_lease_lifecycle_operations_are_admin_gated_transactional_and_audited():
    source = repository()
    expected = {
        "extendLease": "extend_term",
        "setLeaseEndOverride": "set_end_override",
        "terminateLease": "terminate",
        "updateLeaseIncreasePolicy": "update_increase_policy",
        "renewLease": "create_renewal",
    }
    for method, audit_action in expected.items():
        assert f"fun {method}(" in source
        body = source.split(f"fun {method}(", 1)[1].split("\n    fun ", 1)[0]
        assert "requireAdministrator()" in body
        assert "db.beginTransaction()" in body and "db.setTransactionSuccessful()" in body
        assert audit_action in body


def test_renewal_creates_new_contract_identity_and_opening_rent_without_mutating_old_history():
    body = repository().split("fun renewLease(", 1)[1].split("fun addExpense(", 1)[0]
    assert 'put("status", "renewed")' in body
    assert 'db.insertOrThrow("leases"' in body
    assert 'db.insertOrThrow("rent_history"' in body
    assert 'put("lease_id", newId)' in body
    assert 'UPDATE rent_history' not in body
    assert 'DELETE FROM rent_history' not in body


def test_end_date_override_preserves_original_calculated_end_and_contract_start():
    body = repository().split("fun setLeaseEndOverride(", 1)[1].split("fun terminateLease(", 1)[0]
    assert 'SELECT start_date FROM leases' in body
    assert 'put("manual_end_date"' in body
    assert 'put("end_date_override_reason"' in body
    assert 'put("calculated_end_date"' not in body
    assert 'put("start_date"' not in body


def test_termination_preserves_receipts_and_rent_history():
    body = repository().split("fun terminateLease(", 1)[1].split("fun updateLeaseIncreasePolicy(", 1)[0]
    assert 'put("status", "terminated")' in body
    assert 'put("manual_end_date"' in body
    assert 'DELETE FROM receipts' not in body
    assert 'DELETE FROM rent_history' not in body


def test_law164_residential_increase_policy_cannot_be_weakened_through_editor():
    body = repository().split("fun updateLeaseIncreasePolicy(", 1)[1].split("fun renewLease(", 1)[0]
    assert 'law_164_residential_rules' in body
    assert 'BigDecimal("15")' in body
    assert 'month == 9 && day == 1' in body
