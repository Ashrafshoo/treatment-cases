import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCHEMA = ROOT / 'app' / 'assets' / 'database' / '001_initial_schema.sql'


def db_with_records():
    db = sqlite3.connect(':memory:')
    db.execute('PRAGMA foreign_keys=ON')
    for statement in SCHEMA.read_text(encoding='utf-8').split(';'):
        if statement.strip():
            db.execute(statement)
    db.execute("INSERT INTO properties(id,name,review_status,modified_unreviewed) VALUES('p1','عقار تجريبي','needs_review',1)")
    db.execute("INSERT INTO documents(id,entity_type,entity_id,title,relative_path,source_type) VALUES('d1','property','p1','عقد ملكية','archive/p1.pdf','manual')")
    db.execute("INSERT INTO review_items(id,entity_type,entity_id,field_name,original_value,proposed_value,source_description,confidence) VALUES('r1','property','p1','name','اسم قديم','اسم صحيح','مستخرج من مستند تجريبي',0.9)")
    return db


def test_document_archive_is_soft_and_auditable():
    db = db_with_records()
    db.execute("UPDATE documents SET archived_at='2026-11-09' WHERE id='d1'")
    assert db.execute("SELECT COUNT(*) FROM documents WHERE id='d1'").fetchone()[0] == 1
    assert db.execute("SELECT archived_at FROM documents WHERE id='d1'").fetchone()[0] == '2026-11-09'
    db.close()


def test_review_approval_can_apply_proposed_property_field():
    db = db_with_records()
    item = db.execute("SELECT entity_type,entity_id,field_name,proposed_value FROM review_items WHERE id='r1'").fetchone()
    entity_type, entity_id, field, proposed = item
    assert entity_type == 'property' and field == 'name'
    db.execute(f"UPDATE properties SET {field}=?, modified_unreviewed=0, review_status='sound' WHERE id=?", (proposed, entity_id))
    db.execute("UPDATE review_items SET status='approved', reviewed_at='2026-11-09' WHERE id='r1'")
    assert db.execute("SELECT name,modified_unreviewed,review_status FROM properties WHERE id='p1'").fetchone() == ('اسم صحيح', 0, 'sound')
    assert db.execute("SELECT status FROM review_items WHERE id='r1'").fetchone()[0] == 'approved'
    db.close()


def test_review_reject_keeps_original_entity_value():
    db = db_with_records()
    db.execute("UPDATE review_items SET status='rejected', reviewed_at='2026-11-09' WHERE id='r1'")
    assert db.execute("SELECT name FROM properties WHERE id='p1'").fetchone()[0] == 'عقار تجريبي'
    db.close()


if __name__ == '__main__':
    test_document_archive_is_soft_and_auditable()
    test_review_approval_can_apply_proposed_property_field()
    test_review_reject_keeps_original_entity_value()
    print('Stage 8 archive/review tests: 3/3 passed')
