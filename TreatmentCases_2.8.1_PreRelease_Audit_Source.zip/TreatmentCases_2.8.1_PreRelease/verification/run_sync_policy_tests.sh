#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
kotlinc "$ROOT/android/app/src/main/java/com/treatmentcases/app/SyncProtocol.kt" "$ROOT/verification/SyncConflictPolicyTest.kt" -include-runtime -d "$TMP/sync-policy-tests.jar"
java -jar "$TMP/sync-policy-tests.jar"
