from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / 'android-app/src/main'


def test_database_fresh_install_applies_law_policy_and_archive_indexes():
    source = (APP / 'java/com/familyproperties/app/FamilyDatabase.kt').read_text()
    assert 'executeAssetScript(db, "database/007_fresh_install_policy.sql")' in source
    assert 'executeAssetScript(db, "database/008_archive_indexes.sql")' in source
    assert 'DATABASE_VERSION = 8' in source


def test_archive_indexes_are_non_destructive_and_migration_is_registered():
    sql = (APP / 'assets/database/008_archive_indexes.sql').read_text()
    assert 'CREATE INDEX IF NOT EXISTS idx_documents_entity_active' in sql
    assert 'CREATE INDEX IF NOT EXISTS idx_documents_type_active' in sql
    assert 'INSERT OR IGNORE INTO schema_migrations(version,name)' in sql and "VALUES (8,'stage27_archive_indexes')" in sql
    assert not any(token in sql.upper() for token in ('DROP TABLE', 'DELETE FROM DOCUMENTS', 'UPDATE DOCUMENTS'))


def test_excel_template_covers_approved_data_domains_and_preview_only():
    source = (APP / 'java/com/familyproperties/app/ExcelInterchange.kt').read_text()
    for sheet in ('العقارات', 'الوحدات', 'الملاك', 'حصص_الملكية', 'المستأجرون', 'العقود', 'التحصيلات', 'المصروفات'):
        assert f'"{sheet}"' in source
    assert 'fun preview(input: InputStream)' in source
    assert 'fun writeBlankTemplate(output: OutputStream)' in source
    assert 'never writes imported rows' in source


def test_archive_is_admin_gated_and_keeps_file_in_private_internal_storage():
    source = (APP / 'java/com/familyproperties/app/DocumentArchiveRepository.kt').read_text()
    assert 'takeIf { it.isAdministrator }' in source
    assert 'appContext.filesDir' in source
    assert 'archived_at=CURRENT_TIMESTAMP' in source
    assert 'targetDir.deleteRecursively()' in source
    assert 'canonicalFile' in source
