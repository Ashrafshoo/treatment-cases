# No custom shrinking rules are required for the initial WebView shell.
