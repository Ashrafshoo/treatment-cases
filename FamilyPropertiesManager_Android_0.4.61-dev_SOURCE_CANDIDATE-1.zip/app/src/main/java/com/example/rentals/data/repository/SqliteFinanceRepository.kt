package com.example.rentals.data.repository

import com.example.rentals.data.RentalsDb
import com.example.rentals.domain.finance.FinanceSummary
import com.example.rentals.domain.finance.HeirPayout
import com.example.rentals.domain.finance.HeirShare

class SqliteFinanceRepository(private val database: RentalsDb) : FinanceRepository {
    override fun getSummary(): FinanceSummary {
        val values = database.financeSummary()
        return FinanceSummary(
            due = values["due"] ?: 0.0,
            received = values["received"] ?: 0.0,
            collectorHeld = values["collectorHeld"] ?: 0.0,
            expenses = values["expenses"] ?: 0.0,
            undistributed = values["undistributed"] ?: 0.0,
            unassignedLegacy = values["unassignedLegacy"] ?: 0.0,
            unassignedLegacyExpenses = values["unassignedLegacyExpenses"] ?: 0.0
        )
    }

    override fun getActiveHeirs(): List<HeirShare> = database.heirs().map { (id, name, share) -> HeirShare(id, name, share) }

    override fun addLedger(unitCode: String, tenant: String, date: String, period: String, type: String, debit: Double, credit: Double, method: String, notes: String) =
        database.addLedger(unitCode, tenant, date, period, type, debit, credit, method, notes)

    override fun addExpense(title: String, amount: Double, date: String, period: String, category: String, notes: String) =
        database.addExpense(title, amount, date, period, category, notes)

    override fun addCollectorReceivable(collector: String, period: String, date: String, amount: Double, notes: String) =
        database.addCollectorReceivable(collector, period, date, amount, notes)

    override fun handoverCollector(collector: String, date: String, amount: Double, method: String, expenses: Double, distributed: Double, period: String, notes: String) =
        database.handoverCollector(collector, date, amount, method, expenses, distributed, period, notes)

    override fun payHeirs(payouts: List<HeirPayout>, date: String, period: String) =
        database.payHeirsDetailed(payouts.map { Triple(it.heirId, it.amount, it.method) }, date, period)
}
