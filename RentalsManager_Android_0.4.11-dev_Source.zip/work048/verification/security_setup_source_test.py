from pathlib import Path
root=Path(__file__).resolve().parents[1]
main=(root/'app/src/main/java/com/example/rentals/MainActivity.kt').read_text()
security=(root/'app/src/main/java/com/example/rentals/security/AppSecurity.kt').read_text()
assert 'withContext(Dispatchers.Default){runCatching{sec.setPin(pin)}}' in main
assert 'withContext(Dispatchers.Default){runCatching{sec.verifyPin(pin)}' in main
assert 'var saving by remember{mutableStateOf(false)}' in main
assert 'جارٍ حفظ الرمز' in main
assert 'result.onSuccess{onDone()}.onFailure' in main
assert 'PBEKeySpec(pin.toCharArray(),salt,120_000,256)' in security
assert 'putString("pin_hash"' in security
print('PASS: pin setup and verification hashing run off the UI thread; save state/error handling retained; hash format unchanged')
