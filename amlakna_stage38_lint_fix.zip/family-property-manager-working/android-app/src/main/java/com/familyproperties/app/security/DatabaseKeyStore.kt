package com.familyproperties.app.security

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Stores only an AES-GCM-wrapped SQLCipher key in app-private preferences.
 * The wrapping key itself is non-exportable and held by Android Keystore.
 */
class DatabaseKeyStore(context: Context) {
    private val preferences = context.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE)
    private val alias = KEY_ALIAS

    @Synchronized
    fun getOrCreateDatabasePassphrase(databaseFileAlreadyExists: Boolean): ByteArray {
        val ciphertext = preferences.getString(CIPHERTEXT_KEY, null)
        val nonce = preferences.getString(NONCE_KEY, null)

        if (ciphertext != null && nonce != null) {
            return decrypt(ciphertext, nonce)
        }
        check(ciphertext == null && nonce == null) {
            "Database encryption metadata is incomplete; database access has been stopped to protect data."
        }
        check(!databaseFileAlreadyExists) {
            "The database exists but its encryption key is missing. The original data has been preserved; recovery is required."
        }

        val rawPassphrase = ByteArray(PASSPHRASE_BYTES).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateWrappingKey())
        val encrypted = cipher.doFinal(rawPassphrase)
        val saved = preferences.edit()
            .putString(CIPHERTEXT_KEY, Base64.encodeToString(encrypted, Base64.NO_WRAP))
            .putString(NONCE_KEY, Base64.encodeToString(cipher.iv, Base64.NO_WRAP))
            .commit()
        check(saved) { "Could not save the encrypted database key." }
        return rawPassphrase
    }

    private fun decrypt(ciphertext: String, nonce: String): ByteArray {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(
            Cipher.DECRYPT_MODE,
            getExistingWrappingKey(),
            GCMParameterSpec(GCM_TAG_BITS, Base64.decode(nonce, Base64.NO_WRAP))
        )
        return cipher.doFinal(Base64.decode(ciphertext, Base64.NO_WRAP))
    }

    private fun getExistingWrappingKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        return (keyStore.getKey(alias, null) as? SecretKey)
            ?: throw IllegalStateException("The Android Keystore key is missing; the encrypted database has been preserved.")
    }

    private fun getOrCreateWrappingKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        (keyStore.getKey(alias, null) as? SecretKey)?.let { return it }

        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        generator.init(
            KeyGenParameterSpec.Builder(
                alias,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    companion object {
        private const val PREFERENCES_NAME = "family_properties_secure_key_v1"
        private const val KEY_ALIAS = "family_properties_sqlcipher_wrapper_v1"
        private const val CIPHERTEXT_KEY = "database_key_ciphertext"
        private const val NONCE_KEY = "database_key_nonce"
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private const val PASSPHRASE_BYTES = 32
        private const val GCM_TAG_BITS = 128
    }
}
