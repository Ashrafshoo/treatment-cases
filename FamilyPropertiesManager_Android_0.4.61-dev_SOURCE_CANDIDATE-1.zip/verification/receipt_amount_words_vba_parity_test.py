#!/usr/bin/env python3
"""Verify the production Kotlin port against the Monitize VBA module extracted from the source XLS."""
from pathlib import Path
import hashlib
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
FIXTURE = ROOT / 'verification/fixtures/Monitize_Module1_Original.bas'
KOTLIN = ROOT / 'app/src/main/java/com/example/rentals/printing/VbaMonitize.kt'
RENDERER = ROOT / 'app/src/main/java/com/example/rentals/printing/OriginalReceiptTemplateRenderer.kt'
HARNESS = ROOT / 'verification/VbaMonitizeParityHarness.kt'

vba = FIXTURE.read_text(encoding='utf-8')
source = KOTLIN.read_text(encoding='utf-8')
renderer = RENDERER.read_text(encoding='utf-8')
assert 'Public Function Monitize(num_entry)' in vba
assert 'fFrac = Val(Right(Format(num_entry, "000000000000.00"), 2))' in vba
assert 'iVal = Int(num_entry)' in vba
assert 'Private Function Digit_Translator(X)' in vba
assert 'BigDecimal(value).setScale(2, RoundingMode.HALF_EVEN)' in source
assert 'floor(value).toLong()' in source
assert 'VbaMonitize.amountWords(item.amount)' in renderer
assert hashlib.sha256(FIXTURE.read_bytes()).hexdigest() == 'ed305b15c3b4be0934278fb0b40d537bbc6b5d1a563a0d9c4ea57278fdf680d5'

kotlinc = shutil.which('kotlinc')
if kotlinc:
    with tempfile.TemporaryDirectory(prefix='vba-monutize-') as tmp:
        jar = Path(tmp) / 'parity.jar'
        compile_result = subprocess.run(
            [kotlinc, str(KOTLIN), str(HARNESS), '-include-runtime', '-d', str(jar)],
            text=True, capture_output=True, timeout=120
        )
        assert compile_result.returncode == 0, compile_result.stdout + compile_result.stderr
        run_result = subprocess.run(['java', '-jar', str(jar)], text=True, capture_output=True, timeout=30)
        assert run_result.returncode == 0, run_result.stdout + run_result.stderr
        assert 'PASS: 36 Kotlin Monitize parity cases' in run_result.stdout
        print(run_result.stdout.strip())
else:
    print('SKIP: kotlinc unavailable; source-level VBA parity checks passed')
print('PASS: production Kotlin port is wired to the workbook-derived Monitize implementation')
