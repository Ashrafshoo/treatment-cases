import re
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPOSITORY = ROOT / "android-app/src/main/java/com/familyproperties/app/PropertyRepository.kt"


def _monthly_statement_sql():
    source = REPOSITORY.read_text(encoding="utf-8")
    method = source.split("fun monthlyStatement", 1)[1].split("fun listApprovedReceiptsForPrint", 1)[0]
    query = method.split("helper.readableDatabase.rawQuery(", 1)[1].split(",\n            arrayOf(start", 1)[0]
    return "".join(re.findall(r'"((?:\\.|[^"\\])*)"', query))


def test_monthly_statement_uses_effective_rent_history_and_monthly_payments():
    db = sqlite3.connect(":memory:")
    db.executescript((ROOT / "android-app/src/main/assets/database/001_initial_schema.sql").read_text(encoding="utf-8"))
    db.execute("INSERT INTO properties(id,name) VALUES('p1','العقار الأول')")
    db.execute("INSERT INTO tenants(id,full_name) VALUES('t1','مستأجر تجريبي')")
    db.execute("INSERT INTO units(id,property_id,unit_number,unit_type) VALUES('u1','p1','1','residential')")
    db.execute("INSERT INTO leases(id,unit_id,tenant_id,start_date,initial_rent_minor,status) VALUES('l1','u1','t1','2026-01-01',50000,'active')")
    db.execute("INSERT INTO rent_history(id,lease_id,amount_minor,valid_from) VALUES('rh1','l1',60000,'2026-06-01')")
    db.execute("INSERT INTO payments(id,lease_id,paid_at,amount_minor,period_start,period_end) VALUES('pay1','l1','2026-11-05',20000,'2026-11-01','2026-11-30')")
    sql = _monthly_statement_sql()
    row = db.execute(sql, ("2026-11-01", "2026-11-01", "2026-11", "2026-11-30", "2026-11-01")).fetchone()
    assert row == ("l1", "العقار الأول", "1", "مستأجر تجريبي", 60000, 20000, 0)


def test_scheduled_increases_use_latest_approved_rent_history_as_anchor():
    source = REPOSITORY.read_text(encoding="utf-8")
    method = source.split("fun applyDueRentIncreases(", 1)[1].split("fun addLease(", 1)[0]
    assert "var nextDate = LeaseRules.nextIncreaseDate(lease.start, rent.third" in method
    assert "today.minusDays(1)" not in method
    assert "valid_from set to that effective date" in method


def test_law_164_financial_rules_are_limited_to_residential_units():
    source = REPOSITORY.read_text(encoding="utf-8")
    method = source.split("fun addLease(", 1)[1].split("fun addExpense(", 1)[0]
    assert 'val residentialLaw164 = law164Applies && unit.equals("residential", ignoreCase = true)' in method
    assert 'if (residentialLaw164) java.math.BigDecimal("15") else increasePercent' in method
    assert 'if (residentialLaw164) { put("increase_month", 9); put("increase_day", 1) }' in method
    assert 'if (law164Applies) 1 else 0' in method
