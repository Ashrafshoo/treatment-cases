#!/usr/bin/env python3
"""اختبارات سلامة خط المعالجة: تشغَّل بعد build_db.py على القاعدة الناتجة.
    python3 tools/test_pipeline.py app/src/main/assets/drugs.db tools/DrugItem_export.csv
"""
import csv, sqlite3, sys

db, src = sys.argv[1], sys.argv[2]
c = sqlite3.connect(db)
q = lambda s: c.execute(s).fetchall()
fails = []
def check(name, ok, detail=""):
    print(("PASS " if ok else "FAIL ") + name + (f"  {detail}" if detail and not ok else ""))
    if not ok: fails.append(name)

codes_src = {int(r["item_code"]) for r in csv.DictReader(open(src, encoding="utf-8-sig"))}
codes_db = {r[0] for r in q("select code from items")}
check("لا كود يُحذف: items = المصدر", codes_db == codes_src)
check("original_items تطابق المصدر", {r[0] for r in q("select code from original_items")} == codes_src)
check("الأصلية لا تحتوي أسماء آلية", q("select count(*) from original_items where name_src != 'original'")[0][0] == 0)
check("لا صنف بلا اسم عربي بحروف عربية", q("select count(*) from items where name_ar = ''")[0][0] == 0)
check("الصحيح المُبقى لا يكون محذوفًا", q("select count(*) from links l join items k on k.code=l.code where l.kind in ('dup_exact','dup_near') and k.decision='remove'")[0][0] == 0)
check("كل محذوف تقريبي له رابط", q("select count(*) from items i where i.status='similar' and i.decision='remove' and not exists(select 1 from links l where l.related=i.code)")[0][0] == 0)
check("الأجهزة بلا شكل دوائي", q("select count(*) from items where is_device=1 and dosage_form!=''")[0][0] == 0)
check("لا تصنيف جهاز لغير الأجهزة", q("select count(*) from items where is_device=0 and therapeutic_class like 'أجهزة%'")[0][0] == 0)
check("كل صنف له عائلة", q("select count(*) from items where family=''")[0][0] == 0)
check("الأكواد الناقصة لا تتقاطع مع الموجودة", not ({r[0] for r in q("select code from missing_codes")} & codes_db))
check("حالة تركيز مختلف لا تبقى معلّقة", q("select count(*) from items where status='concentration' and decision='pending'")[0][0] == 0)
check("اسم أجنبي لم يتغيّر أبدًا", q("select count(*) from items i join original_items o using(code) where o.name_en != '' and i.name_en != o.name_en")[0][0] == 0)
print(f"\n{len(fails)} فشل" if fails else "\nكل الاختبارات نجحت")
sys.exit(1 if fails else 0)
