#!/usr/bin/env python3
from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'android/app/src/main/java/com/treatmentcases/app/MainActivity.kt').read_text(encoding='utf-8')
g=(root/'android/app/build.gradle').read_text(encoding='utf-8')
checks={
 'independent 2.6.7 application id': "applicationId 'com.treatmentcases.app.preview275'" in g,
 '2.7.3 development version': "versionName '2.8.2-visual-polish'" in g and 'versionCode 34' in g,
 'medicine search state': 'var medicineQuery by remember' in s,
 'medicine search includes generic, specialty and aliases': 'm.genericName,m.specialty,m.aliases,m.criticalClassification' in s,
 'medicine list uses filtered results': 'items(medicineResults)' in s,
 'report search state': 'var reportQuery by remember' in s,
 'report list uses filtered medicine results': 'items(visibleReportMeds)' in s,
 'select all report medicines preserved': 'selectedReportMeds=reportMeds.toSet()' in s,
 'select current report search results': 'selectedReportMeds=selectedReportMeds+visibleReportMeds' in s,
 'case search clear action': 'query=""}){Icon(Icons.Default.Close,appLabel("مسح البحث","Clear search",isEnglish))' in s,
 'employee search clear action': 'employeeQuery=""}){Icon(Icons.Default.Close,appLabel("مسح البحث","Clear search",isEnglish))' in s,
 'medicine search clear action': 'medicineQuery=""}){Icon(Icons.Default.Close,appLabel("مسح البحث","Clear search",isEnglish))' in s,
 'empty case results message': 'لا توجد نتائج مطابقة' in s,
}
for label,ok in checks.items(): print(('PASS' if ok else 'FAIL')+': '+label)
assert all(checks.values())
print(f'PASS: {len(checks)} UI refinement assertions')
