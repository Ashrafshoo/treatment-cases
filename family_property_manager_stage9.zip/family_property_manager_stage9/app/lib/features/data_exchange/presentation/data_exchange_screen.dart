import 'dart:io';
import 'package:flutter/material.dart';
import '../data/excel_exchange_repository.dart';
import '../../auth/data/app_session.dart';

class DataExchangeScreen extends StatefulWidget {
  const DataExchangeScreen({super.key});
  @override State<DataExchangeScreen> createState()=>_DataExchangeScreenState();
}
class _DataExchangeScreenState extends State<DataExchangeScreen>{
  final _repo=ExcelExchangeRepository();
  bool _busy=false;

  Future<void> _run(Future<File> Function() action) async {
    setState(()=>_busy=true);
    try{final file=await action();await _repo.shareFile(file);}
    catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تعذر تجهيز الملف: $e')));}
    finally{if(mounted)setState(()=>_busy=false);}
  }

  Future<void> _importPreview() async {
    setState(()=>_busy=true);
    try{
      final result=await _repo.pickAndValidate();
      if(!mounted||result['cancelled']==true)return;
      final errors=(result['errors'] as List).cast<String>();
      final tables=result['tables'] as Map<String,List<Map<String,String>>>;
      final summary=tables.entries.where((e)=>e.value.isNotEmpty).map((e)=>'${e.key}: ${e.value.length} صف').join('\n');
      final confirmed=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(
        title:const Text('معاينة استيراد Excel'),
        content:SingleChildScrollView(child:Text('الملف: ${result['file_name']}\nإجمالي الصفوف: ${result['data_rows']}\n\n$summary\n\n${errors.isEmpty?'لم تظهر أخطاء في أسماء الأعمدة.':'الأخطاء:\n${errors.join('\n')}'}\n\nالسجلات الجديدة ستضاف مع وضعها للمراجعة عند الحاجة. وأي تغيير على سجل موجود لن يستبدله مباشرة، بل سينشئ بند مراجعة منفصلاً.')),
        actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('إلغاء')),if(AppSession.instance.isAdmin&&result['valid_structure']==true)FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('اعتماد الاستيراد'))],
      ));
      if(confirmed==true&&mounted){
        final imported=await _repo.applyImport(result);
        if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('اكتمل الاستيراد: ${imported['inserted']} سجل جديد، ${imported['review_items']} بنداً في مركز المراجعة')));
      }
    }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تعذر فحص/استيراد الملف: $e')));}
    finally{if(mounted)setState(()=>_busy=false);}
  }

  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Excel والاستيراد والتصدير')),
    body:!AppSession.instance.isAdmin
      ? const Center(child:Padding(padding:EdgeInsets.all(24),child:Text('قسم الاستيراد والتصدير متاح للمدير فقط. حساب العائلة للعرض فقط.')))
      : ListView(padding:const EdgeInsets.all(16),children:[
      if(_busy)const LinearProgressIndicator(),
      Card(child:ListTile(leading:const Icon(Icons.file_upload_outlined),title:const Text('فحص واستيراد ملف Excel'),subtitle:const Text('فحص الأوراق والأعمدة والصفوف ثم معاينة قبل الاعتماد'),onTap:_busy?null:_importPreview)),
      if(AppSession.instance.isAdmin)Card(child:ListTile(leading:const Icon(Icons.file_download_outlined),title:const Text('تصدير البيانات إلى Excel'),subtitle:const Text('تصدير الجداول الأساسية إلى أوراق منفصلة'),onTap:_busy?null:()=>_run(_repo.exportAll))),
      const SizedBox(height:16),Text('قوالب Excel فارغة',style:Theme.of(context).textTheme.titleLarge),
      const Text('املأ عمود id بمعرّف ثابت، واحتفظ بمعرّفات الربط كما هي عند استيراد الوحدات والعقود والتحصيلات.'),
      ...ExcelExchangeRepository.templates.keys.map((name)=>Card(child:ListTile(title:Text(name),leading:const Icon(Icons.table_view_outlined),trailing:const Icon(Icons.download),onTap:_busy?null:()=>_run(()=>_repo.createTemplate(name))))),
      const SizedBox(height:12),const Text('تنبيه خصوصية: ملفات Excel المصدّرة غير مشفرة. احفظها في مكان آمن ولا تشاركها. تشفير قاعدة البيانات والتشفير الافتراضي لملفات التصدير ما زالا مطلوبين قبل الاستخدام الحقيقي.',style:TextStyle(fontSize:12)),
    ]),
  );
}
