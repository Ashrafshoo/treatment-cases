from pathlib import Path
root = Path(__file__).resolve().parents[1]
screen = (root/'app/src/main/java/com/example/rentals/features/printing/MonthlyCollectionScreen.kt').read_text()
main = (root/'app/src/main/java/com/example/rentals/MainActivity.kt').read_text()
repo = (root/'app/src/main/java/com/example/rentals/data/repository/SqliteMonthlyCollectionRepository.kt').read_text()
usecase = (root/'app/src/main/java/com/example/rentals/domain/collection/PrepareMonthlyCollection.kt').read_text()
assert 'MonthlyCollectionRepository' in screen
assert 'repository.getBatches()' in screen
assert 'repository.getBatchReceipts(' in screen
assert 'repository.getBatchItems(' in screen
assert 'repository.recordCollectorResult(' in screen
assert 'db.monthly' not in screen and 'db.createMonthly' not in screen and 'db.updateMonthly' not in screen
assert 'SqliteMonthlyCollectionRepository(db)' in main
assert 'database.createMonthlyCollectionBatch' in repo
assert 'database.updateMonthlyCollectionResult' in repo
assert 'unitIds.isNotEmpty()' in usecase and 'unitIds.all { it > 0 }' in usecase
print('monthly collection repository boundary: PASS')
