from pathlib import Path

root = Path(__file__).resolve().parents[1]
db = (root / 'app/src/main/java/com/example/rentals/data/RentalsDb.kt').read_text(encoding='utf-8')
ui = (root / 'app/src/main/java/com/example/rentals/features/printing/MonthlyCollectionScreen.kt').read_text(encoding='utf-8')

# Monthly receipt preparation is a print/export workflow. It must not gate
# selection or batch creation on collection-status approval.
assert 'val displayedUnits=remember(units,propertyFilter){units.filter{propertyFilter=="الكل"||it.property==propertyFilter}}' in ui
assert 'displayedUnits.forEach{u->' in ui
assert 'تحديد كل الوحدات (' in ui
assert 'collectionIneligibilityReason(it.status)' not in ui
assert 'عرض السجلات وأسباب الاستبعاد' not in ui
batch_start = db.index('@Synchronized fun createMonthlyCollectionBatch')
batch_end = db.index('@Synchronized fun monthlyBatches', batch_start)
batch = db[batch_start:batch_end]
assert 'collectionIneligibilityReason(unit.status)' not in batch
assert 'if (missingIds.isNotEmpty())' in batch
assert 'بعض الوحدات لم تعد موجودة' in batch
assert 'Receipt preparation/export is independent from the unit\'s collection status.' in batch
assert 'إعداد الطباعة وتجهيز الإيصالات' in ui
assert 'ReceiptPdfExporter.export(activity,context.contentResolver,uri,receipts,3,settings.marginMm,true)' in ui
print('PASS: all units are displayed regardless of their status')
print('PASS: select-all includes every unit in the selected property filter')
print('PASS: batch creation no longer blocks unresolved/stopped/sold/etc. statuses')
print('PASS: only deleted/missing unit IDs are rejected')
print('PASS: PDF export retains three receipts per A4 page')
