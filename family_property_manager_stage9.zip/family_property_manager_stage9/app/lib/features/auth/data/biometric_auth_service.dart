import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:local_auth/local_auth.dart';

import 'app_session.dart';

/// Stores only the opted-in account identifier, never a credential or biometric data.
/// Biometric templates remain exclusively in Android's system biometric service.
class BiometricAuthService {
  BiometricAuthService._();
  static final BiometricAuthService instance = BiometricAuthService._();

  static const _enabledKey = 'biometric_login_enabled_v1';
  static const _usernameKey = 'biometric_login_username_v1';
  static const _storage = FlutterSecureStorage();
  final LocalAuthentication _localAuth = LocalAuthentication();

  Future<bool> get isAvailable async {
    try {
      if (!await _localAuth.isDeviceSupported()) return false;
      return (await _localAuth.getAvailableBiometrics()).isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  Future<bool> get isEnabled async =>
      await _storage.read(key: _enabledKey) == 'true' &&
      (await _storage.read(key: _usernameKey)) != null;

  Future<bool> isEnabledForCurrentUser() async {
    if (!AppSession.instance.isAuthenticated || !await isEnabled) return false;
    return await _storage.read(key: _usernameKey) == AppSession.instance.username;
  }

  Future<void> enableForCurrentUser() async {
    if (!AppSession.instance.isAuthenticated) throw StateError('سجّل الدخول أولاً لتفعيل البصمة');
    if (!await isAvailable) {
      throw StateError('هذا الجهاز لا يحتوي على بصمة مسجلة أو وسيلة تحقق حيوي مدعومة');
    }
    final passed = await _localAuth.authenticate(
      localizedReason: 'تأكيد هويتك لتفعيل الدخول بالبصمة إلى إدارة أملاك العائلة',
      options: const AuthenticationOptions(biometricOnly: true, stickyAuth: true),
    );
    if (!passed) throw StateError('لم يتم تأكيد الهوية؛ لم يتم تفعيل البصمة');
    await _storage.write(key: _usernameKey, value: AppSession.instance.username);
    await _storage.write(key: _enabledKey, value: 'true');
  }

  Future<String?> authenticate() async {
    if (!await isEnabled || !await isAvailable) return null;
    final passed = await _localAuth.authenticate(
      localizedReason: 'استخدم بصمة الجهاز لفتح حسابك في إدارة أملاك العائلة',
      options: const AuthenticationOptions(biometricOnly: true, stickyAuth: true),
    );
    if (!passed) return null;
    return _storage.read(key: _usernameKey);
  }

  Future<void> disableForCurrentUser() async {
    if (await _storage.read(key: _usernameKey) != AppSession.instance.username) return;
    await _storage.delete(key: _enabledKey);
    await _storage.delete(key: _usernameKey);
  }
}
