import sqlite3, tempfile, pathlib, unittest
SCHEMA = pathlib.Path(__file__).parents[1] / 'database' / '001_initial_schema.sql'
EXPECTED = {'owners','ownership_shares','property_groups','properties','units','tenants','leases','rent_increases','rent_history','payments','receipts','expenses','documents','review_items','users','devices','sync_operations','audit_log','notifications','app_settings','schema_migrations'}
class SchemaTest(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.NamedTemporaryFile(suffix='.db')
  self.db=sqlite3.connect(self.tmp.name)
  self.db.execute('PRAGMA foreign_keys=ON')
  self.db.executescript(SCHEMA.read_text())
 def tearDown(self): self.db.close(); self.tmp.close()
 def test_all_tables_and_fk(self):
  names={r[0] for r in self.db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
  self.assertTrue(EXPECTED.issubset(names), EXPECTED-names)
  self.assertEqual([], self.db.execute('PRAGMA foreign_key_check').fetchall())
  fk=self.db.execute('PRAGMA foreign_key_list(units)').fetchall()
  self.assertTrue(any(r[2]=='tenants' and r[3]=='current_tenant_id' for r in fk), fk)
 def test_receipt_snapshot_immutable(self):
  self.db.execute("INSERT INTO property_groups(id,name) VALUES('g','مجموعة')")
  self.db.execute("INSERT INTO properties(id,group_id,name) VALUES('p','g','عقار')")
  self.db.execute("INSERT INTO units(id,property_id) VALUES('u','p')")
  self.db.execute("INSERT INTO tenants(id,full_name) VALUES('t','مستأجر')")
  self.db.execute("INSERT INTO leases(id,unit_id,tenant_id,start_date) VALUES('l','u','t','2026-01-01')")
  self.db.execute("INSERT INTO receipts(id,lease_id,receipt_number,issued_at,amount_minor,approved) VALUES('r','l','R-1','2026-01-02',10000,1)")
  with self.assertRaises(sqlite3.IntegrityError): self.db.execute("UPDATE receipts SET amount_minor=20000 WHERE id='r'")
  with self.assertRaises(sqlite3.IntegrityError): self.db.execute("DELETE FROM receipts WHERE id='r'")
 def test_fk_rejects_unknown_tenant(self):
  self.db.execute("INSERT INTO property_groups(id,name) VALUES('g','g')")
  self.db.execute("INSERT INTO properties(id,group_id,name) VALUES('p','g','p')")
  with self.assertRaises(sqlite3.IntegrityError): self.db.execute("INSERT INTO units(id,property_id,current_tenant_id) VALUES('u','p','missing')")
 def test_expenses_are_general(self):
  cols={r[1] for r in self.db.execute('PRAGMA table_info(expenses)')}
  self.assertNotIn('property_id', cols); self.assertNotIn('unit_id', cols)
if __name__=='__main__': unittest.main(verbosity=2)
