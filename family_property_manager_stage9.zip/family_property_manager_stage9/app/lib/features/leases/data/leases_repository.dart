import 'dart:convert';

import 'package:sqflite_sqlcipher/sqflite.dart';

import '../../../core/database/app_database.dart';
import '../../auth/data/app_session.dart';

class LeasesRepository {
  Future<Database> get _db async => AppDatabase.instance.database;

  String _id() => DateTime.now().microsecondsSinceEpoch.toString();

  Future<List<Map<String, Object?>>> leaseOptions() async {
    final db = await _db;
    return db.rawQuery('''
      SELECT u.id AS unit_id, u.unit_number, u.unit_type, u.old_law_164_2025, p.name AS property_name,
             t.id AS tenant_id, t.full_name AS tenant_name
      FROM units u JOIN properties p ON p.id = u.property_id
      LEFT JOIN tenants t ON t.id = u.current_tenant_id
      WHERE u.archived_at IS NULL AND p.archived_at IS NULL
      ORDER BY p.name, u.unit_number
    ''');
  }

  Future<List<Map<String, Object?>>> tenants() async => (await _db).query(
        'tenants',
        columns: ['id', 'full_name'],
        where: 'archived_at IS NULL',
        orderBy: 'full_name COLLATE NOCASE',
      );

  Future<List<Map<String, Object?>>> leases() async => (await _db).rawQuery('''
    SELECT l.*, p.name AS property_name, u.unit_number, u.unit_type,
           t.full_name AS tenant_name,
           COALESCE(l.manual_end_date, l.calculated_end_date) AS effective_end_date,
           (SELECT rh.amount_minor FROM rent_history rh
             WHERE rh.lease_id=l.id AND rh.approval_status='approved'
             ORDER BY rh.valid_from DESC LIMIT 1) AS current_rent_minor
    FROM leases l
    JOIN units u ON u.id=l.unit_id
    JOIN properties p ON p.id=u.property_id
    JOIN tenants t ON t.id=l.tenant_id
    WHERE l.archived_at IS NULL
    ORDER BY l.start_date DESC
  ''');

  Future<void> saveLease({
    String? id,
    required String unitId,
    required String tenantId,
    required DateTime startDate,
    int? durationValue,
    String? durationUnit,
    DateTime? manualEndDate,
    String? overrideReason,
    required int initialRentMinor,
    double? annualIncreasePercent,
    required String increaseRule,
    int? increaseMonth,
    int? increaseDay,
    required bool law164,
    required bool residential,
    required int minimumOldRentMinor,
  }) async {
    AppSession.instance.requireAdmin();
    if (initialRentMinor < 0) throw ArgumentError('الإيجار لا يمكن أن يكون سالباً');
    if ((durationValue == null) != (durationUnit == null)) {
      throw ArgumentError('يجب إدخال المدة ووحدتها معاً');
    }
    if (durationValue != null && durationValue <= 0) {
      throw ArgumentError('مدة العقد يجب أن تكون أكبر من صفر');
    }
    if (annualIncreasePercent != null && annualIncreasePercent < 0) {
      throw ArgumentError('نسبة الزيادة غير صحيحة');
    }

    var rent = initialRentMinor;
    // User-approved working rule: the EGP 250 minimum is residential only.
    if (law164 && residential && rent < minimumOldRentMinor) {
      rent = minimumOldRentMinor;
    }

    final calculatedEnd = durationValue == null
        ? null
        : _addDuration(startDate, durationValue, durationUnit!);
    final now = DateTime.now().toIso8601String();
    final start = _date(startDate);
    final end = calculatedEnd == null ? null : _date(calculatedEnd);
    final manualEnd = manualEndDate == null ? null : _date(manualEndDate);

    final db = await _db;
    await db.transaction((tx) async {
      final isNew = id == null;
      final recordId = id ?? _id();
      final beforeRows = isNew
          ? <Map<String, Object?>>[]
          : await tx.query('leases', where: 'id=?', whereArgs: [recordId], limit: 1);
      final values = <String, Object?>{
        'unit_id': unitId,
        'tenant_id': tenantId,
        'start_date': start,
        'duration_value': durationValue,
        'duration_unit': durationUnit,
        'calculated_end_date': end,
        'manual_end_date': manualEnd,
        'end_date_override_reason': manualEnd == null ? null : overrideReason,
        'initial_rent_minor': rent,
        'annual_increase_percent': annualIncreasePercent,
        'increase_rule': increaseRule,
        'increase_month': increaseRule == 'fixed_month_day' ? increaseMonth : null,
        'increase_day': increaseRule == 'fixed_month_day' ? increaseDay : null,
        'law_164_2025_applies': law164 ? 1 : 0,
        'status': durationValue == null ? 'open_ended' : 'active',
        'updated_at': now,
      };
      if (isNew) {
        values['id'] = recordId;
        await tx.insert('leases', values);
        await tx.insert('rent_history', {
          'id': _id(),
          'lease_id': recordId,
          'amount_minor': rent,
          'currency_code': 'EGP',
          'valid_from': start,
          'source_type': 'manual',
          'approval_status': 'approved',
        });
      } else {
        values['modified_unreviewed']=1;
        final previousRent=(beforeRows.first['initial_rent_minor'] as num?)?.toInt();
        if(previousRent!=rent){
          final currentHistory=await tx.query('rent_history',where:'lease_id=? AND approval_status=? AND valid_to IS NULL',whereArgs:[recordId,'approved'],orderBy:'valid_from DESC',limit:1);
          final effective=DateTime.now();
          final effectiveText=_date(effective);
          var updateExistingToday=false;
          if(currentHistory.isNotEmpty){
            final currentStart=DateTime.tryParse(currentHistory.first['valid_from'] as String? ?? '');
            final closeDate=effective.subtract(const Duration(days:1));
            if(currentStart!=null&&_date(currentStart)==effectiveText){
              await tx.update('rent_history',{'amount_minor':rent},where:'id=?',whereArgs:[currentHistory.first['id']]);
              updateExistingToday=true;
            }else if(currentStart!=null&&!closeDate.isBefore(currentStart)){
              await tx.update('rent_history',{'valid_to':_date(closeDate)},where:'id=?',whereArgs:[currentHistory.first['id']]);
            }
          }
          if(!updateExistingToday){
            await tx.insert('rent_history',{'id':_id(),'lease_id':recordId,'amount_minor':rent,'currency_code':'EGP','valid_from':effectiveText,'source_type':'manual','approval_status':'approved'});
          }
        }
        await tx.update('leases', values, where: 'id=?', whereArgs: [recordId]);
      }
      await tx.insert('audit_log', {
        'id': _id(),
        'user_id': AppSession.instance.userId,
        'entity_type': 'lease',
        'entity_id': recordId,
        'action': isNew ? 'create' : 'update',
        'before_json': isNew ? null : jsonEncode(beforeRows.first),
        'after_json': jsonEncode(values),
      });
    });
  }

  Future<void> archiveLease(String id) async {
    AppSession.instance.requireAdmin();
    final db = await _db;
    await db.transaction((tx) async {
      final rows = await tx.query('leases', where: 'id=?', whereArgs: [id], limit: 1);
      if (rows.isEmpty) return;
      final now = DateTime.now().toIso8601String();
      await tx.update('leases', {'archived_at': now, 'updated_at': now},
          where: 'id=?', whereArgs: [id]);
      await tx.insert('audit_log', {
        'id': _id(),
        'user_id': AppSession.instance.userId,
        'entity_type': 'lease',
        'entity_id': id,
        'action': 'archive',
        'before_json': jsonEncode(rows.first),
        'after_json': jsonEncode({'archived_at': now}),
      });
    });
  }

  static DateTime _addDuration(DateTime start, int value, String unit) {
    switch (unit) {
      case 'days':
        return start.add(Duration(days: value));
      case 'months':
        final targetMonth = start.month + value;
        final firstOfTarget = DateTime(start.year, targetMonth, 1);
        final lastDay = DateTime(firstOfTarget.year, firstOfTarget.month + 1, 0).day;
        return DateTime(firstOfTarget.year, firstOfTarget.month, start.day > lastDay ? lastDay : start.day);
      case 'years':
        final targetYear = start.year + value;
        final lastDay = DateTime(targetYear, start.month + 1, 0).day;
        return DateTime(targetYear, start.month, start.day > lastDay ? lastDay : start.day);
      default:
        throw ArgumentError('وحدة مدة غير مدعومة');
    }
  }

  static String _date(DateTime value) =>
      '${value.year.toString().padLeft(4, '0')}-${value.month.toString().padLeft(2, '0')}-${value.day.toString().padLeft(2, '0')}';
}
