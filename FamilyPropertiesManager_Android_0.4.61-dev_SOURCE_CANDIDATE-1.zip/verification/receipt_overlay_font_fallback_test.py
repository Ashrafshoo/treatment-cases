#!/usr/bin/env python3
from pathlib import Path
R=Path(__file__).resolve().parents[1]
for name in ('ReceiptPrintAdapter.kt','ReceiptPdfExporter.kt'):
    s=(R/'app/src/main/java/com/example/rentals/printing'/name).read_text(encoding='utf-8')
    assert 'ResourcesCompat.getFont(context, R.font.noto_sans_arabic_regular)' in s,name
    assert 'Typeface.create(arabicTypeface,' in s,name
    assert 'Typeface.create("sans-serif"' not in s,name
print('PASS: standard receipt print/PDF overlays use the bundled Arabic-capable Noto font')
