#!/usr/bin/env python3
"""
يبني app/src/main/assets/drugs.db من DrugItem_export.csv

الاستخدام:
    python3 tools/arabic_names.py tools/DrugItem_export.csv tools/arabic_names.csv
    python3 tools/build_db.py tools/DrugItem_export.csv app/src/main/assets/drugs.db tools/arabic_names.csv [egyptian-drugs.csv]

الجداول:
  original_items : نسخة الشيت الأصلية (لا يكتب فيها التطبيق أبدًا)
  items          : القائمة العاملة (الكود لا يُحذف أبدًا)
  activity       : سجل التعديلات والتعليقات
  links          : روابط (الصحيح ⇄ المحذوف/المتشابه)
  missing_codes  : الأكواد غير الموجودة في تسلسل الشيت
"""
import csv, os, re, sqlite3, sys, time, collections

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import enrich, parse_names

DIAC = re.compile("[\u064B-\u065F\u0670\u0640]")
AR_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩", "0123456789")


def norm(s: str) -> str:
    """نفس منطق Norm.of في Db.kt — يجب أن يبقيا متطابقين."""
    if not s or not s.strip():
        return ""
    s = s.lower()
    s = DIAC.sub("", s)
    s = re.sub("[أإآٱ]", "ا", s).replace("ى", "ي").replace("ة", "ه")
    s = s.translate(AR_DIGITS)
    return re.sub(r"\s+", " ", s).strip()


COLS = ["code", "name_ar", "name_en", "concentration", "dosage_form", "therapeutic_class",
        "is_device", "device_type", "status", "review_group", "decision", "removal_reason",
        "corrected_name", "reviewer_note", "name_src", "family", "variant", "class_src",
        "dev_src", "flag", "fav", "tag", "strength", "pack", "generic", "search"]

DDL = """CREATE TABLE {t} (
  code INTEGER PRIMARY KEY,
  name_ar TEXT NOT NULL DEFAULT '',
  name_en TEXT NOT NULL DEFAULT '',
  concentration TEXT NOT NULL DEFAULT '',
  dosage_form TEXT NOT NULL DEFAULT '',
  therapeutic_class TEXT NOT NULL DEFAULT '',
  is_device INTEGER NOT NULL DEFAULT 0,
  device_type TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'ok',
  review_group TEXT NOT NULL DEFAULT '',
  decision TEXT NOT NULL DEFAULT 'pending',
  removal_reason TEXT NOT NULL DEFAULT '',
  corrected_name TEXT NOT NULL DEFAULT '',
  reviewer_note TEXT NOT NULL DEFAULT '',
  name_src TEXT NOT NULL DEFAULT 'original',
  family TEXT NOT NULL DEFAULT '',
  variant TEXT NOT NULL DEFAULT '',
  class_src TEXT NOT NULL DEFAULT '',
  dev_src TEXT NOT NULL DEFAULT '',
  flag TEXT NOT NULL DEFAULT '',
  fav INTEGER NOT NULL DEFAULT 0,
  tag TEXT NOT NULL DEFAULT '',
  strength TEXT NOT NULL DEFAULT '',
  pack TEXT NOT NULL DEFAULT '',
  generic TEXT NOT NULL DEFAULT '',
  search TEXT NOT NULL DEFAULT ''
)"""


def load_eda(path):
    """اسم تجاري (عائلة) ← أشيع مادة فعّالة، من قاعدة الأدوية المصرية (اختياري)."""
    votes = collections.defaultdict(collections.Counter)
    with open(path, encoding="utf-8-sig", newline="") as f:
        for r in csv.DictReader(f):
            en, sci = (r.get("commercial_name_en") or "").strip(), (r.get("scientific_name") or "").strip()
            if en and sci:
                fam = parse_names.split_family(en)[0]
                if fam:
                    votes[fam][sci.upper()] += 1
    return {fam: c.most_common(1)[0][0] for fam, c in votes.items()}


def main(src, out, names_csv=None, eda_csv=None):
    if os.path.exists(out):
        os.remove(out)
    props = {}
    if names_csv and os.path.exists(names_csv):
        with open(names_csv, encoding="utf-8-sig", newline="") as f:
            for r in csv.DictReader(f):
                props[int(r["item_code"])] = r
    eda_map = load_eda(eda_csv) if eda_csv and os.path.exists(eda_csv) else None
    rows = []
    with open(src, encoding="utf-8-sig", newline="") as f:
        for r in csv.DictReader(f):
            g = lambda k: (r.get(k) or "").strip()
            rows.append(dict(
                code=int(g("item_code")), name_ar=g("name_ar"), name_en=g("name_en"),
                concentration=g("concentration"), dosage_form=g("dosage_form"),
                therapeutic_class=g("therapeutic_class"),
                is_device=1 if g("is_device").lower() == "true" else 0, device_type=g("device_type"),
                status=g("status") or "ok", review_group=g("review_group"),
                decision=g("decision") or "pending", removal_reason=g("removal_reason"),
                corrected_name=g("corrected_name"), reviewer_note=g("reviewer_note")))
    rows.sort(key=lambda x: x["code"])
    # نسخة «الأصلية» تؤخذ قبل أي معالجة
    orig = []
    for r in rows:
        o = dict(r)
        o.update(name_src="original", family="", variant="", class_src="", dev_src="", flag="", fav=0, tag="", strength="", pack="", generic="")
        o["family"], o["variant"] = parse_names.split_family(r["name_en"] or r["name_ar"])
        orig.append(o)
    now = int(time.time() * 1000)
    links, logs, missing, stats = enrich.run(rows, props, eda_map, now)

    con = sqlite3.connect(out)
    ph = ",".join("?" * len(COLS))

    def tup(r, base_search):
        return tuple(r[c] if c != "search" else base_search for c in COLS)

    for t, data in (("original_items", orig), ("items", rows)):
        con.execute(DDL.format(t=t))
        con.executemany(f"INSERT INTO {t} ({','.join(COLS)}) VALUES ({ph})",
                        [tup(r, norm(f"{r['name_ar']} {r['name_en']} {r['concentration']} {r['tag']}")) for r in data])
    for ix in ("decision", "status", "is_device", "review_group", "family", "name_src", "class_src", "dev_src", "flag", "fav", "generic", "strength"):
        con.execute(f"CREATE INDEX ix_items_{ix} ON items({ix})")
    con.execute("CREATE INDEX ix_orig_status ON original_items(status)")
    con.execute("""CREATE TABLE activity (
      id INTEGER PRIMARY KEY AUTOINCREMENT, code INTEGER NOT NULL,
      action TEXT NOT NULL, field TEXT NOT NULL DEFAULT '',
      old_value TEXT NOT NULL DEFAULT '', new_value TEXT NOT NULL DEFAULT '',
      note TEXT NOT NULL DEFAULT '', ts INTEGER NOT NULL)""")
    con.execute("CREATE INDEX ix_activity_code ON activity(code)")
    con.executemany("INSERT INTO activity(code,action,field,old_value,new_value,note,ts) VALUES (?,?,?,?,?,?,?)", logs)
    con.execute("""CREATE TABLE links (
      id INTEGER PRIMARY KEY AUTOINCREMENT, code INTEGER NOT NULL, related INTEGER NOT NULL,
      kind TEXT NOT NULL, note TEXT NOT NULL DEFAULT '')""")
    con.execute("CREATE INDEX ix_links_code ON links(code)")
    con.execute("CREATE INDEX ix_links_rel ON links(related)")
    con.executemany("INSERT INTO links(code,related,kind,note) VALUES (?,?,?,?)", links)
    con.execute("CREATE TABLE missing_codes (code INTEGER PRIMARY KEY)")
    con.executemany("INSERT INTO missing_codes(code) VALUES (?)", [(c,) for c in missing])
    con.commit()
    con.execute("VACUUM")
    con.close()
    print(f"OK: {len(rows)} items, {len(logs)} log rows, {len(links)} links -> {out} ({os.path.getsize(out)/1e6:.1f} MB)")
    for k, v in sorted(stats.items()):
        print(f"   {k}: {v}")


if __name__ == "__main__":
    if len(sys.argv) not in (3, 4, 5):
        sys.exit(__doc__)
    main(*sys.argv[1:])
