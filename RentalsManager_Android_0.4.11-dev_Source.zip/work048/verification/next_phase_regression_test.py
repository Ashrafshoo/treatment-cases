import sqlite3
from pathlib import Path

root = Path(__file__).resolve().parents[1]
main = (root / 'app/src/main/java/com/example/rentals/MainActivity.kt').read_text(encoding='utf-8')
pdf = (root / 'app/src/main/java/com/example/rentals/printing/DatabasePdfExporter.kt').read_text(encoding='utf-8')

# The renewal UI must insert a new lease (id=0) and explicitly preserve the prior lease reference in notes.
assert 'fun beginRenewal(id:Long)' in main
renewal = main.split('fun beginRenewal(id:Long)', 1)[1].split('\n    }', 1)[0]
assert 'editingLeaseId=0L' in renewal
assert 'تجديد مستقل للعقد السابق رقم ${previous.id}' in renewal
assert 'تسجيل تجديد جديد' in main

# Verify the exact SQL shape used by the individual heir report and both bind filters.
assert 'heirFilter: String = ""' in pdf
assert 'filters += "\\"الوارث\\" = ?"' in pdf
assert 'args += selectedHeir' in pdf
con = sqlite3.connect(':memory:')
con.executescript('''
CREATE TABLE heirs(id INTEGER PRIMARY KEY, name TEXT);
CREATE TABLE heir_payouts(id INTEGER PRIMARY KEY, heir_id INTEGER, amount REAL, pay_date TEXT, method TEXT, period TEXT, notes TEXT);
INSERT INTO heirs VALUES(1,'وارث أ'),(2,'وارث ب');
INSERT INTO heir_payouts VALUES(1,1,125.50,'2026-10-05','نقدًا','2026-10','دفعة أولى');
INSERT INTO heir_payouts VALUES(2,1,25.00,'2026-11-05','تحويل','2026-11','دفعة ثانية');
INSERT INTO heir_payouts VALUES(3,2,80.00,'2026-11-06','نقدًا','2026-11','دفعة وارث ب');
''')
base = "SELECT h.name AS 'الوارث',p.pay_date AS 'تاريخ الدفع',p.period AS 'الفترة',p.amount AS 'المبلغ المدفوع فعليًا',p.method AS 'وسيلة الدفع',p.notes AS 'ملاحظات' FROM heir_payouts p JOIN heirs h ON h.id=p.heir_id ORDER BY h.name,p.pay_date,p.id"
query = f'SELECT * FROM ({base}) WHERE "الفترة" = ? AND "الوارث" = ?'
rows = con.execute(query, ('2026-11', 'وارث أ')).fetchall()
assert len(rows) == 1 and rows[0][0] == 'وارث أ' and rows[0][3] == 25.0
rows = con.execute(f'SELECT * FROM ({base}) WHERE "الوارث" = ?', ('وارث ب',)).fetchall()
assert len(rows) == 1 and rows[0][0] == 'وارث ب'
print('PASS: renewal creates a separate lease record and preserves prior lease reference')
print('PASS: heir statement filters exact heir name and selected month without cross-heir leakage')
