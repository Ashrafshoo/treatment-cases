package com.example.rentals.domain.contracts

class GetOwnerDocuments(private val repository: DocumentRepository) {
    operator fun invoke(ownerType: String, ownerId: String) = repository.list(ownerType, ownerId)
}

class AddOwnerDocument(private val repository: DocumentRepository) {
    operator fun invoke(ownerType: String, ownerId: String, uri: String, name: String, mime: String, notes: String = "", category: String = "مستند آخر") =
        repository.add(ownerType, ownerId, uri, name, mime, notes, category)
}

class RemoveOwnerDocumentIndex(private val repository: DocumentRepository) {
    operator fun invoke(id: Long) = repository.removeIndex(id)
}
