import tempfile, unittest, sqlite3
from pathlib import Path
from datetime import date
from test_fixtures import create_test_db
import analytics_center

class AnalyticsCenterTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.db=create_test_db(Path(self.tmp.name)/'fixture.db')
        c=sqlite3.connect(self.db)
        c.executescript('CREATE TABLE Medicine_Dictionary(medicine_id INTEGER PRIMARY KEY, medicine_name TEXT); CREATE TABLE Medicine_Name_Aliases(raw_alias TEXT, medicine_id INTEGER);')
        c.execute("INSERT INTO Medicine_Dictionary(medicine_name) VALUES('دواء تجريبي')")
        c.commit(); c.close()
    def tearDown(self): self.tmp.cleanup()

    def test_alerts_find_missing_approval_and_unknown_dictionary_name(self):
        result=analytics_center.alerts(self.db,today=date(2026,11,10))
        codes={x['code'] for x in result['items']}
        self.assertIn('MISSING_APPROVAL_DATE',codes)
        self.assertIn('MEDICINE_NOT_MAPPED',codes)
        self.assertIn('EXPIRY_DATE_NOT_AVAILABLE',codes)
        self.assertFalse(result['expiry_supported'])

    def test_alerts_flag_missing_strength_and_duplicate_treatment(self):
        c=sqlite3.connect(self.db)
        c.execute("UPDATE Treatment_Entries SET strength_raw=NULL WHERE treatment_entry_id=1")
        c.execute("INSERT INTO Treatment_Entries(beneficiary_id,treatment_order,medicine_name_raw,strength_raw) VALUES(1,3,'دواء تجريبي',NULL)")
        c.commit(); c.close()
        codes={x['code'] for x in analytics_center.alerts(self.db)['items']}
        self.assertIn('MISSING_STRENGTH',codes)
        self.assertIn('DUPLICATE_TREATMENT',codes)

    def test_analytics_counts_and_groupings(self):
        data=analytics_center.analytics(self.db)
        self.assertEqual(data['totals']['personnel'],2)
        self.assertEqual(data['totals']['beneficiaries'],2)
        self.assertEqual(data['totals']['current_treatments'],2)
        self.assertTrue(any(x['label']=='القاهرة' for x in data['regions']))
        self.assertTrue(any(x['label']=='دواء تجريبي' for x in data['medicines']))

    def test_export_contains_management_sheets(self):
        from openpyxl import load_workbook
        out=Path(self.tmp.name)/'analytics.xlsx'
        result=analytics_center.export_analytics_excel(self.db,out)
        self.assertTrue(out.exists()); self.assertEqual(result['sheets'],6)
        wb=load_workbook(out,read_only=True)
        self.assertIn('التنبيهات',wb.sheetnames)
        self.assertIn('الأدوية',wb.sheetnames)

    def test_database_is_not_modified(self):
        c=sqlite3.connect(self.db)
        before=c.execute('PRAGMA data_version').fetchone()[0]
        c.close()
        analytics_center.alerts(self.db)
        analytics_center.analytics(self.db)
        c=sqlite3.connect(self.db)
        self.assertEqual(c.execute('PRAGMA integrity_check').fetchone()[0],'ok')
        c.close()

if __name__=='__main__': unittest.main()
