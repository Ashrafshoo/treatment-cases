import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCHEMA = ROOT / 'app' / 'assets' / 'database' / '001_initial_schema.sql'


def database():
    db = sqlite3.connect(':memory:')
    db.execute('PRAGMA foreign_keys=ON')
    for statement in SCHEMA.read_text(encoding='utf-8').split(';'):
        if statement.strip(): db.execute(statement)
    db.execute("INSERT INTO properties(id,name) VALUES('p','عقار تجريبي')")
    db.execute("INSERT INTO tenants(id,full_name) VALUES('t','مستأجر تجريبي')")
    db.execute("INSERT INTO units(id,property_id,unit_number) VALUES('u','p','3')")
    db.execute("INSERT INTO leases(id,unit_id,tenant_id,start_date,initial_rent_minor) VALUES('l','u','t','2026-01-01',50000)")
    return db


def test_payment_and_receipt_are_atomic_and_linked():
    db = database()
    db.execute("INSERT INTO payments(id,lease_id,paid_at,amount_minor,payment_method) VALUES('pay','l','2026-11-09',50000,'cash')")
    db.execute("""INSERT INTO receipts(id,payment_id,lease_id,receipt_number,issued_at,tenant_snapshot,
        property_snapshot,unit_snapshot,amount_minor,approved)
        VALUES('r','pay','l','R-TEST','2026-11-09','مستأجر تجريبي','عقار تجريبي','3',50000,0)""")
    row = db.execute("SELECT p.amount_minor,r.amount_minor,r.tenant_snapshot,r.property_snapshot FROM payments p JOIN receipts r ON r.payment_id=p.id").fetchone()
    assert row == (50000, 50000, 'مستأجر تجريبي', 'عقار تجريبي')
    assert db.execute('PRAGMA foreign_key_check').fetchall() == []
    db.close()


def test_receipt_number_is_unique():
    db = database()
    db.execute("INSERT INTO receipts(id,lease_id,receipt_number,issued_at,amount_minor) VALUES('r1','l','R-UNIQUE','2026-11-09',100)")
    try:
        db.execute("INSERT INTO receipts(id,lease_id,receipt_number,issued_at,amount_minor) VALUES('r2','l','R-UNIQUE','2026-11-09',100)")
        raise AssertionError('Expected unique receipt number constraint')
    except sqlite3.IntegrityError:
        pass
    db.close()


if __name__ == '__main__':
    test_payment_and_receipt_are_atomic_and_linked()
    test_receipt_number_is_unique()
    print('Stage 6 payment tests: 2/2 passed')
