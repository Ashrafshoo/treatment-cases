import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCHEMA = ROOT / 'app' / 'assets' / 'database' / '001_initial_schema.sql'

QUERY = '''
SELECT u.id AS unit_id, u.unit_number, u.unit_type, u.occupancy_status,
       p.name AS property_name, l.id AS lease_id,
       t.full_name AS tenant_name,
       CASE WHEN l.id IS NULL THEN NULL ELSE
         COALESCE((SELECT rh.amount_minor FROM rent_history rh
           WHERE rh.lease_id=l.id AND rh.approval_status='approved'
             AND rh.valid_from<=? AND (rh.valid_to IS NULL OR rh.valid_to>=?)
           ORDER BY rh.valid_from DESC LIMIT 1),
           CASE WHEN EXISTS(SELECT 1 FROM rent_history pending
             WHERE pending.lease_id=l.id AND pending.approval_status='under_review'
               AND pending.valid_from<=? AND (pending.valid_to IS NULL OR pending.valid_to>=?)
           ) THEN NULL ELSE l.initial_rent_minor END)
       END AS suggested_rent_minor,
       CASE WHEN l.id IS NOT NULL AND EXISTS(SELECT 1 FROM rent_history pending
         WHERE pending.lease_id=l.id AND pending.approval_status='under_review'
           AND pending.valid_from<=? AND (pending.valid_to IS NULL OR pending.valid_to>=?)
       ) THEN 1 ELSE 0 END AS has_pending_rent_review
FROM units u JOIN properties p ON p.id=u.property_id
LEFT JOIN leases l ON l.id=(
  SELECT candidate.id FROM leases candidate
  WHERE candidate.unit_id=u.id AND candidate.archived_at IS NULL
    AND candidate.start_date<=?
    AND (COALESCE(candidate.manual_end_date,candidate.calculated_end_date) IS NULL
      OR COALESCE(candidate.manual_end_date,candidate.calculated_end_date)>=?)
    AND candidate.status<>'suspended'
  ORDER BY candidate.start_date DESC, candidate.created_at DESC LIMIT 1
)
LEFT JOIN tenants t ON t.id=l.tenant_id
WHERE u.archived_at IS NULL AND p.archived_at IS NULL
ORDER BY p.name COLLATE NOCASE,u.unit_number
'''


def db():
    conn = sqlite3.connect(':memory:')
    conn.execute('PRAGMA foreign_keys=ON')
    for statement in SCHEMA.read_text(encoding='utf-8').split(';'):
        if statement.strip():
            conn.execute(statement)
    conn.execute("INSERT INTO properties(id,name) VALUES('p','عقار')")
    conn.execute("INSERT INTO tenants(id,full_name) VALUES('t1','مستأجر أول')")
    conn.execute("INSERT INTO tenants(id,full_name) VALUES('t2','مستأجر ثان')")
    conn.execute("INSERT INTO units(id,property_id,unit_number,unit_type) VALUES('u1','p','1','سكني')")
    conn.execute("INSERT INTO units(id,property_id,unit_number,unit_type) VALUES('u2','p','2','تجاري')")
    conn.execute("INSERT INTO units(id,property_id,unit_number,unit_type) VALUES('u3','p','3','سكني')")
    conn.execute("INSERT INTO leases(id,unit_id,tenant_id,start_date,initial_rent_minor) VALUES('l1','u1','t1','2020-01-01',90000)")
    conn.execute("INSERT INTO leases(id,unit_id,tenant_id,start_date,initial_rent_minor) VALUES('l2','u2','t2','2020-01-01',50000)")
    conn.execute("INSERT INTO rent_history(id,lease_id,amount_minor,valid_from,approval_status) VALUES('rh1','l1',100000,'2020-01-01','approved')")
    conn.execute("INSERT INTO rent_history(id,lease_id,amount_minor,valid_from,approval_status) VALUES('rh2','l1',110000,'2026-01-01','under_review')")
    conn.execute("INSERT INTO rent_history(id,lease_id,amount_minor,valid_from,approval_status) VALUES('rh3','l2',60000,'2026-01-01','under_review')")
    conn.commit()
    return conn


def test_monthly_collection_shows_all_units_and_does_not_guess_pending_rent():
    conn = db()
    rows = conn.execute(QUERY, ('2026-11-30','2026-11-01','2026-11-30','2026-11-01',
                               '2026-11-30','2026-11-01','2026-11-30','2026-11-01')).fetchall()
    by_unit = {row[0]: row for row in rows}
    assert set(by_unit) == {'u1', 'u2', 'u3'}
    assert by_unit['u1'][5] == 'l1' and by_unit['u1'][7] == 100000 and by_unit['u1'][8] == 1
    assert by_unit['u2'][5] == 'l2' and by_unit['u2'][7] is None and by_unit['u2'][8] == 1
    assert by_unit['u3'][5] is None and by_unit['u3'][7] is None
    conn.close()


def test_monthly_collection_batch_uses_single_transaction_semantics():
    conn = db()
    try:
        conn.execute('BEGIN')
        conn.execute("INSERT INTO payments(id,lease_id,paid_at,amount_minor) VALUES('pay1','l1','2026-11-13',100000)")
        conn.execute("INSERT INTO payments(id,lease_id,paid_at,amount_minor) VALUES('pay2','missing','2026-11-13',100000)")
        conn.commit()
    except sqlite3.IntegrityError:
        conn.rollback()
    assert conn.execute('SELECT COUNT(*) FROM payments').fetchone()[0] == 0
    conn.close()




def test_pending_rent_does_not_falsely_show_zero_remaining():
    conn = db()
    sql = '''SELECT CASE
      WHEN EXISTS(SELECT 1 FROM rent_history pending WHERE pending.lease_id=l.id
        AND pending.approval_status='under_review' AND pending.valid_from<=? AND (pending.valid_to IS NULL OR pending.valid_to>=?))
        AND NOT EXISTS(SELECT 1 FROM rent_history approved WHERE approved.lease_id=l.id
          AND approved.approval_status='approved' AND approved.valid_from<=? AND (approved.valid_to IS NULL OR approved.valid_to>=?))
      THEN NULL ELSE COALESCE((SELECT rh.amount_minor FROM rent_history rh WHERE rh.lease_id=l.id
        AND rh.approval_status='approved' AND rh.valid_from<=? AND (rh.valid_to IS NULL OR rh.valid_to>=?)
        ORDER BY rh.valid_from DESC LIMIT 1),l.initial_rent_minor) END
      FROM leases l WHERE l.id=?'''
    args = ('2026-11-30','2026-11-01','2026-11-30','2026-11-01',
            '2026-11-30','2026-11-01','l2')
    assert conn.execute(sql, args).fetchone()[0] is None
    args = ('2026-11-30','2026-11-01','2026-11-30','2026-11-01',
            '2026-11-30','2026-11-01','l1')
    assert conn.execute(sql, args).fetchone()[0] == 100000
    repo = (ROOT / 'app/lib/features/payments/data/payments_repository.dart').read_text()
    assert 'Future<int?> _remainingForPeriod' in repo and 'if (dueValue == null) return null;' in repo
    conn.close()

def test_monthly_receipt_print_filter_uses_rent_period_not_payment_day():
    conn = db()
    conn.execute("INSERT INTO payments(id,lease_id,paid_at,amount_minor,period_start,period_end) VALUES('pay-nov','l1','2026-12-03',100000,'2026-11-01','2026-11-30')")
    conn.execute("INSERT INTO receipts(id,payment_id,lease_id,receipt_number,issued_at,amount_minor,approved) VALUES('r-nov','pay-nov','l1','R-NOV','2026-12-03',100000,1)")
    rows = conn.execute('''SELECT r.id FROM receipts r LEFT JOIN payments p ON p.id=r.payment_id
        WHERE r.approved=1 AND ((p.period_start IS NOT NULL AND p.period_start BETWEEN ? AND ?)
        OR (p.period_start IS NULL AND r.issued_at BETWEEN ? AND ?))''',
        ('2026-11-01','2026-11-30','2026-11-01','2026-11-30')).fetchall()
    assert rows == [('r-nov',)]
    service = (ROOT / 'app/lib/features/payments/services/receipt_print_service.dart').read_text()
    assert 'p.period_start BETWEEN ? AND ?' in service
    assert 'take(3)' in service
    conn.close()

def test_monthly_collection_ui_and_repository_are_wired():
    repo = (ROOT / 'app/lib/features/payments/data/payments_repository.dart').read_text()
    screen = (ROOT / 'app/lib/features/payments/presentation/monthly_collection_screen.dart').read_text()
    payments = (ROOT / 'app/lib/features/payments/presentation/payments_screen.dart').read_text()
    assert 'monthlyCollectionUnits' in repo and 'recordMonthlyCollections' in repo
    assert 'await db.transaction((tx) async {' in repo
    assert 'تحديد كل الوحدات' in screen and 'CheckboxListTile' in screen
    assert 'تاريخ استلام المبلغ' in screen and 'المبلغ المحصل فعلياً' in screen
    assert 'MonthlyCollectionScreen' in payments
    excel = (ROOT / 'app/lib/features/data_exchange/data/excel_exchange_repository.dart').read_text()
    assert 'exportMonthlyCollection' in excel and 'كشف التحصيل الشهري' in excel
    assert '_exportMonthlySheet' in screen


if __name__ == '__main__':
    test_monthly_collection_shows_all_units_and_does_not_guess_pending_rent()
    test_monthly_collection_batch_uses_single_transaction_semantics()
    test_pending_rent_does_not_falsely_show_zero_remaining()
    test_monthly_receipt_print_filter_uses_rent_period_not_payment_day()
    test_monthly_collection_ui_and_repository_are_wired()
    print('Stage 12 tests: 5/5 passed')
