package com.familyproperties.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

/** A4 Arabic monthly statement export. Rows are kept in repository order (property/unit/tenant). */
object MonthlyStatementPdfExporter {
    private const val W = 595
    private const val H = 842
    private const val LEFT = 28f
    private const val RIGHT = 567f

    fun create(context: Context, month: String, rows: List<PropertyRepository.MonthlyStatementRow>): File {
        require(month.matches(Regex("\\d{4}-\\d{2}"))) { "صيغة الشهر يجب أن تكون YYYY-MM." }
        require(rows.isNotEmpty()) { "لا توجد بيانات في الكشف المحدد." }
        val doc = PdfDocument()
        try {
            val chunks = rows.chunked(22)
            chunks.forEachIndexed { index, chunk ->
                val page = doc.startPage(PdfDocument.PageInfo.Builder(W, H, index + 1).create())
                drawPage(page.canvas, month, chunk, index + 1, chunks.size,
                    if (index == chunks.lastIndex) rows.sumOf { it.dueMinor } else null,
                    if (index == chunks.lastIndex) rows.sumOf { it.paidMinor } else null,
                    if (index == chunks.lastIndex) rows.sumOf { it.remainingMinor } else null)
                doc.finishPage(page)
            }
            val dir = File(context.cacheDir, "printouts").apply { mkdirs() }
            val file = File(dir, "amlakna-monthly-statement-$month-${System.currentTimeMillis()}.pdf")
            FileOutputStream(file).use(doc::writeTo)
            return file
        } finally { doc.close() }
    }

    fun shareIntent(context: Context, file: File): android.content.Intent {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", file)
        return android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(android.content.Intent.EXTRA_STREAM, uri)
            addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    private fun drawPage(canvas: Canvas, month: String, rows: List<PropertyRepository.MonthlyStatementRow>, pageNo: Int, pageCount: Int,
                         dueTotal: Long?, paidTotal: Long?, remainingTotal: Long?) {
        canvas.drawColor(android.graphics.Color.WHITE)
        val navy = android.graphics.Color.rgb(16, 29, 54)
        val gold = android.graphics.Color.rgb(190, 145, 65)
        val title = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = navy; textSize = 19f; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER }
        canvas.drawText("أملاكنا – الكشف الشهري المجمع", W / 2f, 42f, title)
        val meta = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.DKGRAY; textSize = 10f; textAlign = Paint.Align.RIGHT }
        canvas.drawText("الفترة: $month     الصفحة $pageNo من $pageCount", RIGHT, 64f, meta)
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = gold; strokeWidth = 2f }
        canvas.drawLine(LEFT, 76f, RIGHT, 76f, line)

        val cols = listOf(Triple("العقار / الوحدة / المستأجر", LEFT, 230f), Triple("المستحق", 270f, 75f),
            Triple("المحصل", 365f, 75f), Triple("المتبقي", 460f, 105f))
        val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = navy; textSize = 9f; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.RIGHT }
        canvas.drawRect(LEFT, 88f, RIGHT, 112f, Paint().apply { color = android.graphics.Color.rgb(239, 242, 247) })
        cols.forEach { (label, x, width) -> canvas.drawText(label, x + width - 4f, 104f, headerPaint) }
        var y = 130f
        val body = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.BLACK; textSize = 8.3f; textAlign = Paint.Align.RIGHT }
        val amount = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.BLACK; textSize = 8.3f; textAlign = Paint.Align.RIGHT }
        val divider = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.LTGRAY; strokeWidth = .5f }
        rows.forEachIndexed { idx, row ->
            if (idx % 2 == 1) canvas.drawRect(LEFT, y - 12f, RIGHT, y + 9f, Paint().apply { color = android.graphics.Color.rgb(249, 250, 252) })
            val label = "${row.propertyName} / ${row.unitNumber} / ${row.tenantName}"
            drawRtl(canvas, label, LEFT + 4f, y - 5f, 230f, 8.3f, navy)
            canvas.drawText(money(row.dueMinor), 341f, y, amount)
            canvas.drawText(money(row.paidMinor), 436f, y, amount)
            canvas.drawText(money(row.remainingMinor), RIGHT - 4f, y, amount)
            y += 25f
            canvas.drawLine(LEFT, y - 9f, RIGHT, y - 9f, divider)
        }
        if (dueTotal != null && paidTotal != null && remainingTotal != null) {
            y += 12f
            canvas.drawRect(LEFT, y - 15f, RIGHT, y + 14f, Paint().apply { color = android.graphics.Color.rgb(239, 242, 247) })
            val bold = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = navy; textSize = 9f; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.RIGHT }
            canvas.drawText("الإجمالي", 258f, y + 4f, bold)
            canvas.drawText(money(dueTotal), 341f, y + 4f, bold)
            canvas.drawText(money(paidTotal), 436f, y + 4f, bold)
            canvas.drawText(money(remainingTotal), RIGHT - 4f, y + 4f, bold)
        }
        val footer = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.GRAY; textSize = 8f; textAlign = Paint.Align.CENTER }
        canvas.drawText("تم إنشاء هذا الكشف من بيانات أملاكنا المحفوظة – راجع السجلات قبل الاعتماد", W / 2f, 816f, footer)
    }

    private fun drawRtl(canvas: Canvas, text: String, x: Float, y: Float, width: Float, size: Float, color: Int) {
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = size; this.color = color; typeface = Typeface.create("sans-serif", Typeface.NORMAL) }
        val layout = StaticLayout.Builder.obtain(text, 0, text.length, paint, width.toInt())
            .setAlignment(Layout.Alignment.ALIGN_OPPOSITE).setTextDirection(TextDirectionHeuristics.RTL)
            .setIncludePad(false).setMaxLines(2).build()
        canvas.save(); canvas.translate(x, y); layout.draw(canvas); canvas.restore()
    }

    private fun money(minor: Long): String = "${minor / 100}.${kotlin.math.abs(minor % 100).toString().padStart(2, '0')} ج.م"
}
