package com.medref.drugs

import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** كاتب xlsx بسيط بلا مكتبات: ورقة واحدة، من اليمين لليسار، الصف الأول مثبّت. */
object Xlsx {

    private fun esc(s: String): String {
        val sb = StringBuilder(s.length + 8)
        for (ch in s) {
            when {
                ch == '&' -> sb.append("&amp;")
                ch == '<' -> sb.append("&lt;")
                ch == '>' -> sb.append("&gt;")
                ch == '"' -> sb.append("&quot;")
                ch.code < 32 && ch != '\n' && ch != '\t' -> {}
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    private fun col(i: Int): String {
        var n = i
        val sb = StringBuilder()
        do {
            sb.insert(0, 'A' + (n % 26))
            n = n / 26 - 1
        } while (n >= 0)
        return sb.toString()
    }

    fun write(f: File, sheetName: String, header: List<String>, rows: List<List<String>>) {
        ZipOutputStream(f.outputStream().buffered()).use { z ->
            fun put(name: String, text: String) {
                z.putNextEntry(ZipEntry(name))
                z.write(text.toByteArray(Charsets.UTF_8))
                z.closeEntry()
            }
            val head = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n"
            put("[Content_Types].xml", head +
                "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
                "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
                "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
                "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>" +
                "<Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" +
                "</Types>")
            put("_rels/.rels", head +
                "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/>" +
                "</Relationships>")
            put("xl/workbook.xml", head +
                "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" " +
                "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">" +
                "<sheets><sheet name=\"${esc(sheetName.take(30))}\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>")
            put("xl/_rels/workbook.xml.rels", head +
                "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/>" +
                "</Relationships>")

            z.putNextEntry(ZipEntry("xl/worksheets/sheet1.xml"))
            val w = z.bufferedWriter(Charsets.UTF_8)
            w.write(head)
            w.write("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">")
            w.write("<sheetViews><sheetView rightToLeft=\"1\" workbookViewId=\"0\">" +
                "<pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews>")
            w.write("<sheetData>")
            fun writeRow(r: Int, cells: List<String>, numericFirst: Boolean) {
                w.write("<row r=\"$r\">")
                for ((i, v) in cells.withIndex()) {
                    val ref = col(i) + r
                    if (numericFirst && i == 0 && v.isNotEmpty() && v.all { it.isDigit() }) {
                        w.write("<c r=\"$ref\"><v>$v</v></c>")
                    } else if (v.isNotEmpty()) {
                        w.write("<c r=\"$ref\" t=\"inlineStr\"><is><t xml:space=\"preserve\">${esc(v)}</t></is></c>")
                    }
                }
                w.write("</row>")
            }
            writeRow(1, header, false)
            for ((i, r) in rows.withIndex()) writeRow(i + 2, r, true)
            w.write("</sheetData></worksheet>")
            w.flush()
            z.closeEntry()
        }
    }
}
