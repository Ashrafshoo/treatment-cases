package com.treatmentcases.app

import java.text.Normalizer
import java.util.Locale

enum class MedicineNameMatchType { EXACT, NORMALIZED, SUGGESTION, NEW }

data class MedicineNameMatch(
    val importedName: String,
    val canonicalName: String?,
    val type: MedicineNameMatchType,
    val similarity: Double = 0.0
)

/** Conservative medicine-name matching. Fuzzy matches are suggestions only and are never merged silently. */
object MedicineNameMatcher {
    fun key(value: String): String {
        val noMarks = Normalizer.normalize(value.trim(), Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")
        return noMarks.lowercase(Locale.ROOT)
            .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
            .replace('ى', 'ي')
            .replace(Regex("[\\s\\p{Punct}\\p{Z}]+"), "")
    }

    fun match(importedName: String, canonicalNames: Collection<String>, aliases: Map<String, String> = emptyMap()): MedicineNameMatch {
        val raw = importedName.trim().replace(Regex("\\s+"), " ")
        if (raw.isBlank()) return MedicineNameMatch(raw, null, MedicineNameMatchType.NEW)
        val exact = canonicalNames.firstOrNull { it.trim().equals(raw, ignoreCase = true) }
        if (exact != null) return MedicineNameMatch(raw, exact, MedicineNameMatchType.EXACT, 1.0)
        val wanted = key(raw)
        if (wanted.isBlank()) return MedicineNameMatch(raw, null, MedicineNameMatchType.NEW)
        val candidates = buildList {
            canonicalNames.forEach { add(it to it) }
            aliases.forEach { (alias, canonical) -> add(alias to canonical) }
        }
        // A user-approved alias always wins over the manual-review quarantine.
        val normalized = candidates.firstOrNull { key(it.first) == wanted }
        if (normalized != null) return MedicineNameMatch(raw, normalized.second, MedicineNameMatchType.NORMALIZED, 1.0)
        // Manual-review quarantine: candidate names are suggestions only until package identity is confirmed.
        val manualReview = mapOf(
            "baraitava" to "BARITAVA؛ تصحيح معتمد في القاموس، اربط الاسم البديل بعد تحديث القاموس",
            "recorman" to "RECORMON؛ تصحيح معتمد في القاموس، اربط الاسم البديل بعد تحديث القاموس",
            "factor" to "Factor VIII؟ غير مؤكد؛ يلزم الاسم الكامل",
            "hydra" to "HYDREA؟ مرشح فقط؛ يلزم صورة العبوة",
            "necorul" to "NEORAL؟ مرشح فقط؛ يلزم صورة العبوة",
            "stelorago" to "STELARA؟ مرشح فقط؛ يلزم صورة العبوة",
            "prefillro" to "لم يظهر تطابق دوائي موثوق؛ احتفظ بالاسم حتى مراجعة العبوة",
            "perdeferx" to "PERDOFENEX؟ مرشح بحثي غير معتمد؛ تحقق من المادة الفعالة والعبوة",
            "leqrius" to "LEQVIO؟ احتمال غير مؤكد؛ يلزم مطابقة العبوة",
            "xilgan" to "احتمال تهجئة غير محسوم؛ يلزم مطابقة العبوة"
        )
        manualReview[wanted]?.let { return MedicineNameMatch(raw, it, MedicineNameMatchType.SUGGESTION, 0.0) }
        val best = candidates.map { it.second to similarity(wanted, key(it.first)) }
            .distinctBy { it.first }.maxByOrNull { it.second }
        if (best != null && raw.length >= 5 && best.second >= 0.80) {
            return MedicineNameMatch(raw, best.first, MedicineNameMatchType.SUGGESTION, best.second)
        }
        return MedicineNameMatch(raw, null, MedicineNameMatchType.NEW)
    }

    private fun similarity(a: String, b: String): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        val distance = levenshtein(a, b)
        return 1.0 - distance.toDouble() / maxOf(a.length, b.length)
    }

    private fun levenshtein(a: String, b: String): Int {
        var previous = IntArray(b.length + 1) { it }
        for (i in a.indices) {
            val current = IntArray(b.length + 1)
            current[0] = i + 1
            for (j in b.indices) {
                val cost = if (a[i] == b[j]) 0 else 1
                current[j + 1] = minOf(current[j] + 1, previous[j + 1] + 1, previous[j] + cost)
            }
            previous = current
        }
        return previous[b.length]
    }
}
