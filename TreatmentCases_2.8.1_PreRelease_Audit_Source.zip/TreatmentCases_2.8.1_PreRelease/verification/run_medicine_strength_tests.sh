#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
kotlinc "$ROOT/android/app/src/main/java/com/treatmentcases/app/MedicineStrengthNormalizer.kt" "$ROOT/verification/MedicineStrengthNormalizerTest.kt" -include-runtime -d "$TMP/medicine-strength-tests.jar"
java -jar "$TMP/medicine-strength-tests.jar"
