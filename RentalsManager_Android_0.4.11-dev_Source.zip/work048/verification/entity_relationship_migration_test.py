import sqlite3, time

def run():
    db=sqlite3.connect(':memory:')
    db.execute('PRAGMA foreign_keys=ON')
    db.executescript('''
      CREATE TABLE properties(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL UNIQUE,address TEXT,notes TEXT,created_at INTEGER NOT NULL);
      CREATE TABLE tenants(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,notes TEXT,created_at INTEGER NOT NULL);
      CREATE TABLE units(id INTEGER PRIMARY KEY AUTOINCREMENT,code TEXT UNIQUE,property TEXT,tenant TEXT,unit_type TEXT,rent REAL,status TEXT,description TEXT,notes TEXT,updated_at INTEGER NOT NULL,legacy_source_id INTEGER UNIQUE);
      CREATE TABLE leases(id INTEGER PRIMARY KEY AUTOINCREMENT,unit_id INTEGER,tenant_id INTEGER,start_date TEXT,end_date TEXT,rent REAL,payment_due_day INTEGER DEFAULT 1,status TEXT,document_uri TEXT,notes TEXT,tenant_name_snapshot TEXT);
      INSERT INTO units(code,property,tenant,updated_at) VALUES
       ('U-1','عقار النخيل','أحمد القديم',1),('U-2','عقار النخيل','أحمد القديم',1),('U-3','عقار النخيل','محمد',1),('U-4','','',1);
      INSERT INTO leases(unit_id,tenant_id,start_date,status,tenant_name_snapshot) VALUES(1,NULL,'2020-01-01','منتهي','أحمد القديم');
      INSERT INTO leases(unit_id,tenant_id,start_date,status,tenant_name_snapshot) VALUES(1,NULL,'2025-01-01','نشط','المستأجر الحالي المختلف');
    ''')
    db.executescript('ALTER TABLE units ADD COLUMN property_id INTEGER; ALTER TABLE units ADD COLUMN tenant_id INTEGER;')
    now=int(time.time())
    property_names=[r[0] for r in db.execute("SELECT DISTINCT TRIM(COALESCE(property,'')) FROM units WHERE TRIM(COALESCE(property,''))<>''")]
    for name in property_names: db.execute('INSERT OR IGNORE INTO properties(name,created_at) VALUES(?,?)',(name,now))
    tenant_names=[r[0] for r in db.execute("SELECT DISTINCT TRIM(COALESCE(tenant,'')) FROM units WHERE TRIM(COALESCE(tenant,''))<>''")]
    for name in tenant_names: db.execute('INSERT INTO tenants(name,created_at) SELECT ?,? WHERE NOT EXISTS(SELECT 1 FROM tenants WHERE name=?)',(name,now,name))
    db.execute("UPDATE units SET property_id=(SELECT id FROM properties WHERE properties.name=TRIM(units.property)) WHERE TRIM(COALESCE(property,''))<>''")
    db.execute("UPDATE units SET tenant_id=(SELECT id FROM tenants WHERE tenants.name=TRIM(units.tenant) ORDER BY id LIMIT 1) WHERE TRIM(COALESCE(tenant,''))<>''")
    db.execute("UPDATE leases SET tenant_id=(SELECT t.id FROM tenants t WHERE t.name=TRIM(COALESCE(leases.tenant_name_snapshot,'')) ORDER BY t.id LIMIT 1) WHERE tenant_id IS NULL AND TRIM(COALESCE(tenant_name_snapshot,''))<>''")
    db.commit()
    assert db.execute('SELECT COUNT(*) FROM properties').fetchone()[0]==1
    assert db.execute('SELECT COUNT(*) FROM tenants').fetchone()[0]==2
    assert db.execute('SELECT property_id FROM units WHERE code="U-1"').fetchone()==db.execute('SELECT property_id FROM units WHERE code="U-3"').fetchone()
    old_tenant_id=db.execute('SELECT id FROM tenants WHERE name="أحمد القديم"').fetchone()[0]
    assert db.execute('SELECT tenant_id FROM units WHERE code="U-2"').fetchone()[0]==old_tenant_id
    assert db.execute('SELECT tenant_id FROM leases WHERE id=1').fetchone()[0]==old_tenant_id
    assert db.execute('SELECT tenant_id FROM leases WHERE id=2').fetchone()[0] is None
    # Current tenant change creates a separate entity and re-links only the unit; historical lease remains linked to old tenant.
    db.execute('INSERT INTO tenants(name,created_at) VALUES(?,?)',('أحمد الجديد',now))
    new_id=db.execute('SELECT last_insert_rowid()').fetchone()[0]
    db.execute('UPDATE units SET tenant=?,tenant_id=? WHERE code="U-1"',('أحمد الجديد',new_id))
    assert db.execute('SELECT tenant_id FROM leases WHERE id=1').fetchone()[0]==old_tenant_id
    assert db.execute('SELECT tenant_name_snapshot FROM leases WHERE id=1').fetchone()[0]=='أحمد القديم'
    assert db.execute('SELECT tenant_id FROM units WHERE code="U-1"').fetchone()[0]==new_id
    print('PASS: v12→v13 entity backfill links properties, current tenants and lease tenant snapshots without overwriting historical identities.')

if __name__=='__main__': run()
