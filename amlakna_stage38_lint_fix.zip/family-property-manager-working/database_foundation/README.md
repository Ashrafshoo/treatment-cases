# Database foundation

The Android application uses the reviewed relational schema inside a SQLCipher-encrypted database. The current application database version is **7**.

- `database/001_initial_schema.sql`: fresh-install schema, including the 20 business tables, migration ledger, and the current Law 164 policy fields.
- `database/005_relationship_financial_integrity.sql`: integrity triggers for ownership shares, approved rent-history periods, payment periods, and receipt/payment lease linkage.
- `database/006_active_lease_integrity.sql`: prevents overlapping active leases for the same unit.
- `database/007_law164_policy_separation.sql`: upgrades version 6 databases by separating legal applicability from residential calculation policy; it preserves approved receipt snapshots.
- `database/002_integrity_additions.sql`: historical schema snapshot retained for reference; it is not part of the Android runtime migration sequence.

Fresh installs record schema versions 1–4 and 7 in the initial schema, then apply migrations 5 and 6 during database creation. Existing installations advance through the explicit upgrade steps in `FamilyDatabase`. Every migration must record its version in `schema_migrations`. Destructive downgrades are blocked.

Database encryption keys are wrapped with AES-GCM and Android Keystore; plaintext legacy databases are preserved and require an explicit verified migration.

Run schema and integrity tests from the repository root with `python -m pytest -q`. Python/SQLite tests do not replace Android Gradle/JUnit/lint or on-device testing.
