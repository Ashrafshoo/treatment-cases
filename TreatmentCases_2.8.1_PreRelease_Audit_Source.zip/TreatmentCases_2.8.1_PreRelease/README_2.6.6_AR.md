# علاج الحالات حاجة — 2.6.6-dev

نسخة مصدر مستقلة لاستكمال إعادة تصميم التطبيق الفعلي بواجهة عربية/إنجليزية ديناميكية.

- applicationId: `com.treatmentcases.app.preview266`
- versionName: `2.6.6-dev`
- versionCode: `22`
- قاعدة البيانات: دون تغيير في هذا الإصدار
- بيانات تجريبية: غير مدمجة

ابدأ من مجلد `android` وافتح المشروع في Android Studio مع تثبيت Android SDK المتوافق. راجع `RELEASE_NOTES_2.6.6_DEV_AR.md` وملفات `verification`. هذه حزمة مصدر وليست APK.
