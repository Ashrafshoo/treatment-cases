#!/usr/bin/env python3
"""SQLite regression checks for tenant changes and immutable lease identity snapshots."""
import sqlite3


def setup():
    db = sqlite3.connect(':memory:')
    db.executescript('''
      CREATE TABLE units(id INTEGER PRIMARY KEY, code TEXT, tenant TEXT, status TEXT, property TEXT, rent REAL);
      CREATE TABLE leases(id INTEGER PRIMARY KEY, unit_id INTEGER, tenant_id INTEGER, tenant_name_snapshot TEXT, start_date TEXT);
      CREATE TABLE receipts(id INTEGER PRIMARY KEY, unit_id INTEGER, unit_code TEXT, tenant TEXT, property TEXT, amount REAL, paid_date TEXT, period TEXT, receipt_no TEXT UNIQUE, notes TEXT, status TEXT);
      CREATE TRIGGER paid_unique_insert BEFORE INSERT ON receipts
      WHEN NEW.status='paid' AND EXISTS(SELECT 1 FROM receipts WHERE unit_id=NEW.unit_id AND period=NEW.period AND tenant=NEW.tenant AND status='paid')
      BEGIN SELECT RAISE(ABORT,'duplicate paid receipt'); END;
      CREATE TRIGGER paid_unique_update BEFORE UPDATE OF unit_id,period,tenant,status ON receipts
      WHEN NEW.status='paid' AND EXISTS(SELECT 1 FROM receipts WHERE unit_id=NEW.unit_id AND period=NEW.period AND tenant=NEW.tenant AND status='paid' AND id<>OLD.id)
      BEGIN SELECT RAISE(ABORT,'duplicate paid receipt'); END;
    ''')
    return db


def main():
    db = setup()
    db.execute("INSERT INTO units VALUES(1,'U-1','المستأجر القديم','نشطة','العقار أ',NULL)")
    db.execute("INSERT INTO leases(id,unit_id,tenant_name_snapshot,start_date) VALUES(1,1,'المستأجر القديم','2025-01-01')")
    db.execute("INSERT INTO receipts VALUES(1,1,'U-1','المستأجر القديم','العقار أ',NULL,'','2026-11','R-OLD','مسودة قديمة','draft')")

    # Marking a tenant change before entering the new name must make the old draft non-actionable.
    db.execute("UPDATE receipts SET status='pending_tenant_change' WHERE unit_id=1 AND period='2026-11' AND status='draft'")
    assert db.execute("SELECT status FROM receipts WHERE id=1").fetchone()[0] == 'pending_tenant_change'
    # After entering the new tenant, retain the old draft as non-actionable and create a new draft with unknown rent.
    db.execute("UPDATE receipts SET status='superseded', notes=notes || ' / محفوظة' WHERE unit_id=1 AND period='2026-11' AND status IN ('draft','pending_tenant_change')")
    db.execute("UPDATE units SET tenant='المستأجر الجديد', status='نشطة' WHERE id=1")
    db.execute("INSERT INTO receipts VALUES(2,1,'U-1','المستأجر الجديد','العقار أ',NULL,'','2026-11','R-NEW','إيصال جديد','draft')")
    old = db.execute("SELECT tenant,status FROM receipts WHERE id=1").fetchone()
    new = db.execute("SELECT tenant,amount,status FROM receipts WHERE id=2").fetchone()
    assert old == ('المستأجر القديم', 'superseded'), old
    assert new == ('المستأجر الجديد', None, 'draft'), new

    # Historical lease name remains the original name after the unit tenant changes.
    lease_name = db.execute("SELECT COALESCE(l.tenant_name_snapshot,u.tenant) FROM leases l JOIN units u ON u.id=l.unit_id WHERE l.id=1").fetchone()[0]
    assert lease_name == 'المستأجر القديم', lease_name

    # A paid receipt for the old tenant does not block a new tenant in the same period.
    db.execute("UPDATE receipts SET status='paid', amount=100 WHERE id=1")
    db.execute("INSERT INTO receipts VALUES(3,1,'U-1','المستأجر الجديد','العقار أ',100,'2026-11-10','2026-11','R-NEW-PAID','سداد الجديد','paid')")
    # But a duplicate paid receipt for the same tenant and period is blocked.
    try:
        db.execute("INSERT INTO receipts VALUES(4,1,'U-1','المستأجر الجديد','العقار أ',100,'2026-11-11','2026-11','R-DUP','مكرر','paid')")
    except sqlite3.IntegrityError:
        pass
    else:
        raise AssertionError('duplicate paid receipt was not blocked')

    # The tenant-change status itself is not a closed/stopped classification.
    closed_terms = ('مغلقة','مباعة','متوقف','مكرر','مستبعد','غير محسومة')
    assert not any(term in 'تغيير مستأجر'.lower() for term in closed_terms)
    print('PASS: tenant change preserves old draft history, creates a new NULL-amount draft, keeps lease tenant snapshot, and scopes paid uniqueness by tenant.')


if __name__ == '__main__':
    main()
