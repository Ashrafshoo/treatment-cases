#!/usr/bin/env python3
"""Grouped Excel drawings must render the inner picture, not the whole group anchor."""
import json, math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
D=json.loads((ROOT/'app/src/main/assets/receipt_templates/receipt_template_catalog_v1.json').read_text(encoding='utf-8'))
S=(ROOT/'app/src/main/java/com/example/rentals/printing/OriginalReceiptTemplateRenderer.kt').read_text(encoding='utf-8')
expected={'T009','T012','T014','T018','T059','T060','T062','T063','T066','T069','T070'}
found={t['template_id'] for t in D['templates'] if t['grid']['images'][0].get('groupPictureTransform')}
assert found==expected,(found,expected)
for t in D['templates']:
    im=t['grid']['images'][0]
    g=im.get('groupPictureTransform')
    if not g: continue
    cols=sorted(t['grid']['columnWidths'],key=lambda k:sum((ord(c)-64)*26**i for i,c in enumerate(k[::-1])))
    rows=sorted(t['grid']['rowHeights'],key=int)
    def col_start(index):
        widths=[]
        for key in cols[:max(0,min(index,len(cols)))]:
            chars=max(0,t['grid']['columnWidths'][key])
            px=math.floor((256*chars+math.floor(128/7))/256*7+5)
            widths.append(px*.75)
        return sum(widths)
    def row_start(index): return sum(t['grid']['rowHeights'][r] for r in rows[:max(0,min(index,len(rows)))])
    widths=[]
    for key in cols:
        chars=max(0,t['grid']['columnWidths'][key]); px=math.floor((256*chars+math.floor(128/7))/256*7+5); widths.append(px*.75)
    total_width=sum(widths)
    raw_left=col_start(im['fromCol'])+im['fromColOffEmu']/12700
    raw_right=col_start(im['toCol'])+im['toColOffEmu']/12700
    anchor_left,anchor_right=(total_width-raw_right,total_width-raw_left) if t['grid'].get('rightToLeft',True) else (raw_left,raw_right)
    anchor_top=row_start(im['fromRow'])+im['fromRowOffEmu']/12700
    anchor_bottom=row_start(im['toRow'])+im['toRowOffEmu']/12700
    sx=(anchor_right-anchor_left)/g['groupChildExtentXEmu']
    sy=(anchor_bottom-anchor_top)/g['groupChildExtentYEmu']
    image_width=g['pictureExtentXEmu']*sx
    image_height=g['pictureExtentYEmu']*sy
    anchor_width=anchor_right-anchor_left
    assert 0 < image_width < anchor_width*.4,(t['template_id'],image_width,anchor_width)
    assert image_height > (anchor_bottom-anchor_top)*.75,(t['template_id'],image_height,anchor_bottom-anchor_top)
assert 'groupPictureTransform' in S and 'pictureExtentXEmu' in S and 'pictureExtentYEmu' in S
assert 'canvas.clipRect(target)' in S
print('PASS: all 11 grouped source pictures use their inner geometry instead of the oversized group anchor')
print('PASS: picture width stays within its narrow signature-strip scale; drawing is clipped to each receipt slot')
