package com.familyproperties.app

import org.apache.poi.ss.usermodel.DataFormatter
import org.apache.poi.ss.usermodel.WorkbookFactory
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import java.io.InputStream
import java.io.OutputStream

/** Excel templates and validation preview; this preview class never writes imported rows. Database writes are performed transactionally by PropertyRepository. */
object ExcelInterchange {
    val schemas: Map<String, List<String>> = linkedMapOf(
        "العقارات" to listOf("property_id", "name", "address_text", "city", "district", "property_type", "notes"),
        "الوحدات" to listOf("unit_id", "property_id", "unit_number", "floor_label", "unit_type", "area", "occupancy_status", "old_law_164_2025", "address_details", "notes"),
        "الملاك" to listOf("owner_id", "full_name", "phone", "notes"),
        "حصص_الملكية" to listOf("share_id", "property_id", "owner_id", "share_percent", "valid_from", "valid_to", "notes"),
        "المستأجرون" to listOf("tenant_id", "full_name", "phone", "national_id_last4", "notes"),
        "العقود" to listOf("lease_id", "unit_id", "tenant_id", "start_date", "duration_value", "duration_unit", "manual_end_date", "initial_rent_egp", "annual_increase_percent", "increase_rule", "increase_month", "increase_day", "law_164_2025_applies", "law_164_residential_rules", "status", "notes"),
        "التحصيلات" to listOf("payment_id", "lease_id", "paid_at", "amount_egp", "period_start", "period_end", "payment_method", "reference_text", "notes"),
        "المصروفات" to listOf("expense_id", "name", "amount_egp", "expense_date", "notes")
    )

    data class RowIssue(val sheet: String, val rowNumber: Int, val message: String)
    data class LegacyCell(val address: String, val value: String)
    data class LegacyRow(val rowNumber: Int, val cells: List<LegacyCell>)
    data class LegacySheet(val name: String, val rows: List<LegacyRow>)
    data class Preview(val sheet: String, val headersValid: Boolean, val rows: List<Map<String, String>>, val issues: MutableList<RowIssue>)

    fun writeBlankTemplate(output: OutputStream) {
        XSSFWorkbook().use { workbook ->
            schemas.forEach { (sheetName, headers) ->
                val sheet = workbook.createSheet(sheetName)
                val header = sheet.createRow(0)
                headers.forEachIndexed { index, name -> header.createCell(index).setCellValue(name) }
                sheet.createFreezePane(0, 1)
                headers.indices.forEach { sheet.setColumnWidth(it, 22 * 256) }
            }
            workbook.write(output)
        }
    }

    /** Writes a complete, schema-aligned workbook from repository-provided values. */
    fun writeWorkbook(output: OutputStream, records: Map<String, List<Map<String, String>>>) {
        XSSFWorkbook().use { workbook ->
            schemas.forEach { (sheetName, headers) ->
                val sheet = workbook.createSheet(sheetName)
                val header = sheet.createRow(0)
                headers.forEachIndexed { index, name -> header.createCell(index).setCellValue(name) }
                records[sheetName].orEmpty().forEachIndexed { rowIndex, values ->
                    val row = sheet.createRow(rowIndex + 1)
                    headers.forEachIndexed { columnIndex, key ->
                        row.createCell(columnIndex).setCellValue(values[key].orEmpty())
                    }
                }
                sheet.createFreezePane(0, 1)
                headers.indices.forEach { sheet.setColumnWidth(it, 22 * 256) }
            }
            workbook.write(output)
        }
    }

    /** Read-only forensic preview for legacy family workbooks with unknown/free-form sheet layouts. */
    fun previewLegacy(input: InputStream): List<LegacySheet> {
        val formatter = DataFormatter()
        WorkbookFactory.create(input).use { workbook ->
            val result = mutableListOf<LegacySheet>()
            for (index in 0 until workbook.numberOfSheets) {
                val sheet = workbook.getSheetAt(index)
                val rows = mutableListOf<LegacyRow>()
                for (r in 0..sheet.lastRowNum) {
                    val row = sheet.getRow(r) ?: continue
                    val cells = row.mapIndexedNotNull { c, cell ->
                        formatter.formatCellValue(cell).trim().takeIf { it.isNotBlank() }?.let { value ->
                            LegacyCell(cellAddress(c, r), value)
                        }
                    }
                    if (cells.isNotEmpty()) rows += LegacyRow(r + 1, cells)
                }
                result += LegacySheet(sheet.sheetName, rows)
            }
            if (result.none { it.rows.isNotEmpty() }) throw IllegalArgumentException("الملف لا يحتوي على بيانات ظاهرة")
            return result
        }
    }

    private fun cellAddress(column: Int, row: Int): String {
        var n = column + 1
        val letters = StringBuilder()
        while (n > 0) {
            val rem = (n - 1) % 26
            letters.insert(0, ('A'.code + rem).toChar())
            n = (n - 1) / 26
        }
        return letters.toString() + (row + 1)
    }

    fun preview(input: InputStream): List<Preview> {
        val formatter = DataFormatter()
        WorkbookFactory.create(input).use { workbook ->
            val results = mutableListOf<Preview>()
            for (index in 0 until workbook.numberOfSheets) {
                val sheet = workbook.getSheetAt(index)
                val expected = schemas[sheet.sheetName]
                if (expected == null) {
                    val hasData = (0..sheet.lastRowNum).any { r ->
                        sheet.getRow(r)?.any { cell -> formatter.formatCellValue(cell).isNotBlank() } == true
                    }
                    if (hasData) throw IllegalArgumentException("الورقة ${sheet.sheetName} لا تطابق أي قالب معتمد؛ لم نتجاهل بياناتها بصمت.")
                    continue
                }
                val headerRow = sheet.getRow(0)
                val actualColumnCount = maxOf(expected.size, headerRow?.lastCellNum?.toInt() ?: 0)
                val actual = (0 until actualColumnCount).map { i ->
                    headerRow?.getCell(i)?.let { formatter.formatCellValue(it).trim() } ?: ""
                }
                val valid = actual == expected
                val issues = mutableListOf<RowIssue>()
                if (!valid) issues += RowIssue(sheet.sheetName, 1, "عناوين الأعمدة لا تطابق القالب المعتمد")
                val rows = mutableListOf<Map<String, String>>()
                if (valid) for (r in 1..sheet.lastRowNum) {
                    val row = sheet.getRow(r) ?: continue
                    val values = expected.mapIndexed { c, key -> key to (row.getCell(c)?.let { formatter.formatCellValue(it).trim() } ?: "") }.toMap()
                    if (values.values.all { it.isBlank() }) continue
                    rows += values
                    validateRow(sheet.sheetName, r + 1, values, issues)
                }
                results += Preview(sheet.sheetName, valid, rows, issues)
            }
            // Cross-row natural-key validation must appear in the preview, not only after confirmation.
            results.firstOrNull { it.sheet == "الوحدات" }?.let { unitPreview ->
                val duplicates = unitPreview.rows.withIndex().groupBy { (_, row) ->
                    "${row["property_id"]?.trim().orEmpty()}|${row["unit_number"]?.trim().orEmpty()}"
                }.filter { (key, indexedRows) -> key.substringAfter('|').isNotBlank() && indexedRows.size > 1 }
                duplicates.forEach { (key, indexedRows) ->
                    indexedRows.forEach { (index, _) ->
                        unitPreview.issues += RowIssue(
                            "الوحدات", index + 2,
                            "رقم الوحدة مكرر داخل العقار نفسه ($key). راجع الرقم؛ لا يتم دمج الوحدات تلقائياً."
                        )
                    }
                }
            }
            if (results.isEmpty()) throw IllegalArgumentException("لم يتم العثور على أوراق مطابقة لقوالب أملاكنا")
            return results
        }
    }

    private fun validateRow(sheet: String, row: Int, values: Map<String, String>, issues: MutableList<RowIssue>) {
        fun required(key: String) { if (values[key].isNullOrBlank()) issues += RowIssue(sheet, row, "الحقل $key مطلوب") }
        required(schemas.getValue(sheet).first())
        when (sheet) {
            "العقارات" -> required("name")
            "الوحدات" -> {
                required("property_id"); required("unit_number")
                val occupancy = values["occupancy_status"]?.takeIf { it.isNotBlank() } ?: "unknown"
                if (occupancy !in setOf("occupied", "vacant", "closed", "unknown")) issues += RowIssue(sheet, row, "حالة الإشغال غير معروفة")
                val type = values["unit_type"]?.takeIf { it.isNotBlank() }
                if (type != null && type !in setOf("residential", "commercial")) issues += RowIssue(sheet, row, "نوع الوحدة يجب أن يكون residential أو commercial")
            }
            "الملاك", "المستأجرون" -> required("full_name")
            "حصص_الملكية" -> {
                required("property_id"); required("owner_id")
                val share = values["share_percent"]?.toDoubleOrNull()
                if (share == null || share <= 0.0 || share > 100.0) issues += RowIssue(sheet, row, "نسبة الحصة يجب أن تكون أكبر من صفر ولا تتجاوز 100")
            }
            "العقود" -> {
                required("unit_id"); required("tenant_id"); required("start_date")
                val duration = values["duration_value"]?.takeIf { it.isNotBlank() }
                val unit = values["duration_unit"]?.takeIf { it.isNotBlank() }
                if ((duration == null) != (unit == null)) issues += RowIssue(sheet, row, "أدخل مدة العقد ووحدتها معاً أو اتركهما فارغين")
                if (duration != null && (duration.toIntOrNull() == null || duration.toInt() <= 0)) issues += RowIssue(sheet, row, "مدة العقد يجب أن تكون عدداً صحيحاً موجباً")
                if (unit != null && unit !in setOf("days", "months", "years")) issues += RowIssue(sheet, row, "وحدة المدة غير صحيحة")
                val status = values["status"]?.takeIf { it.isNotBlank() } ?: "active"
                if (status !in setOf("active", "ending_soon", "ended", "renewed", "terminated", "suspended", "open_ended")) issues += RowIssue(sheet, row, "حالة العقد غير صحيحة")
            }
            "التحصيلات" -> { required("lease_id"); required("paid_at"); required("amount_egp") }
            "المصروفات" -> { required("name"); required("expense_date"); required("amount_egp") }
        }
        listOf("amount_egp", "initial_rent_egp", "area", "annual_increase_percent", "duration_value", "share_percent").forEach { key ->
            val value = values[key]?.takeIf { it.isNotBlank() } ?: return@forEach
            if (value.toBigDecimalOrNull() == null) issues += RowIssue(sheet, row, "القيمة في $key ليست رقماً صالحاً")
        }
        val dateFields = when (sheet) {
            "حصص_الملكية" -> listOf("valid_from", "valid_to")
            "العقود" -> listOf("start_date", "manual_end_date")
            "التحصيلات" -> listOf("paid_at", "period_start", "period_end")
            "المصروفات" -> listOf("expense_date")
            else -> emptyList()
        }
        dateFields.forEach { key ->
            val raw = values[key]?.takeIf { it.isNotBlank() } ?: return@forEach
            try { java.time.LocalDate.parse(raw) } catch (_: Exception) { issues += RowIssue(sheet, row, "التاريخ في $key يجب أن يكون بصيغة YYYY-MM-DD") }
        }
        fun parsedDate(key: String): java.time.LocalDate? = try {
            values[key]?.takeIf { it.isNotBlank() }?.let(java.time.LocalDate::parse)
        } catch (_: Exception) { null }
        val validFrom = parsedDate("valid_from")
        val validTo = parsedDate("valid_to")
        if (validFrom != null && validTo != null && validTo.isBefore(validFrom)) issues += RowIssue(sheet, row, "تاريخ انتهاء الحصة يسبق تاريخ بدايتها")
        val periodStart = parsedDate("period_start")
        val periodEnd = parsedDate("period_end")
        if (periodEnd != null && periodStart == null) issues += RowIssue(sheet, row, "لا يمكن إدخال نهاية فترة التحصيل دون بدايتها")
        if (periodStart != null && periodEnd != null && periodEnd.isBefore(periodStart)) issues += RowIssue(sheet, row, "نهاية فترة التحصيل تسبق بدايتها")
        if (sheet in setOf("التحصيلات", "المصروفات")) {
            val amount = values["amount_egp"]?.toBigDecimalOrNull()
            if (amount != null && amount <= java.math.BigDecimal.ZERO) issues += RowIssue(sheet, row, "المبلغ يجب أن يكون أكبر من صفر")
        }
        val booleanFields = when (sheet) {
            "الوحدات" -> listOf("old_law_164_2025")
            "العقود" -> listOf("law_164_2025_applies", "law_164_residential_rules")
            else -> emptyList()
        }
        booleanFields.forEach { key ->
            val raw = values[key]?.takeIf { it.isNotBlank() } ?: return@forEach
            if (raw !in setOf("0", "1", "true", "false")) issues += RowIssue(sheet, row, "الحقل $key يقبل 0 أو 1 فقط")
        }
        if (sheet == "العقود") {
            val rule = values["increase_rule"]?.takeIf { it.isNotBlank() } ?: "anniversary"
            if (rule !in setOf("anniversary", "fixed_month_day", "manual_dates", "none")) issues += RowIssue(sheet, row, "قاعدة الزيادة غير صحيحة")
            val monthRaw = values["increase_month"]?.takeIf { it.isNotBlank() }
            val dayRaw = values["increase_day"]?.takeIf { it.isNotBlank() }
            val month = monthRaw?.toIntOrNull()
            val day = dayRaw?.toIntOrNull()
            if (monthRaw != null && month == null) issues += RowIssue(sheet, row, "شهر الزيادة يجب أن يكون عدداً صحيحاً")
            if (dayRaw != null && day == null) issues += RowIssue(sheet, row, "يوم الزيادة يجب أن يكون عدداً صحيحاً")
            if (month != null && month !in 1..12) issues += RowIssue(sheet, row, "شهر الزيادة يجب أن يكون من 1 إلى 12")
            if (day != null && day !in 1..31) issues += RowIssue(sheet, row, "يوم الزيادة يجب أن يكون من 1 إلى 31")
            if (rule == "fixed_month_day" && (month == null || day == null)) issues += RowIssue(sheet, row, "قاعدة الزيادة الثابتة تتطلب الشهر واليوم")
            val applies = values["law_164_2025_applies"]?.lowercase() in setOf("1", "true")
            val residentialRules = values["law_164_residential_rules"]?.lowercase() in setOf("1", "true")
            if (residentialRules && !applies) issues += RowIssue(sheet, row, "قواعد السكني لقانون 164 تتطلب تفعيل انطباق القانون أولاً")
        }
        val initialRent = values["initial_rent_egp"]?.toBigDecimalOrNull()
        if (initialRent != null && initialRent < java.math.BigDecimal.ZERO) issues += RowIssue(sheet, row, "الإيجار الابتدائي لا يمكن أن يكون سالباً")
        val increase = values["annual_increase_percent"]?.toBigDecimalOrNull()
        if (increase != null && increase < java.math.BigDecimal.ZERO) issues += RowIssue(sheet, row, "نسبة الزيادة لا يمكن أن تكون سالبة")
        val area = values["area"]?.toBigDecimalOrNull()
        if (area != null && area <= java.math.BigDecimal.ZERO) issues += RowIssue(sheet, row, "المساحة يجب أن تكون أكبر من صفر")
    }
}
