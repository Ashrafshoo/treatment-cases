import 'package:flutter/material.dart';
import '../data/lease_schedule_service.dart';
import '../../auth/data/app_session.dart';

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});
  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  final _service = LeaseScheduleService();
  late Future<List<Map<String, Object?>>> _notifications;
  late Future<List<Map<String, Object?>>> _increases;
  late Future<List<Map<String, Object?>>> _scheduled;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  void _refresh() {
    _notifications = _service.notifications();
    _increases = _service.proposedIncreases();
    _scheduled = _service.scheduledIncreases();
  }

  Future<void> _runSchedule() async {
    try {
      final result = await _service.refresh();
      if (mounted) {
        setState(_refresh);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('تم تحديث الجدول: ${result['reminders_created']} تذكير، ${result['increases_applied']} زيادة مطبقة، ${result['increases_proposed']} زيادة للمراجعة'),
        ));
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر تحديث الجدول: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('التنبيهات والزيادات')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (AppSession.instance.isAdmin)
            FilledButton.icon(onPressed: _runSchedule, icon: const Icon(Icons.sync), label: const Text('تحديث التنبيهات وجدول الزيادات')),
          const SizedBox(height: 16),
          Text('التنبيهات المسجلة', style: Theme.of(context).textTheme.titleLarge),
          FutureBuilder<List<Map<String, Object?>>>(
            future: _notifications,
            builder: (context, snapshot) {
              if (snapshot.hasError) return Text('تعذر تحميل التنبيهات: ${snapshot.error}');
              final rows = snapshot.data ?? [];
              if (rows.isEmpty) return const ListTile(title: Text('لا توجد تنبيهات مسجلة'));
              return Column(
                children: rows.map((r) => Card(
                  child: ListTile(
                    leading: const Icon(Icons.notifications_active_outlined),
                    title: Text('${r['label'] ?? 'سجل'}'),
                    subtitle: Text('${r['notification_type'] == 'rent_increase' ? 'موعد زيادة الإيجار' : 'نهاية العقد'}: ${r['due_at']} • تذكير قبل ${r['remind_days_before']} يوم'),
                  ),
                )).toList(),
              );
            },
          ),
          const SizedBox(height: 16),
          Text('زيادات تنتظر الاعتماد', style: Theme.of(context).textTheme.titleLarge),
          FutureBuilder<List<Map<String, Object?>>>(
            future: _increases,
            builder: (context, snapshot) {
              if (snapshot.hasError) return Text('تعذر تحميل الزيادات: ${snapshot.error}');
              final rows = snapshot.data ?? [];
              if (rows.isEmpty) return const ListTile(title: Text('لا توجد زيادات معلقة'));
              return Column(
                children: rows.map((r) => Card(
                  child: ListTile(
                    title: Text('${r['tenant_name']} • ${r['property_name']} / ${r['unit_number'] ?? '—'}'),
                    subtitle: Text('تاريخ السريان: ${r['effective_date']} • نسبة ${r['percentage']}%\nمن ${((r['previous_rent_minor'] as num) / 100).toStringAsFixed(2)} إلى ${((r['new_rent_minor'] as num) / 100).toStringAsFixed(2)} جنيه'),
                    isThreeLine: true,
                    trailing: AppSession.instance.isAdmin
                        ? IconButton(
                            tooltip: 'اعتماد الزيادة',
                            icon: const Icon(Icons.check_circle_outline),
                            onPressed: () async {
                              try {
                                await _service.approveIncrease(r['id'] as String);
                                if (mounted) setState(_refresh);
                              } catch (e) {
                                if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
                              }
                            },
                          )
                        : null,
                  ),
                )).toList(),
              );
            },
          ),
          const SizedBox(height: 16),
          Text('جدول الزيادات المستقبلية المعتمدة', style: Theme.of(context).textTheme.titleLarge),
          FutureBuilder<List<Map<String, Object?>>>(
            future: _scheduled,
            builder: (context, snapshot) {
              if (snapshot.hasError) return Text('تعذر تحميل الجدول: ${snapshot.error}');
              final rows = snapshot.data ?? [];
              if (rows.isEmpty) return const ListTile(title: Text('لا توجد زيادات مجدولة'));
              return Column(
                children: rows.map((r) => Card(
                  child: ListTile(
                    title: Text('${r['tenant_name']} • ${r['property_name']} / ${r['unit_number'] ?? '—'}'),
                    subtitle: Text('السريان: ${r['effective_date']} • ${r['percentage']}%'),
                    trailing: Text('${((r['new_rent_minor'] as num) / 100).toStringAsFixed(2)} ج.م'),
                  ),
                )).toList(),
              );
            },
          ),
        ],
      ),
    );
  }
}
