package com.treatmentcases.app

import android.app.Activity
import android.graphics.Paint
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.*

private val Navy=Color(0xFF0759C7);private val Teal=Color(0xFF20A447);private val Bg=Color(0xFFF3F7FF)

private const val MAX_BACKUP_BYTES = 64L * 1024L * 1024L
private fun readBackupBytes(context: android.content.Context, uri: Uri): ByteArray {
    val out = java.io.ByteArrayOutputStream()
    context.contentResolver.openInputStream(uri)?.use { input ->
        val buffer = ByteArray(8192)
        var total = 0L
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            total += count
            require(total <= MAX_BACKUP_BYTES) { "حجم ملف النسخة أكبر من الحد المسموح (64 ميجابايت)" }
            out.write(buffer, 0, count)
        }
    } ?: error("تعذر فتح ملف النسخة الاحتياطية")
    return out.toByteArray()
}
class MainActivity:ComponentActivity(){override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);val db=LocalDb(this);val auth=AuthManager(this);val prefs=getSharedPreferences("app_preferences",MODE_PRIVATE);setContent{var darkTheme by remember{mutableStateOf(prefs.getBoolean("dark_theme",false))};var fontScale by remember{mutableFloatStateOf(prefs.getFloat("font_scale",1f))};var fontChoice by remember{mutableStateOf(prefs.getString("font_family","sans")?:"sans")};var paletteChoice by remember{mutableStateOf(prefs.getString("palette","blue")?:"blue")};val family=when(fontChoice){"serif"->FontFamily.Serif;"mono"->FontFamily.Monospace;else->FontFamily.SansSerif};val primary=when(paletteChoice){"green"->Color(0xFF087F6A);"purple"->Color(0xFF6941A5);else->Navy};val secondary=when(paletteChoice){"green"->Color(0xFF42A58D);"purple"->Color(0xFF9B7BD0);else->Teal};val density=LocalDensity.current;CompositionLocalProvider(LocalDensity provides androidx.compose.ui.unit.Density(density.density,fontScale),androidx.compose.material3.LocalTextStyle provides androidx.compose.material3.LocalTextStyle.current.merge(TextStyle(fontFamily=family))){MaterialTheme(colorScheme=if(darkTheme)darkColorScheme(primary=if(paletteChoice=="purple")Color(0xFFC2A6F2) else if(paletteChoice=="green")Color(0xFF80D9C0) else Color(0xFF80B7FF),secondary=secondary,background=Color(0xFF101820),surface=Color(0xFF1B2732)) else lightColorScheme(primary=primary,secondary=secondary,background=Bg)){AppGate(db,auth,darkTheme,{darkTheme=it;prefs.edit().putBoolean("dark_theme",it).apply()},{fontScale=it;prefs.edit().putFloat("font_scale",it).apply()},{fontChoice=it;prefs.edit().putString("font_family",it).apply()},{paletteChoice=it;prefs.edit().putString("palette",it).apply()})}}}}}
@Composable fun AppGate(db:LocalDb,auth:AuthManager,darkTheme:Boolean,onDarkThemeChange:(Boolean)->Unit,onFontScaleChange:(Float)->Unit,onFontChoiceChange:(String)->Unit,onPaletteChange:(String)->Unit){var unlocked by remember{mutableStateOf(false)};var configured by remember{mutableStateOf(auth.isConfigured())};var password by remember{mutableStateOf("")};var confirm by remember{mutableStateOf("")};var error by remember{mutableStateOf("")}
 if(unlocked) App(db,auth,darkTheme,onDarkThemeChange,onFontScaleChange,onFontChoiceChange,onPaletteChange) else Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(24.dp),verticalArrangement=Arrangement.Center,horizontalAlignment=Alignment.CenterHorizontally){Icon(Icons.Default.HealthAndSafety,null,tint=Navy,modifier=Modifier.size(72.dp));Text("علاج الحالات حاجة",fontSize=25.sp,fontWeight=FontWeight.Bold,color=Navy);Text(if(configured)"تسجيل دخول المدير" else "إنشاء كلمة مرور المدير لأول استخدام",color=Color.Gray);OutlinedTextField(password,{password=it},Modifier.fillMaxWidth(),label={Text("كلمة المرور")},singleLine=true,visualTransformation=PasswordVisualTransformation());if(!configured)OutlinedTextField(confirm,{confirm=it},Modifier.fillMaxWidth(),label={Text("تأكيد كلمة المرور")},singleLine=true,visualTransformation=PasswordVisualTransformation());if(error.isNotBlank())Text(error,color=Color.Red);Button(onClick={if(configured){if(auth.verify(password)){unlocked=true;error=""}else error="كلمة المرور غير صحيحة"}else if(password!=confirm)error="كلمتا المرور غير متطابقتين" else if(auth.createAdmin(password)){configured=true;unlocked=true;error=""}else error="استخدم كلمة مرور لا تقل عن 8 أحرف أو أرقام"},Modifier.fillMaxWidth()){Text(if(configured)"دخول" else "إنشاء حساب المدير")};Text("الحماية محلية على هذا الهاتف؛ احتفظ بكلمة المرور في مكان آمن.",fontSize=12.sp,color=Color.Gray)}
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun App(db:LocalDb,auth:AuthManager,darkTheme:Boolean,onDarkThemeChange:(Boolean)->Unit,onFontScaleChange:(Float)->Unit,onFontChoiceChange:(String)->Unit,onPaletteChange:(String)->Unit){val ctx=LocalContext.current;var fontScale by remember{mutableFloatStateOf(ctx.getSharedPreferences("app_preferences",0).getFloat("font_scale",1f))};var fontChoice by remember{mutableStateOf(ctx.getSharedPreferences("app_preferences",0).getString("font_family","sans")?:"sans")};var paletteChoice by remember{mutableStateOf(ctx.getSharedPreferences("app_preferences",0).getString("palette","blue")?:"blue")};var changePasswordDialog by remember{mutableStateOf(false)};var currentPassword by remember{mutableStateOf("")};var newPassword by remember{mutableStateOf("")};var confirmPassword by remember{mutableStateOf("")};var settingsMessage by remember{mutableStateOf("")};var tick by remember{mutableIntStateOf(0)};var page by remember{mutableStateOf("الرئيسية")};var pageBeforeRecords by remember{mutableStateOf("الرئيسية")};var query by remember{mutableStateOf("")};var filter by remember{mutableStateOf("")};var edit by remember{mutableStateOf<CaseRecord?>(null)};var form by remember{mutableStateOf(false)};var msg by remember{mutableStateOf("")};var previewRows by remember{mutableStateOf<List<CaseRecord>?>(null)};var showMedicineAdd by remember{mutableStateOf(false)};var newMedicine by remember{mutableStateOf("")};var newStrengths by remember{mutableStateOf("")};var backupDialog by remember{mutableStateOf("")};var backupPassword by remember{mutableStateOf("")};var restoreBytes by remember{mutableStateOf<ByteArray?>(null)};var restorePreview by remember{mutableStateOf<BackupBundle?>(null)};var exportBackupBytes by remember{mutableStateOf<ByteArray?>(null)};var employeeQuery by remember{mutableStateOf("")};var employeePlan by remember{mutableStateOf<EmployeeImportPlan?>(null)};var employeeEdit by remember{mutableStateOf<EmployeeRecord?>(null)};var showEmployeeForm by remember{mutableStateOf(false)};var reportDialog by remember{mutableStateOf(false)};var selectedReportMeds by remember{mutableStateOf<Set<String>>(emptySet())};var pendingReportRows by remember{mutableStateOf<List<CaseRecord>>(emptyList())};var pendingReportTitle by remember{mutableStateOf("تقرير الحالات الحرجة")}
 val meds=remember(tick){db.medicines()};val counts=remember(tick){db.counts()};val reportMeds=remember(meds,counts){meds.filter{(counts[it]?:0)>0}};val alerts=remember(tick){db.alerts()};val results=remember(tick,query,filter){db.search(query,filter)};val employeeResults=remember(tick,employeeQuery){db.employees(employeeQuery)}
 val import=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){u->if(u!=null)try{val rows=Xlsx.read(ctx.contentResolver,u);previewRows=rows;msg="تمت قراءة ${rows.size} صفًا. راجعها قبل الاعتماد."}catch(e:Exception){msg="تعذر الاستيراد: ${e.message}"}}
 val caseTemplate=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")){u->if(u!=null)try{Xlsx.writeTemplate(ctx.contentResolver,u);msg="تم إنشاء نموذج الحالات الحرجة الفارغ. املأه ثم أعد استيراده."}catch(e:Exception){msg="تعذر إنشاء النموذج: ${e.message}"}}
 val export=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")){u->if(u!=null)try{val rows=pendingReportRows.ifEmpty{db.all()};Xlsx.write(rows,ctx.contentResolver,u);msg="تم تصدير ${rows.size} سجل إلى Excel"}catch(e:Exception){msg="خطأ التصدير: ${e.message}"}}
 val employeeImport=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){u->if(u!=null)try{val rows=EmployeeXlsx.read(ctx.contentResolver,u);employeePlan=db.planEmployeeImport(rows);msg="تم فحص ${rows.size} صفاً. راجع تقرير دليل العاملين قبل الاعتماد."}catch(e:Exception){msg="تعذر قراءة قالب دليل العاملين: ${e.message}"}}
 val employeeTemplate=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")){u->if(u!=null)try{EmployeeXlsx.writeTemplate(ctx.contentResolver,u);msg="تم إنشاء قالب دليل العاملين الفارغ"}catch(e:Exception){msg="تعذر إنشاء القالب: ${e.message}"}}
 val employeeExport=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")){u->if(u!=null)try{EmployeeXlsx.writeDirectory(ctx.contentResolver,u,db.employees());msg="تم تصدير دليل العاملين"}catch(e:Exception){msg="تعذر تصدير الدليل: ${e.message}"}}
 val backupSave=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")){u->if(u!=null&&exportBackupBytes!=null)try{ctx.contentResolver.openOutputStream(u)?.use{it.write(exportBackupBytes!!)};msg="تم حفظ النسخة الاحتياطية المشفرة"}catch(e:Exception){msg="تعذر حفظ النسخة: ${e.message}"};exportBackupBytes=null}
 val backupOpen=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){u->if(u!=null)try{restoreBytes=readBackupBytes(ctx,u);backupDialog="restore"}catch(e:Exception){msg="تعذر قراءة النسخة: ${e.message}"}}
 val pdf=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")){u->if(u!=null)try{val rows=pendingReportRows.ifEmpty{db.all()};pdfReport(ctx as Activity,u,rows,pendingReportTitle);msg="تم إنشاء PDF يضم ${rows.size} سجل"}catch(e:Exception){msg="تعذر إنشاء PDF: ${e.message}"}}
 BackHandler(enabled=page!="الرئيسية"||form||reportDialog||backupDialog.isNotBlank()||restorePreview!=null||previewRows!=null||showMedicineAdd||showEmployeeForm||changePasswordDialog){when{changePasswordDialog->{changePasswordDialog=false;currentPassword="";newPassword="";confirmPassword=""};showMedicineAdd->showMedicineAdd=false;showEmployeeForm->showEmployeeForm=false;previewRows!=null->previewRows=null;restorePreview!=null->restorePreview=null;backupDialog.isNotBlank()->{backupDialog="";backupPassword=""};reportDialog->reportDialog=false;form->form=false;page=="السجلات"->{filter="";page=pageBeforeRecords};page=="العاملون"->page="الإعدادات";page!="الرئيسية"->page="الرئيسية"}}
 Scaffold(topBar={TopAppBar(title={Column{Text("علاج الحالات حاجة",fontWeight=FontWeight.Bold);Text("قاعدة بيانات محلية • دون إنترنت",fontSize=11.sp,color=Color.Gray)}},actions={IconButton(onClick={page="الإعدادات"}){Icon(Icons.Default.Settings,null)}})},bottomBar={NavigationBar{listOf("الرئيسية","السجلات","الأدوية","الإعدادات").forEach{p->NavigationBarItem(selected=page==p,onClick={page=p;filter="";query=""},icon={Icon(when(p){"الرئيسية"->Icons.Default.Home;"السجلات"->Icons.Default.People;"الأدوية"->Icons.Default.Medication;else->Icons.Default.Settings},null)},label={Text(p)})}}}){pad->Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(pad).padding(14.dp)){
 if(msg.isNotBlank()){Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Color(0xFFDDF1EA))){Row(Modifier.padding(9.dp),verticalAlignment=Alignment.CenterVertically){Text(msg,Modifier.weight(1f));TextButton(onClick={msg=""}){Text("إغلاق")}}}}
 when(page){"الرئيسية"->{Text("لوحة المتابعة",fontSize=23.sp,fontWeight=FontWeight.Bold,color=Navy);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Stat("إجمالي السجلات",db.count().toString(),Modifier.weight(1f));Stat("الأدوية",meds.size.toString(),Modifier.weight(1f))};Spacer(Modifier.height(10.dp));Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){Column(Modifier.padding(12.dp)){Text("مراجعة جودة البيانات • ${alerts.size} تنبيه",fontWeight=FontWeight.Bold,color=Navy);if(alerts.isEmpty())Text("لا توجد تنبيهات أساسية",color=Teal) else alerts.forEach{Text("• $it",fontSize=12.sp,color=Color(0xFF9A5A12))}}};Spacer(Modifier.height(12.dp));Text("الأدوية المسجلة",fontWeight=FontWeight.Bold,color=Navy);LazyColumn(verticalArrangement=Arrangement.spacedBy(7.dp)){items(meds){m->Card(Modifier.fillMaxWidth().clickable{pageBeforeRecords="الرئيسية";filter=m;page="السجلات"},colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Text(m,Modifier.weight(1f),fontWeight=FontWeight.SemiBold,color=Navy);Text((counts[m]?:0).toString(),fontSize=22.sp,color=Teal,fontWeight=FontWeight.Bold)}}}};if(meds.isEmpty())Text("أضف سجلًا جديدًا أو استورد ملف Excel من الإعدادات.",color=Color.Gray)}
 "السجلات"->{Text("السجلات والبحث",fontSize=22.sp,fontWeight=FontWeight.Bold,color=Navy);OutlinedTextField(query,{query=it},Modifier.fillMaxWidth(),label={Text("الاسم أو رقم الأداء أو الدواء")},singleLine=true,leadingIcon={Icon(Icons.Default.Search,null)});if(filter.isNotBlank())TextButton(onClick={filter=""}){Text("إلغاء فلتر $filter")};Text("عدد النتائج: ${results.size}",color=Teal);LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(7.dp)){items(results){r->RecordCard(r,{edit=r;form=true},{db.delete(r.id);db.log("حذف",r.performanceNo);tick++})}};Button(onClick={edit=null;form=true},Modifier.fillMaxWidth()){Icon(Icons.Default.Add,null);Text("إضافة مستفيد")}}
 "العاملون"->{
  Row(verticalAlignment=Alignment.CenterVertically){Text("دليل العاملين بالشركة",Modifier.weight(1f),fontSize=22.sp,fontWeight=FontWeight.Bold,color=Navy);IconButton(onClick={page="الإعدادات"}){Icon(Icons.Default.ArrowBack,null,tint=Navy)};IconButton(onClick={employeeEdit=null;showEmployeeForm=true}){Icon(Icons.Default.PersonAdd,null,tint=Teal)}}
  Text("قاعدة مستقلة لجميع العاملين، سواء كانوا يتلقون علاجاً أم لا.",color=Color.Gray,fontSize=12.sp)
  Row(horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically){Stat("إجمالي العاملين",db.employeeCount().toString(),Modifier.weight(1f));Stat("نتائج البحث",employeeResults.size.toString(),Modifier.weight(1f))}
  OutlinedTextField(employeeQuery,{employeeQuery=it},Modifier.fillMaxWidth(),label={Text("بحث برقم الأداء أو الاسم")},singleLine=true)
  Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){Button(onClick={employeeTemplate.launch("قالب_دليل_العاملين_فارغ.xlsx")},modifier=Modifier.weight(1f)){Text("قالب فارغ")};OutlinedButton(onClick={employeeImport.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))},modifier=Modifier.weight(1f)){Text("استيراد")}}
  OutlinedButton(onClick={employeeExport.launch("دليل_العاملين.xlsx")},Modifier.fillMaxWidth()){Text("تصدير الدليل الحالي")}
  LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(6.dp)){items(employeeResults){e->Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){Column(Modifier.padding(10.dp)){Row(verticalAlignment=Alignment.CenterVertically){Text(e.name,Modifier.weight(1f),fontWeight=FontWeight.Bold,color=Navy);IconButton(onClick={employeeEdit=e;showEmployeeForm=true}){Icon(Icons.Default.Edit,null,tint=Teal)}};Text("رقم الأداء: ${e.performanceNo} • ${e.job}",fontSize=12.sp,color=Teal);Text("${e.entity} • ${e.department}",fontSize=12.sp);Text("${e.gender} • ${e.age?.let{"العمر $it سنة"}?:"العمر غير متاح"}",fontSize=12.sp);if(e.serviceStatus.isNotBlank())Text(e.serviceStatus,color=Color(0xFF9A5A12),fontWeight=FontWeight.Bold)}}}}
 }
 "الأدوية"->{
  Row(verticalAlignment=Alignment.CenterVertically){Text("قاموس الأدوية",Modifier.weight(1f),fontSize=22.sp,fontWeight=FontWeight.Bold,color=Navy);IconButton(onClick={showMedicineAdd=true}){Icon(Icons.Default.AddCircle,null,tint=Teal)}}
  Text("الأدوية المسجلة في السجلات أو المضافة حديثًا",color=Color.Gray)
  LazyColumn{items(meds){m->
   val strengthSummary=db.strengthsForMedicine(m).joinToString("، ").ifBlank { "غير محددة" }
   ListItem(headlineContent={Text(m)},supportingContent={Text("${counts[m]?:0} مستفيد • العيارات: $strengthSummary")},leadingContent={Icon(Icons.Default.Medication,null,tint=Teal)},modifier=Modifier.clickable{pageBeforeRecords="الأدوية";filter=m;page="السجلات"})
  }}
 }
 "الإعدادات"->{Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())){Text("الإعدادات العامة",fontSize=22.sp,fontWeight=FontWeight.Bold,color=Navy);Text("خصص شكل التطبيق وطريقة عرضه وحماية الدخول.",color=Color.Gray,fontSize=12.sp);Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("النمط الليلي",fontWeight=FontWeight.SemiBold);Text(if(darkTheme)"مفعّل" else "الوضع النهاري",fontSize=12.sp,color=Color.Gray)};Switch(checked=darkTheme,onCheckedChange=onDarkThemeChange)};Divider();Text("حجم الخط",fontWeight=FontWeight.SemiBold);Text("${(fontScale*100).toInt()}%",color=Teal);Slider(value=fontScale,onValueChange={fontScale=it;onFontScaleChange(it)},valueRange=0.85f..1.25f);Text("نوع الخط",fontWeight=FontWeight.SemiBold);Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){FilterChip(selected=fontChoice=="sans",onClick={fontChoice="sans";onFontChoiceChange("sans")},label={Text("واضح")});FilterChip(selected=fontChoice=="serif",onClick={fontChoice="serif";onFontChoiceChange("serif")},label={Text("نسخي")});FilterChip(selected=fontChoice=="mono",onClick={fontChoice="mono";onFontChoiceChange("mono")},label={Text("ثابت")})};Text("ألوان وتصميم الواجهة",fontWeight=FontWeight.SemiBold);Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){FilterChip(selected=paletteChoice=="blue",onClick={paletteChoice="blue";onPaletteChange("blue")},label={Text("أزرق طبي")});FilterChip(selected=paletteChoice=="green",onClick={paletteChoice="green";onPaletteChange("green")},label={Text("أخضر")});FilterChip(selected=paletteChoice=="purple",onClick={paletteChoice="purple";onPaletteChange("purple")},label={Text("بنفسجي")})};Divider();Text("الأمان",fontWeight=FontWeight.Bold,color=Navy);OutlinedButton(onClick={settingsMessage="";changePasswordDialog=true},Modifier.fillMaxWidth()){Icon(Icons.Default.Lock,null);Text("تغيير كلمة مرور المدير")};Text("البصمة: لم تُفعّل بعد. يلزم ربطها بتسجيل الدخول والتحقق من توفر بصمة مسجلة على الهاتف قبل إظهار مفتاح التفعيل.",fontSize=12.sp,color=Color(0xFF9A5A12));if(settingsMessage.isNotBlank())Text(settingsMessage,color=Teal)}};Spacer(Modifier.height(10.dp));Text("الاستيراد والتصدير",fontSize=20.sp,fontWeight=FontWeight.Bold,color=Navy);Text("تُحفظ البيانات داخل الهاتف ولا تُرسل إلى أي خادم.",color=Color.Gray);OutlinedButton(onClick={page="العاملون"},Modifier.fillMaxWidth()){Icon(Icons.Default.Badge,null);Text("إدارة دليل العاملين (إعدادات المدير)")};Spacer(Modifier.height(10.dp));Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxWidth()){Button(onClick={caseTemplate.launch("نموذج_الحالات_الحرجة_فارغ.xlsx")},Modifier.weight(1f)){Icon(Icons.Default.FileDownload,null);Text("نموذج فارغ")};OutlinedButton(onClick={import.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))},Modifier.weight(1f)){Icon(Icons.Default.FileOpen,null);Text("استيراد النموذج")}};OutlinedButton(onClick={pendingReportRows=emptyList();pendingReportTitle="تقرير الحالات الحرجة";export.launch("تصدير_كل_الحالات_الحرجة.xlsx")},Modifier.fillMaxWidth()){Icon(Icons.Default.FileDownload,null);Text("تصدير كل الحالات إلى Excel")};Button(onClick={selectedReportMeds=reportMeds.toSet();reportDialog=true},Modifier.fillMaxWidth(),enabled=reportMeds.isNotEmpty()){Icon(Icons.Default.PictureAsPdf,null);Text("تقارير حسب الدواء • PDF أو Excel")};OutlinedButton(onClick={backupDialog="export";backupPassword=""},Modifier.fillMaxWidth()){Icon(Icons.Default.Lock,null);Text("إنشاء نسخة احتياطية مشفرة")};OutlinedButton(onClick={backupOpen.launch(arrayOf("application/octet-stream","application/x-tcbak","*/*"))},Modifier.fillMaxWidth()){Icon(Icons.Default.Restore,null);Text("استعادة نسخة احتياطية")};Divider(Modifier.padding(vertical=12.dp));Text("ملاحظات الأمان",fontWeight=FontWeight.Bold,color=Navy);Text("• لا توجد صلاحية إنترنت في التطبيق.\n• قاعدة البيانات مستقلة لكل هاتف.\n• استيراد الحالات يتم من نموذج Excel الفارغ الصادر من التطبيق فقط.\n• لا يطلب التطبيق ملف Excel القديم ولا يعتمد عليه.\n• لا ترفع بيانات شخصية أو صحية إلى GitHub.\n• كلمة مرور مدير محلية، ونسخ احتياطية مشفرة بكلمة مرور منفصلة.\n• الاستعادة تدمج السجلات وتتجاوز التكرارات ولا تحذف البيانات الحالية.\n• راجع ملف النسخة وكلمة مرورها واحفظهما في مكان آمن.",color=Color.Gray)}}
 }} }
 if(form)EditDialog(edit,meds,{db.findEmployee(it)},{db.strengthsForMedicine(it)},{form=false},{r->db.save(r);db.upsertMedicine(r.medicine);if(r.strength.isNotBlank())db.addStrength(r.medicine,r.strength);db.log(if(r.id>0)"تعديل" else "إضافة",r.performanceNo);tick++;form=false})
 if(previewRows!=null){val rows=previewRows!!;val duplicates=db.duplicateCount(rows);val issues=db.caseImportIssues(rows);AlertDialog(onDismissRequest={previewRows=null},title={Text("مراجعة استيراد الحالات الحرجة")},text={Column(Modifier.heightIn(max=480.dp).verticalScroll(rememberScrollState())){Text("السجلات المقروءة: ${rows.size}");Text("سجلات مطابقة موجودة أو مكررة داخل الملف: $duplicates");Text("سجلات جديدة متوقعة: ${(rows.size-duplicates).coerceAtLeast(0)}");Text("أخطاء تمنع الاعتماد: ${issues.size}",color=if(issues.isEmpty())Teal else Color.Red);issues.take(30).forEach{Text("• $it",fontSize=12.sp,color=Color.Red)};Text("عينة من البيانات:",fontWeight=FontWeight.Bold);rows.take(5).forEach{Text("• ${it.name} | ${it.performanceNo} | ${it.medicine} | ${it.strength}",fontSize=12.sp)};Text("لن يتم اعتماد أي سجل إذا كانت هناك أخطاء إلزامية. السجلات المتطابقة بالكامل فقط ستُتجاوز؛ ويمكن للعامل نفسه الحصول على أكثر من علاج أو سجل مختلف.",fontSize=11.sp,color=Color.Gray)}},confirmButton={Button(enabled=issues.isEmpty(),onClick={try{val(a,d)=db.importRows(rows);msg="تمت إضافة $a سجل وتجاوز $d سجلاً مطابقاً بالكامل";previewRows=null;tick++}catch(e:Exception){msg="لم يتم اعتماد الاستيراد: ${e.message}"}}){Text("اعتماد الاستيراد")}},dismissButton={TextButton(onClick={previewRows=null}){Text("إلغاء")}})}
 if(showEmployeeForm)EmployeeEditDialog(employeeEdit,{showEmployeeForm=false},{r->try{db.saveEmployee(r);db.log("حفظ دليل عامل",r.performanceNo);msg="تم حفظ بيانات العامل";tick++;showEmployeeForm=false}catch(e:Exception){msg="تعذر حفظ العامل: ${e.message}"}})
 if(employeePlan!=null){val plan=employeePlan!!;AlertDialog(onDismissRequest={employeePlan=null},title={Text("تقرير مراجعة دليل العاملين")},text={Column(Modifier.heightIn(max=480.dp).verticalScroll(rememberScrollState())){Text("موظفون جدد: ${plan.inserts.size}",color=Teal);Text("بيانات سيتم تحديثها: ${plan.updates.size}",color=Teal);Text("دون تغيير: ${plan.unchanged}");Text("أخطاء تمنع الاعتماد: ${plan.issues.size}",color=if(plan.issues.isEmpty())Teal else Color.Red);plan.issues.take(30).forEach{Text("صف ${it.row} • ${it.performanceNo}: ${it.message}",fontSize=12.sp,color=Color.Red)};plan.changes.take(20).forEach{change->Text("${change.performanceNo} • ${change.name}",fontWeight=FontWeight.Bold,color=Navy,fontSize=12.sp);change.fields.forEach{field->Text("${field.field}: ${field.oldValue.ifBlank{"(فارغ)"}} ← ${field.newValue}",fontSize=11.sp)}};if(plan.issues.isEmpty())Text("لن تُمسح البيانات القديمة عند ترك خلية فارغة. ستتم العملية داخل معاملة واحدة، إما تكتمل كلها أو لا يُعتمد أي تغيير.",fontSize=12.sp)}} ,confirmButton={Button(enabled=plan.canCommit,onClick={try{val(a,u)=db.commitEmployeeImport(plan);msg="تم تحديث دليل العاملين: إضافة $a وتحديث $u";employeePlan=null;tick++}catch(e:Exception){msg="لم يتم اعتماد الاستيراد: ${e.message}"}}){Text("اعتماد التحديث")}},dismissButton={TextButton(onClick={employeePlan=null}){Text("إلغاء")}})}
 if(reportDialog)AlertDialog(onDismissRequest={reportDialog=false},title={Text("اختيار الأدوية للتقرير")},text={Column(Modifier.heightIn(max=520.dp)) {Text("حدد دواءً واحداً أو عدة أدوية، أو اترك الكل محدداً لإصدار تقرير شامل.",fontSize=12.sp,color=Color.Gray);Row(verticalAlignment=Alignment.CenterVertically){TextButton(onClick={selectedReportMeds=reportMeds.toSet()}){Text("تحديد الكل")};TextButton(onClick={selectedReportMeds=emptySet()}){Text("إلغاء التحديد")};Spacer(Modifier.weight(1f));Text("${selectedReportMeds.size}/${reportMeds.size}",color=Teal,fontWeight=FontWeight.Bold)};Column(Modifier.weight(1f,false).verticalScroll(rememberScrollState())){reportMeds.forEach{medicine->Row(Modifier.fillMaxWidth().clickable{selectedReportMeds=if(medicine in selectedReportMeds)selectedReportMeds-medicine else selectedReportMeds+medicine}.padding(vertical=3.dp),verticalAlignment=Alignment.CenterVertically){Checkbox(checked=medicine in selectedReportMeds,onCheckedChange={checked->selectedReportMeds=if(checked)selectedReportMeds+medicine else selectedReportMeds-medicine});Text("$medicine  •  ${counts[medicine]?:0} سجل",Modifier.weight(1f))}}}}},confirmButton={Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){Button(enabled=selectedReportMeds.isNotEmpty(),onClick={pendingReportRows=db.all().filter{it.medicine in selectedReportMeds};pendingReportTitle=if(selectedReportMeds.size==reportMeds.size)"تقرير جميع الأدوية" else "تقرير الأدوية المختارة";reportDialog=false;pdf.launch("تقرير_الأدوية_المختارة.pdf")}){Text("PDF")};Button(enabled=selectedReportMeds.isNotEmpty(),onClick={pendingReportRows=db.all().filter{it.medicine in selectedReportMeds};pendingReportTitle=if(selectedReportMeds.size==reportMeds.size)"تقرير جميع الأدوية" else "تقرير الأدوية المختارة";reportDialog=false;export.launch("تقرير_الأدوية_المختارة.xlsx")}){Text("Excel")}}},dismissButton={TextButton(onClick={reportDialog=false}){Text("إلغاء")}})
 if(backupDialog.isNotBlank())AlertDialog(onDismissRequest={backupDialog="";backupPassword="";restoreBytes=null},title={Text(if(backupDialog=="export")"حماية النسخة الاحتياطية" else "كلمة مرور الاستعادة")},text={Column{Text("${if(backupDialog=="export")"أنشئ كلمة مرور لحماية ملف النسخة. استخدم 8 أحرف أو أرقام على الأقل." else "أدخل كلمة المرور التي استُخدمت عند إنشاء النسخة."}");OutlinedTextField(backupPassword,{backupPassword=it},label={Text("كلمة مرور النسخة")},singleLine=true,visualTransformation=PasswordVisualTransformation())}},confirmButton={Button(onClick={try{if(backupDialog=="export"){exportBackupBytes=EncryptedBackup.encodeFull(db.all(),db.employees(),db.medicineCatalog(),db.medicineStrengths(),backupPassword);backupDialog="";backupSave.launch("نسخة_علاج_الحالات_المشفرة.tcbak")}else{restorePreview=EncryptedBackup.decodeFull(restoreBytes?:byteArrayOf(),backupPassword);backupDialog="";restoreBytes=null};backupPassword=""}catch(e:Exception){msg="تعذر تنفيذ العملية: ${e.message ?: "تحقق من كلمة المرور"}"}}){Text("متابعة")}},dismissButton={TextButton(onClick={backupDialog="";backupPassword="";restoreBytes=null}){Text("إلغاء")}})
 if(restorePreview!=null){val bundle=restorePreview!!;val caseIssues=CaseDataRules.validate(bundle.cases);val employeeIssues=db.planEmployeeImport(bundle.employees).issues;AlertDialog(onDismissRequest={restorePreview=null},title={Text("معاينة النسخة قبل الاستعادة")},text={Column(Modifier.heightIn(max=460.dp).verticalScroll(rememberScrollState())){Text("الحالات العلاجية: ${bundle.cases.size}",color=Navy);Text("العاملون: ${bundle.employees.size}",color=Navy);Text("الأدوية في القاموس: ${bundle.medicineDetails.size.coerceAtLeast(bundle.medicines.size)}",color=Navy);Text("العيارات: ${bundle.strengths.size}",color=Navy);Text("مشكلات بيانات الحالات: ${caseIssues.size}",color=if(caseIssues.isEmpty())Teal else Color.Red);Text("مشكلات بيانات العاملين: ${employeeIssues.size}",color=if(employeeIssues.isEmpty())Teal else Color.Red);(caseIssues+employeeIssues.take(10).map{"بيانات عامل: ${it.message}"}).take(15).forEach{Text("• $it",fontSize=12.sp,color=Color.Red)};Text("الاستعادة ستدمج البيانات ولن تحذف السجلات الحالية. كلمة مرور المدير وصلاحيات هذا الهاتف لن تنتقل من النسخة.",fontSize=12.sp,color=Color.Gray)}},confirmButton={Button(enabled=caseIssues.isEmpty()&&employeeIssues.isEmpty(),onClick={try{val(casesAdded,employeesAdded,employeesUpdated)=db.restoreBundle(bundle);msg="تمت الاستعادة الدمجية: حالات جديدة $casesAdded، عاملون جدد $employeesAdded، تحديث عاملين $employeesUpdated. تم دمج قاموس الأدوية والعيارات دون حذف البيانات الحالية.";tick++;restorePreview=null}catch(e:Exception){msg="لم تتم الاستعادة: ${e.message}"}}){Text("اعتماد الاستعادة")}},dismissButton={TextButton(onClick={restorePreview=null}){Text("إلغاء")}})}
 if(changePasswordDialog)AlertDialog(onDismissRequest={changePasswordDialog=false;currentPassword="";newPassword="";confirmPassword=""},title={Text("تغيير كلمة مرور المدير")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(currentPassword,{currentPassword=it},label={Text("كلمة المرور الحالية")},singleLine=true,visualTransformation=PasswordVisualTransformation());OutlinedTextField(newPassword,{newPassword=it},label={Text("كلمة المرور الجديدة")},singleLine=true,visualTransformation=PasswordVisualTransformation());OutlinedTextField(confirmPassword,{confirmPassword=it},label={Text("تأكيد كلمة المرور الجديدة")},singleLine=true,visualTransformation=PasswordVisualTransformation());Text("يجب ألا تقل كلمة المرور الجديدة عن 8 أحرف أو أرقام.",fontSize=11.sp,color=Color.Gray);if(settingsMessage.isNotBlank())Text(settingsMessage,color=Color.Red,fontSize=12.sp)}},confirmButton={Button(onClick={if(!auth.verify(currentPassword))settingsMessage="كلمة المرور الحالية غير صحيحة" else if(newPassword.length<8)settingsMessage="كلمة المرور الجديدة قصيرة" else if(newPassword!=confirmPassword)settingsMessage="تأكيد كلمة المرور غير مطابق" else if(auth.createAdmin(newPassword)){settingsMessage="تم تغيير كلمة المرور بنجاح";changePasswordDialog=false;currentPassword="";newPassword="";confirmPassword=""}else settingsMessage="تعذر تغيير كلمة المرور"}){Text("حفظ التغيير")}},dismissButton={TextButton(onClick={changePasswordDialog=false}){Text("إلغاء")}})
 if(showMedicineAdd)AlertDialog(onDismissRequest={showMedicineAdd=false},title={Text("إضافة دواء للقاموس")},text={Column{OutlinedTextField(newMedicine,{newMedicine=it},label={Text("اسم الدواء")});OutlinedTextField(newStrengths,{newStrengths=it},label={Text("التركيزات المتاحة")})}},confirmButton={Button(onClick={if(db.addMedicine(newMedicine,strengths=newStrengths)){msg="تمت إضافة الدواء إلى القاموس";tick++;newMedicine="";newStrengths="";showMedicineAdd=false}else msg="الاسم فارغ أو الدواء موجود بالفعل"}){Text("حفظ")}},dismissButton={TextButton(onClick={showMedicineAdd=false}){Text("إلغاء")}})
}
@Composable fun EmployeeEditDialog(old:EmployeeRecord?,close:()->Unit,save:(EmployeeRecord)->Unit){
 val fields=listOf("رقم الأداء","الاسم","الوظيفة","الجهة","الإدارة","رقم البطاقة","رقم التليفون","رقم التليفون الثاني","النوع","ملاحظات")
 val values= remember(old){mutableStateListOf(*(old?.cells()?.toTypedArray()?:Array(10){""}))}
 AlertDialog(onDismissRequest=close,title={Text(if(old==null)"إضافة عامل إلى الدليل" else "تعديل بيانات العامل")},text={Column(Modifier.heightIn(max=520.dp).verticalScroll(rememberScrollState())){fields.forEachIndexed{i,label->OutlinedTextField(values[i],{values[i]=it},Modifier.fillMaxWidth().padding(vertical=2.dp),label={Text(label)},singleLine=i!=9,enabled=(i!=0||old==null))};Text("رقم الأداء فريد ولا يقبل التكرار. رقم البطاقة إن أدخلته يجب أن يكون صحيحاً.",fontSize=11.sp,color=Color.Gray)}},confirmButton={Button(enabled=values[0].isNotBlank()&&values[1].isNotBlank(),onClick={save(EmployeeRecord(performanceNo=values[0].trim(),name=values[1],job=values[2],entity=values[3],department=values[4],nationalId=values[5],phone1=values[6],phone2=values[7],gender=values[8],notes=values[9]))}){Text("حفظ")}},dismissButton={TextButton(onClick=close){Text("إلغاء")}})
}
@Composable fun Stat(label:String,value:String,mod:Modifier){Card(mod,colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),shape=RoundedCornerShape(15.dp)){Column(Modifier.padding(15.dp)){Text(label,color=Color.Gray,fontSize=12.sp);Text(value,color=Teal,fontSize=27.sp,fontWeight=FontWeight.Bold)}}}
@Composable fun RecordCard(r:CaseRecord,edit:()->Unit,delete:()->Unit){var ask by remember{mutableStateOf(false)};Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){Column(Modifier.padding(11.dp)){Row(verticalAlignment=Alignment.CenterVertically){Text(r.name,Modifier.weight(1f),fontWeight=FontWeight.Bold,color=Navy);IconButton(onClick=edit){Icon(Icons.Default.Edit,null,tint=Teal)};IconButton(onClick={ask=true}){Icon(Icons.Default.Delete,null,tint=Color.Red)}};Text("رقم الأداء: ${r.performanceNo} • ${r.medicine}",color=Teal);Text("${r.strength} | الموافقة: ${r.approvalDate}",fontSize=12.sp,color=Color.Gray);if(r.condition.isNotBlank())Text(r.condition,fontSize=12.sp)}};if(ask)AlertDialog(onDismissRequest={ask=false},title={Text("حذف السجل؟")},confirmButton={TextButton(onClick={delete;ask=false}){Text("حذف")}},dismissButton={TextButton(onClick={ask=false}){Text("إلغاء")}})}
@Composable
fun EditDialog(
    old: CaseRecord?,
    meds: List<String>,
    lookup: (String) -> EmployeeRecord?,
    strengthOptions: (String) -> List<String>,
    close: () -> Unit,
    save: (CaseRecord) -> Unit
) {
    val labels = listOf("المنطقة", "القطاع", "الاسم", "رقم الأداء", "اسم الدواء", "التركيز/العيار", "بيان إضافي 1", "بيان إضافي 2", "مدة الصرف", "الجرعة", "الحالة المرضية", "تاريخ الموافقة", "انتهاء الموافقة")
    val values = remember(old) { mutableStateListOf(*(old?.cells()?.toTypedArray() ?: Array(13) { "" })) }
    var formError by remember(old) { mutableStateOf("") }
    var medicineMenu by remember { mutableStateOf(false) }
    var strengthMenu by remember { mutableStateOf(false) }
    val options = strengthOptions(values[4])

    AlertDialog(
        onDismissRequest = close,
        title = { Text(if (old == null) "إضافة مستفيد" else "تعديل مستفيد") },
        text = {
            Column(Modifier.heightIn(max = 530.dp).verticalScroll(rememberScrollState())) {
                labels.forEachIndexed { index, label ->
                    when (index) {
                        4 -> Box {
                            OutlinedTextField(
                                values[index], {}, Modifier.fillMaxWidth().padding(vertical = 2.dp),
                                label = { Text(label) }, readOnly = true,
                                trailingIcon = { IconButton(onClick = { medicineMenu = true }) { Icon(Icons.Default.ArrowDropDown, null) } }
                            )
                            DropdownMenu(expanded = medicineMenu, onDismissRequest = { medicineMenu = false }) {
                                meds.forEach { medicine ->
                                    DropdownMenuItem(text = { Text(medicine) }, onClick = {
                                        values[4] = medicine
                                        values[5] = ""
                                        medicineMenu = false
                                    })
                                }
                            }
                        }
                        5 -> if (options.isNotEmpty()) Box {
                            OutlinedTextField(
                                values[index], { values[index] = it }, Modifier.fillMaxWidth().padding(vertical = 2.dp),
                                label = { Text(label) },
                                trailingIcon = { IconButton(onClick = { strengthMenu = true }) { Icon(Icons.Default.ArrowDropDown, null) } }
                            )
                            DropdownMenu(expanded = strengthMenu, onDismissRequest = { strengthMenu = false }) {
                                options.forEach { strength ->
                                    DropdownMenuItem(text = { Text(strength) }, onClick = {
                                        values[5] = strength
                                        strengthMenu = false
                                    })
                                }
                            }
                        } else {
                            OutlinedTextField(values[index], { values[index] = it }, Modifier.fillMaxWidth().padding(vertical = 2.dp), label = { Text(label) })
                        }
                        else -> OutlinedTextField(
                            values[index], { values[index] = it }, Modifier.fillMaxWidth().padding(vertical = 2.dp),
                            label = { Text(label) }, singleLine = index != 10
                        )
                    }
                    if (index == 3 && values[index].isNotBlank()) {
                        val employee = lookup(values[index].trim())
                        if (employee != null) {
                            values[2] = employee.name
                            Text("تم العثور على العامل: ${employee.name} • ${employee.job} • ${employee.entity} / ${employee.department}", fontSize = 11.sp, color = Teal)
                        } else {
                            Text("رقم الأداء غير موجود في دليل العاملين", fontSize = 11.sp, color = Color(0xFF9A5A12))
                        }
                    }
                }
                if (formError.isNotBlank()) Text(formError, color = Color.Red, fontSize = 12.sp)
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val record = CaseDataRules.normalizeForImport(CaseRecord.from(values.toList()).copy(id = old?.id ?: 0))
                    val issues = CaseDataRules.validate(listOf(record))
                    if (issues.isNotEmpty()) formError = issues.joinToString("\n")
                    else { formError = ""; save(record) }
                },
                enabled = values[2].isNotBlank() && values[3].isNotBlank() && values[4].isNotBlank()
            ) { Text("حفظ") }
        },
        dismissButton = { TextButton(onClick = close) { Text("إلغاء") } }
    )
}

fun pdfReport(activity:Activity,uri:Uri,rows:List<CaseRecord>,reportTitle:String="تقرير السجلات"){
 val doc=PdfDocument();val width=595;val height=842;val margin=30f;val body=TextPaint(Paint.ANTI_ALIAS_FLAG).apply{textSize=10f;color=android.graphics.Color.DKGRAY};val header=TextPaint(Paint.ANTI_ALIAS_FLAG).apply{textSize=16f;color=android.graphics.Color.rgb(7,89,199);isFakeBoldText=true;textAlign=Paint.Align.RIGHT};var pageNo=1;var page=doc.startPage(PdfDocument.PageInfo.Builder(width,height,pageNo).create());var canvas=page.canvas;var y=42f
 fun heading(){canvas.drawText("علاج الحالات حاجة - $reportTitle",width-margin,y,header);y+=28;canvas.drawLine(margin,y,width-margin,y,Paint().apply{color=android.graphics.Color.LTGRAY;strokeWidth=1f});y+=16}
 fun newPage(){doc.finishPage(page);pageNo++;page=doc.startPage(PdfDocument.PageInfo.Builder(width,height,pageNo).create());canvas=page.canvas;y=42f;heading()}
 heading()
 rows.forEachIndexed{index,r->
  val line="${index+1}) الاسم: ${r.name}   |   رقم الأداء: ${r.performanceNo}\nالدواء: ${r.medicine}   |   التركيز/العيار: ${r.strength}\nالمنطقة: ${r.region}   |   القطاع: ${r.sector}\nمدة الصرف: ${r.duration}   |   الجرعة: ${r.dosage}\nالحالة المرضية: ${r.condition}\nتاريخ الموافقة: ${r.approvalDate}   |   الانتهاء: ${r.approvalExpiry}\n${listOf(r.extra1,r.extra2).filter{it.isNotBlank()}.joinToString("   |   ")}"
  val layout=StaticLayout.Builder.obtain(line,0,line.length,body,(width-(margin*2)).toInt()).setAlignment(Layout.Alignment.ALIGN_OPPOSITE).setTextDirection(TextDirectionHeuristics.RTL).setIncludePad(false).setLineSpacing(2f,1f).build()
  if(y+layout.height>height-35)newPage()
  canvas.save();canvas.translate(margin,y);layout.draw(canvas);canvas.restore();y+=layout.height+10
  canvas.drawLine(margin,y,width-margin,y,Paint().apply{color=android.graphics.Color.LTGRAY;strokeWidth=0.5f});y+=8
 }
 doc.finishPage(page);activity.contentResolver.openOutputStream(uri)?.use{doc.writeTo(it)}?:error("تعذر حفظ تقرير PDF");doc.close()
}
