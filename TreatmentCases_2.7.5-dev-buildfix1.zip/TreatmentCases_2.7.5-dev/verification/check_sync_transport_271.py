#!/usr/bin/env python3
"""Static safety checks for the HTTPS outbound sync transport in 2.7.1."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
transport=(root/'android/app/src/main/java/com/treatmentcases/app/SyncTransport.kt').read_text(encoding='utf-8')
main=(root/'android/app/src/main/java/com/treatmentcases/app/MainActivity.kt').read_text(encoding='utf-8')
manifest=(root/'android/app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
gradle=(root/'android/app/build.gradle').read_text(encoding='utf-8')
checks=[
 ('HTTPS required for endpoint', 'startsWith("https://")' in transport),
 ('Bearer token required', 'Authorization", "Bearer $bearerToken' in transport),
 ('token encrypted with Android Keystore AES-GCM', 'AndroidKeyStore' in transport and 'AES/GCM/NoPadding' in transport and 'GCMParameterSpec' in transport),
 ('token never placed in WorkManager input', 'setInputData' not in transport),
 ('event IDs sent for idempotency', 'event_id' in transport and 'eventId' in transport),
 ('server acknowledgements validated against submitted IDs', 'accepted_event_ids' in transport and 'accepted.all { it in allowedIds }' in transport),
 ('only acknowledged events marked sent', 'acknowledgeSyncEvents(accepted)' in transport),
 ('unacknowledged events remain retryable', 'recordSyncFailure(response.rejectedIds.toList()' in transport and 'Result.retry()' in transport),
 ('network constrained background work', 'NetworkType.CONNECTED' in transport),
 ('network permission present', 'android.permission.INTERNET' in manifest),
 ('settings expose HTTPS endpoint and manual sync', 'HTTPS server URL' in main and 'SyncWorkScheduler.enqueue(ctx)' in main),
 ('isolated 2.7.3 preview build', "versionName '2.7.5-dev'" in gradle and 'com.treatmentcases.app.preview275' in gradle),
]
for name,ok in checks: print(('PASS' if ok else 'FAIL')+': '+name)
assert all(ok for _,ok in checks)
print(f'{len(checks)} transport assertions passed')
