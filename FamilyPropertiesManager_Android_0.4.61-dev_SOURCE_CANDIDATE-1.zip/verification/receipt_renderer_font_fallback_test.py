#!/usr/bin/env python3
"""Missing workbook Arabic font must use a bundled, licensed Arabic-capable asset."""
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / "app/src/main/java/com/example/rentals/printing/OriginalReceiptTemplateRenderer.kt").read_text(encoding="utf-8")
license_text = (ROOT / "licenses/NOTO_FONTS_LICENSE.txt").read_text(encoding="utf-8")
font = ROOT / "app/src/main/res/font/noto_sans_arabic_regular.ttf"
assert font.is_file() and font.stat().st_size > 100_000
assert 'sourceFont.contains("ae_almohanad") -> ResourcesCompat.getFont(context, R.font.noto_sans_arabic_regular)' in source
assert 'sourceFont.contains("ae_almohanad") -> Typeface.create("sans-serif"' not in source
assert "Noto" in license_text
print("PASS: ae_AlMohanad now uses bundled Noto Arabic fallback, not device-dependent sans-serif")
