package com.example.rentals.security

import android.content.Context
import android.util.Base64
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

class AppSecurity(context: Context) {
    private val prefs=context.getSharedPreferences("app_security",Context.MODE_PRIVATE)
    fun hasPin()=prefs.contains("pin_hash")
    fun setPin(pin:String) { val salt=ByteArray(16).also{SecureRandom().nextBytes(it)}; prefs.edit().putString("pin_salt",Base64.encodeToString(salt,Base64.NO_WRAP)).putString("pin_hash",Base64.encodeToString(hash(pin,salt),Base64.NO_WRAP)).apply() }
    fun verifyPin(pin:String):Boolean { val salt=Base64.decode(prefs.getString("pin_salt","")?:"",Base64.NO_WRAP); val expected=Base64.decode(prefs.getString("pin_hash","")?:"",Base64.NO_WRAP); return expected.isNotEmpty() && java.security.MessageDigest.isEqual(expected,hash(pin,salt)) }
    fun biometricEnabled()=prefs.getBoolean("biometric_enabled",true)
    fun setBiometricEnabled(value:Boolean){prefs.edit().putBoolean("biometric_enabled",value).apply()}
    fun biometricAvailable(context:Context)=BiometricManager.from(context).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL)==BiometricManager.BIOMETRIC_SUCCESS
    fun prompt(activity:FragmentActivity,onSuccess:()->Unit,onError:(String)->Unit) {
        val executor=ContextCompat.getMainExecutor(activity)
        val prompt=BiometricPrompt(activity,executor,object:BiometricPrompt.AuthenticationCallback(){
            override fun onAuthenticationSucceeded(result:BiometricPrompt.AuthenticationResult){onSuccess()}
            override fun onAuthenticationError(errorCode:Int,errString:CharSequence){onError(errString.toString())}
        })
        val info=BiometricPrompt.PromptInfo.Builder().setTitle("فتح نظام إدارة الإيجارات").setSubtitle("استخدم بصمة الإصبع أو وسيلة قفل الجهاز").setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL).build()
        prompt.authenticate(info)
    }
    private fun hash(pin:String,salt:ByteArray):ByteArray { val spec=PBEKeySpec(pin.toCharArray(),salt,120_000,256); return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded }
}
