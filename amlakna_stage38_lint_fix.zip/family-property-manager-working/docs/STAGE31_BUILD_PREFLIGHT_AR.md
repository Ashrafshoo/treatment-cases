# المرحلة 31 – فحص ما قبل بناء Android

## ما تم التحقق منه في هذه المراجعة
- تم فك حزمة المرحلة 30 وفحص بنية مشروع Kotlin/Jetpack Compose.
- ملف `.github/workflows/android-apk.yml` موجود داخل المصدر، ومطابق بايتياً لملف Workflow المنفصل المرفق سابقاً (SHA-256: `ffc80425170a756a0ac99ffafbe3c33ad9fc642299e7b0e315b7d4d9d5265c6e`).
- Workflow يطلب JDK 17 وAndroid SDK 35 وGradle 8.9، ثم يشغّل Python tests وAndroid unit tests وLint و`assembleDebug` ويرفع APK والتقارير كـ Artifact.
- أُعيد تشغيل اختبارات المصدر في بيئة المراجعة: `84 passed`.
- فُحص AndroidManifest وملفات إعداد Gradle ومراجع ترحيل قاعدة البيانات. مسار التثبيت الجديد يستخدم `007_fresh_install_policy.sql`، ومسار الترقية من الإصدار 6 يستخدم `007_law164_policy_separation.sql`، ثم يطبق الإصدار 8 للأرشيف.
- نُظفت الحزمة من `.pytest_cache` و`__pycache__` وملفات `.pyc`.
- لم تظهر ضمن الحزمة ملفات قواعد بيانات أو ملفات Excel أو عقود أو إيصالات عائلية فعلية.

## ما لم يتم التحقق منه
- بيئة المراجعة لا تحتوي Gradle أو Android SDK ولا Gradle Wrapper؛ لذلك لم ينفذ تجميع Kotlin/Android أو JUnit أو Lint أو APK.
- وجود Workflow في ZIP لا يفعّله تلقائياً في GitHub. يجب وضع الملف نفسه في مستودع GitHub الخاص في `.github/workflows/android-apk.yml` أولاً، ثم رفع مصدر المشروع باسم `project-source.zip`.
- لا توجد نتيجة GitHub Actions ولا Artifact APK حتى تاريخ هذا الفحص.

## قرار المرحلة
هذه حزمة أنظف ومهيأة لبوابة البناء السحابي، وليست إصداراً نهائياً معتمداً. يبقى اعتماد الإصدار مشروطاً بنجاح GitHub Actions ومراجعة APK وتجربته على هاتف Android، إضافة إلى إغلاق الوظائف غير المكتملة المسجلة في `STAGE30_INTEGRATION_AUDIT_AR.md`.
