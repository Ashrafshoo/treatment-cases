// ===== سكربت المزامنة (يعمل بصلاحيات حسابك على Google Drive) =====
// 1) غيّر السطرين التاليين، 2) انشره كتطبيق ويب (Execute as: Me / Who has access: Anyone)
const KEY = 'اكتب_هنا_كلمة_سر_طويلة_عشوائية';      // نفس الكلمة تكتبها في التطبيق
const FILE_ID = 'ضع_هنا_معرّف_الملف';              // الجزء بين /d/ و /view أو /edit في رابط الملف

function doGet(e) {
  if (!e || !e.parameter || e.parameter.key !== KEY) {
    return out_({ ok: false, error: 'كلمة السر غير صحيحة' });
  }
  try {
    const file = DriveApp.getFileById(FILE_ID);
    let blob;
    if (file.getMimeType() === 'application/vnd.google-apps.spreadsheet') {
      const url = 'https://docs.google.com/spreadsheets/d/' + FILE_ID + '/export?format=xlsx';
      blob = UrlFetchApp.fetch(url, { headers: { Authorization: 'Bearer ' + ScriptApp.getOAuthToken() } }).getBlob();
    } else {
      blob = file.getBlob();
    }
    return out_({ ok: true, name: file.getName(), updated: String(file.getLastUpdated()), b64: Utilities.base64Encode(blob.getBytes()) });
  } catch (err) {
    return out_({ ok: false, error: String(err) });
  }
}

function out_(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}
