import 'package:flutter/material.dart';

import '../data/payments_repository.dart';
import '../../auth/data/app_session.dart';
import '../services/receipt_print_service.dart';
import 'monthly_collection_screen.dart';

class PaymentsScreen extends StatefulWidget {
  const PaymentsScreen({super.key});
  @override
  State<PaymentsScreen> createState() => _PaymentsScreenState();
}

class _PaymentsScreenState extends State<PaymentsScreen> {
  final _repo = PaymentsRepository();
  late Future<List<Map<String, Object?>>> _receipts;

  @override
  void initState() { super.initState(); _refresh(); }
  void _refresh() => _receipts = _repo.receipts();
  Future<void> _print() async { try { final count=await ReceiptPrintService().printApprovedReceipts(); if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تم إرسال $count إيصالاً معتمداً إلى معاينة الطباعة'))); } catch(e) { if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تعذرت الطباعة: $e'))); } }

  Future<void> _openMonthlyCollection() async {
    final saved = await Navigator.of(context).push<bool>(
      MaterialPageRoute<bool>(builder: (_) => const MonthlyCollectionScreen()),
    );
    if (saved == true && mounted) setState(_refresh);
  }

  Future<void> _add() async {
    final saved = await showModalBottomSheet<bool>(
      context: context, isScrollControlled: true, useSafeArea: true,
      builder: (_) => _PaymentForm(repository: _repo),
    );
    if (saved == true && mounted) setState(_refresh);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('التحصيلات والإيصالات'),actions:[if(AppSession.instance.isAdmin)IconButton(tooltip:'دورة التحصيل الشهرية',onPressed:_openMonthlyCollection,icon:const Icon(Icons.calendar_month)),if(AppSession.instance.isAdmin)IconButton(tooltip:'طباعة الإيصالات المعتمدة (3 في الصفحة)',onPressed:_print,icon:const Icon(Icons.print_outlined))]),
    floatingActionButton: AppSession.instance.isAdmin ? FloatingActionButton.extended(onPressed:_add,icon:const Icon(Icons.add),label:const Text('تسجيل تحصيل')) : null,
    body: FutureBuilder<List<Map<String, Object?>>>(
      future: _receipts,
      builder: (context, snapshot) {
        if (snapshot.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
        if (snapshot.hasError) return Center(child: Text('تعذر تحميل الإيصالات: ${snapshot.error}'));
        final rows = snapshot.data ?? [];
        if (rows.isEmpty) return const Center(child: Text('لا توجد تحصيلات مسجلة'));
        return ListView.separated(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 96),
          itemCount: rows.length,
          separatorBuilder: (_, __) => const SizedBox(height: 8),
          itemBuilder: (context, index) {
            final r = rows[index];
            final amount = ((r['amount_minor'] as num) / 100).toStringAsFixed(2);
            final approved = r['approved'] == 1;
            return Card(child: ListTile(
              leading: CircleAvatar(child: Icon(approved ? Icons.verified_outlined : Icons.receipt_long_outlined)),
              title: Text('${r['tenant_snapshot'] ?? 'مستأجر غير محدد'} • $amount جنيه'),
              subtitle: Text('إيصال ${r['receipt_number']}\n${r['property_snapshot'] ?? ''} / ${r['unit_snapshot'] ?? '—'} • ${r['issued_at']}\n${approved ? 'معتمد ومحمي من التعديل' : 'مسودة غير معتمدة'}\n${r['amount_words_snapshot'] ?? ''}'),
              isThreeLine: true,
              trailing: !AppSession.instance.isAdmin ? (approved ? const Icon(Icons.lock_outline) : const Icon(Icons.hourglass_empty)) : approved ? const Icon(Icons.lock_outline) : PopupMenuButton<String>(onSelected: (action) async { if (action == 'approve') { try { await _repo.approveReceipt(r['id'] as String); if (mounted) setState(_refresh); } catch(e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر الاعتماد: $e'))); } } else if (action == 'cancel') { final yes = await showDialog<bool>(context: context, builder: (c) => AlertDialog(title: const Text('إلغاء مسودة الإيصال'), content: const Text('سيتم حذف مسودة الإيصال والتحصيل المرتبط بها مع تسجيل العملية. هل تريد المتابعة؟'), actions: [TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('رجوع')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('تأكيد'))])); if (yes == true) { await _repo.rejectDraftReceipt(r['id'] as String); if (mounted) setState(_refresh); } } }, itemBuilder: (_) => const [PopupMenuItem(value:'approve',child:Text('اعتماد الإيصال')),PopupMenuItem(value:'cancel',child:Text('إلغاء المسودة'))]),
            ));
          },
        );
      },
    ),
  );
}

class _PaymentForm extends StatefulWidget {
  const _PaymentForm({required this.repository});
  final PaymentsRepository repository;
  @override
  State<_PaymentForm> createState() => _PaymentFormState();
}

class _PaymentFormState extends State<_PaymentForm> {
  final _form = GlobalKey<FormState>();
  final _amount = TextEditingController();
  final _notes = TextEditingController();
  late Future<List<Map<String, Object?>>> _leases;
  String? _leaseId;
  String _method = 'cash';
  DateTime _paidAt = DateTime.now();
  DateTime? _periodStart;
  DateTime? _periodEnd;
  bool _saving = false;

  @override
  void initState() { super.initState(); _leases = widget.repository.activeLeases(); }
  @override
  void dispose() { _amount.dispose(); _notes.dispose(); super.dispose(); }

  String _fmt(DateTime d) => '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  Future<void> _pick(String field) async {
    final current = field == 'paid' ? _paidAt : field == 'start' ? (_periodStart ?? _paidAt) : (_periodEnd ?? _paidAt);
    final value = await showDatePicker(context: context, initialDate: current, firstDate: DateTime(2000), lastDate: DateTime(2100));
    if (value != null) setState(() { if (field == 'paid') _paidAt = value; if (field == 'start') _periodStart = value; if (field == 'end') _periodEnd = value; });
  }

  Future<void> _save() async {
    if (!_form.currentState!.validate() || _leaseId == null) return;
    if (_periodStart != null && _periodEnd != null && _periodEnd!.isBefore(_periodStart!)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('نهاية الفترة لا يمكن أن تسبق بدايتها')));
      return;
    }
    setState(() => _saving = true);
    try {
      await widget.repository.recordPayment(
        leaseId: _leaseId!, paidAt: _paidAt,
        amountMinor: (double.parse(_amount.text.trim()) * 100).round(),
        periodStart: _periodStart, periodEnd: _periodEnd,
        method: _method, notes: _notes.text.trim(),
      );
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر تسجيل التحصيل: $e')));
    } finally { if (mounted) setState(() => _saving = false); }
  }

  @override
  Widget build(BuildContext context) => Padding(
    padding: EdgeInsets.fromLTRB(18, 18, 18, MediaQuery.of(context).viewInsets.bottom + 18),
    child: Form(key: _form, child: ListView(shrinkWrap: true, children: [
      Text('تسجيل تحصيل جديد', style: Theme.of(context).textTheme.titleLarge),
      const SizedBox(height: 14),
      FutureBuilder<List<Map<String, Object?>>>(future: _leases, builder: (context, snap) {
        final rows = snap.data ?? [];
        return DropdownButtonFormField<String>(
          value: _leaseId, decoration: const InputDecoration(labelText: 'العقد / الوحدة'),
          items: rows.map((r) => DropdownMenuItem(value: r['id'] as String, child: Text('${r['tenant_name']} • ${r['property_name']} / ${r['unit_number'] ?? '—'}'))).toList(),
          onChanged: (v) => setState(() => _leaseId = v), validator: (v) => v == null ? 'اختر العقد' : null,
        );
      }),
      const SizedBox(height: 12),
      TextFormField(controller: _amount, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'المبلغ المحصل بالجنيه'), validator: (v) => double.tryParse(v ?? '') == null || double.parse(v!) <= 0 ? 'أدخل مبلغاً صحيحاً' : null),
      ListTile(contentPadding: EdgeInsets.zero, title: const Text('تاريخ التحصيل'), subtitle: Text(_fmt(_paidAt)), trailing: IconButton(onPressed: () => _pick('paid'), icon: const Icon(Icons.calendar_month))),
      DropdownButtonFormField<String>(value: _method, decoration: const InputDecoration(labelText: 'طريقة الدفع'), items: const [DropdownMenuItem(value: 'cash', child: Text('نقداً')), DropdownMenuItem(value: 'bank_transfer', child: Text('تحويل بنكي')), DropdownMenuItem(value: 'wallet', child: Text('محفظة إلكترونية')), DropdownMenuItem(value: 'cheque', child: Text('شيك')), DropdownMenuItem(value: 'other', child: Text('أخرى'))], onChanged: (v) => setState(() => _method = v ?? 'cash')),
      const SizedBox(height: 8),
      const Text('الفترة الإيجارية (اختيارية)'),
      Row(children: [Expanded(child: ListTile(contentPadding: EdgeInsets.zero, title: const Text('من'), subtitle: Text(_periodStart == null ? '—' : _fmt(_periodStart!)), onTap: () => _pick('start'))), Expanded(child: ListTile(contentPadding: EdgeInsets.zero, title: const Text('إلى'), subtitle: Text(_periodEnd == null ? '—' : _fmt(_periodEnd!)), onTap: () => _pick('end')))]),
      TextField(controller: _notes, maxLines: 2, decoration: const InputDecoration(labelText: 'ملاحظات')),
      const SizedBox(height: 18),
      FilledButton.icon(onPressed: _saving ? null : _save, icon: const Icon(Icons.save_outlined), label: Text(_saving ? 'جارٍ الحفظ…' : 'حفظ التحصيل وإنشاء مسودة إيصال')),
      const SizedBox(height: 8),
      const Text('ينشأ الإيصال كمسودة. بعد اعتماد المدير يصبح الإيصال محمياً من التعديل ويمكن طباعته ضمن صفحة A4 تحتوي حتى ثلاثة إيصالات.', style: TextStyle(fontSize: 12)),
    ])),
  );
}
