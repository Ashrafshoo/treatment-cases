package com.familyproperties.app.security

import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/** Authenticated, password-protected backup container for the encrypted SQLCipher file.
 * Backups are restorable on the same installation (whose SQLCipher key remains in Android Keystore).
 * This format deliberately does not pretend to migrate a database key to a different device.
 */
object BackupCipher {
    private val MAGIC = "AMLAKNA1".toByteArray(Charsets.US_ASCII)
    private const val ITERATIONS = 310_000
    private const val SALT_BYTES = 16
    private const val NONCE_BYTES = 12
    private const val TAG_BITS = 128

    fun createBackup(databaseFile: File, destination: File, password: CharArray) {
        try {
        require(databaseFile.canonicalFile != destination.canonicalFile) { "لا يمكن حفظ النسخة الاحتياطية فوق ملف قاعدة البيانات." }
        require(databaseFile.isFile && databaseFile.length() > 0) { "قاعدة البيانات غير موجودة أو فارغة." }
        require(!isPlaintextSqlite(databaseFile)) { "تم إيقاف النسخ لأن الملف يبدو غير مشفر." }
        require(password.size >= 12) { "كلمة مرور النسخة الاحتياطية يجب ألا تقل عن 12 حرفاً." }
        val salt = ByteArray(SALT_BYTES).also(SecureRandom()::nextBytes)
        val nonce = ByteArray(NONCE_BYTES).also(SecureRandom()::nextBytes)
        val key = derive(password, salt)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(TAG_BITS, nonce))
        cipher.updateAAD(MAGIC + salt + nonce)
        val parent = destination.absoluteFile.parentFile ?: error("مسار النسخة الاحتياطية غير صالح.")
        check(parent.exists() || parent.mkdirs())
        val temp = File(parent, destination.name + ".tmp")
        try {
            FileOutputStream(temp).use { raw ->
                raw.write(MAGIC); raw.write(salt); raw.write(nonce)
                javax.crypto.CipherOutputStream(raw, cipher).use { encrypted ->
                    FileInputStream(databaseFile).use { input -> input.copyTo(encrypted) }
                }
            }
            val previous = if (destination.exists()) File(parent, destination.name + ".previous-" + java.util.UUID.randomUUID()) else null
            if (previous != null) check(destination.renameTo(previous)) { "تعذر حفظ النسخة السابقة بأمان." }
            if (!temp.renameTo(destination)) {
                if (previous != null) previous.renameTo(destination)
                error("تعذر تثبيت ملف النسخة الاحتياطية.")
            }
        } finally {
            temp.delete()
        }
        } finally { password.fill('\u0000') }
    }

    fun restoreBackup(backupFile: File, databaseFile: File, password: CharArray) {
        try {
        require(backupFile.canonicalFile != databaseFile.canonicalFile) { "ملف النسخة الاحتياطية يجب أن يكون منفصلاً عن قاعدة البيانات." }
        require(backupFile.isFile && backupFile.length() > MAGIC.size + SALT_BYTES + NONCE_BYTES + 16) {
            "ملف النسخة الاحتياطية غير صالح أو ناقص."
        }
        require(password.size >= 12) { "كلمة مرور النسخة الاحتياطية غير صالحة." }
        val parent = databaseFile.absoluteFile.parentFile ?: error("مسار قاعدة البيانات غير صالح.")
        val temp = File(parent, databaseFile.name + ".restore.tmp")
        try {
            FileInputStream(backupFile).use { input ->
                val magic = ByteArray(MAGIC.size); check(input.read(magic) == magic.size && magic.contentEquals(MAGIC)) {
                    "صيغة النسخة الاحتياطية غير معروفة."
                }
                val salt = ByteArray(SALT_BYTES); check(input.read(salt) == salt.size)
                val nonce = ByteArray(NONCE_BYTES); check(input.read(nonce) == nonce.size)
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.DECRYPT_MODE, derive(password, salt), GCMParameterSpec(TAG_BITS, nonce))
                cipher.updateAAD(MAGIC + salt + nonce)
                javax.crypto.CipherInputStream(input, cipher).use { decrypted ->
                    FileOutputStream(temp).use { output -> decrypted.copyTo(output); output.fd.sync() }
                }
            }
            check(temp.isFile && temp.length() > 0 && !isPlaintextSqlite(temp)) { "النسخة المستعادة فارغة أو غير مشفرة." }
            if (databaseFile.exists()) {
                val safetyCopy = File(parent, databaseFile.name + ".before-restore-" + java.util.UUID.randomUUID())
                check(databaseFile.renameTo(safetyCopy)) { "تعذر إنشاء نسخة أمان قبل الاستعادة." }
                if (!temp.renameTo(databaseFile)) {
                    safetyCopy.renameTo(databaseFile)
                    error("فشلت الاستعادة؛ تمت إعادة ملف قاعدة البيانات السابق.")
                }
            } else check(temp.renameTo(databaseFile)) { "تعذر تثبيت قاعدة البيانات المستعادة." }
        } catch (error: Exception) {
            temp.delete()
            throw IllegalStateException("فشلت استعادة النسخة. لم يتم اعتماد ملف غير مكتمل.", error)
        } finally { temp.delete() }
        } finally { password.fill('\u0000') }
    }

    private fun isPlaintextSqlite(file: File): Boolean {
        val header = "SQLite format 3\u0000".toByteArray(Charsets.US_ASCII)
        if (file.length() < header.size) return false
        return FileInputStream(file).use { input ->
            val actual = ByteArray(header.size)
            var offset = 0
            while (offset < actual.size) {
                val count = input.read(actual, offset, actual.size - offset)
                if (count < 0) return@use false
                offset += count
            }
            actual.contentEquals(header)
        }
    }

    private fun derive(password: CharArray, salt: ByteArray): SecretKeySpec {
        val spec = PBEKeySpec(password, salt, ITERATIONS, 256)
        return try {
            SecretKeySpec(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded, "AES")
        } finally { spec.clearPassword() }
    }
}
