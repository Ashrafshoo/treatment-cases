package com.example.rentals.backup

import android.content.Context
import android.net.Uri
import com.example.rentals.data.RentalsDb
import java.io.File
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Password-protected AES-256-GCM backup container. The password is never stored. */
object EncryptedBackup {
    private val magic = "RNTLENC1".toByteArray(Charsets.US_ASCII)
    fun create(context: Context, destination: Uri, includeDatabase: Boolean, includeAttachments: Boolean, password: String) {
        require(password.length >= 8) { "كلمة مرور النسخة يجب ألا تقل عن 8 أحرف" }
        require(includeDatabase || includeAttachments) { "اختر قاعدة البيانات أو المرفقات" }
        val plain = File(context.cacheDir,"backup-plain.zip")
        val db = File(context.cacheDir,"backup-db-copy.db")
        try {
            RentalsDb.get(context).closeForBackup()
            try {
                ZipOutputStream(plain.outputStream()).use { zip ->
                    if(includeDatabase) {
                        val live=context.getDatabasePath("rentals_local.db")
                        require(live.exists()) { "قاعدة البيانات غير موجودة" }
                        live.copyTo(db,true); add(zip,db,"database/rentals_local.db")
                    }
                    var attachmentCount=0
                    if(includeAttachments) {
                        val dir=File(context.filesDir,"attachments")
                        if(dir.exists()) dir.walkTopDown().filter{it.isFile}.forEach{f->
                            add(zip,f,"attachments/"+f.relativeTo(dir).path.replace(File.separatorChar,'/'))
                            attachmentCount++
                        }
                    }
                    zip.putNextEntry(ZipEntry("backup-info.txt"));zip.write(("RentalsManager encrypted backup\nCreated: ${System.currentTimeMillis()}\n" +
                        "Database: $includeDatabase\nAttachments: $includeAttachments\nAttachment files: $attachmentCount\n").toByteArray());zip.closeEntry()
                }
            } finally { RentalsDb.reopen(context) }
            val salt=ByteArray(16).also{SecureRandom().nextBytes(it)}
            val nonce=ByteArray(12).also{SecureRandom().nextBytes(it)}
            val cipher=Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE,key(password,salt),GCMParameterSpec(128,nonce))
            context.contentResolver.openOutputStream(destination,"w")!!.use { out ->
                out.write(magic);out.write(salt);out.write(nonce)
                CipherOutputStream(out,cipher).use { encrypted -> plain.inputStream().use { it.copyTo(encrypted) } }
            }
        } finally { plain.delete();db.delete() }
    }
    fun restore(context: Context, source: Uri, restoreDatabase: Boolean, restoreAttachments: Boolean, password: String) {
        require(password.isNotBlank()) { "أدخل كلمة مرور النسخة" }
        require(restoreDatabase || restoreAttachments) { "اختر ما تريد استعادته" }
        val decrypted=File(context.cacheDir,"backup-decrypted.zip")
        try {
            context.contentResolver.openInputStream(source)!!.use { input ->
                val header=ByteArray(magic.size);readFully(input,header)
                require(header.contentEquals(magic)) { "هذا الملف ليس نسخة احتياطية مشفرة من التطبيق" }
                val salt=ByteArray(16);val nonce=ByteArray(12);readFully(input,salt);readFully(input,nonce)
                val cipher=Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.DECRYPT_MODE,key(password,salt),GCMParameterSpec(128,nonce))
                try { CipherInputStream(input,cipher).use { encrypted -> decrypted.outputStream().use { encrypted.copyTo(it) } } }
                catch(e:Exception){throw IllegalArgumentException("كلمة المرور غير صحيحة أو الملف تالف")}
            }
            // Reuse the same hardened ZIP validator and transactional rollback path as plain backups.
            BackupManager.restore(context, Uri.fromFile(decrypted), restoreDatabase, restoreAttachments)
        } finally {decrypted.delete()}
    }
    private fun readFully(input:java.io.InputStream,buffer:ByteArray){var offset=0;while(offset<buffer.size){val n=input.read(buffer,offset,buffer.size-offset);require(n>0){"النسخة مشوهة أو غير مكتملة"};offset+=n}}
    private fun key(password:String,salt:ByteArray):SecretKeySpec {val spec=PBEKeySpec(password.toCharArray(),salt,210_000,256);return SecretKeySpec(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded,"AES")}
    private fun add(zip:ZipOutputStream,file:File,name:String){zip.putNextEntry(ZipEntry(name));file.inputStream().use{it.copyTo(zip)};zip.closeEntry()}
}
