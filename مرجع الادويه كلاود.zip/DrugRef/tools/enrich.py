"""
خط المعالجة الكامل على «القائمة العاملة» (الأصلية لا تُمس):
  0) تعارض الاسمين (اسم عربي يخص صنفًا آخر) ← المرجع هو الاسم الأجنبي الملتصق بالكود
  1) عائلة الدواء + التركيز/العبوة
  2) روابط التكرار المطابق القديمة
  3) التكرار التقريبي ← اختيار الصحيح + دمج بياناته + إبقاء المحذوف مرجعًا
  4) الأسماء العربية الناقصة
  5) الأجهزة التعويضية والمستلزمات
  6) التصنيف العلاجي (عائلة/مادة فعّالة/EDA)
  7) تشابه إملائي للمراجعة + الأكواد الناقصة
"""
import re, difflib, collections
import parse_names as P, devices as D, classify as C, normalize as N
import arabic_names as A

ARc = re.compile("[\u0600-\u06FF]")
LAT = re.compile("[A-Za-z]")
AD = str.maketrans("٠١٢٣٤٥٦٧٨٩", "0123456789")
DRUG_AR = re.compile(r"مجم|ملجم|مج\b|اقراص|قرص|كبسول|فيال|امبول|ملل|شراب|اقماع|كريم|مرهم|قطره|\bجم\b")


def has_ar(s): return bool(ARc.search(s or ""))
def nums(s): return set(re.findall(r"\d+(?:\.\d+)?", (s or "").translate(AD)))


def form_from_en(name):
    t = set(P.tokens(name))
    for k, v in D.FORM_FROM_EN:
        if k in t: return v
    return ""


def run(rows, props, eda_map=None, now=0):
    """rows: list[dict] (يُعدَّل في مكانه). يعيد (links, logs, missing_codes, stats)."""
    by = {r["code"]: r for r in rows}
    logs, links, stats = [], [], collections.Counter()

    def log(code, field, old, new, note, action="edit"):
        logs.append((code, action, field, old or "", new or "", note, now))

    # حقول جديدة
    for r in rows:
        r.update(family="", variant="", flag="", fav=0, tag="", dev_src="", name_src="original",
                 strength="", pack="", generic="",
                 class_src="original" if r["therapeutic_class"] not in ("", "غير محدد") else "")
        if r["is_device"]: r["dev_src"] = "original"

    learned = A.learn([{"name_ar": r["name_ar"], "name_en": r["name_en"]} for r in rows])

    # ---- 0) تعارض الاسمين ----
    fixed, weak = set(), set()
    for r in rows:
        en, ar = r["name_en"], r["name_ar"]
        if not en or not ar or not has_ar(ar): continue
        if has_ar(en) and not LAT.search(en):                      # اسم «أجنبي» عربي صرف
            wa = set(re.findall(r"[\u0600-\u06FF]{3,}", en)); wb = set(re.findall(r"[\u0600-\u06FF]{3,}", ar))
            if wa and wb and not (wa & wb): fixed.add(r["code"])
            continue
        if not LAT.search(en): continue
        dev_en = D.detect(en, "")
        if dev_en and DRUG_AR.search(D._n(ar)) and not D.detect("", ar):
            fixed.add(r["code"]); continue
        toks = [t for t in A.prep(en) if t[0].isalpha() and len(t) > 2]
        def _is_form(t):
            u = P.SYN.get(t.upper(), t.upper())
            return u in P.FORMS or u in P.UNITS
        brand = [t for t in toks if t.upper() not in A.BASE]
        trans = [t for t in toks if t.upper() in A.BASE and not _is_form(t)]
        aw = re.findall(r"[\u0600-\u06FF]+", ar)
        if not (brand or trans) or not aw: continue
        latin_ar = {w.upper() for w in re.findall(r"[A-Za-z]{3,}", ar)}
        if latin_ar & {t.upper() for t in toks}: continue                # الاسم الأجنبي مكتوب في العربي نفسه
        best = 0.0
        cands = set()
        for t in brand[:5]:
            cands.add(A.translit(t.upper()))
            if learned.get(t.upper()): cands.add(learned[t.upper()])
        for t in trans[:5]:
            cands.add(A.BASE[t.upper()])
        for cnd in cands:
            for w in aw[:5]:
                if w == cnd: best = 1.0
                a_, b_ = A.skeleton(cnd), A.skeleton(w)
                if a_ and b_: best = max(best, difflib.SequenceMatcher(None, a_, b_).ratio())
        if best >= 0.3: continue
        ne, na = nums(en), nums(ar)
        if ne and na and not (ne & na): fixed.add(r["code"])
        elif ne or na:
            # نطاق الأكواد المتضرر: أسماء عربية مرتّبة هجائيًا تبدأ بالألف من قائمة أخرى
            if r["code"] < 4000 and re.match(r"[اأإآ]", ar.strip()): fixed.add(r["code"])
            else: weak.add(r["code"])
    for c in fixed:
        r = by[c]; old = r["name_ar"]
        if has_ar(r["name_en"]) and not LAT.search(r["name_en"]):
            new, src = r["name_en"], "auto_dict"
        else:
            new, m = A.convert(r["name_en"], learned); src = "auto_dict" if m == "dict" else "auto_translit"
        r["name_ar"], r["name_src"], r["flag"] = new, src, "fixed"
        log(c, "name_ar", old, new, "تعارض: الاسم العربي السابق لا يطابق الاسم الأجنبي (المرجع) — استُبدل")
        # الشكل والتصنيف كانا مشتقَّين من الاسم الخطأ
        if r["dosage_form"] != form_from_en(r["name_en"]):
            log(c, "dosage_form", r["dosage_form"], form_from_en(r["name_en"]), "أُعيد اشتقاقه من الاسم الأجنبي")
            r["dosage_form"] = form_from_en(r["name_en"])
        if r["class_src"] == "original":
            log(c, "therapeutic_class", r["therapeutic_class"], "غير محدد", "كان مشتقًّا من اسم عربي لا يخص الصنف")
            r["therapeutic_class"], r["class_src"] = "غير محدد", ""
    for c in weak - fixed:
        by[c]["flag"] = "mismatch"
    stats["mismatch_fixed"], stats["mismatch_flagged"] = len(fixed), len(weak - fixed)

    # ---- 1) عائلة/تركيز ----
    for r in rows:
        src = r["name_en"] or r["name_ar"]
        r["family"], r["variant"] = P.split_family(src)
        if not r["family"]: r["family"] = (r["name_en"] or r["name_ar"]).upper()[:40]

    # ---- 2) روابط التكرار المطابق القديمة ----
    for r in rows:
        m = re.search(r"للصنف (\d+)", r["removal_reason"] or "")
        if r["decision"] == "remove" and r["status"] == "duplicate" and m and int(m.group(1)) in by:
            links.append((int(m.group(1)), r["code"], "dup_exact", "تكرار مطابق"))

    # ---- 3) التكرار التقريبي ----
    sig = collections.defaultdict(list)
    for r in rows:
        if r["family"] and r["variant"] is not None:
            nm = r["name_en"] or r["name_ar"]
            if not nm: continue
            sig[(r["family"].replace(" ", ""), P.signature(nm).replace(r["family"], "", 1).replace(" ", ""))].append(r["code"])
    gno = 0

    def score(r):
        return (bool(r["name_en"]), bool(r["concentration"]), bool(r["dosage_form"]),
                r["therapeutic_class"] not in ("", "غير محدد"), has_ar(r["name_ar"]) and not LAT.search(r["name_ar"]))

    for key, codes in sig.items():
        if len(codes) < 2: continue
        mem = [by[c] for c in codes]
        if all(m["status"] == "duplicate" for m in mem): continue          # عولج سابقًا بالكامل
        keepers = [m for m in mem if m["status"] == "duplicate" and m["decision"] == "keep"]
        pool = keepers or [m for m in mem if m["decision"] != "remove"] or mem
        keep = max(pool, key=lambda m: (score(m), -m["code"]))
        gno += 1
        grp = f"تكرار-تقريبي-{gno}"
        for m in mem:
            if m is keep: continue
            if m["decision"] == "remove":
                if not any(l[0] == keep["code"] and l[1] == m["code"] for l in links):
                    links.append((keep["code"], m["code"], "dup_exact" if m["status"] == "duplicate" else "dup_near", "حُذف سابقًا"))
                continue
            old_status = m["status"]
            m["decision"], m["status"] = "remove", "similar"
            m["removal_reason"] = f"تكرار تقريبي للصنف {keep['code']} (الاسم نفسه بكتابة مختلفة) — الكود محفوظ ولا يُمحى."
            if not m["review_group"]: m["review_group"] = grp
            log(m["code"], "decision", "pending", "remove", f"تكرار تقريبي للصنف {keep['code']}", "decision")
            links.append((keep["code"], m["code"], "dup_near", "تكرار تقريبي"))
            stats["near_dup_removed"] += 1
            # دمج بيانات المحذوف في الصحيح
            for fld, lab in (("concentration", "التركيز"), ("dosage_form", "الشكل الدوائي"), ("device_type", "نوع الجهاز")):
                if not keep[fld] and m[fld]:
                    log(keep["code"], fld, "", m[fld], f"دمج من الكود {m['code']}")
                    keep[fld] = m[fld]; stats["merged_fields"] += 1
            if keep["class_src"] == "" and m["class_src"] == "original":
                log(keep["code"], "therapeutic_class", keep["therapeutic_class"], m["therapeutic_class"], f"دمج من الكود {m['code']}")
                keep["therapeutic_class"], keep["class_src"] = m["therapeutic_class"], "original"; stats["merged_fields"] += 1
            if (not has_ar(keep["name_ar"]) or LAT.search(keep["name_ar"])) and has_ar(m["name_ar"]) and not LAT.search(m["name_ar"]) and m["name_src"] == "original":
                log(keep["code"], "name_ar", keep["name_ar"], m["name_ar"], f"دمج من الكود {m['code']}")
                keep["name_ar"] = m["name_ar"]; stats["merged_fields"] += 1
        if not keep["review_group"]: keep["review_group"] = grp
    stats["near_dup_groups"] = gno

    # ---- التركيز: يُعالَج بنظام العائلة ----
    for r in rows:
        if r["status"] == "concentration" and r["decision"] == "pending":
            r["status"], r["decision"] = "ok", "keep"
            log(r["code"], "status", "تركيز مختلف", "سليم", "عُولج بنظام «الدواء ← التركيز»")
            stats["concentration_cleared"] += 1

    # ---- 4) الأسماء العربية الناقصة ----
    for r in rows:
        if has_ar(r["name_ar"]): continue
        p = props.get(r["code"])
        if not p: continue
        r["name_ar"] = p["proposed"]
        r["name_src"] = "auto_dict" if p["method"] == "dict" else "auto_translit"
        log(r["code"], "name_ar", p["source_text"] if not p["from_empty"] == "1" else "", p["proposed"],
            "اقتراح آلي — " + ("من قاموس الشيت" if r["name_src"] == "auto_dict" else "نقل صوتي تقريبي"))
        stats["auto_names"] += 1
    for r in rows:
        if r["status"] == "missing_name" and r["name_en"] and has_ar(r["name_ar"]):
            r["status"] = "ok"
            log(r["code"], "status", "اسم أجنبي ناقص", "سليم", "استُكمل الاسم العربي")
            stats["status_cleared"] += 1

    # ---- 5) الأجهزة ----
    for r in rows:
        if r["decision"] == "remove" and not r["is_device"]: continue
        t = D.detect(r["name_en"], r["name_ar"] if (r["name_src"] == "original" and not r["name_en"]) else "")
        was = r["is_device"]
        if t and not was:
            r["is_device"], r["device_type"], r["dev_src"] = 1, t, "auto"
            if r["status"] in ("ok", "missing_name", "similar"): r["status"] = "device"
            log(r["code"], "is_device", "دواء", "جهاز تعويضي", f"بحث شامل: {t}", "decision")
            stats["devices_added"] += 1
        elif was and not r["device_type"] and t:
            r["device_type"] = t
        if r["is_device"]:
            cls = D.device_class(r["device_type"])
            if r["therapeutic_class"] != cls:
                log(r["code"], "therapeutic_class", r["therapeutic_class"], cls, "تصنيف الجهاز")
                r["therapeutic_class"] = cls
                r["class_src"] = "original" if was else "auto_device"
            if r["dosage_form"]:
                log(r["code"], "dosage_form", r["dosage_form"], "", "الشكل الدوائي لا ينطبق على الأجهزة")
                r["dosage_form"] = ""
    for r in rows:   # تصنيف «جهاز» بلا دليل ⇒ يُلغى
        if r["therapeutic_class"] in ("أجهزة تعويضية", "أجهزة ومستلزمات طبية") and not r["is_device"]:
            log(r["code"], "therapeutic_class", r["therapeutic_class"], "غير محدد", "لا دليل على أنه جهاز")
            r["therapeutic_class"], r["class_src"] = "غير محدد", ""
            stats["device_class_reverted"] += 1

    # ---- 6) التصنيف العلاجي ----
    fam_of = {r["code"]: r["family"] for r in rows if not r["is_device"]}
    fam_cls = C.propagate([r for r in rows if not r["is_device"]], fam_of)
    for r in rows:
        if r["is_device"] or r["therapeutic_class"] not in ("", "غير محدد"): continue
        g = C.by_generic(r["name_en"])
        if g:
            r["therapeutic_class"], r["class_src"] = g[0], "auto_generic"
            log(r["code"], "therapeutic_class", "غير محدد", g[0], f"المادة الفعّالة (الجذر {g[1]})"); stats["class_generic"] += 1
            continue
        if r["family"] in fam_cls:
            r["therapeutic_class"], r["class_src"] = fam_cls[r["family"]], "auto_family"
            log(r["code"], "therapeutic_class", "غير محدد", fam_cls[r["family"]], f"أشقاء العائلة «{r['family']}»"); stats["class_family"] += 1
            continue
        if eda_map and r["family"] in eda_map:
            sci = eda_map[r["family"]]
            g = C.by_generic(sci)
            if g:
                r["therapeutic_class"], r["class_src"] = g[0], "auto_eda"
                log(r["code"], "therapeutic_class", "غير محدد", g[0], f"قاعدة الأدوية المصرية: {sci}"); stats["class_eda"] += 1

    # ---- 7) تشابه إملائي (للمراجعة) ----
    byv = collections.defaultdict(list)
    for r in rows:
        if r["variant"] and r["decision"] != "remove" and not r["is_device"]:
            byv[r["variant"]].append(r)
    seen = set()
    for v, grp in byv.items():
        if len(grp) < 2 or len(grp) > 60: continue
        for i in range(len(grp)):
            for j in range(i + 1, len(grp)):
                a, b = grp[i], grp[j]
                fa, fb = a["family"], b["family"]
                if fa != fb and len(fa) >= 5 and abs(len(fa) - len(fb)) <= 1 and difflib.SequenceMatcher(None, fa, fb).ratio() >= 0.88:
                    lo, hi = sorted((a["code"], b["code"]))
                    if (lo, hi) in seen: continue
                    seen.add((lo, hi)); links.append((lo, hi, "similar", f"«{fa}» ≈ «{fb}»"))
                    for x in (a, b):
                        if x["status"] == "ok":
                            x["status"] = "similar"; stats["similar_flagged"] += 1
    # ---- 8) تفكيك التركيز + المادة الفعّالة + اشتقاق الشكل الناقص ----
    for r in rows:
        r["strength"], r["pack"] = N.strength_pack(r["variant"])
        stem = C.by_generic(r["name_en"])
        NOT_GEN = {"SHAMPOO", "INFUSION", "VITAMIN", "MULTIVIT", "MULTIVITAMIN", "ELECTROLYTE", "SUNSCREEN", "SUNBLOCK",
                   "COSMETIC", "DEODORANT", "MOISTURI", "MOISTUR", "CONTRAST", "VACCINE", "VACCIN", "PROBIOTIC", "RINGER",
                   "HARTMANN", "BICARBONATE", "ORS", "HONEY", "COLLAGEN", "PLASMA LYTE", "ISOLYTE", "ROYAL JELLY", "PROPOLIS", "GINSENG", "SPIRULINA", "SODIUM CHLORIDE", "POTASSIUM CHLORIDE"}
        sw = C.matched_word(r["name_en"], stem[1]) if stem and stem[1].upper() not in NOT_GEN else ""
        if eda_map and r["family"] in eda_map:
            r["generic"] = eda_map[r["family"]]
        else:
            r["generic"] = N.generic_from_name(r["name_en"], sw)
        if r["generic"]: stats["generic_filled"] += 1
        if r["strength"]: stats["strength_parsed"] += 1
        if not r["dosage_form"] and not r["is_device"] and r["decision"] != "remove":
            f = form_from_en(r["name_en"])
            if f:
                log(r["code"], "dosage_form", "", f, "اشتُقّ الشكل من الاسم الأجنبي")
                r["dosage_form"] = f; stats["form_derived"] += 1
    codes = set(by)
    missing = sorted(set(range(1, max(codes) + 1)) - codes)
    stats["missing_codes"] = len(missing)
    return links, logs, missing, stats
