from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT / "android-app/src/main/java/com/familyproperties/app/PropertyRepository.kt"
MAIN = ROOT / "android-app/src/main/java/com/familyproperties/app/MainActivity.kt"
EXCEL = ROOT / "android-app/src/main/java/com/familyproperties/app/ExcelInterchange.kt"


def test_export_is_admin_gated_and_covers_all_supported_template_sheets():
    source = REPO.read_text(encoding="utf-8")
    method = source.split("fun exportExcelData()", 1)[1].split("fun dashboardStats", 1)[0]
    assert "requireAdministrator()" in method
    for sheet in ("العقارات", "الوحدات", "الملاك", "حصص_الملكية", "المستأجرون", "العقود", "التحصيلات", "المصروفات"):
        assert f'"{sheet}" to rows(' in method


def test_export_preserves_relationship_ids_and_financial_precision():
    source = REPO.read_text(encoding="utf-8")
    method = source.split("fun exportExcelData()", 1)[1].split("fun dashboardStats", 1)[0]
    for field in ("property_id", "owner_id", "unit_id", "tenant_id", "lease_id", "payment_id", "expense_id"):
        assert f'"{field}"' in method
    assert "printf('%.2f',pay.amount_minor/100.0)" in method
    assert "ORDER BY pay.paid_at,pay.created_at" in method


def test_workbook_writer_uses_the_same_schema_and_writes_header_and_rows():
    source = EXCEL.read_text(encoding="utf-8")
    writer = source.split("fun writeWorkbook", 1)[1].split("fun previewLegacy", 1)[0]
    assert "schemas.forEach" in writer
    assert "createCell(index).setCellValue(name)" in writer
    assert "records[sheetName].orEmpty()" in writer
    assert "headers.forEachIndexed" in writer


def test_legacy_preview_is_read_only_and_preserves_sheet_names_row_numbers_and_cell_addresses():
    source = EXCEL.read_text(encoding="utf-8")
    legacy = source.split("fun previewLegacy", 1)[1].split("private fun cellAddress", 1)[0]
    assert "sheet.sheetName" in legacy
    assert "r + 1" in legacy
    assert "cellAddress(c, r)" in legacy
    assert "DataFormatter()" in legacy
    assert "fun previewLegacy(input: InputStream)" in source
    assert "applyExcelImport" not in legacy


def test_ui_exposes_export_and_legacy_audit_without_automatic_import():
    source = MAIN.read_text(encoding="utf-8")
    screen = source.split("private fun ExcelInterchangeScreen", 1)[1].split("private fun SectionPlaceholder", 1)[0]
    assert "repository.exportExcelData()" in screen
    assert "ExcelInterchange.writeWorkbook(it, data)" in screen
    assert "ExcelInterchange.previewLegacy(it)" in screen
    assert "تصدير بيانات أملاكنا إلى Excel" in screen
    assert "تحليل ملف Excel العائلي القديم" in screen
    assert "لم يتم تعديل أي بيانات" in screen


def test_version_bumped_for_stage36():
    gradle = (ROOT / "android-app/build.gradle.kts").read_text(encoding="utf-8")
    assert "versionCode = 40" in gradle
    assert 'versionName = "0.40.0"' in gradle


def test_all_export_queries_execute_against_the_project_schema():
    import re
    import sqlite3

    schema = (ROOT / "android-app/src/main/assets/database/001_initial_schema.sql").read_text(encoding="utf-8")
    connection = sqlite3.connect(":memory:")
    connection.executescript(schema)
    source = REPO.read_text(encoding="utf-8")
    method = source.split("fun exportExcelData()", 1)[1].split("fun dashboardStats", 1)[0]
    queries = re.findall(r'"(SELECT [^"]+)"', method)
    assert len(queries) == 8
    for query in queries:
        connection.execute(query).fetchall()
    connection.close()
