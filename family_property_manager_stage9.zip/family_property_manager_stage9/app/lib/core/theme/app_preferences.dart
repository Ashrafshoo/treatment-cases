import 'package:flutter/material.dart';
import 'package:sqflite_sqlcipher/sqflite.dart';
import '../database/app_database.dart';

class AppPreferences extends ChangeNotifier {
  AppPreferences._();
  static final AppPreferences instance=AppPreferences._();
  ThemeMode themeMode=ThemeMode.system;
  double fontScale=1.0;
  Color accentColor=const Color(0xFFD6A84F);
  bool compactDashboard=false;
  bool _loaded=false;
  bool get loaded=>_loaded;

  Future<void> load() async {
    if(_loaded)return;
    try {
      final db=await AppDatabase.instance.database;
      final rows=await db.query('app_settings',where:'scope=?',whereArgs:['device']);
      final values={for(final r in rows) r['setting_key'] as String:r['setting_value'] as String};
      themeMode=switch(values['theme_mode']){'light'=>ThemeMode.light,'dark'=>ThemeMode.dark,_=>ThemeMode.system};
      fontScale=(double.tryParse(values['font_scale']??'1.0')??1.0).clamp(0.85,1.35).toDouble();
      accentColor=_parseColor(values['accent_color'])??const Color(0xFFD6A84F);
      compactDashboard=values['compact_dashboard']=='true';
    } catch (_) {
      // Preferences fall back to safe defaults if a fresh database is unavailable.
    }
    _loaded=true;notifyListeners();
  }

  Future<void> update({ThemeMode? mode,double? scale,Color? accent,bool? compact}) async {
    if(mode!=null)themeMode=mode;
    if(scale!=null)fontScale=scale.clamp(0.85,1.35).toDouble();
    if(accent!=null)accentColor=accent;
    if(compact!=null)compactDashboard=compact;
    final values={'theme_mode':themeMode.name,'font_scale':fontScale.toStringAsFixed(2),'accent_color':'#${accentColor.value.toRadixString(16).padLeft(8,'0')}','compact_dashboard':compactDashboard.toString()};
    try {
      final db=await AppDatabase.instance.database;
      await db.transaction((tx)async{for(final entry in values.entries){await tx.insert('app_settings',{'setting_key':entry.key,'setting_value':entry.value,'scope':'device','updated_at':DateTime.now().toIso8601String()},conflictAlgorithm:ConflictAlgorithm.replace);}});
    } finally {notifyListeners();}
  }

  static Color? _parseColor(String? value){if(value==null||!value.startsWith('#'))return null;final n=int.tryParse(value.substring(1),radix:16);return n==null?null:Color(n);}
}
