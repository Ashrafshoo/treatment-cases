package com.example.rentals.printing

import android.content.ContentResolver
import android.content.Context
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.net.Uri
import com.example.rentals.data.AggregateReceiptItem

/** Saves selected aggregate receipts as standalone PDF without creating a paid receipt or ledger entry. */
internal object AggregateReceiptPdfExporter {
    fun export(context: Context, resolver: ContentResolver, uri: Uri, items: List<AggregateReceiptItem>, issuedDate: String, perPage: Int = 3, marginMm: Float = 5f) {
        require(items.isNotEmpty()) { "لا توجد أسماء محددة لتصدير الإيصالات" }
        val renderer = OriginalReceiptTemplateRenderer(context)
        val normalizedIssuedDate = ReceiptDateFormat.toSheet(ReceiptDateFormat.toStorage(issuedDate))
        val count = perPage.coerceIn(1, 3)
        val document = PdfDocument()
        try {
            val pages = (items.size + count - 1) / count
            for (pageNo in 0 until pages) {
                val page = document.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNo + 1).create())
                val margin = marginMm * 2.8346f
                val gap = 5f
                val slotHeight = (842f - margin * 2f - gap * (count - 1)) / count
                for (slot in 0 until count) {
                    val index = pageNo * count + slot
                    if (index >= items.size) break
                    val rect = RectF(margin, margin + slot * (slotHeight + gap), 595f - margin,
                        margin + slot * (slotHeight + gap) + slotHeight)
                    renderer.draw(page.canvas, rect, items[index], normalizedIssuedDate)
                }
                document.finishPage(page)
            }
            val output = resolver.openOutputStream(uri, "w") ?: error("تعذر فتح ملف PDF للحفظ")
            output.use { stream -> document.writeTo(stream); stream.flush() }
        } finally { document.close() }
        // SAF providers may return a URI even when the write failed or produced an empty file.
        // Re-open the saved document and verify its PDF signature and a plausible payload size.
        val input = resolver.openInputStream(uri) ?: error("تعذر التحقق من ملف PDF بعد الحفظ")
        input.use { stream ->
            val header = ByteArray(5)
            var headerRead = 0
            while (headerRead < header.size) {
                val read = stream.read(header, headerRead, header.size - headerRead)
                if (read < 0) break
                headerRead += read
            }
            require(headerRead == 5 && String(header, Charsets.US_ASCII) == "%PDF-") { "الملف الناتج ليس مستند PDF صالحًا" }
            var total = headerRead.toLong()
            val buffer = ByteArray(8192)
            while (true) {
                val read = stream.read(buffer)
                if (read < 0) break
                total += read
            }
            require(total >= 512L) { "ملف PDF الناتج فارغ أو غير مكتمل" }
        }
    }
}
