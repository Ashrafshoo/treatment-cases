package com.example.rentals.domain.finance

data class FinanceSummary(
    val due: Double = 0.0,
    val received: Double = 0.0,
    val collectorHeld: Double = 0.0,
    val expenses: Double = 0.0,
    val undistributed: Double = 0.0,
    val unassignedLegacy: Double = 0.0,
    val unassignedLegacyExpenses: Double = 0.0
)

data class HeirShare(val id: Long, val name: String, val share: Double)
data class HeirPayout(val heirId: Long, val amount: Double, val method: String)
