package com.treatmentcases.app

import org.json.JSONArray
import org.json.JSONObject
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

data class BackupBundle(
    val cases: List<CaseRecord>,
    val employees: List<EmployeeRecord>,
    val medicines: List<String>,
    val medicineDetails: List<MedicineCatalogRecord> = emptyList(),
    val strengths: List<MedicineStrengthRecord> = emptyList()
)

/** Password-protected portable backups. V1 case-only backups remain readable. */
object EncryptedBackup {
    private val magicV1 = "TCBACKUP1".toByteArray(Charsets.US_ASCII)
    private val magicV2 = "TCBACKUP2".toByteArray(Charsets.US_ASCII)
    private val magicV3 = "TCBACKUP3".toByteArray(Charsets.US_ASCII)

    fun encode(rows: List<CaseRecord>, password: String): ByteArray {
        val json = JSONArray()
        rows.forEach { r ->
            val o = JSONObject()
            CaseRecord.headers.zip(r.cells()).forEach { (k, v) -> o.put(k, v) }
            json.put(o)
        }
        return encrypt(json.toString().toByteArray(Charsets.UTF_8), password, magicV1)
    }

    fun encodeFull(
        rows: List<CaseRecord>,
        employees: List<EmployeeRecord>,
        medicineDetails: List<MedicineCatalogRecord>,
        strengths: List<MedicineStrengthRecord>,
        password: String
    ): ByteArray {
        val casesJson = JSONArray()
        rows.forEach { r ->
            val o = JSONObject()
            CaseRecord.headers.zip(r.cells()).forEach { (k, v) -> o.put(k, v) }
            casesJson.put(o)
        }
        val employeesJson = JSONArray()
        employees.forEach { e ->
            val o = JSONObject()
            EmployeeRecord.headers.zip(e.cells()).forEach { (k, v) -> o.put(k, v) }
            employeesJson.put(o)
        }
        val catalogJson = JSONArray()
        medicineDetails.forEach { m ->
            catalogJson.put(JSONObject().put("name", m.name).put("generic_name", m.genericName)
                .put("specialty", m.specialty).put("strengths", m.strengths)
                .put("dosage_form", m.dosageForm).put("review_status", m.reviewStatus)
                .put("indications",m.indications).put("critical_classification",m.criticalClassification)
                .put("target_conditions",m.targetConditions).put("medical_notes",m.medicalNotes)
                .put("source_reference",m.sourceReference).put("last_reviewed",m.lastReviewed).put("aliases",m.aliases))
        }
        val strengthsJson = JSONArray()
        strengths.forEach { st -> strengthsJson.put(JSONObject().put("medicine", st.medicine).put("strength", st.strength)) }
        val root = JSONObject().put("format_version", 3)
            .put("created_at_epoch_ms", System.currentTimeMillis())
            .put("app_version", "2.4.8-local-first")
            .put("counts", JSONObject().put("cases", rows.size).put("employees", employees.size)
                .put("medicines", medicineDetails.size).put("strengths", strengths.size))
            .put("cases", casesJson).put("employees", employeesJson)
            .put("medicine_catalog", catalogJson).put("strength_records", strengthsJson)
        return encrypt(root.toString().toByteArray(Charsets.UTF_8), password, magicV3)
    }

    fun decode(bytes: ByteArray, password: String): List<CaseRecord> = decodeFull(bytes, password).cases

    fun decodeFull(bytes: ByteArray, password: String): BackupBundle {
        if (hasMagic(bytes, magicV3)) {
            val root = JSONObject(String(decrypt(bytes, password, magicV3), Charsets.UTF_8))
            require(root.optInt("format_version") == 3) { "إصدار النسخة الاحتياطية غير مدعوم" }
            val cases = root.optJSONArray("cases") ?: JSONArray()
            val employees = root.optJSONArray("employees") ?: JSONArray()
            val catalog = root.optJSONArray("medicine_catalog") ?: JSONArray()
            val strengths = root.optJSONArray("strength_records") ?: JSONArray()
            val details = (0 until catalog.length()).map { i ->
                val o = catalog.getJSONObject(i)
                MedicineCatalogRecord(o.optString("name"), o.optString("generic_name"), o.optString("specialty"),
                    o.optString("strengths"), o.optString("dosage_form"), o.optString("review_status", "يحتاج مراجعة"),
                    o.optString("indications"),o.optString("critical_classification"),o.optString("target_conditions"),
                    o.optString("medical_notes"),o.optString("source_reference"),o.optString("last_reviewed"),o.optString("aliases"))
            }
            val strengthRows = (0 until strengths.length()).map { i ->
                val o = strengths.getJSONObject(i); MedicineStrengthRecord(o.optString("medicine"), o.optString("strength"))
            }
            return BackupBundle(parseCases(cases), parseEmployees(employees), details.map { it.name }, details, strengthRows)
        }
        if (hasMagic(bytes, magicV2)) {
            val root = JSONObject(String(decrypt(bytes, password, magicV2), Charsets.UTF_8))
            require(root.optInt("format_version") == 2) { "إصدار النسخة الاحتياطية غير مدعوم" }
            val cases = root.optJSONArray("cases") ?: JSONArray()
            val employees = root.optJSONArray("employees") ?: JSONArray()
            val medicines = root.optJSONArray("medicines") ?: JSONArray()
            return BackupBundle(parseCases(cases), parseEmployees(employees), (0 until medicines.length()).map { medicines.optString(it) })
        }
        // Backward compatibility with the original case-only encrypted backup.
        return BackupBundle(decodeV1(bytes, password), emptyList(), emptyList())
    }

    private fun hasMagic(bytes: ByteArray, magic: ByteArray) =
        bytes.size >= magic.size && bytes.copyOfRange(0, magic.size).contentEquals(magic)

    private fun parseCases(array: JSONArray) = (0 until array.length()).map { i ->
        val o = array.getJSONObject(i); CaseRecord.from(CaseRecord.headers.map { o.optString(it, "") })
    }

    private fun parseEmployees(array: JSONArray) = (0 until array.length()).map { i ->
        val o = array.getJSONObject(i); val c = EmployeeRecord.headers.map { o.optString(it, "") }
        EmployeeRecord(performanceNo=c[0], name=c[1], job=c[2], entity=c[3], department=c[4], nationalId=c[5],
            phone1=c[6], phone2=c[7], gender=c[8], notes=c[9])
    }

    private fun decodeV1(bytes: ByteArray, password: String): List<CaseRecord> {
        val json = String(decrypt(bytes, password, magicV1), Charsets.UTF_8)
        val array = JSONArray(json)
        return (0 until array.length()).map { i -> val o=array.getJSONObject(i); CaseRecord.from(CaseRecord.headers.map { o.optString(it, "") }) }
    }

    private fun encrypt(plain: ByteArray, password: String, magic: ByteArray): ByteArray {
        require(password.length >= 8) { "كلمة المرور يجب ألا تقل عن 8 أحرف أو أرقام" }
        val salt=ByteArray(16).also{SecureRandom().nextBytes(it)}
        val iv=ByteArray(12).also{SecureRandom().nextBytes(it)}
        val cipher=Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE,derive(password,salt),GCMParameterSpec(128,iv))
        return magic+salt+iv+cipher.doFinal(plain)
    }

    private fun decrypt(bytes: ByteArray, password: String, magic: ByteArray): ByteArray {
        require(password.length >= 8) { "كلمة المرور يجب ألا تقل عن 8 أحرف أو أرقام" }
        require(bytes.size > magic.size + 28 && bytes.copyOfRange(0, magic.size).contentEquals(magic)) { "ملف النسخة الاحتياطية غير معروف" }
        val salt=bytes.copyOfRange(magic.size,magic.size+16)
        val iv=bytes.copyOfRange(magic.size+16,magic.size+28)
        val encrypted=bytes.copyOfRange(magic.size+28,bytes.size)
        val cipher=Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE,derive(password,salt),GCMParameterSpec(128,iv))
        return cipher.doFinal(encrypted)
    }

    private fun derive(password: String, salt: ByteArray): SecretKeySpec {
        val spec=PBEKeySpec(password.toCharArray(),salt,180_000,256)
        val bytes=try{SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded}finally{spec.clearPassword()}
        return SecretKeySpec(bytes,"AES")
    }
}
