"""SQLite regression checks for the unified financial PDF report query."""
import re
import sqlite3
from pathlib import Path

source = Path(__file__).parents[1] / "app/src/main/java/com/example/rentals/printing/DatabasePdfExporter.kt"
text = source.read_text(encoding="utf-8")
match = re.search(r'"financial" -> Triple\("كشف الحركة المالية الموحد", """(.*?)""",', text, re.S)
assert match, "Unified financial report query is missing"
query = match.group(1)

db = sqlite3.connect(":memory:")
for ddl in (
    "CREATE TABLE ledger(entry_date TEXT,period TEXT,unit_code TEXT,tenant TEXT,entry_type TEXT,debit REAL,credit REAL,collector_method TEXT,notes TEXT)",
    "CREATE TABLE collector_receivables(collected_date TEXT,period TEXT,collector TEXT,amount REAL,handed_over REAL,balance REAL,notes TEXT)",
    "CREATE TABLE collection_batches(received_date TEXT,period TEXT,collector TEXT,expenses REAL,amount REAL,method TEXT,remaining REAL,notes TEXT)",
    "CREATE TABLE expenses(expense_date TEXT,period TEXT,title TEXT,category TEXT,amount REAL,notes TEXT)",
    "CREATE TABLE heir_payouts(pay_date TEXT,period TEXT,heir_id INTEGER,amount REAL,method TEXT,notes TEXT)",
    "CREATE TABLE heirs(id INTEGER,name TEXT)",
):
    db.execute(ddl)

db.execute("INSERT INTO ledger VALUES('2026-11-01','2026-11','U1','مستأجر','تحصيل',0,100,'نقدًا','')")
db.execute("INSERT INTO collector_receivables VALUES('2026-11-02','2026-11','محصل',100,40,60,'')")
db.execute("INSERT INTO collection_batches VALUES('2026-11-03','2026-11','محصل',5,40,'تحويل',35,'')")
db.execute("INSERT INTO expenses VALUES('2026-11-03','2026-11','مصروف مباشر','عام',2,'')")
db.execute("INSERT INTO heirs VALUES(1,'وارث')")
db.execute("INSERT INTO heir_payouts VALUES('2026-11-04','2026-11',1,10,'نقدًا','')")
db.execute("INSERT INTO expenses VALUES('2025-12-01',NULL,'مصروف تاريخي','عام',3,'')")

all_rows = db.execute(query).fetchall()
assert len(all_rows) == 6, f"Expected 6 movements including one undated-period legacy row, got {len(all_rows)}"
for prefix, expected in (("2026", 5), ("2026-11", 5), ("2025-12", 0)):
    filtered = db.execute(f'SELECT * FROM ({query}) WHERE substr(COALESCE("الفترة",\'\'),1,length(?))=?', (prefix, prefix)).fetchall()
    assert len(filtered) == expected, (prefix, len(filtered), expected)
legacy = db.execute(f'SELECT * FROM ({query}) WHERE "الفترة" IS NULL OR "الفترة"=\'\'').fetchall()
assert len(legacy) == 1 and legacy[0][2] == "مصروف مباشر", "Historical NULL-period expense must remain explicitly unassigned"
assert "المتبقي لدى المحصل" in query, "Collector held balance should be disclosed"
assert "المتبقي غير الموزع" in query, "Undistributed batch balance should be disclosed"
print("PASS: unified financial query, source separation, period prefix filters, and NULL-period preservation")
