#!/usr/bin/env python3
"""Consistent SQLite backup/restore for the medication and authentication DBs."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import shutil
import sqlite3
import sys
import tempfile
from datetime import datetime, timezone, timedelta
from pathlib import Path

BASE = Path(__file__).resolve().parent

def env_path(name: str, default: Path) -> Path:
    return Path(os.environ.get(name, str(default))).expanduser().resolve()

MED_DB = env_path('MED_DB', BASE / 'private_data' / 'medication_management.db')
AUTH_DB = env_path('MED_AUTH_DB', BASE / 'private_data' / 'auth.sqlite3')
BACKUP_DIR = env_path('MED_BACKUP_DIR', BASE / 'backups')
RETENTION_DAYS = max(1, int(os.environ.get('MED_BACKUP_RETENTION_DAYS', '30')))


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def integrity(path: Path) -> None:
    if not path.is_file() or path.stat().st_size == 0:
        raise ValueError(f'قاعدة البيانات غير موجودة أو فارغة: {path}')
    with sqlite3.connect(f'file:{path}?mode=ro', uri=True) as c:
        rows = c.execute('PRAGMA integrity_check').fetchall()
    if rows != [('ok',)]:
        raise ValueError(f'فشل فحص سلامة قاعدة البيانات: {path}: {rows[:5]}')


def sqlite_backup(source: Path, destination: Path) -> None:
    integrity(source)
    destination.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=destination.name + '.', suffix='.tmp', dir=destination.parent)
    os.close(fd)
    tmp = Path(tmp_name)
    try:
        with sqlite3.connect(f'file:{source}?mode=ro', uri=True) as src, sqlite3.connect(tmp) as dst:
            src.backup(dst)
        integrity(tmp)
        os.replace(tmp, destination)
    finally:
        tmp.unlink(missing_ok=True)


def prune(now: datetime | None = None) -> list[str]:
    now = now or datetime.now(timezone.utc)
    cutoff = now - timedelta(days=RETENTION_DAYS)
    removed = []
    for manifest in BACKUP_DIR.glob('backup_*.json'):
        try:
            data = json.loads(manifest.read_text(encoding='utf-8'))
            created = datetime.fromisoformat(data['created_at'])
            if created.tzinfo is None:
                created = created.replace(tzinfo=timezone.utc)
            if created < cutoff:
                for item in data.get('files', {}).values():
                    (BACKUP_DIR / item['name']).unlink(missing_ok=True)
                manifest.unlink(missing_ok=True)
                removed.append(manifest.name)
        except (OSError, ValueError, KeyError, TypeError, json.JSONDecodeError):
            # Never delete an unreadable manifest or its files automatically.
            continue
    return removed


def create_backup() -> dict:
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    files = {}
    sources = {'medication': MED_DB, 'authentication': AUTH_DB}
    try:
        for key, source in sources.items():
            target = BACKUP_DIR / f'backup_{stamp}_{key}.sqlite3'
            sqlite_backup(source, target)
            files[key] = {'name': target.name, 'sha256': sha256(target), 'size_bytes': target.stat().st_size}
        manifest = {
            'format_version': 1,
            'created_at': datetime.now(timezone.utc).isoformat(),
            'files': files,
        }
        target_manifest = BACKUP_DIR / f'backup_{stamp}.json'
        tmp = target_manifest.with_suffix('.json.tmp')
        tmp.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
        os.replace(tmp, target_manifest)
        removed = prune()
        return {'timestamp': stamp, 'manifest': str(target_manifest), 'files': files, 'pruned': removed}
    except Exception:
        for item in files.values():
            (BACKUP_DIR / item['name']).unlink(missing_ok=True)
        raise


def verify_manifest(stamp: str) -> tuple[dict, dict[str, Path]]:
    if not stamp or any(ch not in '0123456789TtZz-' for ch in stamp):
        raise ValueError('صيغة الطابع الزمني غير صحيحة')
    manifest_path = BACKUP_DIR / f'backup_{stamp}.json'
    data = json.loads(manifest_path.read_text(encoding='utf-8'))
    if data.get('format_version') != 1 or set(data.get('files', {})) != {'medication', 'authentication'}:
        raise ValueError('ملف وصف النسخة الاحتياطية غير مكتمل أو غير مدعوم')
    verified = {}
    for key, target in [('medication', MED_DB), ('authentication', AUTH_DB)]:
        info = data['files'][key]
        src = (BACKUP_DIR / info['name']).resolve()
        if src.parent != BACKUP_DIR.resolve() or not src.is_file():
            raise ValueError(f'ملف النسخة الاحتياطية مفقود أو مساره غير آمن: {key}')
        if sha256(src) != info['sha256']:
            raise ValueError(f'فشل التحقق من بصمة النسخة الاحتياطية: {key}')
        integrity(src)
        verified[key] = src
    return data, verified


def restore(stamp: str) -> dict:
    _, verified = verify_manifest(stamp)
    # A fresh safety copy of the current databases is mandatory before replacement.
    safety = create_backup()
    replacements = [('medication', verified['medication'], MED_DB),
                     ('authentication', verified['authentication'], AUTH_DB)]
    staged = []
    try:
        for key, source, target in replacements:
            target.parent.mkdir(parents=True, exist_ok=True)
            fd, tmp_name = tempfile.mkstemp(prefix=target.name + '.restore.', dir=target.parent)
            os.close(fd)
            tmp = Path(tmp_name)
            shutil.copy2(source, tmp)
            integrity(tmp)
            staged.append((tmp, target))
        for tmp, target in staged:
            # Restore must be run while the application is stopped.
            os.replace(tmp, target)
            Path(str(target) + '-wal').unlink(missing_ok=True)
            Path(str(target) + '-shm').unlink(missing_ok=True)
        return {'restored': stamp, 'safety_backup': safety['timestamp']}
    finally:
        for tmp, _ in staged:
            tmp.unlink(missing_ok=True)


def list_backups() -> list[dict]:
    result = []
    for path in sorted(BACKUP_DIR.glob('backup_*.json'), reverse=True):
        try:
            data = json.loads(path.read_text(encoding='utf-8'))
            result.append({'timestamp': path.stem.removeprefix('backup_'),
                           'created_at': data.get('created_at'),
                           'files': list(data.get('files', {}).keys())})
        except (OSError, ValueError, json.JSONDecodeError):
            result.append({'timestamp': path.stem, 'error': 'manifest unreadable'})
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description='نسخ احتياطي واستعادة قواعد بيانات علاج الحالات حاجة')
    sub = parser.add_subparsers(dest='command', required=True)
    sub.add_parser('backup', help='إنشاء نسخة متسقة من قاعدة العلاج والمستخدمين')
    restore_parser = sub.add_parser('restore', help='استعادة نسخة بعد إيقاف التطبيق')
    restore_parser.add_argument('--timestamp', required=True, help='الطابع الزمني من أمر list')
    sub.add_parser('list', help='عرض النسخ المتاحة')
    args = parser.parse_args()
    try:
        if args.command == 'backup':
            result = create_backup()
        elif args.command == 'restore':
            result = restore(args.timestamp)
        else:
            result = list_backups()
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except Exception as exc:
        print(f'خطأ: {exc}', file=sys.stderr)
        return 1

if __name__ == '__main__':
    raise SystemExit(main())
