package com.example.rentals.features.units

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import androidx.core.content.FileProvider
import com.example.rentals.data.RentalsDb
import com.example.rentals.data.UnitRecord
import com.example.rentals.data.repository.SqliteDocumentRepository
import com.example.rentals.domain.contracts.AddOwnerDocument
import com.example.rentals.domain.contracts.GetOwnerDocuments
import com.example.rentals.ui.components.AppField
import com.example.rentals.ui.components.PremiumScreenHeader
import com.example.rentals.files.AttachmentFileManager
import java.io.File
import java.util.Locale
import java.text.NumberFormat

private fun unitScreenMoney(value: Double): String = NumberFormat.getNumberInstance(Locale("ar", "EG")).format(value) + " ج.م"

@Composable fun UnitsScreen(activity:FragmentActivity,db:RentalsDb,units:List<UnitRecord>,compact:Boolean,onRefresh:()->Unit){
 var search by remember{mutableStateOf("")};var edit by remember{mutableStateOf<UnitRecord?>(null)};var add by remember{mutableStateOf(false)};var docsUnit by remember{mutableStateOf<UnitRecord?>(null)}
 val filtered=units.filter{search.isBlank()||it.tenant.contains(search,true)||it.property.contains(search,true)||it.code.contains(search,true)}
 Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement=Arrangement.spacedBy(10.dp)){
  PremiumScreenHeader("الوحدات والعقارات", "إدارة الوحدات والمستأجرين والعقود والمستندات المرتبطة", Icons.Default.Apartment)
  Row(verticalAlignment=Alignment.CenterVertically){Text("سجل الوحدات",fontSize=18.sp,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f));FilledTonalButton(onClick={add=true}){Icon(Icons.Default.Add,null);Text("إضافة وحدة")}}
  OutlinedTextField(search,{search=it},modifier=Modifier.fillMaxWidth(),label={Text("بحث بالاسم أو العقار أو الكود")},leadingIcon={Icon(Icons.Default.Search,null)},singleLine=true)
  Spacer(Modifier.height(8.dp))
  LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){
   items(filtered,key={if(it.id>0)it.id else it.code.hashCode().toLong()}){u->
    Card(modifier=Modifier.fillMaxWidth(), shape=androidx.compose.foundation.shape.RoundedCornerShape(20.dp), border=androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha=.35f)), elevation=CardDefaults.cardElevation(defaultElevation=1.dp)){
     Column(Modifier.padding(if(compact)10.dp else 14.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){
      Row(verticalAlignment=Alignment.CenterVertically){Text(u.tenant.ifBlank{"مستأجر غير محدد"},fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f));Text(u.code,color=MaterialTheme.colorScheme.primary,fontSize=12.sp)}
      Text("${u.property}  •  ${u.unitType}",color=MaterialTheme.colorScheme.onSurfaceVariant)
      Row(verticalAlignment=Alignment.CenterVertically){Text(u.status,fontSize=12.sp);Spacer(Modifier.weight(1f));Text(u.rent?.let{unitScreenMoney(it)+" / شهر"}?:"القيمة غير محددة",fontWeight=FontWeight.SemiBold)}
      Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
       TextButton(onClick={edit=u}){Icon(Icons.Default.Edit,null);Text("تعديل البيانات")}
       TextButton(onClick={docsUnit=u}){Icon(Icons.Default.FolderOpen,null);Text("عقد الوحدة ومستنداتها")}
      }
     }
    }
   }
  }
 }
 if(add||edit!=null){UnitEditor(edit,onDismiss={add=false;edit=null},onSave={db.saveUnit(it);add=false;edit=null;onRefresh()})}
 docsUnit?.let{u->UnitDocumentsDialog(activity,SqliteDocumentRepository(db),u,onDismiss={docsUnit=null})}
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun UnitDocumentsDialog(activity:FragmentActivity,documents:SqliteDocumentRepository,unit:UnitRecord,onDismiss:()->Unit){
 val addDocument = remember(documents) { AddOwnerDocument(documents) }
 val fileManager = remember(activity) { AttachmentFileManager(activity) }
 val getDocuments = remember(documents) { GetOwnerDocuments(documents) }
 var refresh by remember{mutableIntStateOf(0)}
 var note by remember{mutableStateOf("")}
 var category by remember{mutableStateOf("عقد أساسي")}
 var categoryExpanded by remember{mutableStateOf(false)}
 var message by remember{mutableStateOf("")}
 var pendingCameraFile by remember{mutableStateOf<File?>(null)}
 val folder=remember(unit.id){File(activity.filesDir,"attachments/units/${unit.id}").apply{mkdirs()}}
 fun registerFile(file:File,mime:String,displayName:String,notes:String=""){
  val contentUri=FileProvider.getUriForFile(activity,"${activity.packageName}.fileprovider",file)
  addDocument("unit",unit.id.toString(),contentUri.toString(),displayName,mime,notes,category)
  refresh++;message="تم حفظ الملف داخل التطبيق وربطه بالوحدة. النسخ السابقة لم تُستبدل."
 }
 fun importUri(uri:Uri,notesForFile:String){
  try {
   val stored=fileManager.import(uri,"unit",unit.id.toString())
   try {
    addDocument("unit",unit.id.toString(),stored.uri,stored.displayName,stored.mimeType,notesForFile,category)
   } catch (error: Exception) { fileManager.discardUnindexed(stored); throw error }
   refresh++;message="تم حفظ الملف داخل مساحة التطبيق الخاصة وربطه بالوحدة. النسخ السابقة لم تُستبدل."
  } catch(e:Exception) { message="تعذر استيراد الملف: ${e.message}" }
 }

 val camera=rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()){ok->
  val f=pendingCameraFile
  if(ok&&f!=null&&f.exists()&&f.length()>0){try{registerFile(f,"image/jpeg","عقد_${unit.code}_${System.currentTimeMillis()}.jpg",note);note=""}catch(e:Exception){f.delete();message="تعذر حفظ الصورة: ${e.message}"}}
  else{f?.delete();message="لم يتم التقاط صورة"}
  pendingCameraFile=null
 }
 val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()){uris->
  if(uris.isNotEmpty()){val sharedNote=note;var saved=0;var errors=0;uris.forEach{u->try{importUri(u,sharedNote);saved++}catch(_:Exception){errors++}};note="";message=when{saved>0&&errors==0->"تم حفظ $saved ملف/صفحة بنجاح";saved>0->"تم حفظ $saved ملف، وتعذر استيراد $errors ملف";else->"تعذر استيراد الملفات المحددة"}}
 }
 val docs=remember(refresh){getDocuments("unit",unit.id.toString())}
 AlertDialog(onDismissRequest=onDismiss,title={Text("عقد الوحدة ومستنداتها")},text={
  Column(Modifier.fillMaxWidth().heightIn(max=560.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)){
   Text("${unit.code} – ${unit.tenant}",fontWeight=FontWeight.Bold)
   Text("أضف العقد أو صفحاته أو الملاحق أو التجديدات. كل ملف يُحفظ كنسخة مستقلة داخل التطبيق، ولا يستبدل أي ملف سابق.",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
   ExposedDropdownMenuBox(expanded=categoryExpanded,onExpandedChange={categoryExpanded=it}){
    OutlinedTextField(value=category,onValueChange={},readOnly=true,label={Text("نوع المستند")},modifier=Modifier.menuAnchor().fillMaxWidth(),trailingIcon={ExposedDropdownMenuDefaults.TrailingIcon(expanded=categoryExpanded)})
    ExposedDropdownMenu(expanded=categoryExpanded,onDismissRequest={categoryExpanded=false}){
     listOf("عقد أساسي","صفحة من العقد","ملحق عقد","تجديد عقد","إنذار / إخطار","مستند آخر").forEach{item->DropdownMenuItem(text={Text(item)},onClick={category=item;categoryExpanded=false})}
    }
   }
   OutlinedTextField(note,{note=it},label={Text("ملاحظة على الملف (اختياري)")},modifier=Modifier.fillMaxWidth(),minLines=2)
   Button(onClick={try{val f=File(folder,"capture_${System.currentTimeMillis()}.jpg");pendingCameraFile=f;camera.launch(FileProvider.getUriForFile(activity,"${activity.packageName}.fileprovider",f))}catch(e:Exception){message="تعذر تشغيل الكاميرا: ${e.message}"}},modifier=Modifier.fillMaxWidth()){
    Icon(Icons.Default.PhotoCamera,null);Text("  تصوير صفحة العقد بالكاميرا")
   }
   OutlinedButton(onClick={picker.launch(arrayOf("image/*","application/pdf","application/msword","application/vnd.openxmlformats-officedocument.wordprocessingml.document"))},modifier=Modifier.fillMaxWidth()){
    Icon(Icons.Default.UploadFile,null);Text("  رفع ملف أو عدة صفحات / ملفات")
   }
   HorizontalDivider();Text("المستندات المحفوظة (${docs.size})",fontWeight=FontWeight.Bold)
   if(docs.isEmpty())Text("لم تتم إضافة عقد أو مستند لهذه الوحدة بعد.",color=MaterialTheme.colorScheme.onSurfaceVariant)
   docs.forEach{d->
    Card(Modifier.fillMaxWidth()){
     Column(Modifier.padding(8.dp),verticalArrangement=Arrangement.spacedBy(4.dp)){
      Text(d.name,fontWeight=FontWeight.SemiBold)
      Text("${d.category} • ${d.mime}",fontSize=11.sp,color=MaterialTheme.colorScheme.primary)
      Text("أضيف في ${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(java.util.Date(d.createdAt))}",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
      if(d.notes.isNotBlank())Text(d.notes,fontSize=12.sp)
      TextButton(onClick={try{activity.startActivity(fileManager.openIntent(d.uri,d.mime))}catch(e:Exception){message="تعذر فتح الملف: ${e.message}"}}){Icon(Icons.Default.OpenInNew,null);Text("فتح المستند")}
     }
    }
   }
   if(message.isNotBlank())Text(message,color=MaterialTheme.colorScheme.primary,fontSize=12.sp)
  }
 },confirmButton={TextButton(onClick=onDismiss){Text("إغلاق")}})
}

@Composable
private fun UnitEditor(existing: UnitRecord?, onDismiss: () -> Unit, onSave: (UnitRecord) -> Unit) {
    var code by remember { mutableStateOf(existing?.code ?: "") }
    var property by remember { mutableStateOf(existing?.property ?: "") }
    var tenant by remember { mutableStateOf(existing?.tenant ?: "") }
    var type by remember { mutableStateOf(existing?.unitType ?: "سكني") }
    var rent by remember { mutableStateOf(existing?.rent?.toString() ?: "") }
    var status by remember { mutableStateOf(existing?.status ?: "نشطة") }
    var desc by remember { mutableStateOf(existing?.description ?: "") }
    var notes by remember { mutableStateOf(existing?.notes ?: "") }
    AlertDialog(onDismissRequest=onDismiss,title={Text(if(existing==null)"إضافة وحدة" else "تعديل بيانات الوحدة")},text={Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(6.dp)){
      AppField("كود الوحدة",code,onChange={code=it});AppField("العقار / العنوان",property,onChange={property=it});AppField("اسم المستأجر",tenant,onChange={tenant=it});AppField("نوع الوحدة",type,onChange={type=it});AppField("القيمة الشهرية بالجنيه",rent,KeyboardType.Decimal,onChange={rent=it});AppField("الحالة التشغيلية",status,onChange={status=it});AppField("وصف العين",desc,onChange={desc=it});AppField("ملاحظات",notes,onChange={notes=it})
    }},confirmButton={TextButton(onClick={if(tenant.isNotBlank()) onSave(UnitRecord(existing?.id?:0,code,property,tenant,type,rent.toDoubleOrNull(),status,desc,notes))}){Text("حفظ")}},dismissButton={TextButton(onClick=onDismiss){Text("إلغاء")}})
}



