package com.critical.cases

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.os.Environment
import android.print.PrintManager
import android.provider.MediaStore
import android.util.Base64
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.JsResult
import androidx.appcompat.app.AlertDialog
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.IntentSenderRequest
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewAssetLoader

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private var chooserCallback: ValueCallback<Array<Uri>>? = null

    private val picker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val data = res.data
        val uris: Array<Uri>? =
            if (res.resultCode == Activity.RESULT_OK && data != null) {
                WebChromeClient.FileChooserParams.parseResult(res.resultCode, data)
            } else {
                null
            }
        chooserCallback?.onReceiveValue(uris)
        chooserCallback = null
    }

    private var pendingFileId: String? = null
    private var pendingOpen = false
    private val prefs by lazy { getSharedPreferences("sync", MODE_PRIVATE) }
    private val xlsxMime = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

    private val docLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val uri = res.data?.data
        if (res.resultCode == Activity.RESULT_OK && uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
                // permission could not be persisted; the file will still be read now
            }
            var name = "ملف"
            try {
                contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                    if (it.moveToFirst()) name = it.getString(0)
                }
            } catch (e: Exception) {
                name = "ملف"
            }
            prefs.edit().putString("uri", uri.toString()).putString("name", name).apply()
            web.evaluateJavascript("window.cbPicked&&window.cbPicked(" + JSONObject.quote(name) + ")", null)
            syncFromUri(uri, name)
        }
    }

    private fun isSheet(b: ByteArray): Boolean {
        if (b.size < 4) return false
        val zip = b[0] == 'P'.code.toByte() && b[1] == 'K'.code.toByte()
        val ole = b[0] == 0xD0.toByte() && b[1] == 0xCF.toByte()
        return zip || ole
    }

    private fun readUri(uri: Uri): ByteArray {
        try {
            val st = contentResolver.openInputStream(uri)
            if (st != null) {
                val b = st.use { it.readBytes() }
                if (b.isNotEmpty()) return b
            }
        } catch (e: Exception) {
            // may be a virtual document (native Google Sheets): fall through
        }
        val types = contentResolver.getStreamTypes(uri, "*/*")
        val t = types?.firstOrNull { it == xlsxMime }
            ?: types?.firstOrNull { it.contains("spreadsheetml") || it.contains("ms-excel") }
            ?: throw IllegalStateException("لا يمكن قراءة الملف بصيغة Excel")
        val afd = contentResolver.openTypedAssetFileDescriptor(uri, t, null)
            ?: throw IllegalStateException("تعذر فتح الملف")
        return afd.createInputStream().use { it.readBytes() }
    }

    private fun syncFromUri(uri: Uri, name: String) {
        Thread {
            try {
                val bytes = readUri(uri)
                if (bytes.isEmpty()) throw IllegalStateException("الملف فارغ")
                File(filesDir, "sync/latest.xlsx").writeBytes(bytes)
                runOnUiThread {
                    web.evaluateJavascript("window.cbSync(true,''," + JSONObject.quote("الملف: " + name) + ")", null)
                }
            } catch (e: Exception) {
                jsFail("تعذر القراءة: " + (e.message ?: "") + " — اختر الملف من Drive مرة أخرى")
            }
        }.start()
    }

    private fun handleOpenIntent(intent: Intent?) {
        if (intent == null) return
        val uri: Uri? = when (intent.action) {
            Intent.ACTION_VIEW -> intent.data
            Intent.ACTION_SEND -> {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
            }
            else -> null
        }
        if (uri == null) return
        Thread {
            try {
                val bytes = readUri(uri)
                if (bytes.isEmpty()) throw IllegalStateException("الملف فارغ")
                File(filesDir, "sync").mkdirs()
                File(filesDir, "sync/latest.xlsx").writeBytes(bytes)
                pendingOpen = true
                runOnUiThread {
                    web.evaluateJavascript("window.appOpenPending&&window.appOpenPending()", null)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "تعذر فتح الملف: " + (e.message ?: ""), Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleOpenIntent(intent)
    }

    private val authLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        try {
            val r = Identity.getAuthorizationClient(this).getAuthorizationResultFromIntent(res.data)
            val tok = r.accessToken
            val id = pendingFileId
            if (tok != null && id != null) {
                downloadDrive(id, tok)
            } else {
                jsFail("لم يتم منح الصلاحية")
            }
        } catch (e: Exception) {
            jsFail("تعذر الحصول على الصلاحية: " + (e.message ?: ""))
        }
    }

    private fun jsFail(msg: String) {
        runOnUiThread {
            web.evaluateJavascript("window.cbSync(false," + JSONObject.quote(msg) + ")", null)
        }
    }

    private fun httpGet(url: String, token: String): ByteArray {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 20000
        c.readTimeout = 60000
        c.setRequestProperty("Authorization", "Bearer " + token)
        if (c.responseCode !in 200..299) {
            val err = c.errorStream?.readBytes()?.let { String(it) } ?: ""
            throw IllegalStateException("HTTP " + c.responseCode + " " + err.take(150))
        }
        return c.inputStream.use { it.readBytes() }
    }

    private fun downloadDrive(fileId: String, token: String) {
        Thread {
            try {
                val meta = httpGet("https://www.googleapis.com/drive/v3/files/" + fileId + "?fields=mimeType&supportsAllDrives=true", token)
                val mime = JSONObject(String(meta)).optString("mimeType")
                val url = if (mime == "application/vnd.google-apps.spreadsheet") {
                    "https://www.googleapis.com/drive/v3/files/" + fileId + "/export?mimeType=application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                } else {
                    "https://www.googleapis.com/drive/v3/files/" + fileId + "?alt=media&supportsAllDrives=true"
                }
                val bytes = httpGet(url, token)
                if (bytes.size > 4 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte()) {
                    File(filesDir, "sync/latest.xlsx").writeBytes(bytes)
                    var email = ""
                    try {
                        val about = JSONObject(String(httpGet("https://www.googleapis.com/drive/v3/about?fields=user(emailAddress)", token)))
                        email = about.optJSONObject("user")?.optString("emailAddress") ?: ""
                    } catch (e: Exception) {
                        email = ""
                    }
                    runOnUiThread {
                        web.evaluateJavascript("window.cbSync(true,''," + JSONObject.quote(email) + ")", null)
                    }
                } else {
                    jsFail("الملف المحدد ليس ملف Excel")
                }
            } catch (e: Exception) {
                jsFail("تعذر التحميل: " + (e.message ?: ""))
            }
        }.start()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        val syncDir = File(filesDir, "sync")
        syncDir.mkdirs()
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .addPathHandler("/sync/", WebViewAssetLoader.InternalStoragePathHandler(this, syncDir))
            .build()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(window.appBack?window.appBack():'0')") { r ->
                    if (r == null || !r.contains("1")) {
                        finish()
                    }
                }
            }
        })

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = false

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                return loader.shouldInterceptRequest(request.url)
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setPositiveButton("موافق") { _, _ -> result?.confirm() }
                    .setNegativeButton("إلغاء") { _, _ -> result?.cancel() }
                    .setOnCancelListener { result?.cancel() }
                    .show()
                return true
            }

            override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setPositiveButton("حسناً") { _, _ -> result?.confirm() }
                    .setOnCancelListener { result?.confirm() }
                    .show()
                return true
            }

            override fun onShowFileChooser(
                webView: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                chooserCallback?.onReceiveValue(null)
                chooserCallback = callback
                return try {
                    picker.launch(params.createIntent())
                    true
                } catch (e: Exception) {
                    chooserCallback = null
                    false
                }
            }
        }
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("https://appassets.androidplatform.net/assets/www/index.html")
        handleOpenIntent(intent)
    }

    private fun startShare(send: Intent, target: String, title: String) {
        val pkg = when (target) {
            "wa" -> "com.whatsapp"
            "mail" -> "com.google.android.gm"
            else -> null
        }
        if (pkg != null) {
            try {
                startActivity(Intent(send).setPackage(pkg))
                return
            } catch (e: Exception) {
                // app not installed: fall back to the system chooser
            }
        }
        startActivity(Intent.createChooser(send, title))
    }

    override fun onPause() {
        super.onPause()
        if (::web.isInitialized) {
            web.evaluateJavascript("window.appPause&&window.appPause()", null)
        }
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) {
            web.evaluateJavascript("window.appResume&&window.appResume()", null)
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun setSecure(on: Boolean) {
            runOnUiThread {
                if (on) {
                    this@MainActivity.window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
                } else {
                    this@MainActivity.window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                }
            }
        }

        @JavascriptInterface
        fun saveFile(name: String, base64: String, mime: String, target: String) {
            try {
                val bytes = Base64.decode(base64, Base64.DEFAULT)
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("insert failed")
                contentResolver.openOutputStream(uri)!!.use { it.write(bytes) }
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "تم الحفظ في مجلد Downloads: " + name, Toast.LENGTH_LONG).show()
                    if (target != "save") {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = mime
                            putExtra(Intent.EXTRA_STREAM, uri)
                            putExtra(Intent.EXTRA_SUBJECT, name)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        startShare(send, target, name)
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "تعذر حفظ الملف: " + e.message, Toast.LENGTH_LONG).show()
                }
            }
        }

        @JavascriptInterface
        fun shareText(text: String, subject: String, target: String) {
            runOnUiThread {
                try {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, text)
                        putExtra(Intent.EXTRA_SUBJECT, subject)
                    }
                    startShare(send, target, subject)
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "تعذر الإرسال: " + e.message, Toast.LENGTH_LONG).show()
                }
            }
        }

        @JavascriptInterface
        fun appInfo(): String {
            val o = JSONObject()
            try {
                val pi = packageManager.getPackageInfo(packageName, 0)
                o.put("name", pi.versionName ?: "")
                o.put("code", pi.longVersionCode)
            } catch (e: Exception) {
                o.put("name", "?")
                o.put("code", 0)
            }
            o.put("built", BuildConfig.BUILD_TIME)
            o.put("sha", BuildConfig.BUILD_SHA)
            o.put("pkg", packageName)
            return o.toString()
        }

        @JavascriptInterface
        fun openUrl(url: String) {
            runOnUiThread {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "تعذر فتح الرابط", Toast.LENGTH_LONG).show()
                }
            }
        }

        @JavascriptInterface
        fun httpGet(id: String, url: String, headers: String) {
            Thread {
                var status = 0
                var text = ""
                try {
                    val c = URL(url).openConnection() as HttpURLConnection
                    c.connectTimeout = 20000
                    c.readTimeout = 30000
                    c.instanceFollowRedirects = true
                    val h = JSONObject(headers)
                    val keys = h.keys()
                    while (keys.hasNext()) {
                        val key = keys.next()
                        c.setRequestProperty(key, h.getString(key))
                    }
                    status = c.responseCode
                    val st = if (status in 200..299) c.inputStream else c.errorStream
                    text = if (st != null) String(st.use { i -> i.readBytes() }, Charsets.UTF_8) else ""
                } catch (e: Exception) {
                    text = "ERR:" + (e.message ?: "")
                }
                val js = "window.cbHttp(" + JSONObject.quote(id) + "," + status + "," + JSONObject.quote(text) + ")"
                runOnUiThread { web.evaluateJavascript(js, null) }
            }.start()
        }

        @JavascriptInterface
        fun httpPost(id: String, url: String, headers: String, body: String) {
            Thread {
                var status = 0
                var text = ""
                try {
                    val c = URL(url).openConnection() as HttpURLConnection
                    c.requestMethod = "POST"
                    c.connectTimeout = 20000
                    c.readTimeout = 90000
                    c.doOutput = true
                    val h = JSONObject(headers)
                    val keys = h.keys()
                    while (keys.hasNext()) {
                        val k = keys.next()
                        c.setRequestProperty(k, h.getString(k))
                    }
                    c.outputStream.use { o -> o.write(body.toByteArray(Charsets.UTF_8)) }
                    status = c.responseCode
                    val st = if (status in 200..299) c.inputStream else c.errorStream
                    text = if (st != null) String(st.use { i -> i.readBytes() }, Charsets.UTF_8) else ""
                } catch (e: Exception) {
                    text = "ERR:" + (e.message ?: "")
                }
                val js = "window.cbHttp(" + JSONObject.quote(id) + "," + status + "," + JSONObject.quote(text) + ")"
                runOnUiThread { web.evaluateJavascript(js, null) }
            }.start()
        }

        @JavascriptInterface
        fun pickDriveFile() {
            runOnUiThread {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                }
                docLauncher.launch(i)
            }
        }

        @JavascriptInterface
        fun syncPicked() {
            val u = prefs.getString("uri", null)
            if (u == null) {
                jsFail("اختر الملف من Drive أولاً")
            } else {
                syncFromUri(Uri.parse(u), prefs.getString("name", "") ?: "")
            }
        }

        @JavascriptInterface
        fun pickedName(): String {
            return prefs.getString("name", "") ?: ""
        }

        @JavascriptInterface
        fun hasPending(): Boolean {
            val p = pendingOpen
            pendingOpen = false
            return p
        }

        @JavascriptInterface
        fun syncGoogle(fileId: String) {
            runOnUiThread {
                pendingFileId = fileId
                val req = AuthorizationRequest.builder()
                    .setRequestedScopes(listOf(Scope("https://www.googleapis.com/auth/drive.readonly")))
                    .build()
                Identity.getAuthorizationClient(this@MainActivity).authorize(req)
                    .addOnSuccessListener { r ->
                        if (r.hasResolution()) {
                            val pi = r.pendingIntent
                            if (pi != null) {
                                authLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
                            } else {
                                jsFail("تعذر فتح شاشة الموافقة")
                            }
                        } else {
                            val tok = r.accessToken
                            if (tok != null) downloadDrive(fileId, tok) else jsFail("لم يتم منح الصلاحية")
                        }
                    }
                    .addOnFailureListener { e -> jsFail("تعذر الربط بحساب Google: " + (e.message ?: "")) }
            }
        }

        @JavascriptInterface
        fun fetchUrl(url: String) {
            Thread {
                var ok = false
                var msg = ""
                var kind = ""
                try {
                    val conn = URL(url).openConnection() as HttpURLConnection
                    conn.connectTimeout = 20000
                    conn.readTimeout = 60000
                    conn.instanceFollowRedirects = true
                    conn.setRequestProperty("User-Agent", "Mozilla/5.0")
                    val bytes = conn.inputStream.use { it.readBytes() }
                    val head = String(bytes, 0, minOf(bytes.size, 600), Charsets.UTF_8).lowercase()
                    if (bytes.isNotEmpty() && bytes[0] == '{'.code.toByte()) {
                        File(filesDir, "sync/latest.json").writeBytes(bytes)
                        ok = true
                        kind = "json"
                    } else if (bytes.isEmpty() || (head.contains("<html") && (head.contains("accounts.google") || head.contains("sign in")))) {
                        msg = "الملف غير متاح للتحميل (صفحة تسجيل دخول أو رد فارغ). تأكد من المشاركة أو رابط السكربت (ينتهي بـ /exec)."
                    } else {
                        File(filesDir, "sync/latest.xlsx").writeBytes(bytes)
                        ok = true
                        kind = ""
                    }
                } catch (e: Exception) {
                    msg = "تعذر الاتصال: " + (e.message ?: "")
                }
                val js = if (ok) "window.cbSync(true,'" + kind + "')" else "window.cbSync(false," + JSONObject.quote(msg) + ")"
                runOnUiThread { web.evaluateJavascript(js, null) }
            }.start()
        }

        @JavascriptInterface
        fun printPage() {
            runOnUiThread {
                val pm = getSystemService(PRINT_SERVICE) as PrintManager
                pm.print("report", web.createPrintDocumentAdapter("report"), null)
            }
        }
    }
}
