package com.medref.drugs

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatDelegate

/** كل إعدادات التطبيق في مكان واحد. تغييرات المظهر تستدعي touch() لإعادة بناء الشاشات. */
object Prefs {
    private lateinit var sp: SharedPreferences

    fun init(ctx: Context) {
        sp = ctx.applicationContext.getSharedPreferences("settings", Context.MODE_PRIVATE)
    }

    private fun str(k: String, d: String): String = sp.getString(k, d) ?: d
    private fun int(k: String, d: Int): Int = sp.getInt(k, d)
    private fun bool(k: String, d: Boolean): Boolean = sp.getBoolean(k, d)
    private fun long(k: String, d: Long): Long = sp.getLong(k, d)

    var stamp: Int
        get() = int("stamp", 0)
        set(v) { sp.edit().putInt("stamp", v).apply() }

    fun touch() { stamp = stamp + 1 }

    // ----- المظهر -----
    var themeMode: String            // system | light | dark
        get() = str("themeMode", "system")
        set(v) { sp.edit().putString("themeMode", v).apply() }
    var accent: String
        get() = str("accent", "teal")
        set(v) { sp.edit().putString("accent", v).apply() }
    var background: String           // default | white | cream | gray | blue | green | image
        get() = str("background", "default")
        set(v) { sp.edit().putString("background", v).apply() }
    var bgDim: Int                   // نسبة تعتيم طبقة صورة الخلفية %
        get() = int("bgDim", 35)
        set(v) { sp.edit().putInt("bgDim", v).apply() }
    var font: String
        get() = str("font", "system")
        set(v) { sp.edit().putString("font", v).apply() }
    var textScale: Int               // % من حجم النص
        get() = int("textScale", 100)
        set(v) { sp.edit().putInt("textScale", v).apply() }
    var cardStyle: String            // outlined | elevated | flat
        get() = str("cardStyle", "outlined")
        set(v) { sp.edit().putString("cardStyle", v).apply() }
    var cardRadius: Int              // dp
        get() = int("cardRadius", 12)
        set(v) { sp.edit().putInt("cardRadius", v).apply() }

    // ----- القائمة -----
    var nameOrder: String            // en | ar  (الكود يبقى ملتصقًا بالاسم الأجنبي دائمًا)
        get() = str("nameOrder", "en")
        set(v) { sp.edit().putString("nameOrder", v).apply() }
    var compact: Boolean
        get() = bool("compact", false)
        set(v) { sp.edit().putBoolean("compact", v).apply() }
    var haptic: Boolean
        get() = bool("haptic", true)
        set(v) { sp.edit().putBoolean("haptic", v).apply() }
    var groupMode: Boolean           // عرض بالدواء (العائلة) بدل الصنف
        get() = bool("groupMode", false)
        set(v) { sp.edit().putBoolean("groupMode", v).apply() }
    var autoBackup: Boolean
        get() = bool("autoBackup", true)
        set(v) { sp.edit().putBoolean("autoBackup", v).apply() }
    var lastBackup: Long
        get() = long("lastBackup", 0L)
        set(v) { sp.edit().putLong("lastBackup", v).apply() }
    /** العروض المحفوظة: "الاسم|القسم|الحالة|البحث". */
    var views: Set<String>
        get() = sp.getStringSet("views", emptySet()) ?: emptySet()
        set(v) { sp.edit().putStringSet("views", HashSet(v)).apply() }
    var startScope: String
        get() = str("startScope", "CURATED")
        set(v) { sp.edit().putString("startScope", v).apply() }

    // ----- الأمان -----
    var lockEnabled: Boolean
        get() = bool("lockEnabled", false)
        set(v) { sp.edit().putBoolean("lockEnabled", v).apply() }
    var biometric: Boolean
        get() = bool("biometric", false)
        set(v) { sp.edit().putBoolean("biometric", v).apply() }
    var lockTimeout: Int             // ثوانٍ
        get() = int("lockTimeout", 30)
        set(v) { sp.edit().putInt("lockTimeout", v).apply() }
    var secure: Boolean              // منع لقطات الشاشة
        get() = bool("secure", false)
        set(v) { sp.edit().putBoolean("secure", v).apply() }
    var pinHash: String
        get() = str("pinHash", "")
        set(v) { sp.edit().putString("pinHash", v).apply() }
    var pinSalt: String
        get() = str("pinSalt", "")
        set(v) { sp.edit().putString("pinSalt", v).apply() }
    var pinLen: Int
        get() = int("pinLen", 4)
        set(v) { sp.edit().putInt("pinLen", v).apply() }
    var failCount: Int
        get() = int("failCount", 0)
        set(v) { sp.edit().putInt("failCount", v).apply() }
    var lockoutUntil: Long
        get() = long("lockoutUntil", 0L)
        set(v) { sp.edit().putLong("lockoutUntil", v).apply() }

    fun nightMode(): Int = when (themeMode) {
        "light" -> AppCompatDelegate.MODE_NIGHT_NO
        "dark" -> AppCompatDelegate.MODE_NIGHT_YES
        else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
    }

    fun resetAppearance() {
        sp.edit()
            .remove("themeMode").remove("accent").remove("background").remove("bgDim")
            .remove("font").remove("textScale").remove("cardStyle").remove("cardRadius")
            .remove("nameOrder").remove("compact").remove("haptic").remove("startScope")
            .apply()
        touch()
    }
}
