from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
manager = (ROOT / 'app/src/main/java/com/example/rentals/files/AttachmentFileManager.kt').read_text()
contracts = (ROOT / 'app/src/main/java/com/example/rentals/features/contracts/ContractsArchiveScreen.kt').read_text()
units = (ROOT / 'app/src/main/java/com/example/rentals/features/units/UnitsScreen.kt').read_text()

checks = {
    'imports are copied into app-private files directory': 'File(context.filesDir, "attachments/archive/$ownerType/$ownerId")' in manager,
    'file size is bounded to 50 MiB': 'MAX_FILE_BYTES = 50L * 1024L * 1024L' in manager and 'total <= MAX_FILE_BYTES' in manager,
    'partial imports are removed on failure': 'destination.delete()' in manager,
    'display names are sanitized': 'take(180)' in manager and 'replace(Regex' in manager,
    'only supported document types are accepted': 'application/pdf' in manager and 'application/msword' in manager and 'image/' in manager,
    'archive import uses the shared private-file manager': 'fileManager.import(uri, attachOwnerType, attachOwnerId)' in contracts,
    'archive no longer depends on persisted external URI permission': 'takePersistableUriPermission' not in contracts,
    'unit attachments use centralized safe opening': 'fileManager.openIntent(d.uri,d.mime)' in units,
    'unit imports use the same private-file manager': 'fileManager.import(uri,"unit",unit.id.toString())' in units,
    'failed metadata writes roll back only the new unindexed file': 'discardUnindexed(stored)' in contracts and 'discardUnindexed(stored)' in units,
    'archive attachments use centralized safe opening': 'fileManager.openIntent(a.uri,a.mime)' in contracts,
    'metadata removal remains separate from file deletion': 'RemoveContractAttachment' in contracts and 'destination.delete()' not in contracts,
}
for name, passed in checks.items():
    print(('PASS' if passed else 'FAIL') + ' ' + name)
assert all(checks.values()), [name for name, passed in checks.items() if not passed]
print(f'{sum(checks.values())}/{len(checks)} attachment lifecycle checks passed')
