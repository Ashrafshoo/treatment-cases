#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
kotlinc \
  "$ROOT/android/app/src/main/java/com/treatmentcases/app/CaseRecord.kt" \
  "$ROOT/android/app/src/main/java/com/treatmentcases/app/CaseDataRules.kt" \
  "$ROOT/verification/CaseDataRulesTest.kt" \
  -include-runtime -d "$OUT/case-rules-tests.jar"
java -jar "$OUT/case-rules-tests.jar"
