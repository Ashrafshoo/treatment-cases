#!/usr/bin/env python3
from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'android/app/src/main/java/com/treatmentcases/app/MainActivity.kt').read_text(encoding='utf-8')
db=(root/'android/app/src/main/java/com/treatmentcases/app/LocalDb.kt').read_text(encoding='utf-8')
g=(root/'android/app/build.gradle').read_text(encoding='utf-8')
checks={
 '2.7.3 isolated preview package': "applicationId 'com.treatmentcases.app.preview275'" in g,
 '2.7.3 version increment': "versionName '2.8.1-ui-polish'" in g and 'versionCode 33' in g,
 'medicine catalog search retained': 'medicineResults' in s and 'medicineQuery' in s,
 'medicine result is an interactive medical card': 'Card(Modifier.fillMaxWidth().clickable{selectedMedicineDetails=m}' in s and 'Icons.Default.Medication' in s,
 'beneficiary count shown on card': 'beneficiaries' in s and 'مستفيد' in s,
 'strength summary shown on card': 'strengthSummary' in s and 'العيارات' in s,
 'review status shown on card': 'reviewStatus' in s,
 'medicine detail editor retained': 'MedicineDetailsDialog' in s,
 'add medicine retained': 'db.addMedicine(newMedicine' in s,
 'strengths stored separately': 'CREATE TABLE strengths' in db,
 'medicine-strength link in case form retained': 'strengthOptions(values[4])' in s,
 'single/multi/all reports retained': 'Select All' in s and 'اختيار الكل' in s and 'pendingReportRows=db.all().filter{it.medicine in selectedReportMeds}' in s,
 'medicine catalog changes remain schema-compatible': 'CREATE TABLE' not in s and 'ALTER TABLE' not in s,
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+': '+k)
assert all(checks.values())
print(f'PASS: {len(checks)} medicine catalog 2.6.8 assertions')
