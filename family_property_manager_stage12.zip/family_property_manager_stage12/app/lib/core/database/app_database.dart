import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:flutter/services.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite_sqlcipher/sqflite.dart';

/// Owns the encrypted local database and its Android Keystore-backed key.
/// Existing plaintext databases are exported to SQLCipher before first use.
class AppDatabase {
  AppDatabase._();
  static final AppDatabase instance = AppDatabase._();

  static const _keyName = 'family_properties_sqlcipher_key_v1';
  static const _storage = FlutterSecureStorage();
  Database? _database;
  Future<Database>? _opening;

  Future<String> get databasePath async {
    final dir = await getApplicationDocumentsDirectory();
    return p.join(dir.path, 'family_properties.db');
  }

  Future<String?> readEncryptionKey() => _storage.read(key: _keyName);

  Future<void> writeEncryptionKey(String key) async {
    if (!RegExp(r'^[0-9a-f]{64}$').hasMatch(key)) {
      throw FormatException('مفتاح قاعدة البيانات غير صالح');
    }
    await _storage.write(key: _keyName, value: key);
  }

  Future<void> close() async {
    final db = _database;
    _database = null;
    if (db != null) await db.close();
  }

  Future<Database> get database async {
    if (_database != null) return _database!;
    final pending = _opening;
    if (pending != null) return pending;
    final future = _openSecureDatabase();
    _opening = future;
    try {
      _database = await future;
      return _database!;
    } finally {
      _opening = null;
    }
  }

  Future<Database> _openSecureDatabase() async {
    final path = await databasePath;
    final file = File(path);
    final legacyBackup = File('$path.plaintext_backup');

    // Recover an interrupted atomic replacement before attempting to open.
    if (!await file.exists() && await legacyBackup.exists()) {
      await legacyBackup.rename(path);
    }

    var key = await readEncryptionKey();
    if (key != null && !RegExp(r'^[0-9a-f]{64}$').hasMatch(key)) {
      throw StateError('مفتاح تشفير قاعدة البيانات غير صالح؛ لم يتم فتح الملف أو تعديله.');
    }
    if (key == null) {
      if (await file.exists()) {
        if (!await _hasPlainSqliteHeader(file)) {
          throw StateError('تعذر العثور على مفتاح تشفير قاعدة البيانات. لم يتم تعديل الملف حفاظاً على البيانات.');
        }
      }
      key = _newKey();
      await writeEncryptionKey(key);
    }

    if (await file.exists() && await _hasPlainSqliteHeader(file)) {
      await _encryptLegacyDatabase(path, key);
    }

    // If a previous migration completed the rename but stopped before cleanup,
    // the encrypted database is opened and verified before its plaintext copy is removed.
    final db = await openDatabase(
      path,
      password: key,
      version: 5,
      onConfigure: (database) async {
        await database.execute('PRAGMA cipher_memory_security = ON');
        await database.execute('PRAGMA foreign_keys = ON');
      },
      onCreate: (database, version) async {
        final schema = await rootBundle.loadString('assets/database/001_initial_schema.sql');
        await database.transaction((txn) async {
          for (final raw in schema.split(';')) {
            final statement = raw.trim();
            if (statement.isNotEmpty) await txn.execute(statement);
          }
          await _applyStage3Integrity(txn);
          await _applyStage9Indexes(txn);
          await _applyStage10Flags(txn);
          await _applyStage11Documents(txn);
        });
      },
      onUpgrade: (database, oldVersion, newVersion) async {
        if (oldVersion < 2) await _applyStage3Integrity(database);
        if (oldVersion < 3) await _applyStage9Indexes(database);
        if (oldVersion < 4) await _applyStage10Flags(database);
        if (oldVersion < 5) await _applyStage11Documents(database);
      },
    );

    final integrity = await db.rawQuery('PRAGMA quick_check');
    if (integrity.isEmpty || integrity.first.values.first != 'ok') {
      await db.close();
      throw StateError('فشل فحص سلامة قاعدة البيانات المشفرة. لم يتم حذف أي نسخة احتياطية.');
    }
    if (await legacyBackup.exists()) await legacyBackup.delete();
    return db;
  }

  Future<bool> _hasPlainSqliteHeader(File file) async {
    if (await file.length() < 16) return false;
    final handle = await file.open();
    try {
      final header = await handle.read(16);
      return utf8.decode(header, allowMalformed: true) == 'SQLite format 3\u0000';
    } finally {
      await handle.close();
    }
  }

  String _newKey() {
    final random = Random.secure();
    return List<int>.generate(32, (_) => random.nextInt(256))
        .map((value) => value.toRadixString(16).padLeft(2, '0'))
        .join();
  }

  Future<void> _encryptLegacyDatabase(String path, String key) async {
    final source = File(path);
    final temporary = File('$path.encrypted_tmp');
    final backup = File('$path.plaintext_backup');
    final wal = File('$path-wal');
    final shm = File('$path-shm');
    if (await temporary.exists()) await temporary.delete();

    // SQLCipher can open a legacy SQLite file without a password, then export
    // it into a separately encrypted attached database.
    final legacy = await openDatabase(path, singleInstance: false);
    try {
      final legacyVersion = await legacy.getVersion();
      await legacy.execute('PRAGMA wal_checkpoint(FULL)');
      await legacy.execute("ATTACH DATABASE ? AS encrypted KEY '$key'", [temporary.path]);
      await legacy.execute("SELECT sqlcipher_export('encrypted')");
      await legacy.execute('PRAGMA encrypted.user_version = $legacyVersion');
      await legacy.execute('DETACH DATABASE encrypted');
    } catch (_) {
      await legacy.close();
      if (await temporary.exists()) await temporary.delete();
      // Keep the original plaintext database untouched if export fails.
      rethrow;
    }
    await legacy.close();
    if (await wal.exists()) await wal.delete();
    if (await shm.exists()) await shm.delete();
    if (await backup.exists()) await backup.delete();
    await source.rename(backup.path);
    try {
      await temporary.rename(path);
      final check = await openDatabase(path, password: key, singleInstance: false);
      final integrity = await check.rawQuery('PRAGMA quick_check');
      await check.close();
      if (integrity.isEmpty || integrity.first.values.first != 'ok') {
        throw StateError('فشل التحقق من النسخة المشفرة الناتجة');
      }
      // The caller removes the plaintext backup only after normal open succeeds.
    } catch (_) {
      final encrypted = File(path);
      if (await encrypted.exists()) await encrypted.delete();
      if (await backup.exists()) await backup.rename(path);
      if (await temporary.exists()) await temporary.delete();
      rethrow;
    }
  }

  Future<void> _applyStage9Indexes(DatabaseExecutor db) async {
    final columns = await db.rawQuery('PRAGMA table_info(receipts)');
    if (!columns.any((column) => column['name'] == 'law_164_2025_snapshot')) {
      await db.execute('ALTER TABLE receipts ADD COLUMN law_164_2025_snapshot INTEGER NOT NULL DEFAULT 0');
    }
    final statements = <String>[
      'CREATE INDEX IF NOT EXISTS idx_payments_paid_at ON payments(paid_at)',
      'CREATE INDEX IF NOT EXISTS idx_expenses_month ON expenses(expense_date, archived_at)',
      'CREATE INDEX IF NOT EXISTS idx_increases_lease_date ON rent_increases(lease_id, effective_date, status)',
      'CREATE INDEX IF NOT EXISTS idx_notifications_entity_due ON notifications(entity_type, entity_id, due_at, status)',
      'CREATE INDEX IF NOT EXISTS idx_receipts_issued_at ON receipts(issued_at)',
      "INSERT OR IGNORE INTO schema_migrations(version, name) VALUES (3, 'reports_schedules_and_exchange_indexes')",
    ];
    for (final statement in statements) {
      await db.execute(statement);
    }
  }

  Future<void> _applyStage10Flags(DatabaseExecutor db) async {
    const tables = ['owners', 'ownership_shares', 'tenants', 'leases', 'expenses'];
    for (final table in tables) {
      final columns = await db.rawQuery('PRAGMA table_info($table)');
      if (!columns.any((column) => column['name'] == 'modified_unreviewed')) {
        await db.execute('ALTER TABLE $table ADD COLUMN modified_unreviewed INTEGER NOT NULL DEFAULT 0 CHECK (modified_unreviewed IN (0,1))');
      }
    }
    await db.insert('schema_migrations', {'version': 4, 'name': 'modified_flags_for_all_editable_records'}, conflictAlgorithm: ConflictAlgorithm.ignore);
  }

  Future<void> _applyStage11Documents(DatabaseExecutor db) async {
    final columns = await db.rawQuery('PRAGMA table_info(documents)');
    final names = columns.map((column) => column['name']).toSet();
    if (!names.contains('notes')) await db.execute('ALTER TABLE documents ADD COLUMN notes TEXT');
    if (!names.contains('version_group_id')) await db.execute('ALTER TABLE documents ADD COLUMN version_group_id TEXT');
    if (!names.contains('version_number')) await db.execute('ALTER TABLE documents ADD COLUMN version_number INTEGER NOT NULL DEFAULT 1');
    if (!names.contains('supersedes_document_id')) await db.execute('ALTER TABLE documents ADD COLUMN supersedes_document_id TEXT REFERENCES documents(id) ON DELETE RESTRICT');
    if (!names.contains('document_date')) await db.execute('ALTER TABLE documents ADD COLUMN document_date TEXT');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_documents_entity_versions ON documents(entity_type, entity_id, version_group_id, version_number)');
    await db.insert('schema_migrations', {'version': 5, 'name': 'document_versions_and_notes'}, conflictAlgorithm: ConflictAlgorithm.ignore);
  }

  Future<void> _applyStage3Integrity(DatabaseExecutor db) async {
    final statements = <String>[
      'CREATE INDEX IF NOT EXISTS idx_ownership_property_dates ON ownership_shares(property_id, valid_from, valid_to)',
      'CREATE INDEX IF NOT EXISTS idx_rent_history_lease_dates ON rent_history(lease_id, valid_from, valid_to)',
      'CREATE INDEX IF NOT EXISTS idx_expenses_date ON expenses(expense_date)',
      'CREATE INDEX IF NOT EXISTS idx_payments_period ON payments(period_start, period_end)',
      'CREATE INDEX IF NOT EXISTS idx_documents_entity ON documents(entity_type, entity_id)',
      'CREATE INDEX IF NOT EXISTS idx_units_review ON units(review_status, modified_unreviewed)',
      'CREATE INDEX IF NOT EXISTS idx_properties_review ON properties(review_status, modified_unreviewed)',
      'CREATE INDEX IF NOT EXISTS idx_leases_active ON leases(status, unit_id)',
      "CREATE TRIGGER IF NOT EXISTS approved_receipt_no_update BEFORE UPDATE ON receipts WHEN OLD.approved = 1 BEGIN SELECT RAISE(ABORT, 'approved_receipt_is_immutable'); END",
      "CREATE TRIGGER IF NOT EXISTS approved_receipt_no_delete BEFORE DELETE ON receipts WHEN OLD.approved = 1 BEGIN SELECT RAISE(ABORT, 'approved_receipt_is_immutable'); END",
      "INSERT OR IGNORE INTO schema_migrations(version, name) VALUES (2, 'stage3_integrity_and_history_protection')",
    ];
    for (final statement in statements) {
      await db.execute(statement);
    }
  }
}
