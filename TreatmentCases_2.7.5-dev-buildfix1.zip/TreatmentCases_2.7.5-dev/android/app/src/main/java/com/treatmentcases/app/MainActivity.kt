package com.treatmentcases.app

import android.app.Activity
import android.graphics.Paint
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.fragment.app.FragmentActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.draw.scale
import kotlinx.coroutines.delay
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontFamily
import android.graphics.Typeface
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.*

private val Navy=Color(0xFF1457B8);private val Teal=Color(0xFF0D9488);private val Bg=Color(0xFFF3F7FB)
private fun appLabel(ar:String,en:String,english:Boolean)=if(english) en else ar
private val fontOptions = listOf(
    "sans" to "عربي واضح (افتراضي)", "naskh" to "نسخي عربي", "serif" to "سيريـف",
    "mono" to "ثابت", "cursive" to "مائل", "condensed" to "مضغوط",
    "rounded" to "مستدير", "light" to "خفيف", "medium" to "متوسط", "black" to "عريض جداً"
)
private val paletteOptions = listOf(
    "blue" to "أزرق طبي", "green" to "أخضر هادئ", "purple" to "بنفسجي",
    "teal" to "تركواز", "indigo" to "نيلي", "rose" to "وردي هادئ",
    "amber" to "ذهبي", "slate" to "رمادي أزرق"
)
private val backgroundOptions = listOf(
    "white" to "أبيض نقي", "sky" to "أزرق سماوي واضح", "mint" to "أخضر نعناعي",
    "lavender" to "بنفسجي فاتح", "cream" to "كريمي دافئ", "rose" to "وردي فاتح",
    "slate" to "رمادي مزرق", "aqua" to "فيروزي فاتح"
)
private val themePresetOptions = listOf(
    "clinic" to "1. الطبي الأبيض — فاتح",
    "forest" to "2. الأخضر الطبي — فاتح",
    "lavender" to "3. البنفسجي المتوازن — متوسط",
    "midnight" to "4. الأزرق الليلي — داكن",
    "graphite" to "5. الفحمي الذهبي — داكن"
)
private fun appTypeface(choice:String): Typeface = Typeface.create(when(choice){
    "naskh","serif"->"serif"; "mono"->"monospace"; "cursive"->"casual";
    "condensed"->"sans-serif-condensed"; "rounded"->"sans-serif-rounded";
    "light"->"sans-serif-light"; "medium"->"sans-serif-medium"; "black"->"sans-serif-black"; else->"sans-serif"
}, Typeface.NORMAL)
private fun appTypography(family:FontFamily,bold:Boolean=false):Typography {
    val t=Typography(); val weight=if(bold) FontWeight.Bold else FontWeight.Normal
    return t.copy(
        displayLarge=t.displayLarge.copy(fontFamily=family,fontWeight=weight),displayMedium=t.displayMedium.copy(fontFamily=family,fontWeight=weight),displaySmall=t.displaySmall.copy(fontFamily=family,fontWeight=weight),
        headlineLarge=t.headlineLarge.copy(fontFamily=family,fontWeight=weight),headlineMedium=t.headlineMedium.copy(fontFamily=family,fontWeight=weight),headlineSmall=t.headlineSmall.copy(fontFamily=family,fontWeight=weight),
        titleLarge=t.titleLarge.copy(fontFamily=family,fontWeight=weight),titleMedium=t.titleMedium.copy(fontFamily=family,fontWeight=weight),titleSmall=t.titleSmall.copy(fontFamily=family,fontWeight=weight),
        bodyLarge=t.bodyLarge.copy(fontFamily=family,fontWeight=weight),bodyMedium=t.bodyMedium.copy(fontFamily=family,fontWeight=weight),bodySmall=t.bodySmall.copy(fontFamily=family,fontWeight=weight),
        labelLarge=t.labelLarge.copy(fontFamily=family,fontWeight=weight),labelMedium=t.labelMedium.copy(fontFamily=family,fontWeight=weight),labelSmall=t.labelSmall.copy(fontFamily=family,fontWeight=weight)
    )
}
private fun accentColor(choice:String)=when(choice){
    "green"->Color(0xFF087F6A); "purple"->Color(0xFF6941A5); "teal"->Color(0xFF007C91);
    "indigo"->Color(0xFF3949AB); "rose"->Color(0xFFAD496B); "amber"->Color(0xFF9A6500);
    "slate"->Color(0xFF455A64); else->Navy
}
private fun appBackground(choice:String)=when(choice){
    "sky"->Color(0xFFE1F0FF); "mint"->Color(0xFFDFF3E8); "lavender"->Color(0xFFECE4F7);
    "cream"->Color(0xFFFFF0D6); "rose"->Color(0xFFFBE1E8); "slate"->Color(0xFFE0E8F0);
    "aqua"->Color(0xFFD8F1F0); else->Color.White
}
@Composable private fun PreferenceDropdown(label:String, selected:String, options:List<Pair<String,String>>, onSelected:(String)->Unit){
    var expanded by remember { mutableStateOf(false) }
    Column(verticalArrangement=Arrangement.spacedBy(3.dp)) {
        Text(label,fontWeight=FontWeight.SemiBold)
        Box(Modifier.fillMaxWidth()) {
            OutlinedButton(onClick={expanded=true},modifier=Modifier.fillMaxWidth(),contentPadding=PaddingValues(horizontal=12.dp,vertical=8.dp)) {
                Text(options.firstOrNull{it.first==selected}?.second ?: options.first().second,Modifier.weight(1f))
                Icon(Icons.Default.ArrowDropDown,null)
            }
            DropdownMenu(expanded=expanded,onDismissRequest={expanded=false},modifier=Modifier.fillMaxWidth(.88f)) {
                options.forEach { option -> DropdownMenuItem(text={Text(option.second)},onClick={onSelected(option.first);expanded=false}) }
            }
        }
    }
}

private const val MAX_BACKUP_BYTES = 64L * 1024L * 1024L
private fun readBackupBytes(context: android.content.Context, uri: Uri): ByteArray {
    val out = java.io.ByteArrayOutputStream()
    context.contentResolver.openInputStream(uri)?.use { input ->
        val buffer = ByteArray(8192)
        var total = 0L
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            total += count
            require(total <= MAX_BACKUP_BYTES) { "حجم ملف النسخة أكبر من الحد المسموح (64 ميجابايت)" }
            out.write(buffer, 0, count)
        }
    } ?: error("تعذر فتح ملف النسخة الاحتياطية")
    return out.toByteArray()
}
private fun promptFingerprint(activity:FragmentActivity,title:String,onSuccess:()->Unit,onError:(String)->Unit){
    val manager=BiometricManager.from(activity)
    val availability=manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG)
    if(availability!=BiometricManager.BIOMETRIC_SUCCESS){onError(when(availability){BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE->"هذا الهاتف لا يحتوي على مستشعر بصمة متوافق";BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE->"مستشعر البصمة غير متاح حالياً";BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED->"لا توجد بصمة مسجلة في إعدادات الهاتف";else->"المصادقة بالبصمة غير متاحة على هذا الهاتف"});return}
    val prompt=BiometricPrompt(activity,ContextCompat.getMainExecutor(activity),object:BiometricPrompt.AuthenticationCallback(){
        override fun onAuthenticationSucceeded(result:BiometricPrompt.AuthenticationResult){super.onAuthenticationSucceeded(result);onSuccess()}
        override fun onAuthenticationError(errorCode:Int,errString:CharSequence){super.onAuthenticationError(errorCode,errString);onError(errString.toString())}
        override fun onAuthenticationFailed(){super.onAuthenticationFailed();onError("لم يتم التعرف على البصمة؛ حاول مرة أخرى")}
    })
    val info=BiometricPrompt.PromptInfo.Builder().setTitle(title).setSubtitle("تحقق من هويتك للمتابعة").setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG).setNegativeButtonText("إلغاء").build()
    prompt.authenticate(info)
}

class MainActivity:FragmentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){
  super.onCreate(savedInstanceState)
  val db=LocalDb(this);val auth=AuthManager(this,db)
  val prefs=getSharedPreferences("app_preferences",MODE_PRIVATE)
  setContent {
   var darkTheme by remember{mutableStateOf(prefs.getBoolean("dark_theme",false))}
   var fontScale by remember{mutableFloatStateOf(prefs.getFloat("font_scale",1f).coerceIn(0.6f,1.4f))}
   var fontChoice by remember{mutableStateOf(prefs.getString("font_family","sans")?:"sans")}
   var paletteChoice by remember{mutableStateOf(prefs.getString("palette","blue")?:"blue")}
   var backgroundChoice by remember{mutableStateOf(prefs.getString("background","white")?:"white")}
   var fingerprintEnabled by remember{mutableStateOf(prefs.getBoolean("fingerprint_enabled",false))}
   var boldText by remember{mutableStateOf(prefs.getBoolean("bold_text",false))}
   val family=FontFamily(appTypeface(fontChoice))
   val primary=accentColor(paletteChoice)
   val secondary=when(paletteChoice){
    "green"->Color(0xFF42A58D);"purple"->Color(0xFF9B7BD0);"teal"->Color(0xFF42B8C3)
    "rose"->Color(0xFFD68AA2);"indigo"->Color(0xFF7986CB);"amber"->Color(0xFFD4A64A)
    "slate"->Color(0xFF78909C);else->Teal
   }
   val density=LocalDensity.current
   val lightBg=if(backgroundChoice=="white") Bg else appBackground(backgroundChoice)
   CompositionLocalProvider(LocalDensity provides androidx.compose.ui.unit.Density(density.density,fontScale)) {
    MaterialTheme(typography=appTypography(family,boldText),shapes=Shapes(small=RoundedCornerShape(12.dp),medium=RoundedCornerShape(18.dp),large=RoundedCornerShape(24.dp)),colorScheme=if(darkTheme) darkColorScheme(primary=primary,secondary=secondary,background=if(paletteChoice=="amber")Color(0xFF191A1F) else Color(0xFF101D2D),surface=if(paletteChoice=="amber")Color(0xFF292B32) else Color(0xFF1D3047)) else lightColorScheme(primary=primary,secondary=secondary,background=lightBg,surface=Color.White)) {
     // Apply the selected typeface AFTER MaterialTheme, otherwise MaterialTheme's typography overrides it.
     CompositionLocalProvider(androidx.compose.material3.LocalTextStyle provides androidx.compose.material3.LocalTextStyle.current.merge(TextStyle(fontFamily=family))) {
      AppGate(db,auth,darkTheme,
       {darkTheme=it;prefs.edit().putBoolean("dark_theme",it).apply()},
       {fontScale=it;prefs.edit().putFloat("font_scale",it).apply()},
       {fontChoice=it;prefs.edit().putString("font_family",it).apply()},
       {paletteChoice=it;prefs.edit().putString("palette",it).apply()},
       backgroundChoice,{backgroundChoice=it;prefs.edit().putString("background",it).apply()},
       fingerprintEnabled,{fingerprintEnabled=it;prefs.edit().putBoolean("fingerprint_enabled",it).apply()},
       boldText,{boldText=it;prefs.edit().putBoolean("bold_text",it).apply()})
     }
    }
   }
  }
 }
}
@Composable fun AppGate(
 db:LocalDb,auth:AuthManager,darkTheme:Boolean,onDarkThemeChange:(Boolean)->Unit,
 onFontScaleChange:(Float)->Unit,onFontChoiceChange:(String)->Unit,onPaletteChange:(String)->Unit,
 backgroundChoice:String,onBackgroundChange:(String)->Unit,fingerprintEnabled:Boolean,
 onFingerprintEnabledChange:(Boolean)->Unit,boldText:Boolean,onBoldTextChange:(Boolean)->Unit
){
 val gateContext=LocalContext.current
 val prefs=gateContext.getSharedPreferences("app_preferences",0)
 var unlocked by remember{mutableStateOf(false)}
 var configured by remember{mutableStateOf(auth.isConfigured())}
 var password by remember{mutableStateOf("")}
 var username by remember{mutableStateOf("admin")}
 var activationCode by remember{mutableStateOf("")}
 var confirm by remember{mutableStateOf("")}
 var accountMode by remember{mutableStateOf("login")}
 var session by remember{mutableStateOf<UserSession?>(null)}
 var error by remember{mutableStateOf("")}
 var english by remember{mutableStateOf(prefs.getString("ui_language","ar")=="en")}
 CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides if(english) androidx.compose.ui.unit.LayoutDirection.Ltr else androidx.compose.ui.unit.LayoutDirection.Rtl){
  if(unlocked) App(db,auth,session ?: UserSession(null,"admin","ADMIN",auth.permissionKeys),{db.setActiveSession("GUEST",emptySet());session=null;unlocked=false;password="";username="admin";accountMode="login"},darkTheme,onDarkThemeChange,onFontScaleChange,onFontChoiceChange,onPaletteChange,backgroundChoice,onBackgroundChange,fingerprintEnabled,onFingerprintEnabledChange,boldText,onBoldTextChange)
  else Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(24.dp),verticalArrangement=Arrangement.Center,horizontalAlignment=Alignment.CenterHorizontally){
   Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.End){TextButton(onClick={english=!english;prefs.edit().putString("ui_language",if(english)"en" else "ar").apply()}){Text(if(english)"العربية" else "English")}}
   Image(painterResource(id=R.drawable.ic_medical_brand),contentDescription=if(english)"Medical app logo" else "شعار التطبيق الطبي",modifier=Modifier.size(78.dp))
   Text(if(english)"Treatment Cases Haja" else "علاج الحالات حاجة",fontSize=25.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary)
   Text(if(!configured){if(english)"Create the administrator password" else "إنشاء كلمة مرور المدير لأول استخدام"}else if(accountMode=="activate"){if(english)"Activate delegated account" else "تفعيل حساب مستخدم مفوض"}else{if(english)"Sign in with your account" else "تسجيل الدخول بالحساب"},color=MaterialTheme.colorScheme.onSurfaceVariant)
   if(configured){OutlinedTextField(username,{username=it},Modifier.fillMaxWidth(),label={Text(if(english)"Username" else "اسم المستخدم")},singleLine=true)}
   if(accountMode=="activate"&&configured){OutlinedTextField(activationCode,{activationCode=it.uppercase()},Modifier.fillMaxWidth(),label={Text(if(english)"One-time activation code" else "رمز التفعيل لمرة واحدة")},singleLine=true)}
   OutlinedTextField(password,{password=it},Modifier.fillMaxWidth(),label={Text(if(english)"Password" else "كلمة المرور")},singleLine=true,visualTransformation=PasswordVisualTransformation())
   if(!configured || accountMode=="activate")OutlinedTextField(confirm,{confirm=it},Modifier.fillMaxWidth(),label={Text(if(english)"Confirm password" else "تأكيد كلمة المرور")},singleLine=true,visualTransformation=PasswordVisualTransformation())
   if(error.isNotBlank())Text(error,color=Color.Red)
   Button(onClick={
    if(!configured){if(password!=confirm)error=if(english)"Passwords do not match" else "كلمتا المرور غير متطابقتين" else if(auth.createAdmin(password)){configured=true;session=UserSession(null,"admin","ADMIN",auth.permissionKeys);db.setActiveSession("ADMIN",auth.permissionKeys);unlocked=true;error=""}else error=if(english)"Use at least 8 characters" else "استخدم كلمة مرور لا تقل عن 8 أحرف أو أرقام"}
    else if(accountMode=="activate"){if(password!=confirm)error=if(english)"Passwords do not match" else "كلمتا المرور غير متطابقتين" else if(auth.activate(username,activationCode,password)){accountMode="login";activationCode="";password="";confirm="";error=if(english)"Account activated. Sign in now." else "تم تفعيل الحساب؛ سجّل الدخول الآن"}else error=if(english)"Invalid, expired or already-used activation code" else "رمز التفعيل غير صحيح أو منتهي أو مستخدم من قبل"}
    else {val signed=auth.authenticate(username,password);if(signed!=null){session=signed;db.setActiveSession(signed.role,signed.permissions,signed.userId);unlocked=true;error=""}else error=if(english)"Incorrect credentials or disabled account" else "بيانات الدخول غير صحيحة أو الحساب موقوف"}
   },Modifier.fillMaxWidth()) {Text(if(!configured){if(english)"Create Administrator" else "إنشاء حساب المدير"}else if(accountMode=="activate"){if(english)"Activate Account" else "تفعيل الحساب"}else{if(english)"Sign In" else "دخول"})}
   if(configured){TextButton(onClick={accountMode=if(accountMode=="activate")"login" else "activate";error="";password="";confirm=""}){Text(if(accountMode=="activate")if(english)"Back to sign in" else "العودة لتسجيل الدخول" else if(english)"Activate a new account" else "تفعيل حساب جديد")}}
   if(configured&&fingerprintEnabled&&username.equals("admin",true)&&accountMode=="login")OutlinedButton(onClick={promptFingerprint(gateContext as FragmentActivity,if(english)"Administrator fingerprint sign in" else "دخول المدير بالبصمة",{session=UserSession(null,"admin","ADMIN",auth.permissionKeys);db.setActiveSession("ADMIN",auth.permissionKeys);unlocked=true;error=""},{error=it})},Modifier.fillMaxWidth()){Icon(Icons.Default.Fingerprint,null);Text(if(english)"Use fingerprint" else "الدخول بالبصمة")}
   Text(if(english)"Your data is protected locally on this device. Keep your password safe." else "الحماية محلية على هذا الهاتف؛ احتفظ بكلمة المرور في مكان آمن.",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
  }
 }
}

@Composable private fun UserManagementCard(auth:AuthManager,isEnglish:Boolean){
 var username by remember{mutableStateOf("")};var hours by remember{mutableStateOf("72")};var selected by remember{mutableStateOf(if("view_search" in auth.activePermissions())setOf("view_search") else auth.activePermissions().take(1).toSet())};var generated by remember{mutableStateOf("")};var message by remember{mutableStateOf("")};var refresh by remember{mutableIntStateOf(0)};var editing by remember{mutableStateOf<ManagedUser?>(null)};var editPermissions by remember{mutableStateOf(setOf<String>())}
 val labels=linkedMapOf("view_search" to ("العرض والبحث" to "View & search"),"add_edit" to ("الإضافة والتعديل" to "Add & edit"),"export_share" to ("التصدير والمشاركة" to "Export & share"),"import_excel" to ("استيراد Excel" to "Import Excel"),"manage_medicines" to ("إدارة الأدوية" to "Manage medicines"),"manage_users" to ("إدارة المستخدمين" to "Manage users"))
 Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceVariant),shape=RoundedCornerShape(14.dp)){
  Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){
   Text(if(isEnglish)"Delegated user accounts (this device only)" else "حسابات المستخدمين المفوضين (على هذا الجهاز فقط)",fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary)
   OutlinedTextField(username,{username=it},Modifier.fillMaxWidth(),singleLine=true,label={Text(if(isEnglish)"New username" else "اسم المستخدم الجديد")})
   OutlinedTextField(hours,{hours=it.filter(Char::isDigit)},Modifier.fillMaxWidth(),singleLine=true,label={Text(if(isEnglish)"Code validity in hours (1–720)" else "صلاحية الرمز بالساعات (1–720)")})
   labels.forEach{(key,label)->Row(verticalAlignment=Alignment.CenterVertically){Checkbox(checked=key in selected,enabled=key in auth.activePermissions(),onCheckedChange={checked->selected=if(checked)selected+key else selected-key});Text(if(isEnglish)label.second else label.first,fontSize=13.sp)}}
   Button(onClick={val code=auth.createActivationCode(username,selected,hours.toIntOrNull()?:72);if(code!=null){generated=code;message=if(isEnglish)"Show this code to the user once. It will not be retrievable later." else "اعرض الرمز للمستخدم الآن؛ لن يمكن استرجاعه لاحقاً.";username=""}else message=if(isEnglish)"Could not create code. Check username, permissions and validity." else "تعذر إنشاء الرمز؛ راجع اسم المستخدم والصلاحيات ومدة الصلاحية."},modifier=Modifier.fillMaxWidth(),enabled=selected.isNotEmpty()){Text(if(isEnglish)"Generate one-time activation code" else "إنشاء رمز تفعيل لمرة واحدة")}
   if(generated.isNotBlank()){Text(generated,fontSize=22.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary);Text(message,fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant);TextButton(onClick={generated=""}){Text(if(isEnglish)"Hide code" else "إخفاء الرمز")}}
   else if(message.isNotBlank())Text(message,fontSize=11.sp,color=MaterialTheme.colorScheme.error)
   Divider();Text(if(isEnglish)"Existing accounts" else "الحسابات الحالية",fontWeight=FontWeight.SemiBold)
   val users=remember(refresh){auth.users()}
   if(users.isEmpty())Text(if(isEnglish)"No delegated accounts yet." else "لا توجد حسابات مفوضة حتى الآن.",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
   users.forEach{u->Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(u.username,fontWeight=FontWeight.SemiBold);Text(if(u.active)if(isEnglish)"Active" else "نشط" else if(isEnglish)"Disabled" else "موقوف",fontSize=11.sp,color=if(u.active)MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.error);Text(u.permissions.mapNotNull{labels[it]?.let{v->if(isEnglish)v.second else v.first}}.joinToString(" • "),fontSize=10.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)};TextButton(onClick={editing=u;editPermissions=u.permissions}){Text(if(isEnglish)"Permissions" else "الصلاحيات")};TextButton(onClick={auth.setUserActive(u.id,!u.active);refresh++}){Text(if(u.active)if(isEnglish)"Disable" else "إيقاف" else if(isEnglish)"Enable" else "تفعيل")}}}
  }
 }
 if(editing!=null)AlertDialog(onDismissRequest={editing=null},title={Text(if(isEnglish)"Edit permissions — ${editing!!.username}" else "تعديل صلاحيات — ${editing!!.username}")},text={Column{labels.forEach{(key,label)->Row(verticalAlignment=Alignment.CenterVertically){Checkbox(checked=key in editPermissions,onCheckedChange={checked->editPermissions=if(checked)editPermissions+key else editPermissions-key});Text(if(isEnglish)label.second else label.first)}}}},confirmButton={Button(enabled=editPermissions.isNotEmpty(),onClick={if(auth.updatePermissions(editing!!.id,editPermissions)){refresh++;editing=null}}){Text(if(isEnglish)"Save" else "حفظ")}},dismissButton={TextButton(onClick={editing=null}){Text(if(isEnglish)"Cancel" else "إلغاء")}})
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun SyncMetric(label:String,value:Int,modifier:Modifier=Modifier){
 Surface(modifier=modifier,shape=RoundedCornerShape(12.dp),color=MaterialTheme.colorScheme.secondaryContainer){Column(Modifier.padding(9.dp),horizontalAlignment=Alignment.CenterHorizontally){Text(value.toString(),fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary,fontSize=18.sp);Text(label,fontSize=10.sp,color=MaterialTheme.colorScheme.onSecondaryContainer)}}
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun App(db:LocalDb,auth:AuthManager,session:UserSession,onLogout:()->Unit,darkTheme:Boolean,onDarkThemeChange:(Boolean)->Unit,onFontScaleChange:(Float)->Unit,onFontChoiceChange:(String)->Unit,onPaletteChange:(String)->Unit,backgroundChoice:String,onBackgroundChange:(String)->Unit,fingerprintEnabled:Boolean,onFingerprintEnabledChange:(Boolean)->Unit,boldText:Boolean,onBoldTextChange:(Boolean)->Unit){val ctx=LocalContext.current;var fontScale by remember{mutableFloatStateOf(ctx.getSharedPreferences("app_preferences",0).getFloat("font_scale",1f))};var fontChoice by remember{mutableStateOf(ctx.getSharedPreferences("app_preferences",0).getString("font_family","sans")?:"sans")};var paletteChoice by remember{mutableStateOf(ctx.getSharedPreferences("app_preferences",0).getString("palette","blue")?:"blue")};var backgroundChoiceLocal by remember{mutableStateOf(backgroundChoice)};var spacingLevel by remember{mutableFloatStateOf(ctx.getSharedPreferences("app_preferences",0).getFloat("spacing_percent",100f).coerceIn(50f,140f))};var themePresetChoice by remember{mutableStateOf(ctx.getSharedPreferences("app_preferences",0).getString("theme_preset",null)?:when{darkTheme&&paletteChoice=="amber"->"graphite";darkTheme->"midnight";paletteChoice=="green"->"forest";paletteChoice=="purple"->"lavender";else->"clinic"})};var changePasswordDialog by remember{mutableStateOf(false)};var resetMode by remember{mutableStateOf("")};var resetPhrase by remember{mutableStateOf("")};var resetPassword by remember{mutableStateOf("")};var currentPassword by remember{mutableStateOf("")};var newPassword by remember{mutableStateOf("")};var confirmPassword by remember{mutableStateOf("")};var settingsMessage by remember{mutableStateOf("")};var syncEndpoint by remember{mutableStateOf(SyncConnectionSettings(ctx).endpoint())};var syncToken by remember{mutableStateOf("")};var syncConfigured by remember{mutableStateOf(SyncConnectionSettings(ctx).token().isNotBlank())};var tick by remember{mutableIntStateOf(0)};var selectedSyncReview by remember{mutableStateOf<SyncReviewItem?>(null)};var isEnglish by remember{mutableStateOf(ctx.getSharedPreferences("app_preferences",0).getString("ui_language","ar")=="en")};var page by remember{mutableStateOf(if(session.can("view_search"))"الرئيسية" else if(session.can("add_edit"))"السجلات" else if(session.can("manage_medicines"))"الأدوية" else if(session.can("export_share"))"التقارير" else if(session.can("manage_users"))"المستخدمون" else if(session.can("import_excel"))"استيراد" else "الرئيسية")};var pageBeforeRecords by remember{mutableStateOf("الرئيسية")};var query by remember{mutableStateOf("")};var filter by remember{mutableStateOf("")};var edit by remember{mutableStateOf<CaseRecord?>(null)};var form by remember{mutableStateOf(false)};var msg by remember{mutableStateOf("")};var previewRows by remember{mutableStateOf<List<CaseRecord>?>(null)};var showMedicineAdd by remember{mutableStateOf(false)};var selectedMedicineDetails by remember{mutableStateOf<MedicineCatalogRecord?>(null)};var medicineNameCorrection by remember{mutableStateOf<MedicineCatalogRecord?>(null)};var medicineAuditReport by remember{mutableStateOf<List<String>?>(null)};var newMedicine by remember{mutableStateOf("")};var newStrengths by remember{mutableStateOf("")};var backupDialog by remember{mutableStateOf("")};var backupPassword by remember{mutableStateOf("")};var restoreBytes by remember{mutableStateOf<ByteArray?>(null)};var restorePreview by remember{mutableStateOf<BackupBundle?>(null)};var exportBackupBytes by remember{mutableStateOf<ByteArray?>(null)};var employeeQuery by remember{mutableStateOf("")};var medicineQuery by remember{mutableStateOf("")};var reportQuery by remember{mutableStateOf("")};var employeePlan by remember{mutableStateOf<EmployeeImportPlan?>(null)};var employeeEdit by remember{mutableStateOf<EmployeeRecord?>(null)};var showEmployeeForm by remember{mutableStateOf(false)};var reportDialog by remember{mutableStateOf(false)};var selectedReportMeds by remember{mutableStateOf<Set<String>>(emptySet())};var pendingReportRows by remember{mutableStateOf<List<CaseRecord>>(emptyList())};var pendingReportTitle by remember{mutableStateOf("تقرير الحالات الحرجة")}
 val applyThemePreset:(String)->Unit={preset->
  themePresetChoice=preset;ctx.getSharedPreferences("app_preferences",0).edit().putString("theme_preset",preset).apply()
  when(preset){
   "forest"->{paletteChoice="green";backgroundChoiceLocal="mint";onPaletteChange("green");onBackgroundChange("mint");onDarkThemeChange(false)}
   "lavender"->{paletteChoice="purple";backgroundChoiceLocal="slate";onPaletteChange("purple");onBackgroundChange("slate");onDarkThemeChange(false)}
   "midnight"->{paletteChoice="blue";backgroundChoiceLocal="slate";onPaletteChange("blue");onBackgroundChange("slate");onDarkThemeChange(true)}
   "graphite"->{paletteChoice="amber";backgroundChoiceLocal="slate";onPaletteChange("amber");onBackgroundChange("slate");onDarkThemeChange(true)}
   else->{paletteChoice="blue";backgroundChoiceLocal="white";onPaletteChange("blue");onBackgroundChange("white");onDarkThemeChange(false)}
  }
 }
 val meds=remember(tick){db.medicines()};val medicineCatalog=remember(tick){db.medicineCatalog()};val counts=remember(tick){db.counts()};val reportMeds=remember(meds,counts){meds.filter{(counts[it]?:0)>0}};val alerts=remember(tick){db.alerts()};val results=remember(tick,query,filter){db.search(query,filter)};val employeeResults=remember(tick,employeeQuery){db.employees(employeeQuery)};val medicineResults=remember(medicineCatalog,medicineQuery){val q=MedicineNameMatcher.key(medicineQuery);if(q.isBlank())medicineCatalog else medicineCatalog.filter{m->listOf(m.name,m.genericName,m.specialty,m.aliases,m.criticalClassification).any{MedicineNameMatcher.key(it).contains(q)}}};val visibleReportMeds=remember(reportMeds,reportQuery){val q=MedicineNameMatcher.key(reportQuery);if(q.isBlank())reportMeds else reportMeds.filter{MedicineNameMatcher.key(it).contains(q)}}
 LaunchedEffect(reportMeds){selectedReportMeds=selectedReportMeds.intersect(reportMeds.toSet())}
 val import=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){u->if(u!=null)try{val rows=Xlsx.read(ctx.contentResolver,u);previewRows=rows;msg="تمت قراءة ${rows.size} صفًا. راجعها قبل الاعتماد."}catch(e:Exception){msg="تعذر الاستيراد: ${e.message}"}}
 val caseTemplate=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")){u->if(u!=null)try{Xlsx.writeTemplate(ctx.contentResolver,u);msg="تم إنشاء نموذج الحالات الحرجة الفارغ. املأه ثم أعد استيراده."}catch(e:Exception){msg="تعذر إنشاء النموذج: ${e.message}"}}
 val export=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")){u->if(u!=null)try{val rows=pendingReportRows;Xlsx.write(rows,ctx.contentResolver,u);msg="تم تصدير ${rows.size} سجل إلى Excel"}catch(e:Exception){msg="خطأ التصدير: ${e.message}"}}
 val employeeImport=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){u->if(u!=null)try{val rows=EmployeeXlsx.read(ctx.contentResolver,u);employeePlan=db.planEmployeeImport(rows);msg="تم فحص ${rows.size} صفاً. راجع تقرير دليل العاملين قبل الاعتماد."}catch(e:Exception){msg="تعذر قراءة قالب دليل العاملين: ${e.message}"}}
 val employeeTemplate=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")){u->if(u!=null)try{EmployeeXlsx.writeTemplate(ctx.contentResolver,u);msg="تم إنشاء قالب دليل العاملين الفارغ"}catch(e:Exception){msg="تعذر إنشاء القالب: ${e.message}"}}
 val employeeExport=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")){u->if(u!=null)try{EmployeeXlsx.writeDirectory(ctx.contentResolver,u,db.employees());msg="تم تصدير دليل العاملين"}catch(e:Exception){msg="تعذر تصدير الدليل: ${e.message}"}}
 val backupSave=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")){u->if(u!=null&&exportBackupBytes!=null)try{ctx.contentResolver.openOutputStream(u)?.use{it.write(exportBackupBytes!!)};msg="تم حفظ النسخة الاحتياطية المشفرة"}catch(e:Exception){msg="تعذر حفظ النسخة: ${e.message}"};exportBackupBytes=null}
 val backupOpen=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){u->if(u!=null)try{restoreBytes=readBackupBytes(ctx,u);backupDialog="restore"}catch(e:Exception){msg="تعذر قراءة النسخة: ${e.message}"}}
 val pdf=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")){u->if(u!=null)try{val rows=pendingReportRows;pdfReport(ctx as Activity,u,rows,pendingReportTitle);msg="تم إنشاء PDF يضم ${rows.size} سجل"}catch(e:Exception){msg="تعذر إنشاء PDF: ${e.message}"}}
 LaunchedEffect(page){
  val allowed=when(page){"الرئيسية"->session.can("view_search");"السجلات"->session.can("view_search")||session.can("add_edit");"العاملون"->session.can("view_search")||session.can("add_edit");"الأدوية"->session.can("view_search")||session.can("manage_medicines");"التقارير"->session.can("export_share");"المستخدمون"->session.can("manage_users");"استيراد"->session.can("import_excel");"الإعدادات"->session.isAdmin;else->true}
  if(!allowed)page=if(session.can("view_search"))"الرئيسية" else if(session.can("add_edit"))"السجلات" else if(session.can("manage_medicines"))"الأدوية" else if(session.can("export_share"))"التقارير" else if(session.can("manage_users"))"المستخدمون" else if(session.can("import_excel"))"استيراد" else "الرئيسية"
 }
 BackHandler(enabled=page!="الرئيسية"||form||reportDialog||backupDialog.isNotBlank()||restorePreview!=null||previewRows!=null||showMedicineAdd||selectedMedicineDetails!=null||medicineNameCorrection!=null||medicineAuditReport!=null||showEmployeeForm||changePasswordDialog){when{changePasswordDialog->{changePasswordDialog=false;currentPassword="";newPassword="";confirmPassword=""};showMedicineAdd->showMedicineAdd=false;selectedMedicineDetails!=null->selectedMedicineDetails=null;medicineNameCorrection!=null->medicineNameCorrection=null;medicineAuditReport!=null->medicineAuditReport=null;showEmployeeForm->showEmployeeForm=false;previewRows!=null->previewRows=null;restorePreview!=null->restorePreview=null;backupDialog.isNotBlank()->{backupDialog="";backupPassword=""};reportDialog->reportDialog=false;form->form=false;page=="السجلات"->{filter="";page=pageBeforeRecords};page=="العاملون"->page=if(session.isAdmin)"الإعدادات" else if(session.can("view_search"))"الرئيسية" else "السجلات";page!="الرئيسية"->page="الرئيسية"}}
 CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides if(isEnglish) androidx.compose.ui.unit.LayoutDirection.Ltr else androidx.compose.ui.unit.LayoutDirection.Rtl) {
 Scaffold(topBar={TopAppBar(title={Column(verticalArrangement=Arrangement.spacedBy(1.dp)){Text(appLabel("علاج الحالات حاجة","Treatment Cases Haja",isEnglish),fontWeight=FontWeight.Bold,style=MaterialTheme.typography.titleLarge);Text(appLabel("إدارة الحالات والأدوية","Cases & Medicine Management",isEnglish),fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)}},navigationIcon={Image(painter=painterResource(id=R.drawable.ic_medical_brand),contentDescription=appLabel("شعار التطبيق الطبي","Medical app logo",isEnglish),modifier=Modifier.padding(start=10.dp).size(34.dp))},actions={TextButton(onClick={isEnglish=!isEnglish;ctx.getSharedPreferences("app_preferences",0).edit().putString("ui_language",if(isEnglish)"en" else "ar").apply()}){Text(if(isEnglish)"عربي" else "EN",fontWeight=FontWeight.Bold)};if(session.can("view_search")||session.can("add_edit"))IconButton(onClick={page="السجلات";filter="";query=""}){Icon(Icons.Default.Search,appLabel("بحث شامل","Global search",isEnglish))};if(session.isAdmin)IconButton(onClick={page="الإعدادات"}){Icon(Icons.Default.Settings,appLabel("الإعدادات","Settings",isEnglish))};IconButton(onClick=onLogout){Icon(Icons.Default.Logout,appLabel("تسجيل الخروج","Sign out",isEnglish))}},colors=TopAppBarDefaults.topAppBarColors(containerColor=MaterialTheme.colorScheme.surface))},bottomBar={NavigationBar(containerColor=MaterialTheme.colorScheme.surface,tonalElevation=7.dp){listOf("الرئيسية","السجلات","الأدوية","التقارير","المستخدمون","استيراد","الإعدادات").filter{p->session.isAdmin || when(p){"الرئيسية"->session.can("view_search");"السجلات"->session.can("view_search")||session.can("add_edit");"الأدوية"->session.can("manage_medicines")||session.can("view_search");"التقارير"->session.can("export_share");"المستخدمون"->session.can("manage_users");"استيراد"->session.can("import_excel");else->false}}.forEach{p->NavigationBarItem(selected=page==p,onClick={page=p;filter="";query=""},icon={Icon(when(p){"الرئيسية"->Icons.Default.Home;"السجلات"->Icons.Default.People;"الأدوية"->Icons.Default.Medication;"التقارير"->Icons.Default.Assessment;"المستخدمون"->Icons.Default.ManageAccounts;"استيراد"->Icons.Default.FileOpen;else->Icons.Default.Settings},null)},label={Text(when(p){"الرئيسية"->appLabel("الرئيسية","Home",isEnglish);"السجلات"->appLabel("السجلات","Records",isEnglish);"الأدوية"->appLabel("الأدوية","Medicines",isEnglish);"التقارير"->appLabel("التقارير","Reports",isEnglish);"المستخدمون"->appLabel("المستخدمون","Users",isEnglish);"استيراد"->appLabel("استيراد","Import",isEnglish);else->appLabel("الإعدادات","Settings",isEnglish)},fontWeight=if(page==p)FontWeight.Bold else FontWeight.Normal)},alwaysShowLabel=true)}}}){pad->Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(pad).padding((12f * spacingLevel / 100f).dp)){
 if(msg.isNotBlank()){Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceVariant)){Row(Modifier.padding(9.dp),verticalAlignment=Alignment.CenterVertically){Text(msg,Modifier.weight(1f));TextButton(onClick={msg=""}){Text("إغلاق")}}}}
 when(page){"الرئيسية"->{Column(Modifier.fillMaxSize(),verticalArrangement=Arrangement.spacedBy(12.dp)){
 DashboardHero(isEnglish=isEnglish, onOpenRecords={page="السجلات"})
 Row(horizontalArrangement=Arrangement.spacedBy(9.dp)){DynamicStatCard(appLabel("إجمالي السجلات","Total Records",isEnglish),db.count(),Icons.Default.Groups,Color(0xFF1769D2),Modifier.weight(1f));DynamicStatCard(appLabel("الأدوية المسجلة","Listed Medicines",isEnglish),meds.size,Icons.Default.Medication,Color(0xFF078A78),Modifier.weight(1f))}
 Text(appLabel("الوصول السريع","Quick Access" ,isEnglish),fontWeight=FontWeight.Bold,fontSize=18.sp,color=MaterialTheme.colorScheme.primary)
 Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){DashboardShortcut(appLabel("السجلات","Records",isEnglish),appLabel("بحث وإضافة","Search & Add",isEnglish),Icons.Default.People,Modifier.weight(1f)){page="السجلات";filter=""};DashboardShortcut(appLabel("دليل العاملين","Staff Directory",isEnglish),appLabel("بيانات العاملين","Staff Details",isEnglish),Icons.Default.Badge,Modifier.weight(1f)){page="العاملون"}}
 Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){DashboardShortcut(appLabel("قاموس الأدوية","Medicine Catalog",isEnglish),appLabel("الأسماء والعيارات","Names & Strengths",isEnglish),Icons.Default.Medication,Modifier.weight(1f)){page="الأدوية"};DashboardShortcut(appLabel("التقارير","Reports",isEnglish),appLabel("طباعة وتصدير","Print & Export",isEnglish),Icons.Default.Assessment,Modifier.weight(1f)){page="التقارير"}}
 Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){Row(verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.FactCheck,null,tint=MaterialTheme.colorScheme.primary);Spacer(Modifier.width(7.dp));Text(appLabel("مراجعة جودة البيانات","Data Quality Review",isEnglish),fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary);Spacer(Modifier.weight(1f));Surface(shape=RoundedCornerShape(50),color=if(alerts.isEmpty())MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.errorContainer){Text(if(isEnglish)"${alerts.size} alerts" else "${alerts.size} تنبيه",Modifier.padding(horizontal=10.dp,vertical=4.dp),fontSize=11.sp,fontWeight=FontWeight.Bold)}};if(alerts.isEmpty())Text(appLabel("لا توجد تنبيهات أساسية حالياً","No critical data alerts",isEnglish),color=MaterialTheme.colorScheme.secondary,fontSize=12.sp) else alerts.forEach{Text("• $it",fontSize=12.sp,color=MaterialTheme.colorScheme.tertiary)}}};Row(verticalAlignment=Alignment.CenterVertically){Text(appLabel("الأدوية المسجلة","Medicines in Use",isEnglish),Modifier.weight(1f),fontWeight=FontWeight.Bold,fontSize=17.sp,color=MaterialTheme.colorScheme.primary);TextButton(onClick={page="الأدوية"}){Text(appLabel("عرض الكل","View All",isEnglish))}};LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy((6f * spacingLevel / 100f).dp)){items(meds){m->Card(Modifier.fillMaxWidth().clickable{pageBeforeRecords="الرئيسية";filter=m;page="السجلات"},shape=RoundedCornerShape(16.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){Row(Modifier.padding(horizontal=15.dp,vertical=12.dp),verticalAlignment=Alignment.CenterVertically){Surface(shape=RoundedCornerShape(12.dp),color=MaterialTheme.colorScheme.secondaryContainer){Icon(Icons.Default.Medication,null,tint=MaterialTheme.colorScheme.secondary,modifier=Modifier.padding(9.dp).size(22.dp))};Spacer(Modifier.width(12.dp));Text(m,Modifier.weight(1f),fontWeight=FontWeight.SemiBold,color=MaterialTheme.colorScheme.onSurface);Text((counts[m]?:0).toString(),fontSize=21.sp,color=MaterialTheme.colorScheme.primary,fontWeight=FontWeight.Bold)}}}};if(meds.isEmpty())Text("أضف سجلًا جديدًا أو استورد ملف Excel من الإعدادات.",color=MaterialTheme.colorScheme.onSurfaceVariant)}}
 "السجلات"->{
  Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(appLabel("السجلات والبحث","Records & Search",isEnglish),fontSize=22.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary);Text(appLabel("بحث سريع بالاسم أو رقم الأداء أو الدواء","Search by name, employee number or medicine",isEnglish),fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)};Surface(shape=RoundedCornerShape(12.dp),color=MaterialTheme.colorScheme.secondaryContainer){Text("${results.size} نتيجة",Modifier.padding(horizontal=10.dp,vertical=7.dp),fontSize=12.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.onSecondaryContainer)}}
  OutlinedTextField(query,{query=it},Modifier.fillMaxWidth(),label={Text(appLabel("الاسم أو رقم الأداء أو الدواء","Name, employee number or medicine",isEnglish))},singleLine=true,leadingIcon={Icon(Icons.Default.Search,null)},trailingIcon={if(query.isNotBlank())IconButton(onClick={query=""}){Icon(Icons.Default.Close,appLabel("مسح البحث","Clear search",isEnglish))}})
  if(filter.isNotBlank())Row(verticalAlignment=Alignment.CenterVertically){Text(appLabel("الفلتر: $filter","Filter: $filter",isEnglish),Modifier.weight(1f),fontSize=12.sp,color=MaterialTheme.colorScheme.secondary);TextButton(onClick={filter=""}){Text(appLabel("إلغاء الفلتر","Clear filter",isEnglish))}}
  if(results.isEmpty())Box(Modifier.weight(1f).fillMaxWidth(),contentAlignment=Alignment.Center){Column(horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(6.dp)){Icon(Icons.Default.SearchOff,null,tint=MaterialTheme.colorScheme.onSurfaceVariant,modifier=Modifier.size(38.dp));Text(if(query.isBlank()&&filter.isBlank())appLabel("لا توجد سجلات بعد","No records yet",isEnglish) else appLabel("لا توجد نتائج مطابقة","No matching results",isEnglish),fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.onSurfaceVariant);Text(appLabel("يمكنك إضافة مستفيد جديد أو تعديل كلمات البحث.","Add a new beneficiary or refine your search.",isEnglish),fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)}}
  else LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy((5f * spacingLevel / 100f).dp)){items(results){r->RecordCard(r,{if(session.can("add_edit")){edit=r;form=true}},{if(session.can("add_edit"))try{db.delete(r.id);db.log("حذف",r.performanceNo);tick++}catch(e:Exception){msg="لا تملك صلاحية الحذف أو تعذر التنفيذ"}},medicineCatalog.firstOrNull{it.name.equals(r.medicine,true)},isEnglish)}}
  Button(enabled=session.can("add_edit"),onClick={edit=null;form=true},modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp)){Icon(Icons.Default.Add,null);Text(appLabel("إضافة مستفيد","Add Beneficiary",isEnglish))}
 }
 "العاملون"->{
  Row(verticalAlignment=Alignment.CenterVertically){Text(appLabel("دليل العاملين بالشركة","Staff Directory",isEnglish),Modifier.weight(1f),fontSize=22.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary);IconButton(onClick={page=if(session.isAdmin)"الإعدادات" else if(session.can("view_search"))"الرئيسية" else "السجلات"}){Icon(Icons.Default.ArrowBack,null,tint=MaterialTheme.colorScheme.primary)};if(session.can("add_edit"))IconButton(onClick={employeeEdit=null;showEmployeeForm=true}){Icon(Icons.Default.PersonAdd,null,tint=MaterialTheme.colorScheme.secondary)}}
  Text(appLabel("دليل موحد للعاملين، سواء كانوا يتلقون علاجاً أم لا.","A unified directory of all staff members, whether receiving treatment or not.",isEnglish),color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=12.sp)
  Row(horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically){Stat(appLabel("إجمالي العاملين","Total Staff",isEnglish),db.employeeCount().toString(),Modifier.weight(1f));Stat(appLabel("نتائج البحث","Search Results",isEnglish),employeeResults.size.toString(),Modifier.weight(1f))}
  OutlinedTextField(employeeQuery,{employeeQuery=it},Modifier.fillMaxWidth(),label={Text(appLabel("ابحث بالاسم أو رقم الأداء أو الوظيفة","Search by name, employee number or job",isEnglish))},singleLine=true,leadingIcon={Icon(Icons.Default.Search,null)},trailingIcon={if(employeeQuery.isNotBlank())IconButton(onClick={employeeQuery=""}){Icon(Icons.Default.Close,appLabel("مسح البحث","Clear search",isEnglish))}})
  Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){Button(enabled=session.can("import_excel"),onClick={employeeTemplate.launch("قالب_دليل_العاملين_فارغ.xlsx")},modifier=Modifier.weight(1f)){Text(appLabel("قالب فارغ","Blank Template",isEnglish))};OutlinedButton(enabled=session.can("import_excel")&&session.can("add_edit"),onClick={employeeImport.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))},modifier=Modifier.weight(1f)){Text(appLabel("استيراد","Import",isEnglish))}}
  OutlinedButton(enabled=session.can("export_share"),onClick={employeeExport.launch("دليل_العاملين.xlsx")},modifier=Modifier.fillMaxWidth()){Text(appLabel("تصدير الدليل الحالي","Export Current Directory",isEnglish))}
  LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(6.dp)){items(employeeResults){e->Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){Column(Modifier.padding(10.dp)){Row(verticalAlignment=Alignment.CenterVertically){Text(e.name,Modifier.weight(1f),fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary);if(session.can("add_edit"))IconButton(onClick={employeeEdit=e;showEmployeeForm=true}){Icon(Icons.Default.Edit,null,tint=MaterialTheme.colorScheme.secondary)}};Text("رقم الأداء: ${e.performanceNo} • ${e.job}",fontSize=12.sp,color=MaterialTheme.colorScheme.secondary);Text("${e.entity} • ${e.department}",fontSize=12.sp);Text("${e.gender} • ${e.age?.let{"العمر $it سنة"}?:"العمر غير متاح"}",fontSize=12.sp);if(e.serviceStatus.isNotBlank())Text(e.serviceStatus,color=MaterialTheme.colorScheme.tertiary,fontWeight=FontWeight.Bold)}}}}
 }
 "الأدوية"->{
  Row(verticalAlignment=Alignment.CenterVertically){Text(appLabel("قاموس الأدوية","Medicine Catalog",isEnglish),Modifier.weight(1f),fontSize=22.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary);TextButton(onClick={medicineAuditReport=db.medicineCatalogReviewReport()+listOf("— سجل تصحيحات الأسماء المعتمدة —")+db.medicineNameHistoryReport()}){Text(appLabel("تقرير المراجعة","Audit Report",isEnglish))};if(session.can("manage_medicines"))IconButton(onClick={showMedicineAdd=true}){Icon(Icons.Default.AddCircle,null,tint=MaterialTheme.colorScheme.secondary)}}
  Text(appLabel("ابحث بالاسم التجاري أو المادة الفعالة أو التصنيف أو أحد الأسماء البديلة، ثم افتح الدواء لمراجعة العيارات والبيانات.","Search by brand name, active ingredient, category or alias, then open a medicine to review strengths and details.",isEnglish),color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=12.sp)
  OutlinedTextField(medicineQuery,{medicineQuery=it},Modifier.fillMaxWidth(),label={Text(appLabel("بحث في قاموس الأدوية","Search Medicine Catalog",isEnglish))},singleLine=true,leadingIcon={Icon(Icons.Default.Search,null)},trailingIcon={if(medicineQuery.isNotBlank())IconButton(onClick={medicineQuery=""}){Icon(Icons.Default.Close,appLabel("مسح البحث","Clear search",isEnglish))}})
  Text(appLabel("${medicineResults.size} دواء من أصل ${medicineCatalog.size}","${medicineResults.size} of ${medicineCatalog.size} medicines",isEnglish),fontSize=11.sp,color=MaterialTheme.colorScheme.secondary,fontWeight=FontWeight.SemiBold)
  if(medicineResults.isEmpty())Box(Modifier.weight(1f).fillMaxWidth(),contentAlignment=Alignment.Center){Text(appLabel("لا توجد أدوية مطابقة للبحث","No matching medicines",isEnglish),color=MaterialTheme.colorScheme.onSurfaceVariant)}
  else LazyColumn(Modifier.weight(1f)){items(medicineResults){m->
   val strengthSummary=db.strengthsForMedicine(m.name).joinToString("، ").ifBlank { "غير محددة" }
   Card(Modifier.fillMaxWidth().clickable{selectedMedicineDetails=m},shape=RoundedCornerShape(17.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),elevation=CardDefaults.cardElevation(defaultElevation=2.dp)) {
    Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(11.dp)) {
     Surface(shape=RoundedCornerShape(14.dp),color=MaterialTheme.colorScheme.secondaryContainer,modifier=Modifier.size(46.dp)) { Box(contentAlignment=Alignment.Center){Icon(Icons.Default.Medication,null,tint=MaterialTheme.colorScheme.onSecondaryContainer,modifier=Modifier.size(25.dp))} }
     Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(3.dp)) {
      Text(m.name,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary,fontSize=15.sp)
      Text("${counts[m.name]?:0} ${if(isEnglish)"beneficiaries" else "مستفيد"} • ${m.genericName.ifBlank { if(isEnglish)"Active ingredient under review" else "المادة الفعالة غير مسجلة" }}",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
      Text("${if(isEnglish)"Strengths" else "العيارات"}: $strengthSummary",fontSize=11.sp,color=MaterialTheme.colorScheme.secondary,maxLines=2)
      if(m.reviewStatus.isNotBlank())Text(if(isEnglish)"Review: ${m.reviewStatus}" else "حالة المراجعة: ${m.reviewStatus}",fontSize=10.sp,color=MaterialTheme.colorScheme.tertiary,maxLines=1)
     }
     Icon(Icons.Default.ChevronRight,null,tint=MaterialTheme.colorScheme.secondary)
    }
   }
  }}
 }
 "التقارير"->{
  Text(appLabel("مركز تقارير الأدوية","Medicine Reports Center",isEnglish),fontSize=22.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary)
  Text(appLabel("اختر دواءً واحداً أو عدة أدوية أو جميع الأدوية، ثم صدّر القائمة نفسها إلى PDF أو Excel.","Select one, several or all medicines, then export the same selection to PDF or Excel.",isEnglish),fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
  OutlinedTextField(reportQuery,{reportQuery=it},Modifier.fillMaxWidth(),label={Text(appLabel("ابحث عن دواء داخل قائمة التقرير","Search medicines in this report",isEnglish))},singleLine=true,leadingIcon={Icon(Icons.Default.Search,null)},trailingIcon={if(reportQuery.isNotBlank())IconButton(onClick={reportQuery=""}){Icon(Icons.Default.Close,appLabel("مسح البحث","Clear search",isEnglish))}})
  Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) { OutlinedButton(onClick={selectedReportMeds=reportMeds.toSet()}){Text(appLabel("اختيار الكل","Select All",isEnglish))}; TextButton(onClick={selectedReportMeds=selectedReportMeds+visibleReportMeds}){Text(appLabel("اختيار النتائج","Select Results",isEnglish))}; TextButton(onClick={selectedReportMeds=emptySet()}){Text(appLabel("مسح","Clear",isEnglish))} }
  Text(appLabel("المحدد: ${selectedReportMeds.size} من ${reportMeds.size} دواءً • المعروض: ${visibleReportMeds.size}","Selected: ${selectedReportMeds.size} of ${reportMeds.size} • Visible: ${visibleReportMeds.size}",isEnglish),color=MaterialTheme.colorScheme.primary,fontWeight=FontWeight.Bold,fontSize=12.sp)
  LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy((2f * spacingLevel / 100f).dp)) { items(visibleReportMeds) { medicine -> Row(Modifier.fillMaxWidth().clickable{selectedReportMeds=if(medicine in selectedReportMeds)selectedReportMeds-medicine else selectedReportMeds+medicine}.padding(vertical=(2f * spacingLevel / 100f).dp),verticalAlignment=Alignment.CenterVertically){Checkbox(checked=medicine in selectedReportMeds,onCheckedChange={checked->selectedReportMeds=if(checked)selectedReportMeds+medicine else selectedReportMeds-medicine});Column(Modifier.weight(1f)){Text(medicine,fontWeight=FontWeight.SemiBold);Text("${counts[medicine]?:0} سجل",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)}} } }
  Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxWidth()) {
   Button(enabled=session.can("export_share")&&selectedReportMeds.isNotEmpty(),onClick={pendingReportRows=db.all().filter{it.medicine in selectedReportMeds};pendingReportTitle=if(selectedReportMeds.size==reportMeds.size)"تقرير جميع الأدوية" else "تقرير الأدوية المختارة";pdf.launch("تقرير_الأدوية_المختارة.pdf")},modifier=Modifier.weight(1f)){Icon(Icons.Default.PictureAsPdf,null);Text(appLabel("تصدير PDF","Export PDF",isEnglish))}
   OutlinedButton(enabled=session.can("export_share")&&selectedReportMeds.isNotEmpty(),onClick={pendingReportRows=db.all().filter{it.medicine in selectedReportMeds};pendingReportTitle=if(selectedReportMeds.size==reportMeds.size)"تقرير جميع الأدوية" else "تقرير الأدوية المختارة";export.launch("تقرير_الأدوية_المختارة.xlsx")},modifier=Modifier.weight(1f)){Icon(Icons.Default.TableView,null);Text(appLabel("تصدير Excel","Export Excel",isEnglish))}
  }
  if(reportMeds.isEmpty())Text("لا توجد أدوية لها سجلات حالياً.",color=MaterialTheme.colorScheme.onSurfaceVariant)
 }
 "استيراد"->{
  Column(Modifier.fillMaxSize(),verticalArrangement=Arrangement.spacedBy(10.dp)){
   Text(appLabel("استيراد البيانات","Import Data",isEnglish),fontSize=22.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary)
   Text(appLabel("أنشئ قالباً فارغاً، املأه، ثم استورده بعد المعاينة والتحقق. يتطلب اعتماد البيانات صلاحية الاستيراد وصلاحية الإضافة والتعديل.","Create a blank template, fill it, then import it after preview and validation. Committing data requires both import and domain write permission.",isEnglish),fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
   Button(onClick={caseTemplate.launch("نموذج_الحالات_الحرجة_فارغ.xlsx")},modifier=Modifier.fillMaxWidth()){Text(appLabel("تنزيل قالب الحالات الحرجة","Create cases template",isEnglish))}
   OutlinedButton(enabled=session.can("import_excel")&&session.can("add_edit"),onClick={import.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))},modifier=Modifier.fillMaxWidth()){Text(appLabel("استيراد حالات من Excel","Import cases from Excel",isEnglish))}
   Divider()
   Button(onClick={employeeTemplate.launch("قالب_دليل_العاملين_فارغ.xlsx")},modifier=Modifier.fillMaxWidth()){Text(appLabel("تنزيل قالب دليل العاملين","Create staff template",isEnglish))}
   OutlinedButton(enabled=session.can("import_excel")&&session.can("add_edit"),onClick={employeeImport.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))},modifier=Modifier.fillMaxWidth()){Text(appLabel("استيراد دليل العاملين","Import staff directory",isEnglish))}
  }
 }
 "المستخدمون"->{
  Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)){
   Text(appLabel("إدارة الحسابات المفوضة","Delegated Account Management",isEnglish),fontSize=22.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary)
   UserManagementCard(auth,isEnglish)
  }
 }
 "الإعدادات"->{
  Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)) {
   Text(appLabel("الإعدادات العامة","General Settings",isEnglish),fontSize=22.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary)
   Text(appLabel("خصص شكل التطبيق وطريقة عرضه وحماية الدخول.","Customize the app appearance, display and sign-in security.",isEnglish),color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=12.sp)
   val syncStats=db.syncDiagnostics()
   Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),shape=RoundedCornerShape(18.dp)) {
    Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(7.dp)) {
     Row(verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.CloudSync,null,tint=MaterialTheme.colorScheme.primary);Spacer(Modifier.width(8.dp));Text(appLabel("المزامنة بين الأجهزة","Device Synchronization",isEnglish),fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary);Spacer(Modifier.weight(1f));Text(appLabel("تجهيز محلي","Local ready",isEnglish),fontSize=11.sp,color=MaterialTheme.colorScheme.secondary)}
     Text(appLabel("أدخل عنوان خادم المزامنة الآمن ورمز الاتصال الذي يصدره المدير. لن تُرسل أي بيانات قبل حفظ الإعدادات وتشغيل المزامنة.","Enter the secure sync server URL and the access token issued by the administrator. No data is sent until settings are saved and sync is started.",isEnglish),fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
     OutlinedTextField(value=syncEndpoint,onValueChange={syncEndpoint=it},modifier=Modifier.fillMaxWidth(),singleLine=true,label={Text(appLabel("عنوان الخادم HTTPS","HTTPS server URL",isEnglish))},placeholder={Text("https://your-server.example")})
     OutlinedTextField(value=syncToken,onValueChange={syncToken=it},modifier=Modifier.fillMaxWidth(),singleLine=true,label={Text(appLabel("رمز الاتصال (Bearer Token)","Connection token (Bearer Token)",isEnglish))},visualTransformation=PasswordVisualTransformation(),placeholder={Text(if(syncConfigured)appLabel("محفوظ بشكل مشفر؛ اكتب بديلاً للتغيير","Encrypted token saved; enter a replacement to change",isEnglish) else "")})
     Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxWidth()) {
      OutlinedButton(onClick={try{val settings=SyncConnectionSettings(ctx);settings.saveEndpoint(syncEndpoint);if(syncToken.isNotBlank())settings.saveToken(syncToken);syncConfigured=settings.token().isNotBlank();syncToken="";settingsMessage=appLabel("تم حفظ إعدادات الاتصال محلياً بشكل آمن.","Connection settings saved securely on this device.",isEnglish)}catch(e:Exception){settingsMessage=e.message?:"تعذر حفظ الإعدادات"}},modifier=Modifier.weight(1f)){Text(appLabel("حفظ الإعدادات","Save Settings",isEnglish))}
      Button(enabled=syncEndpoint.startsWith("https://")&&syncConfigured,onClick={SyncWorkScheduler.enqueue(ctx);settingsMessage=appLabel("تم وضع المزامنة في قائمة التنفيذ. ستظهر النتيجة حسب استجابة الخادم.","Sync queued. Result depends on the server response.",isEnglish)},modifier=Modifier.weight(1f)){Icon(Icons.Default.CloudUpload,null);Text(appLabel("مزامنة الآن","Sync Now",isEnglish))}
     }
     if(settingsMessage.isNotBlank())Text(settingsMessage,fontSize=11.sp,color=MaterialTheme.colorScheme.secondary)
     Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxWidth()){
      SyncMetric(appLabel("عناصر معلقة","Pending",isEnglish),syncStats["pending"]?:0,Modifier.weight(1f))
      SyncMetric(appLabel("الهويات","Identities",isEnglish),syncStats["identities"]?:0,Modifier.weight(1f))
     }
     Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxWidth()){
      SyncMetric(appLabel("وارد للمراجعة","Inbox review",isEnglish),syncStats["inbox"]?:0,Modifier.weight(1f))
      SyncMetric(appLabel("تعارضات","Conflicts",isEnglish),syncStats["conflicts"]?:0,Modifier.weight(1f))
     }
     Text(appLabel("مراجعة التحديثات الواردة — افتح أي عنصر لمقارنة البيانات قبل اتخاذ القرار.","Review incoming updates — open an item to compare data before deciding.",isEnglish),fontSize=12.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary)
     val syncReviewItems=db.syncReviewItems(50)
     if(syncReviewItems.isEmpty())Text(appLabel("لا توجد تحديثات تنتظر المراجعة حالياً.","No incoming updates are waiting for review.",isEnglish),fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
     syncReviewItems.take(12).forEach{item->Card(Modifier.fillMaxWidth().clickable{selectedSyncReview=item},colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceVariant),shape=RoundedCornerShape(12.dp)){Column(Modifier.padding(10.dp),verticalArrangement=Arrangement.spacedBy(3.dp)){Row(verticalAlignment=Alignment.CenterVertically){Text("${item.entityType} • ${item.operation}",fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f));Text(if(item.state=="conflict")appLabel("تعارض","Conflict",isEnglish) else appLabel("بانتظار المراجعة","Review",isEnglish),fontSize=10.sp,color=if(item.state=="conflict")MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.tertiary)};Text("${item.entityUuid.take(18)}…  •  v${item.baseVersion} → v${item.remoteVersion}",fontSize=10.sp,color=MaterialTheme.colorScheme.onSurfaceVariant);TextButton(onClick={selectedSyncReview=item}){Text(appLabel("مقارنة واتخاذ قرار","Compare & Review",isEnglish))}}}}
     OutlinedButton(onClick={tick++},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Refresh,null);Text(appLabel("تحديث حالة المزامنة","Refresh Sync Status",isEnglish))}
    }
   }
   Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),shape=RoundedCornerShape(18.dp)) {
    Row(Modifier.fillMaxWidth().padding(14.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(appLabel("لغة التطبيق","App Language",isEnglish),fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary);Text(appLabel("يمكنك التبديل بين العربية والإنجليزية من هنا أو من زر اللغة أعلى الشاشة.","Switch between Arabic and English here or from the language button in the top bar.",isEnglish),fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)};OutlinedButton(onClick={isEnglish=!isEnglish;ctx.getSharedPreferences("app_preferences",0).edit().putString("ui_language",if(isEnglish)"en" else "ar").apply()}){Text(if(isEnglish)"العربية" else "English")}}
   }
   Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)) {
    Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy((3f * spacingLevel / 100f).dp)) {
     Text(appLabel("خمسة أنماط متكاملة تغير ألوان الواجهة بالكامل","Five complete themes for the app interface",isEnglish),fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary)
     PreferenceDropdown(appLabel("اختر نمط البرنامج","Choose App Theme",isEnglish),themePresetChoice,if(isEnglish)listOf("clinic" to "1. Medical White — Light","forest" to "2. Medical Green — Light","lavender" to "3. Balanced Lavender","midnight" to "4. Midnight Blue — Dark","graphite" to "5. Graphite Gold — Dark") else themePresetOptions){applyThemePreset(it)}
     Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(appLabel("الخط العريض","Bold Text",isEnglish),fontWeight=FontWeight.SemiBold);Text(if(boldText)appLabel("مفعّل على أنماط النصوص","Enabled across text styles",isEnglish) else appLabel("النص العادي","Regular text",isEnglish),fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)};Switch(checked=boldText,onCheckedChange=onBoldTextChange)}
     Text(appLabel("اختر أحد الأنماط الخمسة لتغيير الهوية اللونية الكاملة، بما فيها الخلفية والبطاقات والأزرار.","Choose one of five presets to update the complete color system, including backgrounds, cards and buttons.",isEnglish),fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
     Divider()
     Text(appLabel("حجم الخط","Font Size",isEnglish),fontWeight=FontWeight.SemiBold);Text("${(fontScale*100).toInt()}%",color=MaterialTheme.colorScheme.secondary)
     Text(appLabel("من 60% (أصغر) إلى 140% (أكبر) — الحجم المعتاد 100%","From 60% (smaller) to 140% (larger) — standard size is 100%",isEnglish),fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
     Slider(value=fontScale,onValueChange={fontScale=it;onFontScaleChange(it)},valueRange=0.6f..1.4f,steps=15)
     PreferenceDropdown(appLabel("نوع الخط","Font Family",isEnglish),fontChoice,if(isEnglish)listOf("sans" to "Clear Sans (Default)","naskh" to "Arabic Naskh","serif" to "Serif","mono" to "Monospace","cursive" to "Casual","condensed" to "Condensed","rounded" to "Rounded","light" to "Light","medium" to "Medium","black" to "Extra Bold") else fontOptions){fontChoice=it;onFontChoiceChange(it)}
     Text(appLabel("كثافة المسافات بين العناصر","Interface Spacing",isEnglish),fontWeight=FontWeight.SemiBold)
     Text(if(isEnglish)"${spacingLevel.toInt()}% of original spacing — ${if(spacingLevel<=55f)"Compact" else if(spacingLevel<95f)"Tight" else if(spacingLevel<=105f)"Standard" else "Wide"}" else "${spacingLevel.toInt()}% من المسافة الأصلية — ${if(spacingLevel<=55f)"ضغط مرتفع: نصف المسافة" else if(spacingLevel<95f)"مسافات مضغوطة" else if(spacingLevel<=105f)"المسافة المعتادة" else "مسافات أوسع"}",fontSize=12.sp,color=MaterialTheme.colorScheme.secondary)
     Slider(value=spacingLevel,onValueChange={spacingLevel=it;ctx.getSharedPreferences("app_preferences",0).edit().putFloat("spacing_percent",it).apply()},valueRange=50f..140f,steps=17)
     Text(appLabel("يمكنك تقليل المسافات حتى 50% من حجمها الأصلي أو توسيعها إلى 140%. نحافظ على الحد الأدنى الآمن لمناطق اللمس.","Adjust spacing from 50% to 140%. Minimum touch-target sizes remain protected.",isEnglish),fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
     Divider();Text(appLabel("الأمان","Security",isEnglish),fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary)
     if(session.can("manage_users")) UserManagementCard(auth,isEnglish)
     OutlinedButton(enabled=session.isAdmin,onClick={settingsMessage="";changePasswordDialog=true},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Lock,null);Text(appLabel("تغيير كلمة مرور المدير","Change Administrator Password",isEnglish))}
     Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("تفعيل الدخول بالبصمة",fontWeight=FontWeight.SemiBold);Text(if(fingerprintEnabled)"مفعّل — سيظهر خيار البصمة عند فتح التطبيق" else "غير مفعّل",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)};Switch(checked=fingerprintEnabled,onCheckedChange={enable->if(!enable){onFingerprintEnabledChange(false);settingsMessage="تم إيقاف الدخول بالبصمة"}else{promptFingerprint(ctx as FragmentActivity,"تفعيل الدخول بالبصمة",{onFingerprintEnabledChange(true);settingsMessage="تم تفعيل البصمة بنجاح"},{settingsMessage=it})}})}
     if(settingsMessage.isNotBlank())Text(settingsMessage,color=MaterialTheme.colorScheme.secondary)
    }
   }
   Text(appLabel("الاستيراد والتصدير","Import & Export",isEnglish),fontSize=20.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary)
   Text(appLabel("تُحفظ البيانات داخل الهاتف ولا تُرسل إلى أي خادم.","Data is stored locally on this device and is not sent to a server.",isEnglish),color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=12.sp)
   OutlinedButton(onClick={page="العاملون"},Modifier.fillMaxWidth()){Icon(Icons.Default.Badge,null);Text(appLabel("إدارة دليل العاملين","Manage Staff Directory",isEnglish))}
   Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxWidth()) {
    Button(enabled=session.can("import_excel"),onClick={caseTemplate.launch("نموذج_الحالات_الحرجة_فارغ.xlsx")},modifier=Modifier.weight(1f)){Icon(Icons.Default.FileDownload,null);Text(appLabel("نموذج فارغ","Blank Template",isEnglish))}
    OutlinedButton(enabled=session.can("import_excel")&&session.can("add_edit"),onClick={import.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))},modifier=Modifier.weight(1f)){Icon(Icons.Default.FileOpen,null);Text("استيراد النموذج")}
   }
   OutlinedButton(enabled=session.can("export_share"),onClick={pendingReportRows=db.all();pendingReportTitle="تقرير كل الحالات الحرجة";export.launch("تصدير_كل_الحالات_الحرجة.xlsx")},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.FileDownload,null);Text("تصدير كل الحالات إلى Excel")}
   Button(onClick={selectedReportMeds=reportMeds.toSet();page="التقارير"},Modifier.fillMaxWidth(),enabled=reportMeds.isNotEmpty()){Icon(Icons.Default.Assessment,null);Text("فتح مركز تقارير الأدوية")}
   OutlinedButton(enabled=session.can("export_share"),onClick={backupDialog="export";backupPassword=""},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Lock,null);Text("إنشاء نسخة احتياطية مشفرة")}
   OutlinedButton(enabled=session.can("import_excel")&&session.can("add_edit")&&session.can("manage_medicines"),onClick={backupOpen.launch(arrayOf("application/octet-stream","application/x-tcbak","*/*"))},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Restore,null);Text("استعادة نسخة احتياطية")}
   Divider(Modifier.padding(vertical=8.dp))
   Text("إدارة ومسح البيانات",fontSize=20.sp,fontWeight=FontWeight.Bold,color=Color(0xFFB3261E))
   Text("يمكنك مسح الحالات وحدها أو دليل العاملين وحده أو إعادة بناء قاعدة البيانات بالكامل. أنشئ نسخة احتياطية مشفرة أولاً إذا كانت البيانات مهمة.",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
   OutlinedButton(enabled=session.isAdmin,onClick={resetMode="cases";resetPhrase="";resetPassword=""},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Delete,null);Text("مسح جميع سجلات الحالات فقط")}
   OutlinedButton(enabled=session.isAdmin,onClick={resetMode="employees";resetPhrase="";resetPassword=""},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.People,null);Text("مسح دليل العاملين فقط")}
   Button(enabled=session.isAdmin,onClick={resetMode="all";resetPhrase="";resetPassword=""},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFFB3261E))){Icon(Icons.Default.Warning,null);Text("إعادة ضبط بيانات البرنامج بالكامل")}
   Divider(Modifier.padding(vertical=8.dp))
   Text("ملاحظات الأمان",fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary)
   Text("• لا توجد صلاحية إنترنت في التطبيق.\n• قاعدة البيانات مستقلة لكل هاتف.\n• استيراد الحالات يتم من نموذج Excel الصادر من التطبيق.\n• لا ترفع بيانات شخصية أو صحية إلى GitHub.\n• النسخ الاحتياطية مشفرة والاستعادة دمجية ولا تحذف البيانات الحالية.",color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=12.sp)
  }
 }
 }} }
 if(form)EditDialog(edit,meds,{db.findEmployee(it)},{db.strengthsForMedicine(it)},{form=false},{r->try{db.save(r);db.upsertMedicine(r.medicine);if(r.strength.isNotBlank())db.addStrength(r.medicine,r.strength);db.log(if(r.id>0)"تعديل" else "إضافة",r.performanceNo);tick++;form=false;msg="تم حفظ السجل وربطه بالاسم المعتمد للدواء"}catch(e:Exception){msg="لم يتم حفظ السجل: ${e.message}"}},isEnglish)
 if(previewRows!=null){val rows=previewRows!!;val duplicates=db.duplicateCount(rows);val issues=db.caseImportIssues(rows)+db.medicineNameReviewIssues(rows);val newMedicineNames=rows.map{it.medicine.trim()}.filter{it.isNotBlank()&&db.medicineNameMatch(it).type==MedicineNameMatchType.NEW}.distinct();val normalizedMedicineNames=db.medicineNameNormalizationNotes(rows);AlertDialog(onDismissRequest={previewRows=null},title={Text("مراجعة استيراد الحالات الحرجة")},text={Column(Modifier.heightIn(max=480.dp).verticalScroll(rememberScrollState())){Text("السجلات المقروءة: ${rows.size}");Text("سجلات مطابقة موجودة أو مكررة داخل الملف: $duplicates");Text("سجلات جديدة متوقعة: ${(rows.size-duplicates).coerceAtLeast(0)}");Text("أخطاء تمنع الاعتماد: ${issues.size}",color=if(issues.isEmpty())Teal else Color.Red);Text("أسماء تم توحيدها تلقائياً بعد المطابقة: ${normalizedMedicineNames.size}",color=if(normalizedMedicineNames.isEmpty())Teal else MaterialTheme.colorScheme.secondary);normalizedMedicineNames.take(12).forEach{Text("• $it",fontSize=12.sp,color=MaterialTheme.colorScheme.secondary)};Text("أسماء أدوية جديدة تحتاج مراجعة القاموس: ${newMedicineNames.size}",color=if(newMedicineNames.isEmpty())Teal else MaterialTheme.colorScheme.tertiary);newMedicineNames.take(12).forEach{Text("• $it (سيُضاف كاسم جديد بحالة يحتاج مراجعة)",fontSize=12.sp,color=MaterialTheme.colorScheme.tertiary)};issues.take(30).forEach{Text("• $it",fontSize=12.sp,color=Color.Red)};Text("عينة من البيانات:",fontWeight=FontWeight.Bold);rows.take(5).forEach{Text("• ${it.name} | ${it.performanceNo} | ${it.medicine} | ${it.strength}",fontSize=12.sp)};Text("لن يتم اعتماد أي سجل إذا كانت هناك أخطاء إلزامية. السجلات المتطابقة بالكامل فقط ستُتجاوز؛ ويمكن للعامل نفسه الحصول على أكثر من علاج أو سجل مختلف.",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)}},confirmButton={Button(enabled=issues.isEmpty(),onClick={try{val(a,d)=db.importRows(rows);msg="تمت إضافة $a سجل وتجاوز $d سجلاً مطابقاً بالكامل";previewRows=null;tick++}catch(e:Exception){msg="لم يتم اعتماد الاستيراد: ${e.message}"}}){Text("اعتماد الاستيراد")}},dismissButton={TextButton(onClick={previewRows=null}){Text("إلغاء")}})}
 if(showEmployeeForm)EmployeeEditDialog(employeeEdit,{showEmployeeForm=false},{r->try{db.saveEmployee(r);db.log("حفظ دليل عامل",r.performanceNo);msg="تم حفظ بيانات العامل";tick++;showEmployeeForm=false}catch(e:Exception){msg="تعذر حفظ العامل: ${e.message}"}})
 if(employeePlan!=null){val plan=employeePlan!!;AlertDialog(onDismissRequest={employeePlan=null},title={Text("تقرير مراجعة دليل العاملين")},text={Column(Modifier.heightIn(max=480.dp).verticalScroll(rememberScrollState())){Text("موظفون جدد: ${plan.inserts.size}",color=MaterialTheme.colorScheme.secondary);Text("بيانات سيتم تحديثها: ${plan.updates.size}",color=MaterialTheme.colorScheme.secondary);Text("دون تغيير: ${plan.unchanged}");Text("أخطاء تمنع الاعتماد: ${plan.issues.size}",color=if(plan.issues.isEmpty())Teal else Color.Red);plan.issues.take(30).forEach{Text("صف ${it.row} • ${it.performanceNo}: ${it.message}",fontSize=12.sp,color=Color.Red)};plan.changes.take(20).forEach{change->Text("${change.performanceNo} • ${change.name}",fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary,fontSize=12.sp);change.fields.forEach{field->Text("${field.field}: ${field.oldValue.ifBlank{"(فارغ)"}} ← ${field.newValue}",fontSize=11.sp)}};if(plan.issues.isEmpty())Text("لن تُمسح البيانات القديمة عند ترك خلية فارغة. ستتم العملية داخل معاملة واحدة، إما تكتمل كلها أو لا يُعتمد أي تغيير.",fontSize=12.sp)}} ,confirmButton={Button(enabled=plan.canCommit,onClick={try{val(a,u)=db.commitEmployeeImport(plan);msg="تم تحديث دليل العاملين: إضافة $a وتحديث $u";employeePlan=null;tick++}catch(e:Exception){msg="لم يتم اعتماد الاستيراد: ${e.message}"}}){Text("اعتماد التحديث")}},dismissButton={TextButton(onClick={employeePlan=null}){Text("إلغاء")}})}
 if(reportDialog)AlertDialog(onDismissRequest={reportDialog=false},title={Text("اختيار الأدوية للتقرير")},text={Column(Modifier.heightIn(max=520.dp)) {Text("حدد دواءً واحداً أو عدة أدوية، أو اترك الكل محدداً لإصدار تقرير شامل.",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant);Row(verticalAlignment=Alignment.CenterVertically){TextButton(onClick={selectedReportMeds=reportMeds.toSet()}){Text("تحديد الكل")};TextButton(onClick={selectedReportMeds=emptySet()}){Text("إلغاء التحديد")};Spacer(Modifier.weight(1f));Text("${selectedReportMeds.size}/${reportMeds.size}",color=MaterialTheme.colorScheme.secondary,fontWeight=FontWeight.Bold)};Column(Modifier.weight(1f,false).verticalScroll(rememberScrollState())){reportMeds.forEach{medicine->Row(Modifier.fillMaxWidth().clickable{selectedReportMeds=if(medicine in selectedReportMeds)selectedReportMeds-medicine else selectedReportMeds+medicine}.padding(vertical=3.dp),verticalAlignment=Alignment.CenterVertically){Checkbox(checked=medicine in selectedReportMeds,onCheckedChange={checked->selectedReportMeds=if(checked)selectedReportMeds+medicine else selectedReportMeds-medicine});Text("$medicine  •  ${counts[medicine]?:0} سجل",Modifier.weight(1f))}}}}},confirmButton={Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){Button(enabled=session.can("export_share")&&selectedReportMeds.isNotEmpty(),onClick={pendingReportRows=db.all().filter{it.medicine in selectedReportMeds};pendingReportTitle=if(selectedReportMeds.size==reportMeds.size)"تقرير جميع الأدوية" else "تقرير الأدوية المختارة";reportDialog=false;pdf.launch("تقرير_الأدوية_المختارة.pdf")}){Text("PDF")};Button(enabled=session.can("export_share")&&selectedReportMeds.isNotEmpty(),onClick={pendingReportRows=db.all().filter{it.medicine in selectedReportMeds};pendingReportTitle=if(selectedReportMeds.size==reportMeds.size)"تقرير جميع الأدوية" else "تقرير الأدوية المختارة";reportDialog=false;export.launch("تقرير_الأدوية_المختارة.xlsx")}){Text("Excel")}}},dismissButton={TextButton(onClick={reportDialog=false}){Text("إلغاء")}})
 if(backupDialog.isNotBlank())AlertDialog(onDismissRequest={backupDialog="";backupPassword="";restoreBytes=null},title={Text(if(backupDialog=="export")"حماية النسخة الاحتياطية" else "كلمة مرور الاستعادة")},text={Column{Text("${if(backupDialog=="export")"أنشئ كلمة مرور لحماية ملف النسخة. استخدم 8 أحرف أو أرقام على الأقل." else "أدخل كلمة المرور التي استُخدمت عند إنشاء النسخة."}");OutlinedTextField(backupPassword,{backupPassword=it},label={Text("كلمة مرور النسخة")},singleLine=true,visualTransformation=PasswordVisualTransformation())}},confirmButton={Button(onClick={try{if(backupDialog=="export"){exportBackupBytes=EncryptedBackup.encodeFull(db.all(),db.employees(),db.medicineCatalog(),db.medicineStrengths(),backupPassword);backupDialog="";backupSave.launch("نسخة_علاج_الحالات_المشفرة.tcbak")}else{restorePreview=EncryptedBackup.decodeFull(restoreBytes?:byteArrayOf(),backupPassword);backupDialog="";restoreBytes=null};backupPassword=""}catch(e:Exception){msg="تعذر تنفيذ العملية: ${e.message ?: "تحقق من كلمة المرور"}"}}){Text("متابعة")}},dismissButton={TextButton(onClick={backupDialog="";backupPassword="";restoreBytes=null}){Text("إلغاء")}})
 if(restorePreview!=null){val bundle=restorePreview!!;val restoreIssues=db.restoreBundleIssues(bundle);AlertDialog(onDismissRequest={restorePreview=null},title={Text("معاينة النسخة قبل الاستعادة")},text={Column(Modifier.heightIn(max=460.dp).verticalScroll(rememberScrollState())){Text("الحالات العلاجية: ${bundle.cases.size}",color=MaterialTheme.colorScheme.primary);Text("العاملون: ${bundle.employees.size}",color=MaterialTheme.colorScheme.primary);Text("الأدوية في القاموس: ${bundle.medicineDetails.size.coerceAtLeast(bundle.medicines.size)}",color=MaterialTheme.colorScheme.primary);Text("العيارات: ${bundle.strengths.size}",color=MaterialTheme.colorScheme.primary);Text("إجمالي المشكلات التي تمنع الاستعادة: ${restoreIssues.size}",color=if(restoreIssues.isEmpty())Teal else Color.Red);restoreIssues.take(20).forEach{Text("• $it",fontSize=12.sp,color=Color.Red)};if(restoreIssues.isEmpty())Text("اجتازت البيانات فحص الاستعادة المبدئي.",color=Teal);Text("الاستعادة ستدمج البيانات ولن تحذف السجلات الحالية. كلمة مرور المدير وصلاحيات هذا الهاتف لن تنتقل من النسخة.",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)}},confirmButton={Button(enabled=restoreIssues.isEmpty(),onClick={try{val(casesAdded,employeesAdded,employeesUpdated)=db.restoreBundle(bundle);msg="تمت الاستعادة الدمجية: حالات جديدة $casesAdded، عاملون جدد $employeesAdded، تحديث عاملين $employeesUpdated. تم دمج قاموس الأدوية والعيارات دون حذف البيانات الحالية.";tick++;restorePreview=null}catch(e:Exception){msg="لم تتم الاستعادة: ${e.message}"}}){Text("اعتماد الاستعادة")}},dismissButton={TextButton(onClick={restorePreview=null}){Text("إلغاء")}})}
 if(resetMode.isNotBlank()){
  val requiredPhrase=when(resetMode){"cases"->"مسح الحالات";"employees"->"مسح العاملين";else->"إعادة ضبط"}
  val resetTitle=when(resetMode){"cases"->"تأكيد مسح سجلات الحالات";"employees"->"تأكيد مسح دليل العاملين";else->"تأكيد إعادة ضبط بيانات البرنامج"}
  AlertDialog(onDismissRequest={resetMode="";resetPhrase="";resetPassword=""},title={Text(resetTitle)},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
   Text(when(resetMode){"cases"->"سيتم حذف جميع سجلات الحالات العلاجية فقط. سيظل دليل العاملين وقاموس الأدوية كما هما.";"employees"->"سيتم حذف جميع العاملين فقط. ستظل سجلات الحالات العلاجية كما هي.";else->"سيتم حذف جميع الحالات والعاملين والأدوية والعيارات وسجل التدقيق، ثم إعادة تحميل قاموس الأدوية الأساسي. ستظل كلمة مرور المدير وإعدادات العرض محفوظة."},color=Color(0xFFB3261E))
   Text("هذه العملية لا يمكن التراجع عنها. يفضّل إنشاء نسخة احتياطية مشفرة أولاً.",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
   OutlinedTextField(resetPhrase,{resetPhrase=it},Modifier.fillMaxWidth(),label={Text("اكتب للتأكيد: $requiredPhrase")},singleLine=true)
   OutlinedTextField(resetPassword,{resetPassword=it},Modifier.fillMaxWidth(),label={Text("كلمة مرور المدير الحالية")},singleLine=true,visualTransformation=PasswordVisualTransformation())
  }},confirmButton={Button(enabled=resetPhrase.trim()==requiredPhrase&&resetPassword.isNotBlank(),onClick={
   if(!auth.verify(resetPassword)){settingsMessage="كلمة مرور المدير غير صحيحة";msg=settingsMessage}
   else try{when(resetMode){"cases"->db.clearCases();"employees"->db.clearEmployees();else->db.factoryResetData()};tick++;msg=when(resetMode){"cases"->"تم مسح سجلات الحالات فقط";"employees"->"تم مسح دليل العاملين فقط";else->"تمت إعادة ضبط بيانات البرنامج وإعادة تحميل قاموس الأدوية الأساسي. كلمة مرور المدير وإعدادات العرض محفوظة."};resetMode="";resetPhrase="";resetPassword=""}catch(e:Exception){msg="تعذر تنفيذ المسح: ${e.message}"}
  }){Text("تنفيذ المسح")}},dismissButton={TextButton(onClick={resetMode="";resetPhrase="";resetPassword=""}){Text("إلغاء")}})
 }
 if(changePasswordDialog)AlertDialog(onDismissRequest={changePasswordDialog=false;currentPassword="";newPassword="";confirmPassword=""},title={Text(appLabel("تغيير كلمة مرور المدير","Change Administrator Password",isEnglish))},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(currentPassword,{currentPassword=it},label={Text("كلمة المرور الحالية")},singleLine=true,visualTransformation=PasswordVisualTransformation());OutlinedTextField(newPassword,{newPassword=it},label={Text("كلمة المرور الجديدة")},singleLine=true,visualTransformation=PasswordVisualTransformation());OutlinedTextField(confirmPassword,{confirmPassword=it},label={Text("تأكيد كلمة المرور الجديدة")},singleLine=true,visualTransformation=PasswordVisualTransformation());Text("يجب ألا تقل كلمة المرور الجديدة عن 8 أحرف أو أرقام.",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant);if(settingsMessage.isNotBlank())Text(settingsMessage,color=Color.Red,fontSize=12.sp)}},confirmButton={Button(onClick={if(!auth.verify(currentPassword))settingsMessage="كلمة المرور الحالية غير صحيحة" else if(newPassword.length<8)settingsMessage="كلمة المرور الجديدة قصيرة" else if(newPassword!=confirmPassword)settingsMessage="تأكيد كلمة المرور غير مطابق" else if(auth.createAdmin(newPassword)){settingsMessage="تم تغيير كلمة المرور بنجاح";changePasswordDialog=false;currentPassword="";newPassword="";confirmPassword=""}else settingsMessage="تعذر تغيير كلمة المرور"}){Text("حفظ التغيير")}},dismissButton={TextButton(onClick={changePasswordDialog=false}){Text("إلغاء")}})
 if(selectedSyncReview!=null){val item=selectedSyncReview!!;AlertDialog(onDismissRequest={selectedSyncReview=null},title={Text(appLabel("مراجعة تحديث وارد","Review Incoming Update",isEnglish))},text={Column(Modifier.heightIn(max=500.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(6.dp)){Text("${item.entityType} • ${item.operation} • ${item.state}",fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary);Text("معرّف الحدث: ${item.eventId}",fontSize=10.sp);Text("الجهاز المصدر: ${item.sourceDevice}",fontSize=10.sp);Text("الإصدار الأساسي: ${item.baseVersion} • الإصدار الوارد: ${item.remoteVersion}",fontSize=11.sp);if(item.error.isNotBlank())Text(item.error,color=MaterialTheme.colorScheme.error,fontSize=11.sp);Text(appLabel("البيانات المحلية وقت اكتشاف التعارض","Local data snapshot",isEnglish),fontWeight=FontWeight.Bold);Text(item.localPayloadJson.take(5000),fontSize=10.sp);Text(appLabel("البيانات الواردة","Incoming data",isEnglish),fontWeight=FontWeight.Bold);Text(item.payloadJson.take(5000),fontSize=10.sp);if(item.operation=="delete")Text(appLabel("الحذف الوارد غير قابل للتطبيق حالياً حفاظاً على السجلات؛ يمكنك الاحتفاظ بالبيانات المحلية أو تأجيل القرار.","Remote deletion is blocked for data safety; keep local data or defer.",isEnglish),color=MaterialTheme.colorScheme.error,fontSize=11.sp)}} ,confirmButton={Button(enabled=item.operation=="upsert",onClick={val error=db.applyReviewedRemoteEvent(item.eventId);settingsMessage=error?:appLabel("تم تطبيق التحديث الوارد داخل معاملة آمنة.","Incoming update applied atomically.",isEnglish);selectedSyncReview=null;tick++}){Text(appLabel("اعتماد البيانات الواردة","Apply Incoming",isEnglish))}},dismissButton={Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){TextButton(enabled=item.state=="conflict"||item.operation=="delete",onClick={val kept=db.keepLocalForRemoteEvent(item.eventId);settingsMessage=if(kept)appLabel("تم الاحتفاظ بالبيانات المحلية.","Local data retained.",isEnglish) else appLabel("تعذر تسجيل القرار.","Could not record decision.",isEnglish);selectedSyncReview=null;tick++}){Text(appLabel("الاحتفاظ بالمحلي","Keep Local",isEnglish))};TextButton(onClick={selectedSyncReview=null}){Text(appLabel("لاحقاً","Later",isEnglish))}}})}
 if(medicineAuditReport!=null) AlertDialog(onDismissRequest={medicineAuditReport=null},title={Text("تقرير تدقيق قاموس الأدوية")},text={Column(Modifier.heightIn(max=480.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(5.dp)){medicineAuditReport!!.forEach{Text(it,fontSize=12.sp,color=MaterialTheme.colorScheme.onSurface)}}},confirmButton={TextButton(onClick={medicineAuditReport=null}){Text("إغلاق")}})
 if(selectedMedicineDetails!=null){
  if(session.can("manage_medicines")){
   MedicineDetailsDialog(selectedMedicineDetails!!,close={selectedMedicineDetails=null},correctName={medicineNameCorrection=selectedMedicineDetails;selectedMedicineDetails=null},save={updated->try{if(db.updateMedicineClinicalDetails(updated)){msg="تم حفظ الملف الطبي والعيارات والمرادفات";tick++;selectedMedicineDetails=null}else msg="تعذر تحديث بيانات الدواء"}catch(e:Exception){msg="لم يتم الحفظ: ${e.message}"}})
  }else{
   val medicine=selectedMedicineDetails!!
   AlertDialog(onDismissRequest={selectedMedicineDetails=null},title={Text(medicine.name)},text={Column(Modifier.verticalScroll(rememberScrollState())){
    Text("المادة الفعالة: ${medicine.genericName.ifBlank{"غير مسجلة"}}")
    Text("التخصص: ${medicine.specialty.ifBlank{"غير مسجل"}}")
    Text("العيارات: ${medicine.strengths.ifBlank{"غير محددة"}}")
    Text("التصنيف: ${medicine.criticalClassification.ifBlank{"غير مسجل"}}")
    Text("الحالات المستهدفة: ${medicine.targetConditions.ifBlank{"غير مسجلة"}}")
    Text("دواعي الاستعمال: ${medicine.indications.ifBlank{"غير مسجلة"}}")
    Text("حالة المراجعة: ${medicine.reviewStatus}")
   }},confirmButton={TextButton(onClick={selectedMedicineDetails=null}){Text("إغلاق")}})
  }
 }
 if(medicineNameCorrection!=null) MedicineNameCorrectionDialog(medicineNameCorrection!!,close={medicineNameCorrection=null},approve={newName,reason->try{val count=db.approveMedicineNameCorrection(medicineNameCorrection!!.name,newName,reason);msg="تم اعتماد الاسم الجديد وتحديث $count سجل مرتبط بالدواء مع حفظ الاسم السابق في سجل التدقيق";medicineNameCorrection=null;tick++}catch(e:Exception){msg="لم يتم اعتماد التصحيح: ${e.message}"}})
 if(showMedicineAdd)AlertDialog(onDismissRequest={showMedicineAdd=false},title={Text("إضافة دواء للقاموس")},text={Column{OutlinedTextField(newMedicine,{newMedicine=it},label={Text("اسم الدواء")});OutlinedTextField(newStrengths,{newStrengths=it},label={Text("التركيزات المتاحة")})}},confirmButton={Button(onClick={val match=db.medicineNameMatch(newMedicine);if(match.type==MedicineNameMatchType.SUGGESTION)msg=if(match.similarity>0.0)"اسم الدواء قريب من ${match.canonicalName}. صحح الاسم أو راجع الدواء الموجود قبل إضافة اسم جديد." else "هذا الاسم يحتاج مراجعة العبوة قبل إضافته: ${match.canonicalName}. لم تتم الإضافة." else if(match.type==MedicineNameMatchType.NORMALIZED)msg="هذا الاسم مطابق بعد توحيد الكتابة للدواء ${match.canonicalName}؛ لم تتم إضافة نسخة مكررة." else if(db.addMedicine(newMedicine,strengths=newStrengths)){msg="تمت إضافة الدواء إلى القاموس بحالة يحتاج مراجعة";tick++;newMedicine="";newStrengths="";showMedicineAdd=false}else msg="الاسم فارغ أو الدواء موجود بالفعل"}){Text("حفظ")}},dismissButton={TextButton(onClick={showMedicineAdd=false}){Text("إلغاء")}})}
}

@Composable fun MedicineDetailsDialog(record:MedicineCatalogRecord,close:()->Unit,correctName:()->Unit,save:(MedicineCatalogRecord)->Unit){
 val name=record.name
 var generic by remember(record){mutableStateOf(record.genericName)}
 var specialty by remember(record){mutableStateOf(record.specialty)}
 var form by remember(record){mutableStateOf(record.dosageForm)}
 var classification by remember(record){mutableStateOf(record.criticalClassification)}
 var conditions by remember(record){mutableStateOf(record.targetConditions)}
 var indications by remember(record){mutableStateOf(record.indications)}
 var notes by remember(record){mutableStateOf(record.medicalNotes)}
 var source by remember(record){mutableStateOf(record.sourceReference)}
 var reviewed by remember(record){mutableStateOf(record.lastReviewed)}
 var status by remember(record){mutableStateOf(record.reviewStatus.ifBlank{"يحتاج مراجعة"})}
 val strengthItems= remember(record){mutableStateListOf<String>().apply{addAll(MedicineStrengthNormalizer.unique(record.strengths.split(Regex("[;؛,،|\\n]+"))))}}
 val aliasItems= remember(record){mutableStateListOf<String>().apply{addAll(record.aliases.split(Regex("[;؛,،|\\n]+")).map{it.trim()}.filter{it.isNotBlank()}.distinctBy{MedicineNameMatcher.key(it)})}}
 var newStrength by remember(record){mutableStateOf("")}
 var newAlias by remember(record){mutableStateOf("")}
 var strengthEditTarget by remember(record){mutableStateOf<String?>(null)}
 var strengthEditValue by remember(record){mutableStateOf("")}
 var aliasEditTarget by remember(record){mutableStateOf<String?>(null)}
 var aliasEditValue by remember(record){mutableStateOf("")}
 AlertDialog(onDismissRequest=close,title={Text("الملف الطبي للدواء: $name")},text={Column(Modifier.heightIn(max=560.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(6.dp)){
  Text("المعلومات التالية مرجعية وليست توصية علاجية. اترك أي معلومة غير موثقة فارغة.",fontSize=12.sp,color=MaterialTheme.colorScheme.secondary)
  OutlinedTextField(generic,{generic=it},Modifier.fillMaxWidth(),label={Text("المادة الفعالة / الاسم العلمي")})
  OutlinedTextField(specialty,{specialty=it},Modifier.fillMaxWidth(),label={Text("التخصص الطبي")})
  OutlinedTextField(classification,{classification=it},Modifier.fillMaxWidth(),label={Text("التصنيف الموجه إليه / مجموعة الأمراض")})
  OutlinedTextField(conditions,{conditions=it},Modifier.fillMaxWidth(),label={Text("الأمراض والحالات المستهدفة")},minLines=2)
  OutlinedTextField(indications,{indications=it},Modifier.fillMaxWidth(),label={Text("دواعي الاستعمال الموثقة")},minLines=3)
  Text("العيارات والتركيزات",fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary)
  strengthItems.toList().forEach{st->Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text(st,Modifier.weight(1f));IconButton(onClick={strengthEditTarget=st;strengthEditValue=st}){Icon(Icons.Default.Edit,"تعديل العيار",tint=MaterialTheme.colorScheme.secondary)};IconButton(onClick={strengthItems.remove(st)}){Icon(Icons.Default.Delete,"حذف العيار",tint=MaterialTheme.colorScheme.error)}}}
  Row(verticalAlignment=Alignment.CenterVertically){OutlinedTextField(newStrength,{newStrength=it},Modifier.weight(1f),label={Text("إضافة عيار")},singleLine=true);IconButton(onClick={val v=newStrength.trim();if(v.isNotBlank()&&strengthItems.none{MedicineStrengthNormalizer.key(it)==MedicineStrengthNormalizer.key(v)}){strengthItems.add(v);newStrength=""}}){Icon(Icons.Default.Add,"إضافة عيار")}}
  OutlinedTextField(form,{form=it},Modifier.fillMaxWidth(),label={Text("الشكل الدوائي")})
  OutlinedTextField(notes,{notes=it},Modifier.fillMaxWidth(),label={Text("ملاحظات وتنبيهات")},minLines=2)
  OutlinedTextField(source,{source=it},Modifier.fillMaxWidth(),label={Text("المصدر الطبي / رابط النشرة")},minLines=2)
  OutlinedTextField(reviewed,{reviewed=it},Modifier.fillMaxWidth(),label={Text("تاريخ آخر مراجعة")})
  Text("الأسماء البديلة والتهجئات المعروفة",fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary)
  aliasItems.toList().forEach{alias->Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text(alias,Modifier.weight(1f));IconButton(onClick={aliasEditTarget=alias;aliasEditValue=alias}){Icon(Icons.Default.Edit,"تعديل الاسم البديل",tint=MaterialTheme.colorScheme.secondary)};IconButton(onClick={aliasItems.remove(alias)}){Icon(Icons.Default.Delete,"حذف الاسم البديل",tint=MaterialTheme.colorScheme.error)}}}
  Row(verticalAlignment=Alignment.CenterVertically){OutlinedTextField(newAlias,{newAlias=it},Modifier.weight(1f),label={Text("إضافة اسم بديل")},singleLine=true);IconButton(onClick={val v=newAlias.trim();if(v.isNotBlank()&&aliasItems.none{MedicineNameMatcher.key(it)==MedicineNameMatcher.key(v)}&&MedicineNameMatcher.key(v)!=MedicineNameMatcher.key(name)){aliasItems.add(v);newAlias=""}}){Icon(Icons.Default.Add,"إضافة اسم بديل")}}
  OutlinedTextField(status,{status=it},Modifier.fillMaxWidth(),label={Text("حالة التحقق")})
 }},confirmButton={Column(horizontalAlignment=Alignment.End){TextButton(onClick=correctName){Text("تصحيح واعتماد الاسم")};Button(onClick={save(record.copy(genericName=generic,specialty=specialty,strengths=strengthItems.joinToString("; "),dosageForm=form,criticalClassification=classification,targetConditions=conditions,indications=indications,medicalNotes=notes,sourceReference=source,lastReviewed=reviewed,aliases=aliasItems.joinToString("; "),reviewStatus=status))}){Text("حفظ البيانات")}}},dismissButton={TextButton(onClick=close){Text("إغلاق")}})
 if(strengthEditTarget!=null) AlertDialog(onDismissRequest={strengthEditTarget=null},title={Text("تعديل العيار")},text={OutlinedTextField(strengthEditValue,{strengthEditValue=it},label={Text("التركيز الجديد")},singleLine=true)},confirmButton={Button(onClick={val old=strengthEditTarget;val v=strengthEditValue.trim();if(old!=null&&v.isNotBlank()&&strengthItems.none{it!=old&&MedicineStrengthNormalizer.key(it)==MedicineStrengthNormalizer.key(v)}){val index=strengthItems.indexOf(old);if(index>=0)strengthItems[index]=v;strengthEditTarget=null}}){Text("حفظ العيار")}},dismissButton={TextButton(onClick={strengthEditTarget=null}){Text("إلغاء")}})
 if(aliasEditTarget!=null) AlertDialog(onDismissRequest={aliasEditTarget=null},title={Text("تعديل الاسم البديل")},text={OutlinedTextField(aliasEditValue,{aliasEditValue=it},label={Text("الاسم البديل الجديد")},singleLine=true)},confirmButton={Button(onClick={val old=aliasEditTarget;val v=aliasEditValue.trim();if(old!=null&&v.isNotBlank()&&MedicineNameMatcher.key(v)!=MedicineNameMatcher.key(name)&&aliasItems.none{it!=old&&MedicineNameMatcher.key(it)==MedicineNameMatcher.key(v)}){val index=aliasItems.indexOf(old);if(index>=0)aliasItems[index]=v;aliasEditTarget=null}}){Text("حفظ الاسم")}},dismissButton={TextButton(onClick={aliasEditTarget=null}){Text("إلغاء")}})
}

@Composable fun MedicineNameCorrectionDialog(record:MedicineCatalogRecord,close:()->Unit,approve:(String,String)->Unit){
 var proposed by remember(record){mutableStateOf("")};var reason by remember(record){mutableStateOf("تم التحقق من الاسم من العبوة أو مصدر موثوق")};var confirm by remember(record){mutableStateOf(false)}
 AlertDialog(onDismissRequest=close,title={Text("تصحيح واعتماد اسم الدواء")},text={Column(Modifier.heightIn(max=420.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)){
  Text("الاسم الحالي: ${record.name}",fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary)
  OutlinedTextField(proposed,{proposed=it},Modifier.fillMaxWidth(),label={Text("الاسم الصحيح المعتمد")},singleLine=true)
  OutlinedTextField(reason,{reason=it},Modifier.fillMaxWidth(),label={Text("سبب التصحيح / مرجع التحقق")},minLines=2)
  Text("سيتم تحديث اسم الدواء في سجلات الحالات المرتبطة به، ونقل العيارات والمرادفات والبيانات الطبية، والاحتفاظ بالاسم القديم كسجل بديل وتوثيق عدد السجلات المتأثرة.",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
  Row(verticalAlignment=Alignment.CenterVertically){Checkbox(checked=confirm,onCheckedChange={confirm=it});Text("أؤكد أن الاسم الجديد يخص المستحضر نفسه")}
 }},confirmButton={Button(enabled=proposed.isNotBlank()&&confirm,onClick={approve(proposed.trim(),reason.trim())}){Text("اعتماد التصحيح")}},dismissButton={TextButton(onClick=close){Text("إلغاء")}})
}

@Composable fun EmployeeEditDialog(old:EmployeeRecord?,close:()->Unit,save:(EmployeeRecord)->Unit){
 val fields=listOf("رقم الأداء","الاسم","الوظيفة","الجهة","الإدارة","رقم البطاقة","رقم التليفون","رقم التليفون الثاني","النوع","ملاحظات")
 val values= remember(old){mutableStateListOf(*(old?.cells()?.toTypedArray()?:Array(10){""}))}
 AlertDialog(onDismissRequest=close,title={Text(if(old==null)"إضافة عامل إلى الدليل" else "تعديل بيانات العامل")},text={Column(Modifier.heightIn(max=520.dp).verticalScroll(rememberScrollState())){fields.forEachIndexed{i,label->OutlinedTextField(values[i],{values[i]=it},Modifier.fillMaxWidth().padding(vertical=2.dp),label={Text(label)},singleLine=i!=9,enabled=(i!=0||old==null))};Text("رقم الأداء فريد ولا يقبل التكرار. رقم البطاقة إن أدخلته يجب أن يكون صحيحاً.",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)}},confirmButton={Button(enabled=values[0].isNotBlank()&&values[1].isNotBlank(),onClick={save(EmployeeRecord(performanceNo=values[0].trim(),name=values[1],job=values[2],entity=values[3],department=values[4],nationalId=values[5],phone1=values[6],phone2=values[7],gender=values[8],notes=values[9]))}){Text("حفظ")}},dismissButton={TextButton(onClick=close){Text("إلغاء")}})
}
@Composable fun Stat(label:String,value:String,mod:Modifier){Card(mod,colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),shape=RoundedCornerShape(20.dp),elevation=CardDefaults.cardElevation(defaultElevation=2.dp)){Column(Modifier.fillMaxWidth().padding(horizontal=14.dp,vertical=13.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){Row(verticalAlignment=Alignment.CenterVertically){Text(label,Modifier.weight(1f),color=MaterialTheme.colorScheme.onSurfaceVariant,fontSize=12.sp,fontWeight=FontWeight.Medium);Icon(Icons.Default.Insights,null,tint=MaterialTheme.colorScheme.secondary,modifier=Modifier.size(18.dp))};Text(value,color=MaterialTheme.colorScheme.primary,fontSize=29.sp,fontWeight=FontWeight.Bold,lineHeight=32.sp)}}}

@Composable private fun DashboardHero(isEnglish:Boolean,onOpenRecords:()->Unit){
 var pressed by remember{mutableStateOf(false)}
 LaunchedEffect(pressed){if(pressed){delay(120);pressed=false}}
 val scale by animateFloatAsState(if(pressed)0.985f else 1f,animationSpec=spring(stiffness=520f),label="heroPress")
 Card(Modifier.fillMaxWidth().scale(scale).clickable{pressed=true;onOpenRecords()}.animateContentSize(),shape=RoundedCornerShape(26.dp),elevation=CardDefaults.cardElevation(defaultElevation=5.dp)){
  Box(Modifier.fillMaxWidth().height(176.dp)){
   Image(painter=painterResource(id=R.drawable.medical_hero),contentDescription=if(isEnglish)"Medical care illustration" else "صورة توضيحية للرعاية الطبية",modifier=Modifier.fillMaxSize(),contentScale=ContentScale.Crop)
   Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color(0xE611376F),Color(0x99165CB5),Color(0x22165CB5)))))
   Row(Modifier.fillMaxSize().padding(18.dp),verticalAlignment=Alignment.CenterVertically){
    Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(7.dp)){
     Text(appLabel("لوحة المتابعة","Dashboard",isEnglish),fontSize=11.sp,fontWeight=FontWeight.Bold,color=Color.White.copy(alpha=.86f),letterSpacing=1.2.sp)
     Text(if(isEnglish)"Care starts with\nclear information" else "رعاية أفضل تبدأ\nبمعلومة واضحة",fontSize=22.sp,lineHeight=27.sp,fontWeight=FontWeight.ExtraBold,color=Color.White)
     Surface(color=Color.White.copy(alpha=.18f),shape=RoundedCornerShape(50)){Row(Modifier.padding(horizontal=12.dp,vertical=7.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Search,null,tint=Color.White,modifier=Modifier.size(16.dp));Spacer(Modifier.width(6.dp));Text(if(isEnglish)"Open records" else "فتح السجلات",fontSize=12.sp,fontWeight=FontWeight.Bold,color=Color.White)}}
    }
    Icon(Icons.Default.Favorite,contentDescription=if(isEnglish)"Care" else "الرعاية",tint=Color.White.copy(alpha=.92f),modifier=Modifier.size(42.dp))
   }
  }
 }
}

@Composable private fun DynamicStatCard(title:String,value:Int,icon:androidx.compose.ui.graphics.vector.ImageVector,tint:Color,modifier:Modifier=Modifier){
 Card(modifier.animateContentSize(),shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=tint),elevation=CardDefaults.cardElevation(defaultElevation=3.dp)){
  Row(Modifier.fillMaxWidth().padding(horizontal=12.dp,vertical=14.dp),verticalAlignment=Alignment.CenterVertically){
   Surface(color=Color.White.copy(alpha=.18f),shape=RoundedCornerShape(14.dp)){Icon(icon,contentDescription=title,tint=Color.White,modifier=Modifier.padding(9.dp).size(23.dp))}
   Spacer(Modifier.width(9.dp));Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(3.dp)){
    Text(title,color=Color.White.copy(alpha=.92f),fontSize=11.sp,fontWeight=FontWeight.SemiBold,lineHeight=14.sp)
    AnimatedContent(targetState=value,label="statValue"){v->Text(v.toString(),fontSize=24.sp,fontWeight=FontWeight.ExtraBold,color=Color.White)}
   }
  }
 }
}

@Composable fun DashboardShortcut(title:String,subtitle:String,icon: androidx.compose.ui.graphics.vector.ImageVector,modifier:Modifier=Modifier,onClick:()->Unit){
 var pressed by remember{mutableStateOf(false)}
 LaunchedEffect(pressed){if(pressed){delay(120);pressed=false}}
 val scale by animateFloatAsState(if(pressed)0.96f else 1f,animationSpec=spring(stiffness=520f),label="shortcutPress")
 Card(modifier.scale(scale).clickable{pressed=true;onClick()}.animateContentSize(),shape=RoundedCornerShape(20.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),elevation=CardDefaults.cardElevation(defaultElevation=3.dp)){
  Column(Modifier.fillMaxWidth().padding(horizontal=10.dp,vertical=13.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(7.dp)){
   Surface(shape=RoundedCornerShape(16.dp),color=MaterialTheme.colorScheme.secondaryContainer){Icon(icon,contentDescription=title,tint=MaterialTheme.colorScheme.secondary,modifier=Modifier.padding(11.dp).size(26.dp))}
   Text(title,fontWeight=FontWeight.Bold,fontSize=12.sp,color=MaterialTheme.colorScheme.onSurface,lineHeight=16.sp,textAlign=androidx.compose.ui.text.style.TextAlign.Center)
   Text(subtitle,fontSize=10.sp,color=MaterialTheme.colorScheme.onSurfaceVariant,lineHeight=13.sp,textAlign=androidx.compose.ui.text.style.TextAlign.Center)
  }
 }
}
@Composable fun RecordCard(r:CaseRecord,edit:()->Unit,delete:()->Unit,medicine:MedicineCatalogRecord?=null,isEnglish:Boolean=false){
 var ask by remember{mutableStateOf(false)}
 var expanded by remember{mutableStateOf(false)}
 Card(Modifier.fillMaxWidth().animateContentSize().clickable{expanded=!expanded},colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),shape=RoundedCornerShape(20.dp),elevation=CardDefaults.cardElevation(defaultElevation=2.dp)){
  Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){
   Row(verticalAlignment=Alignment.CenterVertically){
    Surface(shape=RoundedCornerShape(13.dp),color=MaterialTheme.colorScheme.secondaryContainer){Icon(Icons.Default.MedicalServices,null,tint=MaterialTheme.colorScheme.secondary,modifier=Modifier.padding(9.dp).size(22.dp))}
    Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(r.name,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.primary,fontSize=15.sp);Text(appLabel("رقم الأداء: ${r.performanceNo}","Employee No.: ${r.performanceNo}",isEnglish),fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)}
    IconButton(onClick=edit){Icon(Icons.Default.Edit,contentDescription=appLabel("تعديل","Edit",isEnglish),tint=MaterialTheme.colorScheme.secondary)}
    IconButton(onClick={ask=true}){Icon(Icons.Default.Delete,contentDescription=appLabel("حذف","Delete",isEnglish),tint=MaterialTheme.colorScheme.error)}
   }
   Row(verticalAlignment=Alignment.CenterVertically){Surface(shape=RoundedCornerShape(50),color=MaterialTheme.colorScheme.primaryContainer){Text(r.medicine,Modifier.padding(horizontal=11.dp,vertical=6.dp),fontWeight=FontWeight.Bold,fontSize=12.sp,color=MaterialTheme.colorScheme.onPrimaryContainer)};Spacer(Modifier.weight(1f));Text(r.strength,fontWeight=FontWeight.SemiBold,fontSize=12.sp,color=MaterialTheme.colorScheme.secondary)}
   Row(verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Event,null,tint=MaterialTheme.colorScheme.onSurfaceVariant,modifier=Modifier.size(15.dp));Spacer(Modifier.width(5.dp));Text(appLabel("الموافقة: ${r.approvalDate.ifBlank{"غير محدد"}}","Approval: ${r.approvalDate.ifBlank{"Not set"}}",isEnglish),fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant);Spacer(Modifier.weight(1f));TextButton(onClick={expanded=!expanded}){Text(if(expanded)appLabel("إخفاء التفاصيل","Hide details",isEnglish) else appLabel("التفاصيل","Details",isEnglish),fontSize=11.sp)} }
   androidx.compose.animation.AnimatedVisibility(visible=expanded){Column(verticalArrangement=Arrangement.spacedBy(4.dp)){
    if(r.condition.isNotBlank())Text(appLabel("الحالة المرضية: ${r.condition}","Condition: ${r.condition}",isEnglish),fontSize=12.sp)
    if(medicine!=null){if(medicine.genericName.isNotBlank())Text(appLabel("المادة الفعالة: ${medicine.genericName}","Active ingredient: ${medicine.genericName}",isEnglish),fontSize=12.sp,color=MaterialTheme.colorScheme.secondary);if(medicine.criticalClassification.isNotBlank())Text(appLabel("التصنيف الطبي: ${medicine.criticalClassification}","Medical class: ${medicine.criticalClassification}",isEnglish),fontSize=12.sp);if(medicine.indications.isNotBlank())Text(appLabel("دواعي الاستعمال المسجلة: ${medicine.indications}","Recorded indications: ${medicine.indications}",isEnglish),fontSize=12.sp) else Text(appLabel("المعلومات الطبية لهذا الدواء لم تكتمل مراجعتها بعد (${medicine.reviewStatus}).","Medical information for this medicine is still under review (${medicine.reviewStatus}).",isEnglish),fontSize=11.sp,color=MaterialTheme.colorScheme.tertiary)}
    if(r.approvalExpiry.isNotBlank())Text(appLabel("انتهاء الموافقة: ${r.approvalExpiry}","Approval expiry: ${r.approvalExpiry}",isEnglish),fontSize=12.sp)
   }}
  }
 }
 if(ask)AlertDialog(onDismissRequest={ask=false},title={Text(appLabel("حذف السجل؟","Delete record?",isEnglish))},text={Text(appLabel("هل أنت متأكد من حذف هذا السجل؟","Are you sure you want to delete this record?",isEnglish))},confirmButton={TextButton(onClick={delete;ask=false}){Text(appLabel("حذف","Delete",isEnglish))}},dismissButton={TextButton(onClick={ask=false}){Text(appLabel("إلغاء","Cancel",isEnglish))}})
}

@Composable
fun EditDialog(
    old: CaseRecord?,
    meds: List<String>,
    lookup: (String) -> EmployeeRecord?,
    strengthOptions: (String) -> List<String>,
    close: () -> Unit,
    save: (CaseRecord) -> Unit,
    isEnglish: Boolean = false
) {
    val labelsAr = listOf("المنطقة", "القطاع", "الاسم", "رقم الأداء", "اسم الدواء", "التركيز/العيار", "بيان إضافي 1", "بيان إضافي 2", "مدة الصرف", "الجرعة", "الحالة المرضية", "تاريخ الموافقة", "انتهاء الموافقة")
    val labelsEn = listOf("Region", "Sector", "Name", "Employee No.", "Medicine", "Strength", "Additional detail 1", "Additional detail 2", "Dispensing period", "Dosage", "Medical condition", "Approval date", "Approval expiry")
    val labels = if(isEnglish) labelsEn else labelsAr
    val values = remember(old) { mutableStateListOf(*(old?.cells()?.toTypedArray() ?: Array(13) { "" })) }
    var formError by remember(old) { mutableStateOf("") }
    var medicineMenu by remember { mutableStateOf(false) }
    var strengthMenu by remember { mutableStateOf(false) }
    val options = strengthOptions(values[4])

    AlertDialog(
        onDismissRequest = close,
        title = { Text(if (old == null) appLabel("إضافة مستفيد","Add beneficiary",isEnglish) else appLabel("تعديل مستفيد","Edit beneficiary",isEnglish)) },
        text = {
            Column(Modifier.heightIn(max = 530.dp).verticalScroll(rememberScrollState())) {
                labels.forEachIndexed { index, label ->
                    when (index) {
                        4 -> Box {
                            OutlinedTextField(
                                values[index], {}, Modifier.fillMaxWidth().padding(vertical = 2.dp),
                                label = { Text(label) }, readOnly = true,
                                trailingIcon = { IconButton(onClick = { medicineMenu = true }) { Icon(Icons.Default.ArrowDropDown, null) } }
                            )
                            DropdownMenu(expanded = medicineMenu, onDismissRequest = { medicineMenu = false }) {
                                meds.forEach { medicine ->
                                    DropdownMenuItem(text = { Text(medicine) }, onClick = {
                                        values[4] = medicine
                                        values[5] = ""
                                        medicineMenu = false
                                    })
                                }
                            }
                        }
                        5 -> if (options.isNotEmpty()) Box {
                            OutlinedTextField(
                                values[index], { values[index] = it }, Modifier.fillMaxWidth().padding(vertical = 2.dp),
                                label = { Text(label) },
                                trailingIcon = { IconButton(onClick = { strengthMenu = true }) { Icon(Icons.Default.ArrowDropDown, null) } }
                            )
                            DropdownMenu(expanded = strengthMenu, onDismissRequest = { strengthMenu = false }) {
                                options.forEach { strength ->
                                    DropdownMenuItem(text = { Text(strength) }, onClick = {
                                        values[5] = strength
                                        strengthMenu = false
                                    })
                                }
                            }
                        } else {
                            OutlinedTextField(values[index], { values[index] = it }, Modifier.fillMaxWidth().padding(vertical = 2.dp), label = { Text(label) })
                        }
                        else -> OutlinedTextField(
                            values[index], { values[index] = it }, Modifier.fillMaxWidth().padding(vertical = 2.dp),
                            label = { Text(label) }, singleLine = index != 10
                        )
                    }
                    if (index == 3 && values[index].isNotBlank()) {
                        val employee = lookup(values[index].trim())
                        if (employee != null) {
                            values[2] = employee.name
                            Text(appLabel("تم العثور على العامل: ${employee.name} • ${employee.job} • ${employee.entity} / ${employee.department}","Staff member found: ${employee.name} • ${employee.job} • ${employee.entity} / ${employee.department}",isEnglish), fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                        } else {
                            Text(appLabel("رقم الأداء غير موجود في دليل العاملين","Employee number was not found in the staff directory",isEnglish), fontSize = 11.sp, color = MaterialTheme.colorScheme.tertiary)
                        }
                    }
                }
                if (formError.isNotBlank()) Text(formError, color = Color.Red, fontSize = 12.sp)
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val record = CaseDataRules.normalizeForImport(CaseRecord.from(values.toList()).copy(id = old?.id ?: 0))
                    val issues = CaseDataRules.validate(listOf(record))
                    if (issues.isNotEmpty()) formError = issues.joinToString("\n")
                    else { formError = ""; save(record) }
                },
                enabled = values[2].isNotBlank() && values[3].isNotBlank() && values[4].isNotBlank()
            ) { Text(appLabel("حفظ","Save",isEnglish)) }
        },
        dismissButton = { TextButton(onClick = close) { Text(appLabel("إلغاء","Cancel",isEnglish)) } }
    )
}

fun pdfReport(activity:Activity,uri:Uri,rows:List<CaseRecord>,reportTitle:String="تقرير السجلات"){
 val doc=PdfDocument();val width=595;val height=842;val margin=30f;val body=TextPaint(Paint.ANTI_ALIAS_FLAG).apply{textSize=10f;color=android.graphics.Color.DKGRAY};val header=TextPaint(Paint.ANTI_ALIAS_FLAG).apply{textSize=16f;color=android.graphics.Color.rgb(7,89,199);isFakeBoldText=true;textAlign=Paint.Align.RIGHT};var pageNo=1;var page=doc.startPage(PdfDocument.PageInfo.Builder(width,height,pageNo).create());var canvas=page.canvas;var y=42f
 fun heading(){canvas.drawText("علاج الحالات حاجة - $reportTitle • عدد السجلات: ${rows.size}",width-margin,y,header);y+=28;canvas.drawLine(margin,y,width-margin,y,Paint().apply{color=android.graphics.Color.LTGRAY;strokeWidth=1f});y+=16}
 fun newPage(){doc.finishPage(page);pageNo++;page=doc.startPage(PdfDocument.PageInfo.Builder(width,height,pageNo).create());canvas=page.canvas;y=42f;heading()}
 heading()
 rows.forEachIndexed{index,r->
  val line="${index+1}) الاسم: ${r.name}   |   رقم الأداء: ${r.performanceNo}\nالدواء: ${r.medicine}   |   التركيز/العيار: ${r.strength}\nالمنطقة: ${r.region}   |   القطاع: ${r.sector}\nمدة الصرف: ${r.duration}   |   الجرعة: ${r.dosage}\nالحالة المرضية: ${r.condition}\nتاريخ الموافقة: ${r.approvalDate}   |   الانتهاء: ${r.approvalExpiry}\n${listOf(r.extra1,r.extra2).filter{it.isNotBlank()}.joinToString("   |   ")}"
  val layout=StaticLayout.Builder.obtain(line,0,line.length,body,(width-(margin*2)).toInt()).setAlignment(Layout.Alignment.ALIGN_OPPOSITE).setTextDirection(TextDirectionHeuristics.RTL).setIncludePad(false).setLineSpacing(2f,1f).build()
  if(y+layout.height>height-35)newPage()
  canvas.save();canvas.translate(margin,y);layout.draw(canvas);canvas.restore();y+=layout.height+10
  canvas.drawLine(margin,y,width-margin,y,Paint().apply{color=android.graphics.Color.LTGRAY;strokeWidth=0.5f});y+=8
 }
 doc.finishPage(page);activity.contentResolver.openOutputStream(uri)?.use{doc.writeTo(it)}?:error("تعذر حفظ تقرير PDF");doc.close()
}
