package com.familyproperties.app.security

import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

/** System biometric prompt wrapper. It never reads or stores biometric templates. */
object BiometricLogin {
    fun isAvailable(activity: FragmentActivity): Boolean {
        return try {
            val result = BiometricManager.from(activity).canAuthenticate(
                BiometricManager.Authenticators.BIOMETRIC_STRONG
            )
            result == BiometricManager.BIOMETRIC_SUCCESS
        } catch (_: RuntimeException) {
            false
        }
    }

    fun authenticate(
        activity: FragmentActivity,
        title: String = "تسجيل الدخول إلى أملاكنا",
        onSuccess: () -> Unit,
        onFailure: (String) -> Unit
    ) {
        try {
            val executor = ContextCompat.getMainExecutor(activity)
            val prompt = BiometricPrompt(activity, executor, object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    onSuccess()
                }
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    onFailure(errString.toString())
                }
                // A failed scan is not terminal; allow the system prompt to retry.
                override fun onAuthenticationFailed() = Unit
            })
            val info = BiometricPrompt.PromptInfo.Builder()
                .setTitle(title)
                .setSubtitle("استخدم وسيلة التحقق الآمنة المسجلة على جهازك")
                .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
                .setNegativeButtonText("إلغاء")
                .build()
            prompt.authenticate(info)
        } catch (error: RuntimeException) {
            onFailure(error.message ?: "تعذر تشغيل نافذة البصمة؛ استخدم كلمة المرور بدلاً من ذلك.")
        }
    }
}
