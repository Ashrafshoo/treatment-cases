from pathlib import Path

root = Path(__file__).resolve().parents[1]
source = (root / "app/src/main/java/com/example/rentals/io/WorkbookExporter.kt").read_text()

assert "private data class TableInfo(val name: String, val headers: List<String>)" in source
assert "SELECT * FROM `$table` LIMIT 0" in source
assert "zip.putNextEntry(ZipEntry(\"xl/worksheets/sheet${index+1}.xml\"))" in source
assert "while (cur.moveToNext())" in source
assert "writeRow(zip, rowNumber++, values)" in source
assert "val rows = mutableListOf<List<String>>()" not in source
assert "tables += (table to rows)" not in source
print("PASS: full database XLSX export streams one table/row at a time instead of retaining the workbook in memory.")
