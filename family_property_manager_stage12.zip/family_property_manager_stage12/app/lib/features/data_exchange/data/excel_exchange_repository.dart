import 'dart:convert';
import 'dart:io';
import 'package:excel/excel.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:sqflite_sqlcipher/sqflite.dart';
import '../../../core/database/app_database.dart';
import '../../auth/data/app_session.dart';
import '../../payments/data/payments_repository.dart';

class ExcelExchangeRepository {
  static const templates = <String, List<String>>{
    'مجموعات العقارات': ['id','name','description'],
    'العقارات': ['id','group_id','name','address_text','city','district','property_type','notes'],
    'الملاك': ['id','full_name','phone','notes'],
    'حصص الملكية': ['id','property_id','owner_id','share_percent','valid_from','valid_to','notes'],
    'الوحدات': ['id','property_id','unit_number','floor_label','unit_type','area','occupancy_status','address_details','current_tenant_id','notes','old_law_164_2025'],
    'المستأجرون': ['id','full_name','phone','national_id_last4','notes'],
    'العقود': ['id','unit_id','tenant_id','start_date','duration_value','duration_unit','manual_end_date','end_date_override_reason','initial_rent_minor','annual_increase_percent','increase_rule','increase_month','increase_day','law_164_2025_applies','status','notes'],
    'سجل الإيجارات': ['id','lease_id','amount_minor','currency_code','valid_from','valid_to','source_type','source_id','approval_status'],
    'الزيادات': ['id','lease_id','effective_date','percentage','previous_rent_minor','new_rent_minor','calculation_method','status','notes'],
    'التحصيلات': ['id','lease_id','paid_at','amount_minor','period_start','period_end','payment_method','notes'],
    'المصروفات': ['id','name','amount_minor','expense_date','notes'],
  };

  Future<File> createTemplate(String sheetName) async {
    AppSession.instance.requireAdmin();
    final headers=templates[sheetName];
    if(headers==null)throw ArgumentError('نوع القالب غير معروف');
    final book=Excel.createExcel();
    final sheet=book[sheetName];
    sheet.appendRow(headers.map((v)=>TextCellValue(v)).toList());
    sheet.appendRow(headers.map((_)=>TextCellValue('')).toList());
    final bytes=book.encode();
    if(bytes==null)throw StateError('تعذر إنشاء ملف Excel');
    return _write('template_${sheetName}_${DateTime.now().millisecondsSinceEpoch}.xlsx',bytes);
  }

  Future<File> exportAll() async {
    AppSession.instance.requireAdmin();
    final db=await AppDatabase.instance.database;
    final book=Excel.createExcel();
    const mappings=<String,String>{'مجموعات العقارات':'property_groups','العقارات':'properties','الملاك':'owners','حصص الملكية':'ownership_shares','الوحدات':'units','المستأجرون':'tenants','العقود':'leases','سجل الإيجارات':'rent_history','الزيادات':'rent_increases','التحصيلات':'payments','المصروفات':'expenses'};
    for(final entry in mappings.entries){
      final rows=await db.query(entry.value,orderBy:'created_at DESC');
      final sheet=book[entry.key];
      final columns=templates[entry.key]!;
      sheet.appendRow(columns.map((v)=>TextCellValue(v)).toList());
      for(final row in rows){sheet.appendRow(columns.map((key){final value=row[key];return value==null?const TextCellValue(''):TextCellValue(value.toString());}).toList());}
    }
    final bytes=book.encode();
    if(bytes==null)throw StateError('تعذر تصدير البيانات');
    return _write('family_properties_export_${DateTime.now().millisecondsSinceEpoch}.xlsx',bytes);
  }

  Future<File> exportMonthlyCollection({
    required DateTime month,
    required List<Map<String, Object?>> rows,
  }) async {
    AppSession.instance.requireAdmin();
    final book = Excel.createExcel();
    final sheet = book['كشف التحصيل الشهري'];
    sheet.appendRow(const [
      TextCellValue('العقار'),
      TextCellValue('رقم الوحدة'),
      TextCellValue('نوع الوحدة'),
      TextCellValue('المستأجر'),
      TextCellValue('معرّف العقد'),
      TextCellValue('الإيجار المرجعي بالجنيه'),
      TextCellValue('المبلغ المدخل للتسجيل بالجنيه'),
      TextCellValue('محدد للتحصيل'),
      TextCellValue('تعديل إيجار قيد المراجعة'),
    ]);
    for (final row in rows) {
      sheet.appendRow([
        TextCellValue(row['property_name']?.toString() ?? ''),
        TextCellValue(row['unit_number']?.toString() ?? ''),
        TextCellValue(row['unit_type']?.toString() ?? ''),
        TextCellValue(row['tenant_name']?.toString() ?? ''),
        TextCellValue(row['lease_id']?.toString() ?? ''),
        TextCellValue(row['suggested_rent_minor'] == null ? '' : (((row['suggested_rent_minor'] as num).toInt()) / 100).toStringAsFixed(2)),
        TextCellValue(row['amount_minor'] == null ? '' : (((row['amount_minor'] as num).toInt()) / 100).toStringAsFixed(2)),
        TextCellValue(row['selected'] == true ? 'نعم' : 'لا'),
        TextCellValue(row['has_pending_rent_review'] == true ? 'نعم' : 'لا'),
      ]);
    }
    final bytes = book.encode();
    if (bytes == null) throw StateError('تعذر إنشاء كشف Excel الشهري');
    final file = await _write(
      'monthly_collection_${month.year}_${month.month.toString().padLeft(2, '0')}_${DateTime.now().millisecondsSinceEpoch}.xlsx',
      bytes,
    );
    return file;
  }

  Future<Map<String,Object?>> pickAndValidate() async {
    AppSession.instance.requireAdmin();
    final result=await FilePicker.platform.pickFiles(type:FileType.custom,allowedExtensions:['xlsx'],withData:true);
    if(result==null||result.files.isEmpty)return {'cancelled':true};
    final file=result.files.single;
    final bytes=file.bytes??(file.path==null?null:await File(file.path!).readAsBytes());
    if(bytes==null)throw StateError('تعذر قراءة الملف المختار');
    final book=Excel.decodeBytes(bytes);
    if(book.tables.isEmpty)throw FormatException('ملف Excel لا يحتوي على أوراق بيانات');
    final parsed=<String,List<Map<String,String>>>{};
    final errors=<String>[];
    var totalRows=0;
    for(final entry in book.tables.entries){
      final rows=entry.value.rows;
      if(rows.isEmpty||rows.every((r)=>r.every((c)=>(c?.value?.toString().trim()??'').isEmpty)))continue;
      final expected=templates[entry.key];
      if(expected==null){errors.add('ورقة غير معروفة: ${entry.key}');continue;}
      final headers=rows.first.map((c)=>c?.value?.toString().trim()??'').toList();
      if(headers.any((h)=>h.isEmpty)){errors.add('توجد عناوين أعمدة فارغة في ورقة ${entry.key}');continue;}
      if(headers.toSet().length!=headers.length){errors.add('توجد أعمدة مكررة في ورقة ${entry.key}');continue;}
      final unknown=headers.where((h)=>!expected.contains(h)).toList();
      if(unknown.isNotEmpty){errors.add('أعمدة غير معروفة في ${entry.key}: ${unknown.join('، ')}');continue;}
      final missing=expected.where((h)=>!headers.contains(h)).toList();
      if(missing.isNotEmpty){errors.add('أعمدة ناقصة في ${entry.key}: ${missing.join('، ')}');continue;}
      final sheetRows=<Map<String,String>>[];
      for(var i=1;i<rows.length;i++){
        final cells=rows[i];
        final values=<String,String>{};
        for(var c=0;c<headers.length;c++){values[headers[c]]=c<cells.length?(cells[c]?.value?.toString().trim()??''):'';}
        if(values.values.every((v)=>v.isEmpty))continue;
        sheetRows.add(values);
      }
      parsed[entry.key]=sheetRows;
      totalRows+=sheetRows.length;
    }
    if(parsed.isEmpty)errors.add('لم يتم العثور على أوراق مدعومة للاستيراد');
    return {'cancelled':false,'file_name':file.name,'tables':parsed,'errors':errors,'data_rows':totalRows,'valid_structure':errors.isEmpty&&totalRows>0};
  }

  /// Imports new records and routes changes to existing IDs into the review queue.
  /// The operation is all-or-nothing: a foreign-key or validation failure rolls back.
  Future<Map<String,int>> applyImport(Map<String,Object?> preview) async {
    AppSession.instance.requireAdmin();
    if(preview['valid_structure']!=true)throw StateError('لا يمكن اعتماد ملف يحتوي على أخطاء بنيوية');
    final tables=preview['tables'] as Map<String,List<Map<String,String>>>;
    final db=await AppDatabase.instance.database;
    var inserted=0,reviewItems=0;
    const order=['مجموعات العقارات','العقارات','الملاك','المستأجرون','حصص الملكية','الوحدات','العقود','سجل الإيجارات','الزيادات','التحصيلات','المصروفات'];
    await db.transaction((tx)async{
      for(final sheetName in order){
        final rows=tables[sheetName]??const <Map<String,String>>[];
        for(var index=0;index<rows.length;index++){
          final row=rows[index];
          try{
            final outcome=await _importRow(tx,sheetName,row);
            inserted+=outcome.$1;
            reviewItems+=outcome.$2;
          }catch(e){throw StateError('ورقة $sheetName، الصف ${index+2}: $e');}
        }
      }
    });
    return {'inserted':inserted,'review_items':reviewItems};
  }

  Future<(int,int)> _importRow(Transaction tx,String sheet,Map<String,String> row) async {
    final id=row['id']??'';
    if(id.isEmpty)throw ArgumentError('المعرّف id مطلوب لربط السجلات دون تخمين');
    final config=switch(sheet){
      'مجموعات العقارات'=>('property_groups','property_group',<String>['name','description']),
      'العقارات'=>('properties','property',<String>['group_id','name','address_text','city','district','property_type','notes']),
      'الملاك'=>('owners','owner',<String>['full_name','phone','notes']),
      'المستأجرون'=>('tenants','tenant',<String>['full_name','phone','national_id_last4','notes']),
      'الوحدات'=>('units','unit',<String>['property_id','unit_number','floor_label','unit_type','area','occupancy_status','address_details','current_tenant_id','notes','old_law_164_2025']),
      'العقود'=>('leases','lease',<String>['unit_id','tenant_id','start_date','duration_value','duration_unit','manual_end_date','end_date_override_reason','initial_rent_minor','annual_increase_percent','increase_rule','increase_month','increase_day','law_164_2025_applies','status','notes']),
      'المصروفات'=>('expenses','expense',<String>['name','amount_minor','expense_date','notes']),
      _=>null,
    };
    if(sheet=='حصص الملكية')return _importOwnership(tx,row);
    if(sheet=='سجل الإيجارات')return _importRentHistory(tx,row);
    if(sheet=='الزيادات')return _importIncrease(tx,row);
    if(sheet=='التحصيلات')return _importPayment(tx,row);
    if(config==null)throw ArgumentError('ورقة غير مدعومة');
    final (table,entity,fields)=config;
    final existing=await tx.query(table,where:'id=?',whereArgs:[id],limit:1);
    final values=<String,Object?>{};
    for(final field in fields){
      final raw=row[field]??'';
      if(raw.isEmpty)continue;
      values[field]=switch(field){
        'area' || 'share_percent' || 'annual_increase_percent'=>double.tryParse(raw)??(throw FormatException('قيمة رقمية غير صحيحة للحقل $field')),
        'duration_value' || 'initial_rent_minor' || 'amount_minor' || 'increase_month' || 'increase_day'=>int.tryParse(raw)??(throw FormatException('قيمة عددية غير صحيحة للحقل $field')),
        'old_law_164_2025' || 'law_164_2025_applies'=>_boolInt(raw),
        'start_date' || 'manual_end_date' || 'expense_date'=>_normalizeDate(raw,field),
        _=>raw,
      };
    }
    final required=switch(sheet){'مجموعات العقارات'=>['name'],'العقارات'=>['name'],'الملاك'=>['full_name'],'المستأجرون'=>['full_name'],'الوحدات'=>['property_id','unit_number','unit_type'],'العقود'=>['unit_id','tenant_id','start_date','initial_rent_minor'],'المصروفات'=>['name','amount_minor','expense_date'],_=>const <String>[]};
    for(final field in required){if((row[field]??'').isEmpty)throw FormatException('الحقل $field مطلوب');}
    if(existing.isNotEmpty){
      var count=0;
      for(final entry in values.entries){
        final old=existing.first[entry.key];
        if((old?.toString()??'')!=(entry.value?.toString()??'')){
          final duplicate=await tx.query('review_items',where:'entity_type=? AND entity_id=? AND field_name=? AND proposed_value=? AND status=?',whereArgs:[entity,id,entry.key,entry.value?.toString(),'pending'],limit:1);
          if(duplicate.isNotEmpty)continue;
          await tx.insert('review_items',{'id':_id(),'entity_type':entity,'entity_id':id,'field_name':entry.key,'original_value':old?.toString(),'proposed_value':entry.value?.toString(),'source_description':'استيراد Excel: ${sheet}','confidence':1.0,'status':'pending'});
          count++;
        }
      }
      if(count>0){
        final table=switch(entity){'property'=>'properties','unit'=>'units','tenant'=>'tenants','owner'=>'owners','lease'=>'leases','expense'=>'expenses',_=>null};
        if(table!=null){final flags=<String,Object?>{'modified_unreviewed':1,'updated_at':DateTime.now().toIso8601String()};if(entity=='property'||entity=='unit')flags['review_status']='needs_review';await tx.update(table,flags,where:'id=?',whereArgs:[id]);}
      }
      return (0,count);
    }
    if(sheet=='العقارات')values.addAll({'review_status':'needs_review','modified_unreviewed':1,'source_status':'excel'});
    if(sheet=='الوحدات')values.addAll({'review_status':'needs_review','modified_unreviewed':1,'source_status':'excel'});
    if(sheet=='العقود'){
      final start=DateTime.tryParse(row['start_date']??'');
      if(start==null)throw FormatException('تاريخ بداية العقد غير صحيح');
      final manualEnd=DateTime.tryParse(row['manual_end_date']??'');
      if((row['manual_end_date']??'').isNotEmpty&&manualEnd==null)throw FormatException('تاريخ النهاية اليدوي غير صحيح');
      if(manualEnd!=null&&(row['end_date_override_reason']??'').trim().isEmpty)throw FormatException('سبب تعديل تاريخ نهاية العقد مطلوب');
      final initialRent=(values['initial_rent_minor'] as num).toInt();
      if(initialRent<0)throw FormatException('قيمة الإيجار لا يمكن أن تكون سالبة');
      final duration=int.tryParse(row['duration_value']??'');
      final unit=row['duration_unit'];
      if((duration==null)!=(unit==null||unit.isEmpty))throw FormatException('مدة العقد ووحدتها يجب أن يدخلا معاً');
      values['calculated_end_date']=duration==null?null:_date(_addDuration(start,duration,unit!));
      values['currency_code']='EGP';
      values['status']=(row['status']??'').isEmpty?(duration==null&&manualEnd==null?'open_ended':'active'):row['status'];
    }
    values['id']=id;
    await tx.insert(table,values);
    if(sheet=='العقارات'||sheet=='الوحدات'){
      await tx.insert('review_items',{'id':_id(),'entity_type':entity,'entity_id':id,'field_name':'review_status','original_value':'needs_review','proposed_value':'sound','source_description':'مراجعة سجل جديد مستورد من Excel','confidence':1.0,'status':'pending'});
    }
    if(sheet=='العقود'){
      final rent=(values['initial_rent_minor'] as num).toInt();
      final historyId=_id();
      await tx.insert('rent_history',{'id':historyId,'lease_id':id,'amount_minor':rent,'currency_code':'EGP','valid_from':row['start_date'],'source_type':'import','approval_status':'under_review'});
      await tx.insert('review_items',{'id':_id(),'entity_type':'rent_history','entity_id':historyId,'field_name':'approval_status','original_value':'under_review','proposed_value':'approved','source_description':'اعتماد الإيجار الابتدائي المستورد بعد المراجعة','confidence':1.0,'status':'pending'});
    }
    await tx.insert('audit_log',{'id':_id(),'user_id':AppSession.instance.userId,'entity_type':entity,'entity_id':id,'action':'import','after_json':jsonEncode(values)});
    return (1,0);
  }

  Future<(int,int)> _importOwnership(Transaction tx,Map<String,String> row) async {
    final id=row['id']??'';if(id.isEmpty)throw ArgumentError('المعرّف id مطلوب');
    for(final field in ['property_id','owner_id','share_percent']){if((row[field]??'').isEmpty)throw FormatException('الحقل $field مطلوب');}
    final share=double.tryParse(row['share_percent']!);if(share==null||share<=0||share>100)throw FormatException('نسبة الملكية يجب أن تكون بين 0 و100');
    final from= _nullIfEmpty(row['valid_from'])==null?null:_normalizeDate(row['valid_from']!,'valid_from');
    final to= _nullIfEmpty(row['valid_to'])==null?null:_normalizeDate(row['valid_to']!,'valid_to');
    if(from!=null&&to!=null&&to.compareTo(from)<0)throw FormatException('نهاية سريان الحصة تسبق بدايتها');
    final existing=await tx.query('ownership_shares',where:'id=?',whereArgs:[id],limit:1);if(existing.isNotEmpty)return (0,0);
    final overlaps=await tx.rawQuery('''SELECT COALESCE(SUM(share_percent),0) AS total FROM ownership_shares WHERE property_id=? AND (valid_to IS NULL OR valid_to>=?) AND (? IS NULL OR valid_from IS NULL OR valid_from<=?)''',[row['property_id'],from??'',to,to??'9999-12-31']);
    final total=(overlaps.first['total'] as num).toDouble()+share;if(total>100.0001)throw StateError('مجموع حصص الملكية المتداخلة سيتجاوز 100%');
    await tx.insert('ownership_shares',{'id':id,'property_id':row['property_id'],'owner_id':row['owner_id'],'share_percent':share,'valid_from':from,'valid_to':to,'notes':_nullIfEmpty(row['notes'])});
    await tx.insert('audit_log',{'id':_id(),'user_id':AppSession.instance.userId,'entity_type':'ownership_share','entity_id':id,'action':'import','after_json':jsonEncode(row)});
    return (1,0);
  }

  Future<(int,int)> _importRentHistory(Transaction tx,Map<String,String> row) async {
    final id=row['id']??'';if(id.isEmpty)throw ArgumentError('المعرّف id مطلوب');
    for(final f in ['lease_id','amount_minor','valid_from']){if((row[f]??'').isEmpty)throw FormatException('الحقل $f مطلوب');}
    final amount=int.tryParse(row['amount_minor']!);if(amount==null||amount<0)throw FormatException('قيمة الإيجار غير صحيحة');
    final validFrom=_normalizeDate(row['valid_from']!,'valid_from');
    final validTo=_nullIfEmpty(row['valid_to'])==null?null:_normalizeDate(row['valid_to']!,'valid_to');
    if(validTo!=null&&validTo.compareTo(validFrom)<0)throw FormatException('نهاية فترة الإيجار تسبق بدايتها');
    final lease=await tx.query('leases',columns:['id'],where:'id=?',whereArgs:[row['lease_id']],limit:1);if(lease.isEmpty)throw StateError('العقد المرتبط غير موجود');
    final existing=await tx.query('rent_history',where:'id=?',whereArgs:[id],limit:1);
    if(existing.isNotEmpty){var count=0;for(final field in ['amount_minor','valid_from','valid_to','source_type','source_id']){final proposed=_nullIfEmpty(row[field]);if(proposed==null)continue;final old=existing.first[field];if(old?.toString()!=proposed){await tx.insert('review_items',{'id':_id(),'entity_type':'rent_history','entity_id':id,'field_name':field,'original_value':old?.toString(),'proposed_value':proposed,'source_description':'استيراد سجل إيجار من Excel','confidence':1.0,'status':'pending'});count++;}}return (0,count);}
    await tx.insert('rent_history',{'id':id,'lease_id':row['lease_id'],'amount_minor':amount,'currency_code':'EGP','valid_from':validFrom,'valid_to':validTo,'source_type':_nullIfEmpty(row['source_type'])??'import','source_id':_nullIfEmpty(row['source_id']),'approval_status':'under_review'});
    await tx.insert('review_items',{'id':_id(),'entity_type':'rent_history','entity_id':id,'field_name':'approval_status','original_value':'under_review','proposed_value':'approved','source_description':'اعتماد قيمة إيجار مستوردة بعد مراجعتها','confidence':1.0,'status':'pending'});
    await tx.insert('audit_log',{'id':_id(),'user_id':AppSession.instance.userId,'entity_type':'rent_history','entity_id':id,'action':'import','after_json':jsonEncode(row)});
    return (1,1);
  }

  Future<(int,int)> _importIncrease(Transaction tx,Map<String,String> row) async {
    final id=row['id']??'';if(id.isEmpty)throw ArgumentError('المعرّف id مطلوب');
    for(final f in ['lease_id','effective_date','new_rent_minor']){if((row[f]??'').isEmpty)throw FormatException('الحقل $f مطلوب');}
    final lease=await tx.query('leases',columns:['id'],where:'id=?',whereArgs:[row['lease_id']],limit:1);if(lease.isEmpty)throw StateError('العقد المرتبط غير موجود');
    final newRent=int.tryParse(row['new_rent_minor']!);if(newRent==null||newRent<0)throw FormatException('قيمة الزيادة غير صحيحة');
    final effectiveDate=_normalizeDate(row['effective_date']!,'effective_date');
    final previous=int.tryParse(row['previous_rent_minor']??'');
    final percent=double.tryParse(row['percentage']??'');
    final existing=await tx.query('rent_increases',where:'id=?',whereArgs:[id],limit:1);if(existing.isNotEmpty)return (0,0);
    await tx.insert('rent_increases',{'id':id,'lease_id':row['lease_id'],'effective_date':effectiveDate,'percentage':percent,'previous_rent_minor':previous,'new_rent_minor':newRent,'calculation_method':_nullIfEmpty(row['calculation_method'])??'manual','status':'proposed','notes':_nullIfEmpty(row['notes'])??'زيادة مستوردة وتنتظر اعتماد المدير'});
    await tx.insert('audit_log',{'id':_id(),'user_id':AppSession.instance.userId,'entity_type':'rent_increase','entity_id':id,'action':'import','after_json':jsonEncode(row)});
    return (1,0);
  }

  Future<(int,int)> _importPayment(Transaction tx,Map<String,String> row) async {
    final id=row['id']??'';if(id.isEmpty)throw ArgumentError('المعرّف id مطلوب');for(final f in ['lease_id','paid_at','amount_minor']){if((row[f]??'').isEmpty)throw FormatException('الحقل $f مطلوب');}
    final amount=int.tryParse(row['amount_minor']!);if(amount==null||amount<=0)throw FormatException('مبلغ التحصيل غير صحيح');
    final existing=await tx.query('payments',where:'id=?',whereArgs:[id],limit:1);if(existing.isNotEmpty)return (0,0);
    final leaseRows=await tx.rawQuery('''SELECT l.id,l.law_164_2025_applies,t.full_name AS tenant,p.name AS property,u.unit_number FROM leases l JOIN tenants t ON t.id=l.tenant_id JOIN units u ON u.id=l.unit_id JOIN properties p ON p.id=u.property_id WHERE l.id=?''',[row['lease_id']]);
    if(leaseRows.isEmpty)throw StateError('العقد المرتبط غير موجود');
    final lease=leaseRows.first;final paidAt=_normalizeDate(row['paid_at']!,'paid_at');
    final periodStart=_nullIfEmpty(row['period_start'])==null?null:_normalizeDate(row['period_start']!,'period_start');
    final periodEnd=_nullIfEmpty(row['period_end'])==null?null:_normalizeDate(row['period_end']!,'period_end');
    if(periodStart!=null&&periodEnd!=null&&periodEnd.compareTo(periodStart)<0)throw FormatException('نهاية فترة التحصيل تسبق بدايتها');
    await tx.insert('payments',{'id':id,'lease_id':row['lease_id'],'paid_at':paidAt,'amount_minor':amount,'currency_code':'EGP','period_start':periodStart,'period_end':periodEnd,'payment_method':_nullIfEmpty(row['payment_method']),'notes':_nullIfEmpty(row['notes'])});
    final receiptId=_id();
    await tx.insert('receipts',{'id':receiptId,'payment_id':id,'lease_id':row['lease_id'],'receipt_number':'IMP-$id','issued_at':paidAt,'tenant_snapshot':lease['tenant'],'property_snapshot':lease['property'],'unit_snapshot':lease['unit_number']?.toString(),'amount_minor':amount,'amount_words_snapshot':PaymentsRepository.amountInArabicWords(amount),'currency_code':'EGP','period_snapshot':periodStart==null?'':'$periodStart${periodEnd==null?'':' إلى $periodEnd'}','payment_method_snapshot':row['payment_method'],'law_164_2025_snapshot':lease['law_164_2025_applies']??0,'approved':0});
    await tx.insert('audit_log',{'id':_id(),'user_id':AppSession.instance.userId,'entity_type':'payment','entity_id':id,'action':'import','after_json':jsonEncode(row)});
    return (1,0);
  }

  int _boolInt(String value){final v=value.toLowerCase();if({'1','true','yes','نعم'}.contains(v))return 1;if({'0','false','no','لا'}.contains(v))return 0;throw FormatException('قيمة نعم/لا غير صحيحة');}
  String? _nullIfEmpty(String? v)=>v==null||v.isEmpty?null:v;
  String _normalizeDate(String raw,String field){final parsed=DateTime.tryParse(raw);if(parsed==null)throw FormatException('تاريخ غير صحيح للحقل $field');return _date(parsed);}
  String _id()=>DateTime.now().microsecondsSinceEpoch.toString();
  String _date(DateTime d)=>'${d.year.toString().padLeft(4,'0')}-${d.month.toString().padLeft(2,'0')}-${d.day.toString().padLeft(2,'0')}';
  DateTime _addDuration(DateTime start,int value,String unit){switch(unit){case 'days':return start.add(Duration(days:value));case 'months':final first=DateTime(start.year,start.month+value,1);final last=DateTime(first.year,first.month+1,0).day;return DateTime(first.year,first.month,start.day>last?last:start.day);case 'years':final last=DateTime(start.year+value,start.month+1,0).day;return DateTime(start.year+value,start.month,start.day>last?last:start.day);default:throw ArgumentError('وحدة مدة غير مدعومة');}}
  Future<void> shareFile(File file) async {AppSession.instance.requireAdmin();await Share.shareXFiles([XFile(file.path)],text:'ملف بيانات إدارة أملاك العائلة');}
  Future<File> _write(String name,List<int> bytes) async {final dir=await getTemporaryDirectory();final file=File('${dir.path}/$name');await file.writeAsBytes(bytes,flush:true);return file;}
}
