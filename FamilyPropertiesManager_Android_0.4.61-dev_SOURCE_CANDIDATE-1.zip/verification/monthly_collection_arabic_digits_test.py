#!/usr/bin/env python3
from pathlib import Path
s=(Path(__file__).resolve().parents[1]/'app/src/main/java/com/example/rentals/features/printing/MonthlyCollectionScreen.kt').read_text(encoding='utf-8')
assert 'value=aggregateExportDigits(period)' in s
assert 'onValueChange={period=aggregateImportDigits(it)}' in s
assert 'aggregateExportDigits(batchReceipts.size.toString())' in s
assert 'aggregateExportDigits(b.itemCount.toString())' in s
assert '٣ في A4' in s
assert 'aggregateExportDigits(b.period)' in s
print('PASS: collection period, visible counts, print labels and generated receipt filenames use Arabic-Indic digits')
