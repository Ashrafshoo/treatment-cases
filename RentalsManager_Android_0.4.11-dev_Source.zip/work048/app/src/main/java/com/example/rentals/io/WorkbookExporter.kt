package com.example.rentals.io

import android.content.ContentResolver
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Exports every application table to a separate plain-value worksheet. */
object WorkbookExporter {
    fun exportAll(resolver: ContentResolver, uri: Uri, database: SQLiteDatabase) {
        val tables = mutableListOf<Pair<String, List<List<String>>>>()
        database.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name", null).use { c ->
            while (c.moveToNext()) {
                val table = c.getString(0)
                if (!table.matches(Regex("[A-Za-z0-9_]+"))) continue
                val rows = mutableListOf<List<String>>()
                database.rawQuery("SELECT * FROM `$table`", null).use { cur ->
                    val headers = (0 until cur.columnCount).map { cur.getColumnName(it) }
                    rows += headers
                    while (cur.moveToNext()) rows += (0 until cur.columnCount).map { i -> if (cur.isNull(i)) "" else cur.getString(i) ?: "" }
                }
                tables += (table to rows)
            }
        }
        require(tables.isNotEmpty()) { "لا توجد جداول للتصدير" }
        resolver.openOutputStream(uri, "w")!!.use { raw -> ZipOutputStream(raw).use { zip ->
            entry(zip, "[Content_Types].xml", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>${tables.indices.joinToString("") { "<Override PartName=\"/xl/worksheets/sheet${it+1}.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" }}</Types>")
            entry(zip, "_rels/.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>")
            val names = tables.mapIndexed { i, p -> safeSheet(p.first, i) }
            entry(zip, "xl/workbook.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets>${names.mapIndexed { i, n -> "<sheet name=\"${esc(n)}\" sheetId=\"${i+1}\" r:id=\"rId${i+1}\"/>" }.joinToString("")}</sheets></workbook>")
            entry(zip, "xl/_rels/workbook.xml.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">${names.indices.joinToString("") { "<Relationship Id=\"rId${it+1}\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet${it+1}.xml\"/>" }}</Relationships>")
            tables.forEachIndexed { index, pair ->
                val xml = buildString {
                    append("<?xml version=\"1.0\" encoding=\"UTF-8\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>")
                    pair.second.forEachIndexed { ri, row -> append("<row r=\"${ri+1}\">"); row.forEachIndexed { ci, value -> append("<c r=\"${column(ci+1)}${ri+1}\" t=\"inlineStr\"><is><t xml:space=\"preserve\">${esc(value)}</t></is></c>") }; append("</row>") }
                    append("</sheetData></worksheet>")
                }
                entry(zip, "xl/worksheets/sheet${index+1}.xml", xml)
            }
        } }
    }
    fun exportRows(resolver: ContentResolver, uri: Uri, sheetName: String, headers: List<String>, rows: List<List<String>>) {
        val all = listOf(headers) + rows
        resolver.openOutputStream(uri, "w")!!.use { raw -> ZipOutputStream(raw).use { zip ->
            entry(zip, "[Content_Types].xml", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/></Types>")
            entry(zip, "_rels/.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>")
            entry(zip, "xl/workbook.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\"${esc(safeSheet(sheetName,0))}\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>")
            entry(zip, "xl/_rels/workbook.xml.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/></Relationships>")
            val xml=buildString { append("<?xml version=\"1.0\" encoding=\"UTF-8\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>");all.forEachIndexed{ri,row->append("<row r=\"${ri+1}\">");row.forEachIndexed{ci,value->append("<c r=\"${column(ci+1)}${ri+1}\" t=\"inlineStr\"><is><t xml:space=\"preserve\">${esc(value)}</t></is></c>")};append("</row>")};append("</sheetData></worksheet>") }
            entry(zip,"xl/worksheets/sheet1.xml",xml)
        } }
    }

    private fun safeSheet(name: String, index: Int): String = name.replace(Regex("[\\\\/?*\\[\\]:]"), "_").take(25).ifBlank { "بيانات${index+1}" }
    private fun column(n0: Int): String { var n=n0; var s=""; while(n>0){val r=(n-1)%26;s=('A'+r)+s;n=(n-1)/26};return s }
    private fun esc(s:String)=s.filter { it == '\t' || it == '\n' || it == '\r' || it.code >= 0x20 }.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&apos;")
    private fun entry(z:ZipOutputStream,name:String,text:String){z.putNextEntry(ZipEntry(name));z.write(text.toByteArray(Charsets.UTF_8));z.closeEntry()}
}
