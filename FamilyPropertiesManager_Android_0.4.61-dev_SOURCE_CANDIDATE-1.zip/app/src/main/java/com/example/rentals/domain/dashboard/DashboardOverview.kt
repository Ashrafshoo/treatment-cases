package com.example.rentals.domain.dashboard

/** Minimal domain input; the domain layer does not depend on SQLite or data-layer models. */
data class DashboardUnitSnapshot(val rent: Double?, val status: String)

/** Conservative operational overview; deliberately does not infer rent collection or arrears. */
data class DashboardOverview(
    val totalRecords: Int,
    val includedOperationalRecords: Int,
    val registeredRentTotal: Double,
    val needsReviewCount: Int
)

class BuildDashboardOverview {
    operator fun invoke(units: List<DashboardUnitSnapshot>): DashboardOverview {
        val included = units.filterNot { isExcludedFromOperationalCount(it.status) }
        val needsReview = included.count { unit ->
            unit.rent == null || !unit.rent.isFinite() || unit.rent < 0.0 ||
                listOf("مؤجل", "تغيير مستأجر", "غير محدد", "مراجعة")
                    .any { marker -> unit.status.contains(marker, ignoreCase = true) }
        }
        val registeredRent = included.mapNotNull { it.rent?.takeIf { value -> value.isFinite() && value >= 0.0 } }.sum()
        return DashboardOverview(
            totalRecords = units.size,
            includedOperationalRecords = included.size,
            registeredRentTotal = registeredRent,
            needsReviewCount = needsReview
        )
    }

    private fun isExcludedFromOperationalCount(status: String): Boolean {
        // Payment stoppage is not the same as a sold, closed, duplicate or excluded unit.
        return listOf("مغلقة", "مباعة", "مكرر", "مستبعد").any { status.contains(it, ignoreCase = true) }
    }
}
