package com.familyproperties.app.notifications

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.familyproperties.app.FamilyDatabase
import java.time.LocalDate

/** Delivers already-approved reminder rows; it does not invent or modify lease dates. */
class DueNotificationWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = try {
        val helper = FamilyDatabase.create(applicationContext)
        try {
            val db = helper.writableDatabase
            val today = LocalDate.now().toString()
            val due = mutableListOf<DueItem>()
            db.rawQuery(
                "SELECT id, entity_type, entity_id, notification_type, due_at FROM notifications WHERE status='pending' AND date(due_at) <= date(?) ORDER BY due_at LIMIT 50",
                arrayOf(today)
            ).use { c ->
                while (c.moveToNext()) due += DueItem(c.getString(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4))
            }
            if (due.isNotEmpty()) {
                createChannel()
                if (Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
                    due.forEach { item ->
                        val title = when (item.type) {
                            "lease_end" -> "تنبيه انتهاء عقد"
                            "rent_increase" -> "تذكير بزيادة الإيجار"
                            "review_due" -> "عنصر يحتاج إلى مراجعة"
                            else -> "تنبيه من أملاكنا"
                        }
                        val text = "موعد الاستحقاق: ${item.dueAt}"
                        val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
                            .setSmallIcon(com.familyproperties.app.R.drawable.ic_launcher_foreground)
                            .setContentTitle(title).setContentText(text)
                            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                            .setPriority(NotificationCompat.PRIORITY_DEFAULT).setAutoCancel(true).build()
                        NotificationManagerCompat.from(applicationContext).notify(item.id.hashCode(), notification)
                        db.execSQL("UPDATE notifications SET status='shown' WHERE id=? AND status='pending'", arrayOf(item.id))
                    }
                }
            }
        } finally { helper.close() }
        Result.success()
    } catch (_: SecurityException) { Result.retry() }
      catch (_: Exception) { Result.retry() }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "تنبيهات أملاكنا", NotificationManager.IMPORTANCE_DEFAULT))
        }
    }

    private data class DueItem(val id: String, val entityType: String, val entityId: String, val type: String, val dueAt: String)
    companion object { private const val CHANNEL_ID = "amlakna_reminders" }
}
