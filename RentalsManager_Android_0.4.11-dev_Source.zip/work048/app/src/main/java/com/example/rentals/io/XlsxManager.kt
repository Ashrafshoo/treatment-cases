package com.example.rentals.io

import android.content.ContentResolver
import android.net.Uri
import android.util.Xml
import com.example.rentals.data.UnitRecord
import org.xmlpull.v1.XmlPullParser
import java.io.InputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** XLSX bridge for plain-value data exchange. It intentionally does not overwrite source workbooks or preserve their formatting/formulas. */
object XlsxManager {
    private val headers=listOf("كود الوحدة","العقار","اسم المستأجر","نوع الوحدة","القيمة الشهرية","الحالة التشغيلية","وصف العين","ملاحظات")
    fun export(resolver:ContentResolver,uri:Uri,units:List<UnitRecord>) {
        resolver.openOutputStream(uri,"w")!!.use { raw -> ZipOutputStream(raw).use { zip ->
            entry(zip,"[Content_Types].xml","""<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>""")
            entry(zip,"_rels/.rels","""<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""")
            entry(zip,"xl/workbook.xml","""<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="الوحدات" sheetId="1" r:id="rId1"/></sheets></workbook>""")
            entry(zip,"xl/_rels/workbook.xml.rels","""<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>""")
            val all=mutableListOf<List<String>>(); all+=headers
            units.forEach { all+=listOf(it.code,it.property,it.tenant,it.unitType,it.rent?.toString()?:"",it.status,it.description,it.notes) }
            val xml=buildString { append("<?xml version=\"1.0\" encoding=\"UTF-8\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>")
                all.forEachIndexed { ri,row -> append("<row r=\"${ri+1}\">"); row.forEachIndexed { ci,v -> val ref=col(ci+1)+(ri+1); val numeric=ri>0 && ci==4 && v.isNotBlank() && v.toDoubleOrNull()!=null; append("<c r=\"$ref\" ${if(numeric) "t=\"n\"" else "t=\"inlineStr\""}>"); if(numeric) append("<v>${v.toDouble()}</v>") else append("<is><t xml:space=\"preserve\">${esc(v)}</t></is>"); append("</c>") }; append("</row>") }; append("</sheetData></worksheet>") }
            entry(zip,"xl/worksheets/sheet1.xml",xml)
        } }
    }
    fun import(resolver:ContentResolver,uri:Uri):List<UnitRecord> {
        val entries=mutableMapOf<String,ByteArray>(); ZipInputStream(resolver.openInputStream(uri)!!).use { z -> var e=z.nextEntry; while(e!=null){entries[e.name]=z.readBytes();e=z.nextEntry} }
        val shared=parseShared(entries["xl/sharedStrings.xml"])
        val workbook=entries["xl/workbook.xml"] ?: error("ملف Excel غير صالح")
        val rels=entries["xl/_rels/workbook.xml.rels"] ?: error("تعذر قراءة أوراق المصنف")
        val sheetName="سجل الوحدات المبدئي"
        val parser=Xml.newPullParser(); parser.setInput(workbook.inputStream(),"UTF-8"); var rid=""
        var ev=parser.eventType; while(ev!=XmlPullParser.END_DOCUMENT){if(ev==XmlPullParser.START_TAG && parser.name=="sheet" && parser.getAttributeValue(null,"name")==sheetName){rid=parser.getAttributeValue("http://schemas.openxmlformats.org/officeDocument/2006/relationships","id")?:"";break};ev=parser.next()}
        if(rid.isBlank()) {
            val p2=Xml.newPullParser(); p2.setInput(workbook.inputStream(),"UTF-8"); var ev2=p2.eventType
            while(ev2!=XmlPullParser.END_DOCUMENT){if(ev2==XmlPullParser.START_TAG&&p2.name=="sheet"&&p2.getAttributeValue(null,"name")=="الوحدات"){rid=p2.getAttributeValue("http://schemas.openxmlformats.org/officeDocument/2006/relationships","id")?:"";break};ev2=p2.next()}
        }
        if(rid.isBlank()) error("لم أجد ورقة «سجل الوحدات المبدئي» أو «الوحدات». استخدم ملف المشروع أو القالب الذي يصدره التطبيق.")
        val rp=Xml.newPullParser(); rp.setInput(rels.inputStream(),"UTF-8"); var target=""
        ev=rp.eventType; while(ev!=XmlPullParser.END_DOCUMENT){if(ev==XmlPullParser.START_TAG && rp.name=="Relationship" && rp.getAttributeValue(null,"Id")==rid){target=rp.getAttributeValue(null,"Target")?:"";break};ev=rp.next()}
        val path="xl/"+target.removePrefix("/").let{if(it.startsWith("xl/"))it.removePrefix("xl/") else it}
        val sheet=entries[path] ?: error("تعذر فتح ورقة الوحدات")
        val rows=parseSheet(sheet,shared)
        if(rows.isEmpty()) return emptyList()
        val h=rows.first().map{it.trim()}; fun idx(vararg names:String)=h.indexOfFirst{x->names.any{x.contains(it,true)}}
        val code=idx("معرّف السجل","كود الوحدة")
        val property=idx("المجموعة/العقار","العقار")
        val tenant=idx("اسم المستأجر")
        val type=idx("نوع الوحدة")
        val rent=idx("القيمة الحالية","القيمة الشهرية")
        val receiptRent=idx("قيمة الإيصال")
        val status=idx("حالة الوحدة التشغيلية","الحالة التشغيلية")
        val desc=idx("وصف العين")
        val address=idx("العنوان كما ورد")
        val classification=idx("التصنيف حسب الإيصال")
        val section=idx("القسم بالكشف")
        val source=idx("مصدر البيانات")
        val linkStatus=idx("حالة الربط")
        val notes=idx("ملاحظات الكشف","ملاحظات")
        if(tenant<0) error("عمود اسم المستأجر غير موجود")
        fun value(row:List<String>, index:Int)=if(index>=0) row.getOrNull(index).orEmpty().trim() else ""
        return rows.drop(1).mapNotNull { r ->
            val name=value(r,tenant)
            if(name.isBlank()) null else {
                val sourceStatus = value(r,status)
                val preserved = listOf(
                    "العنوان كما ورد" to value(r,address),
                    "قيمة الإيصال" to value(r,receiptRent),
                    "التصنيف" to value(r,classification),
                    "القسم بالكشف" to value(r,section),
                    "مصدر البيانات" to value(r,source),
                    "حالة الربط" to value(r,linkStatus),
                    "ملاحظات الاعتماد" to value(r,notes),
                    "مراجعة حالة التشغيل" to if (sourceStatus.isBlank()) "الحالة غير واردة في المصدر؛ تم تصنيفها غير محسومة لحين مراجعتها، ولن تُنشأ لها مسودة إيصال قابلة للتحصيل قبل الاعتماد." else ""
                ).filter { it.second.isNotBlank() }.joinToString("\n") { "${it.first}: ${it.second}" }
                UnitRecord(
                    code=value(r,code), property=value(r,property), tenant=name,
                    unitType=value(r,type).ifBlank{"غير محدد"},
                    rent=value(r,rent).replace(",","").toDoubleOrNull(),
                    status=sourceStatus.ifBlank{"غير محسومة"},
                    description=value(r,desc), notes=preserved
                )
            }
        }
    }
    private fun parseShared(bytes:ByteArray?):List<String>{if(bytes==null)return emptyList();val p=Xml.newPullParser();p.setInput(bytes.inputStream(),"UTF-8");val out=mutableListOf<String>();var inSi=false;var b=StringBuilder();var e=p.eventType;while(e!=XmlPullParser.END_DOCUMENT){if(e==XmlPullParser.START_TAG&&p.name=="si"){inSi=true;b=StringBuilder()}else if(e==XmlPullParser.START_TAG&&p.name=="t"&&inSi){b.append(p.nextText())}else if(e==XmlPullParser.END_TAG&&p.name=="si"){out+=b.toString();inSi=false};e=p.next()};return out}
    private fun parseSheet(bytes:ByteArray,shared:List<String>):List<List<String>>{val p=Xml.newPullParser();p.setInput(bytes.inputStream(),"UTF-8");val rows=mutableListOf<List<String>>();var row=mutableMapOf<Int,String>();var col=0;var type="";var value="";var inCell=false;var e=p.eventType;while(e!=XmlPullParser.END_DOCUMENT){if(e==XmlPullParser.START_TAG&&p.name=="row"){row=mutableMapOf()}else if(e==XmlPullParser.START_TAG&&p.name=="c"){inCell=true;type=p.getAttributeValue(null,"t")?:"";col=colIndex(p.getAttributeValue(null,"r")?:"A1");value=""}else if(e==XmlPullParser.START_TAG&&p.name=="v"&&inCell){value=p.nextText()}else if(e==XmlPullParser.START_TAG&&p.name=="t"&&inCell){value=p.nextText()}else if(e==XmlPullParser.END_TAG&&p.name=="c"){val v=if(type=="s")shared.getOrNull(value.toIntOrNull()?:-1).orEmpty()else value;row[col]=v;inCell=false}else if(e==XmlPullParser.END_TAG&&p.name=="row"){if(row.isNotEmpty())rows+=((0..(row.keys.maxOrNull()?:0)).map{row[it].orEmpty()})};e=p.next()};return rows}
    private fun colIndex(ref:String):Int{val letters=ref.takeWhile{it.isLetter()};var n=0;letters.forEach{n=n*26+(it.uppercaseChar()-'A'+1)};return n-1}
    private fun col(n0:Int):String{var n=n0;var s="";while(n>0){val r=(n-1)%26;s=( 'A'+r)+s;n=(n-1)/26};return s}
    private fun entry(z:ZipOutputStream,name:String,text:String){z.putNextEntry(ZipEntry(name));z.write(text.toByteArray(Charsets.UTF_8));z.closeEntry()}
    private fun esc(s:String)=s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&apos;")
}
