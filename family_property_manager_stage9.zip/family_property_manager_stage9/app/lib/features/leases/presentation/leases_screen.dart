import 'package:flutter/material.dart';

import '../data/leases_repository.dart';
import '../../auth/data/app_session.dart';
import '../../records/data/records_repository.dart';

class LeasesScreen extends StatefulWidget {
  const LeasesScreen({super.key});

  @override
  State<LeasesScreen> createState() => _LeasesScreenState();
}

class _LeasesScreenState extends State<LeasesScreen> {
  final _repo = LeasesRepository();
  final _recordsRepo = RecordsRepository();
  late Future<List<Map<String, Object?>>> _leases;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  void _refresh() => _leases = _repo.leases();

  Future<void> _addLease() async {
    final saved = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (_) => _LeaseForm(repository: _repo),
    );
    if (saved == true && mounted) setState(_refresh);
  }

  Future<void> _editLease(Map<String,Object?> row) async {
    final saved = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (_) => _LeaseForm(repository: _repo, record: row),
    );
    if (saved == true && mounted) setState(_refresh);
  }

  Future<void> _clearModified(Map<String,Object?> lease) async {
    try{await _recordsRepo.clearModifiedFlag('leases',lease['id'] as String);if(mounted)setState(_refresh);}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}
  }

  Future<void> _archive(Map<String, Object?> lease) async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('أرشفة العقد'),
        content: Text('هل تريد أرشفة عقد ${lease['tenant_name']}؟ سيظل محفوظاً في السجل التاريخي.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('أرشفة')),
        ],
      ),
    );
    if (yes == true) {
      await _repo.archiveLease(lease['id'] as String);
      if (mounted) setState(_refresh);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('العقود والإيجارات')),
        floatingActionButton: AppSession.instance.isAdmin ? FloatingActionButton.extended(onPressed:_addLease,icon:const Icon(Icons.add),label:const Text('إضافة عقد')) : null,
        body: FutureBuilder<List<Map<String, Object?>>>(
          future: _leases,
          builder: (context, snapshot) {
            if (snapshot.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator());
            }
            if (snapshot.hasError) return Center(child: Text('تعذر تحميل العقود: ${snapshot.error}'));
            final rows = snapshot.data ?? [];
            if (rows.isEmpty) return const Center(child: Text('لا توجد عقود مسجلة حتى الآن'));
            return ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 96),
              itemCount: rows.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (context, index) {
                final row = rows[index];
                final rent = ((row['current_rent_minor'] ?? row['initial_rent_minor'] ?? 0) as num) / 100;
                final end = row['effective_end_date']?.toString() ?? 'مفتوح المدة';
                return Card(
                  child: ListTile(
                    isThreeLine: true,
                    leading: const CircleAvatar(child: Icon(Icons.description_outlined)),
                    title: Text('${row['tenant_name']} • ${row['property_name']} / ${row['unit_number'] ?? '—'}'),
                    subtitle: Text('بداية العقد: ${row['start_date']}\nنهاية العقد: $end  •  الإيجار: ${rent.toStringAsFixed(2)} جنيه'),
                    tileColor:(row['modified_unreviewed'] as num?)?.toInt()==1?Theme.of(context).colorScheme.tertiaryContainer.withOpacity(0.35):null,
                    onTap: AppSession.instance.isAdmin ? () => _editLease(row) : null,
                    trailing: AppSession.instance.isAdmin ? PopupMenuButton<String>(onSelected:(value){if(value=='edit')_editLease(row);if(value=='archive')_archive(row);if(value=='clear')_clearModified(row);},itemBuilder:(_)=>[const PopupMenuItem(value:'edit',child:Text('تعديل العقد')),const PopupMenuItem(value:'archive',child:Text('أرشفة')),if((row['modified_unreviewed'] as num?)?.toInt()==1)const PopupMenuItem(value:'clear',child:Text('إزالة علامة التعديل بعد المراجعة'))]) : null,
                  ),
                );
              },
            );
          },
        ),
      );
}

class _LeaseForm extends StatefulWidget {
  const _LeaseForm({required this.repository, this.record});
  final LeasesRepository repository;
  final Map<String,Object?>? record;

  @override
  State<_LeaseForm> createState() => _LeaseFormState();
}

class _LeaseFormState extends State<_LeaseForm> {
  final _formKey = GlobalKey<FormState>();
  final _rent = TextEditingController();
  final _duration = TextEditingController(text: '1');
  final _increase = TextEditingController();
  final _overrideReason = TextEditingController();
  DateTime _start = DateTime.now();
  DateTime? _manualEnd;
  String? _unitId;
  String? _tenantId;
  String _durationUnit = 'years';
  String _increaseRule = 'none';
  int _increaseMonth = 9;
  int _increaseDay = 1;
  bool _law164 = false;
  bool _residential = true;
  bool _saving = false;
  late Future<List<Map<String, Object?>>> _units;
  late Future<List<Map<String, Object?>>> _tenants;

  @override
  void initState() {
    super.initState();
    _units = widget.repository.leaseOptions();
    _tenants = widget.repository.tenants();
    final r=widget.record;
    if(r!=null){
      _rent.text=(((r['initial_rent_minor'] as num?)??0)/100).toStringAsFixed(2);
      _duration.text=r['duration_value']?.toString()??'';
      _increase.text=r['annual_increase_percent']?.toString()??'';
      _start=DateTime.tryParse(r['start_date'] as String? ?? '')??DateTime.now();
      _manualEnd=DateTime.tryParse(r['manual_end_date'] as String? ?? '');
      _overrideReason.text=r['end_date_override_reason']?.toString()??'';
      _unitId=r['unit_id'] as String?;
      _tenantId=r['tenant_id'] as String?;
      _durationUnit=r['duration_unit'] as String? ?? 'years';
      _increaseRule=r['increase_rule'] as String? ?? 'none';
      _increaseMonth=(r['increase_month'] as num?)?.toInt()??9;
      _increaseDay=(r['increase_day'] as num?)?.toInt()??1;
      _law164=(r['law_164_2025_applies'] as num?)?.toInt()==1;
      final type=(r['unit_type'] as String? ?? '').toLowerCase();
      _residential=type.contains('سكن')||type.contains('شقة')||type.contains('residential');
    }
  }

  @override
  void dispose() {
    _rent.dispose();
    _duration.dispose();
    _increase.dispose();
    _overrideReason.dispose();
    super.dispose();
  }

  String _fmt(DateTime d) => '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  Future<void> _pickDate({required bool end}) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: end ? (_manualEnd ?? _start) : _start,
      firstDate: DateTime(1950),
      lastDate: DateTime(2100),
    );
    if (picked != null) setState(() { if (end) { _manualEnd = picked; } else { _start = picked; } });
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate() || _unitId == null || _tenantId == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('يرجى اختيار الوحدة والمستأجر وإكمال البيانات')));
      return;
    }
    setState(() => _saving = true);
    try {
      final amount = (double.parse(_rent.text.trim()) * 100).round();
      final duration = _duration.text.trim().isEmpty ? null : int.parse(_duration.text.trim());
      await widget.repository.saveLease(
        id: widget.record?['id'] as String?,
        unitId: _unitId!, tenantId: _tenantId!, startDate: _start,
        durationValue: duration, durationUnit: duration == null ? null : _durationUnit,
        manualEndDate: _manualEnd, overrideReason: _overrideReason.text.trim(),
        initialRentMinor: amount,
        annualIncreasePercent: _increase.text.trim().isEmpty ? null : double.parse(_increase.text.trim()),
        increaseRule: _increaseRule, increaseMonth: _increaseMonth, increaseDay: _increaseDay,
        law164: _law164, residential: _residential, minimumOldRentMinor: 25000,
      );
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر حفظ العقد: $e')));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) => Padding(
        padding: EdgeInsets.only(left: 18, right: 18, top: 18, bottom: MediaQuery.of(context).viewInsets.bottom + 18),
        child: Form(
          key: _formKey,
          child: ListView(
            shrinkWrap: true,
            children: [
              Text(widget.record==null?'بيانات العقد الجديد':'تعديل بيانات العقد', style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 16),
              FutureBuilder<List<Map<String, Object?>>>(future: _units, builder: (context, snap) {
                final rows = snap.data ?? [];
                return DropdownButtonFormField<String>(
                  value: _unitId,
                  decoration: const InputDecoration(labelText: 'الوحدة'),
                  items: rows.map((r) => DropdownMenuItem(value: r['unit_id'] as String, child: Text('${r['property_name']} • ${r['unit_number'] ?? 'بدون رقم'}'))).toList(),
                  onChanged: (v) => setState(() { _unitId = v; final selected = rows.where((r) => r['unit_id'] == v); if (selected.isNotEmpty) { final type = (selected.first['unit_type'] as String? ?? '').toLowerCase(); _residential = type.contains('سكن') || type.contains('شقة') || type.contains('residential'); if (selected.first['tenant_id'] != null) _tenantId = selected.first['tenant_id'] as String; _law164 = (selected.first['old_law_164_2025'] as num?)?.toInt() == 1; if (_law164 && _residential) { _increase.text = '15'; _increaseRule = 'fixed_month_day'; _increaseMonth = 9; _increaseDay = 1; } else { _increase.clear(); _increaseRule = 'none'; } } }),
                  validator: (v) => v == null ? 'اختر الوحدة' : null,
                );
              }),
              const SizedBox(height: 12),
              FutureBuilder<List<Map<String, Object?>>>(future: _tenants, builder: (context, snap) {
                final rows = snap.data ?? [];
                return DropdownButtonFormField<String>(
                  value: _tenantId,
                  decoration: const InputDecoration(labelText: 'المستأجر'),
                  items: rows.map((r) => DropdownMenuItem(value: r['id'] as String, child: Text(r['full_name'] as String))).toList(),
                  onChanged: (v) => setState(() => _tenantId = v),
                  validator: (v) => v == null ? 'اختر المستأجر' : null,
                );
              }),
              const SizedBox(height: 12),
              ListTile(contentPadding: EdgeInsets.zero, title: const Text('تاريخ بداية العقد'), subtitle: Text(_fmt(_start)), trailing: IconButton(onPressed: () => _pickDate(end: false), icon: const Icon(Icons.calendar_month))),
              Row(children: [Expanded(child: TextFormField(controller: _duration, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'مدة العقد (اتركها فارغة لمفتوح المدة)'), validator: (v) { if (v == null || v.trim().isEmpty) return null; return int.tryParse(v) == null || int.parse(v) <= 0 ? 'أدخل مدة صحيحة' : null; })), const SizedBox(width: 10), SizedBox(width: 112, child: DropdownButtonFormField<String>(value: _durationUnit, decoration: const InputDecoration(labelText: 'الوحدة'), items: const [DropdownMenuItem(value: 'years', child: Text('سنوات')), DropdownMenuItem(value: 'months', child: Text('أشهر')), DropdownMenuItem(value: 'days', child: Text('أيام'))], onChanged: (v) => setState(() => _durationUnit = v ?? 'years')))]),
              ListTile(contentPadding: EdgeInsets.zero, title: const Text('نهاية يدوية بديلة (اختياري)'), subtitle: Text(_manualEnd == null ? 'سيتم استخدام نهاية المدة المحسوبة' : _fmt(_manualEnd!)), trailing: Wrap(children: [IconButton(onPressed: () => _pickDate(end: true), icon: const Icon(Icons.edit_calendar)), if (_manualEnd != null) IconButton(onPressed: () => setState(() => _manualEnd = null), icon: const Icon(Icons.clear))])),
              if (_manualEnd != null) TextFormField(controller: _overrideReason, decoration: const InputDecoration(labelText: 'سبب تعديل تاريخ النهاية')),
              const SizedBox(height: 12),
              TextFormField(controller: _rent, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'الإيجار الشهري بالجنيه'), validator: (v) => double.tryParse(v ?? '') == null || double.parse(v!) < 0 ? 'أدخل قيمة صحيحة' : null),
              TextFormField(controller: _increase, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'نسبة الزيادة السنوية % (اختياري)'), validator: (v) => v == null || v.trim().isEmpty || (double.tryParse(v) != null && double.parse(v) >= 0) ? null : 'نسبة غير صحيحة'),
              DropdownButtonFormField<String>(value: _increaseRule, decoration: const InputDecoration(labelText: 'موعد الزيادة'), items: const [DropdownMenuItem(value: 'anniversary', child: Text('في ذكرى بداية العقد')), DropdownMenuItem(value: 'fixed_month_day', child: Text('شهر ويوم ثابتان')), DropdownMenuItem(value: 'manual_dates', child: Text('تواريخ يحددها المدير')), DropdownMenuItem(value: 'none', child: Text('لا توجد زيادة تلقائية'))], onChanged: (v) => setState(() => _increaseRule = v ?? 'anniversary')),
              if (_increaseRule == 'fixed_month_day') Row(children: [Expanded(child: DropdownButtonFormField<int>(value: _increaseMonth, decoration: const InputDecoration(labelText: 'الشهر'), items: List.generate(12, (i) => DropdownMenuItem(value: i + 1, child: Text('${i + 1}'))), onChanged: (v) => setState(() => _increaseMonth = v ?? 9))), const SizedBox(width: 12), Expanded(child: DropdownButtonFormField<int>(value: _increaseDay, decoration: const InputDecoration(labelText: 'اليوم'), items: List.generate(31, (i) => DropdownMenuItem(value: i + 1, child: Text('${i + 1}'))), onChanged: (v) => setState(() => _increaseDay = v ?? 1)))]),
              SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('خاضع لقانون 164 لسنة 2025'), value: _law164, onChanged: (v) => setState(() { _law164 = v; if (v && _residential) { _increase.text = '15'; _increaseRule = 'fixed_month_day'; _increaseMonth = 9; _increaseDay = 1; } else { _increase.clear(); _increaseRule = 'none'; } })),
              if (_law164) SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('الوحدة سكنية (ينطبق الحد الأدنى المحدد)'), subtitle: const Text('الوحدات التجارية لا يطبق عليها حد 250 جنيه ولا تُفرض عليها زيادة 15% تلقائياً'), value: _residential, onChanged: (v) => setState(() { _residential = v; if (v) { _increase.text = '15'; _increaseRule = 'fixed_month_day'; _increaseMonth = 9; _increaseDay = 1; } else { _increase.clear(); _increaseRule = 'none'; } })),
              const SizedBox(height: 18),
              FilledButton.icon(onPressed: _saving ? null : _save, icon: const Icon(Icons.save_outlined), label: Text(_saving ? 'جارٍ الحفظ…' : widget.record==null?'حفظ العقد':'حفظ التعديلات')),
            ],
          ),
        ),
      );
}
