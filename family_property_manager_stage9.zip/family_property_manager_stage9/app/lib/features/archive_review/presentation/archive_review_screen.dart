import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:open_filex/open_filex.dart';

import '../data/archive_review_repository.dart';
import '../../auth/data/app_session.dart';

class ArchiveReviewScreen extends StatefulWidget {
  const ArchiveReviewScreen({super.key});
  @override
  State<ArchiveReviewScreen> createState() => _ArchiveReviewScreenState();
}

class _ArchiveReviewScreenState extends State<ArchiveReviewScreen> with SingleTickerProviderStateMixin {
  final _repo = ArchiveReviewRepository();
  late final TabController _tabs;
  late Future<List<Map<String, Object?>>> _reviews;
  late Future<List<Map<String, Object?>>> _documents;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 2, vsync: this);
    _refresh();
  }
  @override
  void dispose() { _tabs.dispose(); super.dispose(); }
  void _refresh() { _reviews = _repo.pendingReviews(); _documents = _repo.documents(); }

  Future<void> _resolve(String id, bool approve) async {
    try {
      await _repo.resolveReview(id, approve: approve, reviewer: 'Ashrafshoo');
      if (mounted) setState(_refresh);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذرت المراجعة: $e')));
    }
  }

  Future<void> _addDocument() async {
    final saved = await showDialog<bool>(context: context, builder: (_) => const _DocumentDialog());
    if (saved == true && mounted) setState(_refresh);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('الأرشيف ومركز المراجعة'), bottom: TabBar(controller: _tabs, tabs: const [Tab(text: 'مركز المراجعة'), Tab(text: 'الأرشيف') ])),
    floatingActionButton: AnimatedBuilder(animation:_tabs,builder:(_,__)=>AppSession.instance.isAdmin&&_tabs.index==1?FloatingActionButton.extended(onPressed:_addDocument,icon:const Icon(Icons.add),label:const Text('إضافة مستند')):const SizedBox.shrink()),
    body: TabBarView(controller: _tabs, children: [
      FutureBuilder<List<Map<String, Object?>>>(future: _reviews, builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
        if (snap.hasError) return Center(child: Text('تعذر تحميل المراجعات: ${snap.error}'));
        final rows = snap.data ?? [];
        if (rows.isEmpty) return const Center(child: Text('لا توجد عناصر معلقة للمراجعة'));
        return ListView.builder(padding: const EdgeInsets.all(12), itemCount: rows.length, itemBuilder: (context, i) {
          final r = rows[i];
          return Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('${r['entity_label'] ?? r['entity_id']} • ${r['entity_type']}', style: const TextStyle(fontWeight: FontWeight.bold)),
            if (r['field_name'] != null) Text('الحقل: ${r['field_name']}'),
            Text('القيمة الحالية: ${r['original_value'] ?? 'غير محددة'}'),
            Text('القيمة المقترحة: ${r['proposed_value'] ?? 'لا توجد'}'),
            if (r['source_description'] != null) Text('المصدر: ${r['source_description']}'),
            if (r['confidence'] != null) Text('درجة الثقة: ${((r['confidence'] as num) * 100).round()}%'),
            if(AppSession.instance.isAdmin)const SizedBox(height:8), if(AppSession.instance.isAdmin)Row(children:[Expanded(child:OutlinedButton.icon(onPressed:()=>_resolve(r['id'] as String,false),icon:const Icon(Icons.close),label:const Text('رفض'))),const SizedBox(width:8),Expanded(child:FilledButton.icon(onPressed:()=>_resolve(r['id'] as String,true),icon:const Icon(Icons.check),label:const Text('اعتماد')))]),
          ])));
        });
      }),
      FutureBuilder<List<Map<String, Object?>>>(future: _documents, builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
        if (snap.hasError) return Center(child: Text('تعذر تحميل الأرشيف: ${snap.error}'));
        final rows = snap.data ?? [];
        if (rows.isEmpty) return const Center(child: Text('الأرشيف فارغ'));
        return ListView.separated(padding: const EdgeInsets.all(12), itemCount: rows.length, separatorBuilder: (_, __) => const SizedBox(height: 6), itemBuilder: (context, i) {
          final r = rows[i];
          return Card(child: ListTile(leading: const Icon(Icons.description_outlined), title: Text('${r['title']}'), subtitle: Text('${r['entity_type']} • ${r['entity_id']}\n${r['relative_path']}'), isThreeLine: true, trailing: AppSession.instance.isAdmin ? PopupMenuButton<String>(onSelected:(v)async{if(v=='open'){final base=await getApplicationDocumentsDirectory();final file=File(p.join(base.path,r['relative_path'] as String));if(await file.exists()){await OpenFilex.open(file.path);}else if(mounted){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('الملف غير موجود في مساحة التطبيق')));}}else{await _repo.archiveDocument(r['id'] as String);if(mounted)setState(_refresh);}},itemBuilder:(_)=>const [PopupMenuItem(value:'open',child:Text('فتح المستند')),PopupMenuItem(value:'archive',child:Text('أرشفة'))]) : IconButton(onPressed:()async{final base=await getApplicationDocumentsDirectory();final file=File(p.join(base.path,r['relative_path'] as String));if(await file.exists()){await OpenFilex.open(file.path);}},icon:const Icon(Icons.open_in_new))));
        });
      }),
    ]),
  );
}

class _DocumentDialog extends StatefulWidget {
  const _DocumentDialog();
  @override
  State<_DocumentDialog> createState() => _DocumentDialogState();
}
class _DocumentDialogState extends State<_DocumentDialog> {
  final _form = GlobalKey<FormState>();
  final _entityId = TextEditingController();
  final _title = TextEditingController();
  final _path = TextEditingController();
  String _entityType = 'property';
  String _source = 'manual';
  bool _saving = false;
  String? _pickedFileName;
  @override
  void dispose() { _entityId.dispose(); _title.dispose(); _path.dispose(); super.dispose(); }
  Future<void> _pickFile() async {
    final result=await FilePicker.platform.pickFiles(withData:false);
    if(result==null||result.files.single.path==null)return;
    final source=File(result.files.single.path!);
    final docs=await getApplicationDocumentsDirectory();
    final folder=Directory(p.join(docs.path,'property_archive'));
    await folder.create(recursive:true);
    final safeName='${DateTime.now().microsecondsSinceEpoch}_${p.basename(source.path)}';
    final stored=await source.copy(p.join(folder.path,safeName));
    setState(()=>_pickedFileName=result.files.single.name);
    _path.text=p.join('property_archive',p.basename(stored.path));
    if(_title.text.trim().isEmpty)_title.text=p.basenameWithoutExtension(source.path);
  }
  @override
  Widget build(BuildContext context) => AlertDialog(
    title: const Text('إضافة مستند إلى الأرشيف'),
    content: Form(key: _form, child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
      DropdownButtonFormField<String>(value: _entityType, decoration: const InputDecoration(labelText: 'نوع السجل'), items: const [DropdownMenuItem(value: 'property', child: Text('عقار')), DropdownMenuItem(value: 'unit', child: Text('وحدة')), DropdownMenuItem(value: 'tenant', child: Text('مستأجر')), DropdownMenuItem(value: 'lease', child: Text('عقد')), DropdownMenuItem(value: 'receipt', child: Text('إيصال')), DropdownMenuItem(value: 'owner', child: Text('مالك'))], onChanged: (v) => setState(() => _entityType = v ?? 'property')),
      TextFormField(controller: _entityId, decoration: const InputDecoration(labelText: 'معرّف السجل المرتبط'), validator: (v) => v == null || v.trim().isEmpty ? 'أدخل معرّف السجل' : null),
      TextFormField(controller: _title, decoration: const InputDecoration(labelText: 'اسم المستند'), validator: (v) => v == null || v.trim().isEmpty ? 'أدخل اسم المستند' : null),
      OutlinedButton.icon(onPressed:_saving?null:_pickFile,icon:const Icon(Icons.attach_file),label:Text(_pickedFileName??'اختيار ملف من الهاتف')),
      if(_path.text.isNotEmpty) Text('تم نسخ الملف إلى مساحة التطبيق: ${_path.text}',style:const TextStyle(fontSize:12)),
      if(_path.text.isEmpty) const Text('يجب اختيار الملف من الهاتف أولاً.',style:TextStyle(fontSize:12)),
      DropdownButtonFormField<String>(value: _source, decoration: const InputDecoration(labelText: 'مصدر المستند'), items: const [DropdownMenuItem(value: 'manual', child: Text('إضافة يدوية')), DropdownMenuItem(value: 'scan', child: Text('مسح ضوئي')), DropdownMenuItem(value: 'excel', child: Text('Excel')), DropdownMenuItem(value: 'receipt', child: Text('إيصال')), DropdownMenuItem(value: 'other', child: Text('أخرى'))], onChanged: (v) => setState(() => _source = v ?? 'manual')),
      const SizedBox(height: 8), const Text('يتم الاحتفاظ بنسخة داخل مساحة التطبيق الخاصة.', style: TextStyle(fontSize: 12)),
    ]))),
    actions: [TextButton(onPressed: _saving ? null : () => Navigator.pop(context, false), child: const Text('إلغاء')), FilledButton(onPressed: _saving ? null : () async {
      if (_entityId.text.trim().isEmpty || _title.text.trim().isEmpty || _path.text.trim().isEmpty) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('اختر الملف وأدخل معرّف السجل واسمه'))); return; }
      setState(() => _saving = true);
      try {
        await ArchiveReviewRepository().addDocument(entityType: _entityType, entityId: _entityId.text.trim(), title: _title.text.trim(), relativePath: _path.text.trim(), sourceType: _source);
        if (context.mounted) Navigator.pop(context, true);
      } catch (e) { if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذرت الإضافة: $e'))); }
      finally { if (mounted) setState(() => _saving = false); }
    }, child: const Text('حفظ'))],
  );
}
