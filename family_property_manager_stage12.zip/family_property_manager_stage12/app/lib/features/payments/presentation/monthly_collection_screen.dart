import 'package:flutter/material.dart';

import '../data/payments_repository.dart';
import '../services/receipt_print_service.dart';
import '../../data_exchange/data/excel_exchange_repository.dart';
import '../../auth/data/app_session.dart';

class MonthlyCollectionScreen extends StatefulWidget {
  const MonthlyCollectionScreen({super.key});

  @override
  State<MonthlyCollectionScreen> createState() => _MonthlyCollectionScreenState();
}

class _MonthlyCollectionScreenState extends State<MonthlyCollectionScreen> {
  final _repository = PaymentsRepository();
  final Map<String, TextEditingController> _amounts = {};
  final Set<String> _selectedLeaseIds = {};
  DateTime _month = DateTime(DateTime.now().year, DateTime.now().month, 1);
  DateTime _paidAt = DateTime.now();
  String _method = 'cash';
  bool _saving = false;
  late Future<List<Map<String, Object?>>> _rows;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  @override
  void dispose() {
    for (final controller in _amounts.values) {
      controller.dispose();
    }
    super.dispose();
  }

  void _refresh() {
    _rows = _repository.monthlyCollectionUnits(_month);
  }

  String _money(Object? value) {
    if (value == null) return 'غير محدد';
    return '${((value as num).toInt() / 100).toStringAsFixed(2)} جنيه';
  }

  String _date(DateTime value) =>
      '${value.year}-${value.month.toString().padLeft(2, '0')}-${value.day.toString().padLeft(2, '0')}';

  void _changeMonth({int? year, int? month}) {
    setState(() {
      _month = DateTime(year ?? _month.year, month ?? _month.month, 1);
      _selectedLeaseIds.clear();
      for (final controller in _amounts.values) {
        controller.dispose();
      }
      _amounts.clear();
      _refresh();
    });
  }

  TextEditingController _amountController(Map<String, Object?> row) {
    final leaseId = row['lease_id'] as String;
    return _amounts.putIfAbsent(leaseId, () {
      final suggested = (row['suggested_rent_minor'] as num?)?.toInt();
      return TextEditingController(
        text: suggested == null ? '' : (suggested / 100).toStringAsFixed(2),
      );
    });
  }

  Future<void> _pickPaidAt() async {
    final value = await showDatePicker(
      context: context,
      initialDate: _paidAt,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (value != null) setState(() => _paidAt = value);
  }

  Future<void> _exportMonthlySheet() async {
    try {
      final rows = await _rows;
      final exportRows = rows.map((row) {
        final leaseId = row['lease_id'] as String?;
        final amount = leaseId == null ? null : double.tryParse(_amounts[leaseId]?.text.trim() ?? '');
        return <String, Object?>{
          ...row,
          'selected': leaseId != null && _selectedLeaseIds.contains(leaseId),
          'amount_minor': leaseId != null && _selectedLeaseIds.contains(leaseId) && amount != null ? (amount * 100).round() : null,
          'has_pending_rent_review': (row['has_pending_rent_review'] as num?)?.toInt() == 1,
        };
      }).toList();
      final exchange = ExcelExchangeRepository();
      final file = await exchange.exportMonthlyCollection(month: _month, rows: exportRows);
      await exchange.shareFile(file);
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('تعذر تصدير كشف الشهر: $error')),
        );
      }
    }
  }

  Future<void> _printApprovedMonth() async {
    try {
      final count = await ReceiptPrintService().printApprovedReceipts(month: _month);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('تم إرسال $count إيصالاً معتمداً إلى الطباعة (3 إيصالات في صفحة A4)')),
        );
      }
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('تعذرت طباعة إيصالات الشهر: $error')),
        );
      }
    }
  }

  Future<void> _submit() async {
    if (!AppSession.instance.isAdmin || _selectedLeaseIds.isEmpty) return;
    final entries = <Map<String, Object?>>[];
    for (final leaseId in _selectedLeaseIds) {
      final text = _amounts[leaseId]?.text.trim() ?? '';
      final value = double.tryParse(text);
      if (value == null || value <= 0) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('أدخل مبلغ التحصيل الصحيح لكل وحدة محددة')),
        );
        return;
      }
      entries.add({'lease_id': leaseId, 'amount_minor': (value * 100).round()});
    }

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('تأكيد تسجيل التحصيلات'),
        content: Text(
          'سيتم تسجيل ${entries.length} تحصيلاً عن شهر ${_month.year}-${_month.month.toString().padLeft(2, '0')} وإنشاء إيصالات مسودة مرتبطة بها. لن تصبح الإيصالات معتمدة أو قابلة للطباعة قبل اعتمادها.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('مراجعة'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('تأكيد التسجيل'),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;

    setState(() => _saving = true);
    try {
      final count = await _repository.recordMonthlyCollections(
        month: _month,
        paidAt: _paidAt,
        method: _method,
        entries: entries,
      );
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('تم تسجيل $count تحصيلاً وإنشاء $count إيصالاً كمسودات')),
        );
        Navigator.pop(context, true);
      }
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('لم يتم تسجيل الدفعة الشهرية: $error')),
        );
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const Text('دورة التحصيل الشهرية'),
          actions: [
            if (AppSession.instance.isAdmin)
              IconButton(
                tooltip: 'تصدير كشف التحصيل الشهري Excel',
                onPressed: _exportMonthlySheet,
                icon: const Icon(Icons.table_view_outlined),
              ),
            if (AppSession.instance.isAdmin)
              IconButton(
                tooltip: 'طباعة إيصالات الشهر المعتمدة (3 في A4)',
                onPressed: _printApprovedMonth,
                icon: const Icon(Icons.print_outlined),
              ),
          ],
        ),
        body: FutureBuilder<List<Map<String, Object?>>>(
          future: _rows,
          builder: (context, snapshot) {
            if (snapshot.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator());
            }
            if (snapshot.hasError) {
              return Center(child: Text('تعذر تحميل كشف الوحدات: ${snapshot.error}'));
            }
            final rows = snapshot.data ?? [];
            final eligible = rows.where((row) => row['lease_id'] != null).toList();
            final allSelected = eligible.isNotEmpty &&
                eligible.every((row) => _selectedLeaseIds.contains(row['lease_id']));
            return Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
                  child: Card(
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: DropdownButtonFormField<int>(
                                  value: _month.month,
                                  decoration: const InputDecoration(labelText: 'الشهر'),
                                  items: List.generate(
                                    12,
                                    (index) => DropdownMenuItem(
                                      value: index + 1,
                                      child: Text('${index + 1}'.padLeft(2, '0')),
                                    ),
                                  ),
                                  onChanged: (value) {
                                    if (value != null) _changeMonth(month: value);
                                  },
                                ),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: DropdownButtonFormField<int>(
                                  value: _month.year,
                                  decoration: const InputDecoration(labelText: 'السنة'),
                                  items: List.generate(
                                    12,
                                    (index) => DateTime.now().year - 5 + index,
                                  ).map((year) => DropdownMenuItem(value: year, child: Text('$year'))).toList(),
                                  onChanged: (value) {
                                    if (value != null) _changeMonth(year: value);
                                  },
                                ),
                              ),
                            ],
                          ),
                          ListTile(
                            contentPadding: EdgeInsets.zero,
                            title: const Text('تاريخ استلام المبلغ'),
                            subtitle: Text(_date(_paidAt)),
                            trailing: IconButton(
                              onPressed: _pickPaidAt,
                              icon: const Icon(Icons.calendar_month),
                            ),
                          ),
                          DropdownButtonFormField<String>(
                            value: _method,
                            decoration: const InputDecoration(labelText: 'طريقة استلام الإيجار'),
                            items: const [
                              DropdownMenuItem(value: 'cash', child: Text('نقداً')),
                              DropdownMenuItem(value: 'bank_transfer', child: Text('تحويل بنكي')),
                              DropdownMenuItem(value: 'wallet', child: Text('محفظة إلكترونية')),
                              DropdownMenuItem(value: 'cheque', child: Text('شيك')),
                              DropdownMenuItem(value: 'other', child: Text('أخرى')),
                            ],
                            onChanged: (value) => setState(() => _method = value ?? 'cash'),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                CheckboxListTile(
                  value: allSelected,
                  onChanged: eligible.isEmpty
                      ? null
                      : (checked) => setState(() {
                            if (checked == true) {
                              _selectedLeaseIds.addAll(
                                eligible.map((row) => row['lease_id'] as String),
                              );
                            } else {
                              _selectedLeaseIds.clear();
                            }
                          }),
                  title: const Text('تحديد كل الوحدات ذات العقود السارية في الشهر'),
                  subtitle: Text('المحدد: ${_selectedLeaseIds.length} من ${eligible.length} وحدة مؤهلة'),
                  controlAffinity: ListTileControlAffinity.leading,
                ),
                const Divider(height: 1),
                Expanded(
                  child: rows.isEmpty
                      ? const Center(child: Text('لا توجد وحدات مسجلة'))
                      : ListView.separated(
                          padding: const EdgeInsets.only(bottom: 12),
                          itemCount: rows.length,
                          separatorBuilder: (_, __) => const Divider(height: 1),
                          itemBuilder: (context, index) {
                            final row = rows[index];
                            final leaseId = row['lease_id'] as String?;
                            final hasLease = leaseId != null;
                            final selected = hasLease && _selectedLeaseIds.contains(leaseId);
                            final pending = (row['has_pending_rent_review'] as num?)?.toInt() == 1;
                            return Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                              child: Card(
                                child: Padding(
                                  padding: const EdgeInsets.all(8),
                                  child: Column(
                                    children: [
                                      CheckboxListTile(
                                        value: selected,
                                        onChanged: !hasLease
                                            ? null
                                            : (checked) => setState(() {
                                                  if (checked == true) {
                                                    _selectedLeaseIds.add(leaseId!);
                                                  } else {
                                                    _selectedLeaseIds.remove(leaseId!);
                                                  }
                                                }),
                                        title: Text('${row['tenant_name'] ?? 'مستأجر غير محدد'} • وحدة ${row['unit_number'] ?? '—'}'),
                                        subtitle: Text('${row['property_name']} • ${row['unit_type'] ?? 'نوع غير محدد'}\n${hasLease ? 'الإيجار المرجعي: ${_money(row['suggested_rent_minor'])}' : 'لا يوجد عقد يغطي الشهر المحدد'}'),
                                        isThreeLine: true,
                                        controlAffinity: ListTileControlAffinity.leading,
                                      ),
                                      if (hasLease)
                                        Padding(
                                          padding: const EdgeInsetsDirectional.only(start: 52, end: 8, bottom: 8),
                                          child: TextField(
                                            controller: _amountController(row),
                                            enabled: AppSession.instance.isAdmin,
                                            keyboardType: const TextInputType.numberWithOptions(decimal: true),
                                            decoration: InputDecoration(
                                              labelText: 'المبلغ المحصل فعلياً بالجنيه',
                                              helperText: pending ? 'يوجد تعديل إيجار قيد المراجعة؛ أدخل المبلغ الفعلي يدوياً.' : null,
                                            ),
                                          ),
                                        ),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                ),
                if (AppSession.instance.isAdmin)
                  SafeArea(
                    top: false,
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: SizedBox(
                        width: double.infinity,
                        child: FilledButton.icon(
                          onPressed: _saving || _selectedLeaseIds.isEmpty ? null : _submit,
                          icon: const Icon(Icons.receipt_long_outlined),
                          label: Text(_saving ? 'جارٍ تسجيل التحصيلات…' : 'تسجيل التحصيلات المحددة وإنشاء الإيصالات'),
                        ),
                      ),
                    ),
                  ),
              ],
            );
          },
        ),
      );
}
