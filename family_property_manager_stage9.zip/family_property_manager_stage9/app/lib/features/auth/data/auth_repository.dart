import 'dart:convert';
import 'dart:math';
import 'package:cryptography/cryptography.dart';
import 'package:sqflite_sqlcipher/sqflite.dart';
import '../../../core/database/app_database.dart';
import 'app_session.dart';

class AuthRepository {
  Future<Database> get _db async=>AppDatabase.instance.database;
  final _pbkdf2=Pbkdf2(macAlgorithm:Hmac.sha256(),iterations:210000,bits:256);
  String _id()=>DateTime.now().microsecondsSinceEpoch.toString();
  Future<bool> hasUsers() async {final rows=await (await _db).rawQuery('SELECT COUNT(*) AS n FROM users');return (rows.first['n'] as num).toInt()>0;}

  Future<void> createInitialAdmin({required String password,required String confirm}) async {
    if(password.length<10)throw ArgumentError('كلمة المرور يجب ألا تقل عن 10 أحرف');
    if(password!=confirm)throw ArgumentError('تأكيد كلمة المرور غير مطابق');
    final db=await _db;
    await db.transaction((tx)async{
      final count=Sqflite.firstIntValue(await tx.rawQuery('SELECT COUNT(*) FROM users'))??0;
      if(count>0)throw StateError('تم إعداد حساب المدير بالفعل');
      final encoded=await _hash(password);
      final userId=_id();
      await tx.insert('users',{'id':userId,'username':'Ashrafshoo','display_name':'مدير أملاك العائلة','role':'administrator','password_hash':encoded,'is_active':1});
      await tx.insert('audit_log',{'id':_id(),'user_id':userId,'entity_type':'user','entity_id':userId,'action':'create','after_json':jsonEncode({'username':'Ashrafshoo','role':'administrator'})});
    });
  }

  Future<bool> signInWithBiometric(String username) async {
    final db = await _db;
    final rows = await db.query(
      'users',
      where: 'username=? AND is_active=1',
      whereArgs: [username.trim()],
      limit: 1,
    );
    if (rows.isEmpty) return false;
    final user = rows.first;
    AppSession.instance.start(
      id: user['id'] as String,
      user: user['username'] as String,
      name: user['display_name'] as String,
      userRole: user['role'] as String,
    );
    return true;
  }

  Future<bool> signIn(String username,String password) async {
    final db=await _db;
    final rows=await db.query('users',where:'username=? AND is_active=1',whereArgs:[username.trim()],limit:1);
    if(rows.isEmpty)return false;
    final hash=rows.first['password_hash'] as String?;
    if(hash==null||!await _verify(password,hash))return false;
    final user=rows.first;
    AppSession.instance.start(id:user['id'] as String,user:user['username'] as String,name:user['display_name'] as String,userRole:user['role'] as String);
    return true;
  }

  Future<void> changePassword({required String currentPassword,required String newPassword,required String confirm}) async {
    AppSession.instance.requireAdmin();
    if(newPassword.length<10||newPassword!=confirm)throw ArgumentError('كلمة المرور الجديدة غير صحيحة أو التأكيد غير مطابق');
    final db=await _db;
    final rows=await db.query('users',where:'id=?',whereArgs:[AppSession.instance.userId],limit:1);
    if(rows.isEmpty||!await _verify(currentPassword,rows.first['password_hash'] as String? ?? ''))throw StateError('كلمة المرور الحالية غير صحيحة');
    await db.update('users',{'password_hash':await _hash(newPassword),'updated_at':DateTime.now().toIso8601String()},where:'id=?',whereArgs:[AppSession.instance.userId]);
    await db.insert('audit_log',{'id':_id(),'user_id':AppSession.instance.userId,'entity_type':'user','entity_id':AppSession.instance.userId,'action':'update','after_json':jsonEncode({'password_changed':true})});
  }

  Future<void> createFamilyViewer({required String username,required String displayName,required String password}) async {
    AppSession.instance.requireAdmin();
    if(username.trim().isEmpty||displayName.trim().isEmpty||password.length<10)throw ArgumentError('أكمل الاسم واسم المستخدم وكلمة مرور من 10 أحرف على الأقل');
    final db=await _db;
    final id=_id();
    await db.insert('users',{'id':id,'username':username.trim(),'display_name':displayName.trim(),'role':'family_viewer','password_hash':await _hash(password),'is_active':1});
    await db.insert('audit_log',{'id':_id(),'user_id':AppSession.instance.userId,'entity_type':'user','entity_id':id,'action':'create','after_json':jsonEncode({'username':username.trim(),'role':'family_viewer'})});
  }

  Future<List<Map<String,Object?>>> users() async {AppSession.instance.requireAdmin();return (await _db).query('users',columns:['id','username','display_name','role','is_active','created_at'],orderBy:'created_at');}
  Future<void> setUserActive(String id,bool active) async {AppSession.instance.requireAdmin();if(id==AppSession.instance.userId&&!active)throw StateError('لا يمكن تعطيل جلسة المدير الحالية');final db=await _db;
    await db.update('users',{'is_active':active?1:0,'updated_at':DateTime.now().toIso8601String()},where:'id=? AND role=?',whereArgs:[id,'family_viewer']);
    await db.insert('audit_log',{'id':_id(),'user_id':AppSession.instance.userId,'entity_type':'user','entity_id':id,'action':'update','after_json':jsonEncode({'is_active':active})});}

  Future<String> _hash(String password) async {
    final random=Random.secure();final salt=List<int>.generate(16,(_)=>random.nextInt(256));
    final key=await _pbkdf2.deriveKey(secretKey:SecretKey(utf8.encode(password)),nonce:salt);
    final bytes=await key.extractBytes();
    return 'pbkdf2_sha256\$210000\$${base64Encode(salt)}\$${base64Encode(bytes)}';
  }
  Future<bool> _verify(String password,String encoded) async {
    try{final parts=encoded.split(r'$');if(parts.length!=4||parts[0]!='pbkdf2_sha256'||int.parse(parts[1])!=210000)return false;final salt=base64Decode(parts[2]);final expected=base64Decode(parts[3]);final key=await _pbkdf2.deriveKey(secretKey:SecretKey(utf8.encode(password)),nonce:salt);final actual=await key.extractBytes();if(actual.length!=expected.length)return false;var diff=0;for(var i=0;i<actual.length;i++){diff|=actual[i]^expected[i];}return diff==0;}catch(_){return false;}
  }
}
