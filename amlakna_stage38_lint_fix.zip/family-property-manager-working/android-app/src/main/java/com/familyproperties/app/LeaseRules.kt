package com.familyproperties.app

import java.math.BigDecimal
import java.math.RoundingMode
import java.time.LocalDate

/** Deterministic contract and money rules. These functions never mutate persisted records. */
object LeaseRules {
    /** A lease of N units includes its start date, so its last day is start + N - 1 day. */
    fun calculateEndDate(startDate: LocalDate, durationValue: Int?, durationUnit: String?): LocalDate? {
        if (durationValue == null && durationUnit == null) return null
        require(durationValue != null && durationUnit != null) { "مدة العقد ووحدتها يجب إدخالهما معاً" }
        require(durationValue > 0) { "مدة العقد يجب أن تكون أكبر من صفر" }
        val exclusiveEnd = when (durationUnit) {
            "days" -> startDate.plusDays(durationValue.toLong())
            "months" -> startDate.plusMonths(durationValue.toLong())
            "years" -> startDate.plusYears(durationValue.toLong())
            else -> throw IllegalArgumentException("وحدة مدة العقد غير صحيحة")
        }
        return exclusiveEnd.minusDays(1)
    }

    /** Manual end dates are presentation overrides only; they do not alter start or duration. */
    fun effectiveEndDate(calculatedEndDate: LocalDate?, manualEndDate: LocalDate?): LocalDate? =
        manualEndDate ?: calculatedEndDate

    /** Convert user-entered EGP into integer piastres without floating-point arithmetic. */
    fun egpToMinorUnits(value: String): Long {
        var normalized = value.trim()
            .replace('٫', '.')
            .replace("٬", "")
            .filterNot { it.isWhitespace() }
            .map { ch -> if (ch in '٠'..'٩') ('0'.code + (ch.code - '٠'.code)).toChar() else ch }
            .joinToString("")
        if (normalized.contains('.') && normalized.contains(',')) {
            // With both separators, comma is treated as a thousands separator.
            normalized = normalized.replace(",", "")
        } else if (normalized.contains(',')) {
            // A lone comma is accepted as the decimal separator for common local input.
            normalized = normalized.replace(',', '.')
        }
        require(normalized.isNotEmpty()) { "القيمة المالية مطلوبة" }
        val amount = BigDecimal(normalized)
        require(amount >= BigDecimal.ZERO) { "القيمة لا يمكن أن تكون سالبة" }
        return amount.multiply(BigDecimal("100")).setScale(0, RoundingMode.HALF_UP).longValueExact()
    }

    /** Returns the next scheduled increase strictly after the latest effective rent date. */
    fun nextIncreaseDate(
        leaseStart: LocalDate,
        latestRentDate: LocalDate,
        rule: String,
        month: Int?,
        day: Int?
    ): LocalDate? = when (rule) {
        "none", "manual_dates" -> null
        "fixed_month_day" -> {
            require(month != null && month in 1..12 && day != null && day in 1..31) {
                "تاريخ الزيادة السنوية الثابت غير مكتمل"
            }
            fun dateIn(year: Int): LocalDate = LocalDate.of(year, month, 1)
                .withDayOfMonth(day.coerceAtMost(LocalDate.of(year, month, 1).lengthOfMonth()))
            val candidate = dateIn(latestRentDate.year)
            if (candidate.isAfter(latestRentDate)) candidate else dateIn(latestRentDate.year + 1)
        }
        "anniversary" -> {
            var years = (latestRentDate.year - leaseStart.year).coerceAtLeast(1)
            var candidate = leaseStart.plusYears(years.toLong())
            while (!candidate.isAfter(latestRentDate)) {
                years++
                candidate = leaseStart.plusYears(years.toLong())
            }
            candidate
        }
        else -> throw IllegalArgumentException("قاعدة الزيادة غير معروفة")
    }

    fun increasedRentMinor(currentRentMinor: Long, percentage: BigDecimal): Long {
        require(currentRentMinor >= 0) { "الإيجار الحالي غير صحيح" }
        require(percentage >= BigDecimal.ZERO) { "نسبة الزيادة لا يمكن أن تكون سالبة" }
        return BigDecimal.valueOf(currentRentMinor)
            .multiply(BigDecimal.ONE.add(percentage.divide(BigDecimal("100"))))
            .setScale(0, RoundingMode.HALF_UP).longValueExact()
    }

    fun minorUnitsToEgp(value: Long): BigDecimal =
        BigDecimal.valueOf(value, 2).setScale(2, RoundingMode.HALF_UP)
}
