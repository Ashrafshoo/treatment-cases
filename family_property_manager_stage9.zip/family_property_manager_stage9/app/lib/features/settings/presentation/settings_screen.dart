import 'package:flutter/material.dart';
import '../../../core/theme/app_preferences.dart';
import '../../auth/data/app_session.dart';
import '../../auth/data/auth_repository.dart';
import '../../auth/data/biometric_auth_service.dart';
import '../data/backup_repository.dart';
import 'package:share_plus/share_plus.dart';

class SettingsScreen extends StatefulWidget{const SettingsScreen({super.key});@override State<SettingsScreen> createState()=>_SettingsScreenState();}
class _SettingsScreenState extends State<SettingsScreen>{
  final p=AppPreferences.instance;final auth=AuthRepository();final backup=BackupRepository();
  static const colors=[Color(0xFFD6A84F),Color(0xFF17324D),Color(0xFF168C85),Color(0xFF6C4AB6),Color(0xFFB45309),Color(0xFF0F766E),Color(0xFFBE123C)];
  Future<void> _changePassword() async {
    final current=TextEditingController(),next=TextEditingController(),confirm=TextEditingController();
    final ok=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('تغيير كلمة مرور المدير'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:current,obscureText:true,decoration:const InputDecoration(labelText:'كلمة المرور الحالية')),TextField(controller:next,obscureText:true,decoration:const InputDecoration(labelText:'كلمة المرور الجديدة')),TextField(controller:confirm,obscureText:true,decoration:const InputDecoration(labelText:'تأكيد كلمة المرور'))]),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('حفظ'))]));
    if(ok==true){try{await auth.changePassword(currentPassword:current.text,newPassword:next.text,confirm:confirm.text);if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('تم تغيير كلمة المرور')));}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}}
    current.dispose();next.dispose();confirm.dispose();
  }
  Future<void> _createBackup() async {
    final password=TextEditingController(),confirm=TextEditingController();
    final ok=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('إنشاء نسخة احتياطية مشفرة'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:password,obscureText:true,decoration:const InputDecoration(labelText:'كلمة مرور التشفير')),TextField(controller:confirm,obscureText:true,decoration:const InputDecoration(labelText:'تأكيد كلمة المرور'))]),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('إنشاء'))]));
    if(ok==true){try{final file=await backup.createEncryptedBackup(password.text,confirm.text);await Share.shareXFiles([XFile(file.path)],text:'نسخة احتياطية مشفرة لإدارة أملاك العائلة');if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('تم إنشاء ملف النسخة الاحتياطية المشفرة')));}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تعذر إنشاء النسخة: $e')));}}
    password.dispose();confirm.dispose();
  }
  Future<void> _restoreBackup() async {
    final password=TextEditingController();
    final ok=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('استعادة نسخة احتياطية'),content:Column(mainAxisSize:MainAxisSize.min,children:[const Text('سيتم استبدال قاعدة البيانات الحالية بمحتوى النسخة. يُنشأ ملف أمان محلي قبل الاستبدال.'),TextField(controller:password,obscureText:true,decoration:const InputDecoration(labelText:'كلمة مرور النسخة الاحتياطية'))]),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('متابعة'))]));
    if(ok==true){try{await backup.restoreEncryptedBackup(password.text);if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('تمت الاستعادة. أغلق التطبيق وافتحه مجدداً لتحديث جميع الشاشات.')));}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تعذرت الاستعادة: $e')));}}
    password.dispose();
  }

  Future<void> _addViewer() async {
    final username=TextEditingController(),name=TextEditingController(),password=TextEditingController();
    final ok=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('إضافة حساب عائلي للعرض فقط'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:name,decoration:const InputDecoration(labelText:'اسم المستخدم الظاهر')),TextField(controller:username,decoration:const InputDecoration(labelText:'اسم الدخول')),TextField(controller:password,obscureText:true,decoration:const InputDecoration(labelText:'كلمة المرور (10 أحرف على الأقل)'))]),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('إنشاء الحساب'))]));
    if(ok==true){try{await auth.createFamilyViewer(username:username.text,displayName:name.text,password:password.text);if(mounted){setState((){});ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('تم إنشاء حساب العرض')));}}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}}
    username.dispose();name.dispose();password.dispose();
  }
  @override Widget build(BuildContext context)=>AnimatedBuilder(animation:p,builder:(context,_)=>Scaffold(appBar:AppBar(title:const Text('إعدادات التطبيق')),body:ListView(padding:const EdgeInsets.all(16),children:[
    Text('المظهر',style:Theme.of(context).textTheme.titleLarge),const SizedBox(height:8),SegmentedButton<ThemeMode>(segments:const [ButtonSegment(value:ThemeMode.system,label:Text('تلقائي'),icon:Icon(Icons.phone_android)),ButtonSegment(value:ThemeMode.light,label:Text('فاتح'),icon:Icon(Icons.light_mode)),ButtonSegment(value:ThemeMode.dark,label:Text('داكن'),icon:Icon(Icons.dark_mode))],selected:{p.themeMode},onSelectionChanged:(v)=>p.update(mode:v.first)),
    const SizedBox(height:20),Text('لون التطبيق',style:Theme.of(context).textTheme.titleLarge),Wrap(spacing:12,children:colors.map((c)=>IconButton(onPressed:()=>p.update(accent:c),icon:CircleAvatar(backgroundColor:c,child:p.accentColor.value==c.value?const Icon(Icons.check,color:Colors.white):null))).toList()),
    const SizedBox(height:20),Text('حجم الخط: ${(p.fontScale*100).round()}%',style:Theme.of(context).textTheme.titleLarge),Slider(value:p.fontScale,min:0.85,max:1.35,divisions:10,label:'${(p.fontScale*100).round()}%',onChanged:(v)=>p.update(scale:v)),
    SwitchListTile(contentPadding:EdgeInsets.zero,title:const Text('لوحة تحكم مبسطة'),subtitle:const Text('تفضيل العرض المختصر على هذا الجهاز'),value:p.compactDashboard,onChanged:(v)=>p.update(compact:v)),
    const Divider(height:32),Text('الحسابات والصلاحيات',style:Theme.of(context).textTheme.titleLarge),
    if(AppSession.instance.isAuthenticated)FutureBuilder<bool>(future:BiometricAuthService.instance.isEnabledForCurrentUser(),builder:(context,snapshot)=>SwitchListTile(contentPadding:EdgeInsets.zero,title:const Text('تسجيل الدخول بالبصمة'),subtitle:const Text('تفعيل اختياري لهذا الحساب على هذا الهاتف. أي بصمة مسجلة على الهاتف قد تتمكن من الدخول.'),secondary:const Icon(Icons.fingerprint),value:snapshot.data??false,onChanged:snapshot.connectionState==ConnectionState.waiting?null:(enabled)async{try{if(enabled){await BiometricAuthService.instance.enableForCurrentUser();}else{await BiometricAuthService.instance.disableForCurrentUser();}if(mounted)setState((){});}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}})),
    if(AppSession.instance.isAdmin)...[OutlinedButton.icon(onPressed:_createBackup,icon:const Icon(Icons.backup_outlined),label:const Text('إنشاء نسخة احتياطية مشفرة')),OutlinedButton.icon(onPressed:_restoreBackup,icon:const Icon(Icons.restore),label:const Text('استعادة نسخة احتياطية مشفرة')),OutlinedButton.icon(onPressed:_changePassword,icon:const Icon(Icons.password),label:const Text('تغيير كلمة مرور المدير')),OutlinedButton.icon(onPressed:_addViewer,icon:const Icon(Icons.person_add_alt_1),label:const Text('إضافة حساب عائلي للعرض فقط')),FutureBuilder<List<Map<String,Object?>>>(future:auth.users(),builder:(c,s){final rows=s.data??[];return Column(children:rows.map((r)=>ListTile(title:Text('${r['display_name']}'),subtitle:Text('${r['username']} • ${r['role']=='administrator'?'مدير':'عرض فقط'}'),trailing:r['role']=='family_viewer'?Switch(value:r['is_active']==1,onChanged:(v)async{await auth.setUserActive(r['id'] as String,v);setState((){});}):const Icon(Icons.admin_panel_settings_outlined))).toList());})]
    else const Text('حساب العائلة مخصص للعرض فقط. يمكن للمدير وحده إدارة الحسابات والبيانات.'),
    const Divider(height:32),const ListTile(leading:Icon(Icons.security_outlined),title:Text('الحماية'),subtitle:Text('تُستخدم كلمات مرور مشتقة PBKDF2، وقاعدة البيانات مشفرة عبر SQLCipher، ومفتاحها محفوظ في التخزين الآمن للجهاز. الدخول الحيوي اختياري ويُفعّل لكل حساب من إعدادات هذا الجهاز.')),
    const Text('تُحفظ تفضيلات العرض على هذا الجهاز فقط ولا تنتقل مع قاعدة بيانات العائلة.'),
  ])));
}
