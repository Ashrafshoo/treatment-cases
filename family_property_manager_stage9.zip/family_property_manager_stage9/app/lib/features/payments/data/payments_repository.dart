import 'dart:convert';

import 'package:sqflite_sqlcipher/sqflite.dart';

import '../../../core/database/app_database.dart';
import '../../auth/data/app_session.dart';

class PaymentsRepository {
  Future<Database> get _db async => AppDatabase.instance.database;
  String _id() => DateTime.now().microsecondsSinceEpoch.toString();

  Future<List<Map<String, Object?>>> activeLeases() async => (await _db).rawQuery('''
    SELECT l.id, l.initial_rent_minor, t.full_name AS tenant_name,
           p.name AS property_name, u.unit_number,
           COALESCE(l.manual_end_date,l.calculated_end_date) AS end_date
    FROM leases l JOIN tenants t ON t.id=l.tenant_id
    JOIN units u ON u.id=l.unit_id JOIN properties p ON p.id=u.property_id
    WHERE l.archived_at IS NULL AND u.archived_at IS NULL AND p.archived_at IS NULL AND l.status IN ('active','open_ended','ending_soon')
    ORDER BY p.name, u.unit_number
  ''');

  Future<List<Map<String, Object?>>> receipts() async => (await _db).query(
        'receipts', orderBy: 'issued_at DESC', limit: 200);

  Future<void> recordPayment({
    required String leaseId,
    required DateTime paidAt,
    required int amountMinor,
    DateTime? periodStart,
    DateTime? periodEnd,
    required String method,
    String? notes,
  }) async {
    AppSession.instance.requireAdmin();
    if (amountMinor <= 0) throw ArgumentError('يجب أن يكون مبلغ التحصيل أكبر من صفر');
    final db = await _db;
    await db.transaction((tx) async {
      final rows = await tx.rawQuery('''
        SELECT l.id, t.full_name AS tenant_name, p.name AS property_name,
               u.unit_number, l.initial_rent_minor, l.law_164_2025_applies
        FROM leases l JOIN tenants t ON t.id=l.tenant_id
        JOIN units u ON u.id=l.unit_id JOIN properties p ON p.id=u.property_id
        WHERE l.id=? AND l.archived_at IS NULL LIMIT 1
      ''', [leaseId]);
      if (rows.isEmpty) throw StateError('العقد غير موجود أو مؤرشف');
      final lease = rows.first;
      final paymentId = _id();
      final receiptId = _id();
      final now = DateTime.now();
      final receiptNumber = 'R-${now.year}${now.month.toString().padLeft(2, '0')}${now.day.toString().padLeft(2, '0')}-$receiptId';
      final paidDate = _date(paidAt);
      await tx.insert('payments', {
        'id': paymentId,
        'lease_id': leaseId,
        'paid_at': paidDate,
        'amount_minor': amountMinor,
        'currency_code': 'EGP',
        'period_start': periodStart == null ? null : _date(periodStart),
        'period_end': periodEnd == null ? null : _date(periodEnd),
        'payment_method': method,
        'notes': notes,
      });
      await tx.insert('receipts', {
        'id': receiptId,
        'payment_id': paymentId,
        'lease_id': leaseId,
        'receipt_number': receiptNumber,
        'issued_at': paidDate,
        'landlord_snapshot': 'إدارة أملاك العائلة',
        'tenant_snapshot': lease['tenant_name'],
        'property_snapshot': lease['property_name'],
        'unit_snapshot': lease['unit_number']?.toString(),
        'amount_minor': amountMinor,
        'amount_words_snapshot': amountInArabicWords(amountMinor),
        'currency_code': 'EGP',
        'period_snapshot': periodStart == null
            ? null
            : '${_date(periodStart)}${periodEnd == null ? '' : ' إلى ${_date(periodEnd)}'}',
        'payment_method_snapshot': method,
        'law_164_2025_snapshot': (lease['law_164_2025_applies'] as num?)?.toInt() ?? 0,
        'remaining_minor': periodStart == null ? null : await _remainingForPeriod(tx, leaseId, periodStart),
        'approved': 0,
      });
      await tx.insert('audit_log', {
        'id': _id(),
        'user_id': AppSession.instance.userId,
        'entity_type': 'payment',
        'entity_id': paymentId,
        'action': 'create',
        'after_json': jsonEncode({'payment_id': paymentId, 'receipt_id': receiptId, 'lease_id': leaseId, 'amount_minor': amountMinor, 'paid_at': paidDate}),
      });
    });
  }


  Future<int> _remainingForPeriod(DatabaseExecutor tx, String leaseId, DateTime periodStart) async {
    final start = DateTime(periodStart.year, periodStart.month, 1);
    final end = DateTime(periodStart.year, periodStart.month + 1, 0);
    final rentRows = await tx.rawQuery('''
      SELECT COALESCE((SELECT rh.amount_minor FROM rent_history rh
        WHERE rh.lease_id=l.id AND rh.approval_status='approved'
          AND rh.valid_from<=? AND (rh.valid_to IS NULL OR rh.valid_to>=?)
        ORDER BY rh.valid_from DESC LIMIT 1),
        CASE WHEN EXISTS(SELECT 1 FROM rent_history pending
          WHERE pending.lease_id=l.id AND pending.approval_status='under_review'
            AND pending.valid_from<=? AND (pending.valid_to IS NULL OR pending.valid_to>=?)
        ) THEN 0 ELSE l.initial_rent_minor END,0) AS due_minor
      FROM leases l WHERE l.id=?
    ''', [_date(end), _date(start), _date(end), _date(start), leaseId]);
    if (rentRows.isEmpty) return 0;
    final paidRows = await tx.rawQuery('SELECT COALESCE(SUM(amount_minor),0) AS total FROM payments WHERE lease_id=? AND COALESCE(period_start,paid_at) BETWEEN ? AND ?', [leaseId, _date(start), _date(end)]);
    final paid = (paidRows.first['total'] as num).toInt();
    final due = (rentRows.first['due_minor'] as num).toInt();
    return due > paid ? due - paid : 0;
  }

  Future<void> approveReceipt(String receiptId) async {
    AppSession.instance.requireAdmin();
    final db = await _db;
    await db.transaction((tx) async {
      final rows = await tx.query('receipts', where: 'id=? AND approved=0', whereArgs: [receiptId], limit: 1);
      if (rows.isEmpty) throw StateError('الإيصال غير موجود أو سبق اعتماده');
      final receipt = rows.first;
      await tx.update('receipts', {'approved': 1}, where: 'id=?', whereArgs: [receiptId]);
      await tx.insert('audit_log', {'id': _id(), 'user_id': AppSession.instance.userId, 'entity_type': 'receipt', 'entity_id': receiptId, 'action': 'approve', 'before_json': jsonEncode(receipt), 'after_json': jsonEncode({...receipt, 'approved': 1})});
    });
  }

  Future<void> rejectDraftReceipt(String receiptId) async {
    AppSession.instance.requireAdmin();
    final db = await _db;
    await db.transaction((tx) async {
      final rows = await tx.query('receipts', where: 'id=? AND approved=0', whereArgs: [receiptId], limit: 1);
      if (rows.isEmpty) throw StateError('لا يمكن إلغاء هذا الإيصال');
      final receipt = rows.first;
      final paymentId = receipt['payment_id'] as String?;
      await tx.delete('receipts', where: 'id=? AND approved=0', whereArgs: [receiptId]);
      if (paymentId != null) await tx.delete('payments', where: 'id=?', whereArgs: [paymentId]);
      await tx.insert('audit_log', {'id': _id(), 'user_id': AppSession.instance.userId, 'entity_type': 'receipt', 'entity_id': receiptId, 'action': 'reject', 'before_json': jsonEncode(receipt), 'after_json': jsonEncode({'status': 'cancelled_draft'})});
    });
  }

  static String amountInArabicWords(int amountMinor) {
    final pounds = amountMinor ~/ 100;
    final piastres = amountMinor % 100;
    return '${_integerWords(pounds)} جنيه مصري${piastres == 0 ? ' فقط لا غير' : ' و${_integerWords(piastres)} قرشاً'}';
  }

  static String _integerWords(int value) {
    if (value == 0) return 'صفر';
    const ones = ['', 'واحد', 'اثنان', 'ثلاثة', 'أربعة', 'خمسة', 'ستة', 'سبعة', 'ثمانية', 'تسعة'];
    const teens = ['عشرة', 'أحد عشر', 'اثنا عشر', 'ثلاثة عشر', 'أربعة عشر', 'خمسة عشر', 'ستة عشر', 'سبعة عشر', 'ثمانية عشر', 'تسعة عشر'];
    const tens = ['', '', 'عشرون', 'ثلاثون', 'أربعون', 'خمسون', 'ستون', 'سبعون', 'ثمانون', 'تسعون'];
    const hundreds = ['', 'مائة', 'مائتان', 'ثلاثمائة', 'أربعمائة', 'خمسمائة', 'ستمائة', 'سبعمائة', 'ثمانمائة', 'تسعمائة'];
    if (value < 10) return ones[value];
    if (value < 20) return teens[value - 10];
    if (value < 100) return value % 10 == 0 ? tens[value ~/ 10] : '${ones[value % 10]} و${tens[value ~/ 10]}';
    if (value < 1000) return value % 100 == 0 ? hundreds[value ~/ 100] : '${hundreds[value ~/ 100]} و${_integerWords(value % 100)}';
    if (value < 1000000) {
      final thousands = value ~/ 1000;
      final rest = value % 1000;
      final prefix = thousands == 1 ? 'ألف' : thousands == 2 ? 'ألفان' : thousands < 11 ? '${_integerWords(thousands)} آلاف' : '${_integerWords(thousands)} ألفاً';
      return rest == 0 ? prefix : '$prefix و${_integerWords(rest)}';
    }
    final millions = value ~/ 1000000;
    final rest = value % 1000000;
    final prefix = millions == 1 ? 'مليون' : millions == 2 ? 'مليونان' : '${_integerWords(millions)} مليوناً';
    return rest == 0 ? prefix : '$prefix و${_integerWords(rest)}';
  }

  static String _date(DateTime value) =>
      '${value.year.toString().padLeft(4, '0')}-${value.month.toString().padLeft(2, '0')}-${value.day.toString().padLeft(2, '0')}';
}
