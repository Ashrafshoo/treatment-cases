package com.treatmentcases.app

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.URL
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.net.ssl.HttpsURLConnection

/** Stores the bearer token encrypted with an Android Keystore AES-GCM key. */
class SyncConnectionSettings(context: Context) {
    private val app = context.applicationContext
    private val prefs = app.getSharedPreferences("sync_connection", Context.MODE_PRIVATE)
    fun endpoint(): String = prefs.getString("endpoint", "")?.trim().orEmpty()
    fun saveEndpoint(value: String) {
        val normalized = value.trim().trimEnd('/')
        require(normalized.isBlank() || (normalized.startsWith("https://") && normalized.length <= 500)) {
            "يجب أن يبدأ عنوان الخادم بـ https://"
        }
        prefs.edit().putString("endpoint", normalized).apply()
    }
    fun saveToken(token: String) {
        require(token.length <= 4096) { "رمز الاتصال أطول من الحد المسموح" }
        if (token.isBlank()) { prefs.edit().remove("token_blob").remove("token_iv").apply(); return }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val encrypted = cipher.doFinal(token.toByteArray(Charsets.UTF_8))
        prefs.edit().putString("token_blob", Base64.encodeToString(encrypted, Base64.NO_WRAP))
            .putString("token_iv", Base64.encodeToString(cipher.iv, Base64.NO_WRAP)).apply()
    }
    fun token(): String {
        val blob = prefs.getString("token_blob", null) ?: return ""
        val iv = prefs.getString("token_iv", null) ?: return ""
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, Base64.decode(iv, Base64.NO_WRAP)))
        return String(cipher.doFinal(Base64.decode(blob, Base64.NO_WRAP)), Charsets.UTF_8)
    }
    private fun key(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true).build())
        return generator.generateKey()
    }
    companion object { private const val KEY_ALIAS = "treatment_cases_sync_token_v1" }
}

data class SyncPushResult(val acceptedIds: Set<String>, val rejectedIds: Set<String>, val message: String = "")
data class SyncPullEvent(val eventId:String,val sourceDeviceId:String,val entityType:String,val entityId:String,val operation:String,val baseVersion:Long,val newVersion:Long,val payloadJson:String)
data class SyncPullResult(val events:List<SyncPullEvent>,val nextCursor:String)

/** HTTPS-only, bounded, idempotent push transport. The server must deduplicate event_id. */
class SyncHttpTransport(private val endpoint: String, private val bearerToken: String) {
    fun push(deviceId: String, events: List<SyncEnvelope>): SyncPushResult {
        require(endpoint.startsWith("https://")) { "الاتصال السحابي يتطلب HTTPS" }
        require(bearerToken.isNotBlank()) { "رمز الاتصال غير مضبوط" }
        if (events.isEmpty()) return SyncPushResult(emptySet(), emptySet())
        val allowedIds = events.map { it.eventId }.toSet()
        val body = JSONObject().put("protocol_version", 1).put("device_id", deviceId)
            .put("events", JSONArray().apply { events.forEach { event ->
                put(JSONObject().put("event_id", event.eventId).put("source_device_id", event.sourceDeviceId)
                    .put("entity_type", event.entityType).put("entity_id", event.entityId)
                    .put("operation", event.operation).put("base_version", event.baseVersion)
                    .put("new_version", event.newVersion).put("payload", JSONObject(event.payloadJson)))
            } }).toString()
        val url = URL(endpoint.trimEnd('/') + "/v1/sync/push")
        val connection = (url.openConnection() as HttpsURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 15000; readTimeout = 20000
            doOutput = true; setRequestProperty("Authorization", "Bearer $bearerToken")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
            setFixedLengthStreamingMode(body.toString().toByteArray(Charsets.UTF_8).size)
        }
        try {
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText().take(256 * 1024) }.orEmpty()
            if (code !in 200..299) throw IllegalStateException("خادم المزامنة أعاد HTTP $code")
            val json = JSONObject(response)
            val acceptedArray = json.optJSONArray("accepted_event_ids")
                ?: throw IllegalStateException("استجابة الخادم لا تحتوي accepted_event_ids")
            val accepted = buildSet { for (i in 0 until acceptedArray.length()) add(acceptedArray.getString(i)) }
            require(accepted.all { it in allowedIds }) { "الخادم أعاد معرف حدث غير موجود في الدفعة" }
            return SyncPushResult(accepted, allowedIds - accepted, json.optString("message"))
        } finally { connection.disconnect() }
    }
}


/** Pull transport. Remote events are validated and quarantined locally; this class never applies business rows. */
class SyncPullHttpTransport(private val endpoint:String, private val bearerToken:String) {
    fun pull(deviceId:String,cursor:String):SyncPullResult {
        require(endpoint.startsWith("https://")) { "الاتصال السحابي يتطلب HTTPS" }
        require(bearerToken.isNotBlank()) { "رمز الاتصال غير مضبوط" }
        val body=JSONObject().put("protocol_version",1).put("device_id",deviceId).put("cursor",cursor).toString()
        val url=URL(endpoint.trimEnd('/')+"/v1/sync/pull")
        val connection=(url.openConnection() as HttpsURLConnection).apply {
            requestMethod="POST";connectTimeout=15000;readTimeout=20000;doOutput=true
            setRequestProperty("Authorization","Bearer $bearerToken")
            setRequestProperty("Content-Type","application/json; charset=utf-8")
            setRequestProperty("Accept","application/json")
            setFixedLengthStreamingMode(body.toByteArray(Charsets.UTF_8).size)
        }
        try {
            connection.outputStream.use{it.write(body.toByteArray(Charsets.UTF_8))}
            val code=connection.responseCode
            val stream=if(code in 200..299)connection.inputStream else connection.errorStream
            val response=stream?.bufferedReader(Charsets.UTF_8)?.use{it.readText().take(512*1024)}.orEmpty()
            if(code !in 200..299)throw IllegalStateException("خادم المزامنة أعاد HTTP $code أثناء الاستقبال")
            val json=JSONObject(response);val array=json.optJSONArray("events")?:throw IllegalStateException("استجابة الاستقبال لا تحتوي events")
            require(array.length()<=500){"دفعة الاستقبال أكبر من الحد المسموح"}
            val events=ArrayList<SyncPullEvent>(array.length());val seen=HashSet<String>()
            for(i in 0 until array.length()) {
                val e=array.getJSONObject(i)
                val eventId=e.getString("event_id").trim();val source=e.getString("source_device_id").trim()
                val type=e.getString("entity_type").trim();val entity=e.getString("entity_id").trim()
                val op=e.getString("operation").trim();val base=e.getLong("base_version");val next=e.getLong("new_version")
                require(eventId.isNotBlank()&&source.isNotBlank()&&entity.isNotBlank()){"حدث وارد ينقصه معرّف أساسي"}
                require(type in setOf("case","employee","medicine","strength")){"نوع سجل وارد غير مدعوم"}
                require(op in setOf("upsert","delete")&&next>base){"تسلسل إصدار الحدث الوارد غير صالح"}
                require(seen.add(eventId)){"تكرار معرف حدث داخل دفعة الاستقبال"}
                val payload=e.optJSONObject("payload")?:JSONObject()
                events+=SyncPullEvent(eventId,source,type,entity,op,base,next,payload.toString())
            }
            val nextCursor=json.optString("next_cursor",cursor).take(2048)
            return SyncPullResult(events,nextCursor)
        } finally {connection.disconnect()}
    }
}

class SyncPullWorker(context:Context,params:WorkerParameters):CoroutineWorker(context,params) {
    override suspend fun doWork():Result=withContext(Dispatchers.IO){
        val settings=SyncConnectionSettings(applicationContext);val endpoint=settings.endpoint()
        if(endpoint.isBlank()||settings.token().isBlank())return@withContext Result.failure()
        try {
            val db=LocalDb(applicationContext);val prefs=applicationContext.getSharedPreferences("sync_connection",Context.MODE_PRIVATE)
            val cursor=prefs.getString("pull_cursor","").orEmpty()
            val result=SyncPullHttpTransport(endpoint,settings.token()).pull(db.syncDeviceId(),cursor)
            db.receiveRemoteSyncEvents(result.events)
            prefs.edit().putString("pull_cursor",result.nextCursor).apply()
            Result.success()
        } catch(e:Exception) { Result.retry() }
    }
}

class SyncPushWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val settings = SyncConnectionSettings(applicationContext)
        val endpoint = settings.endpoint()
        if (endpoint.isBlank()) return@withContext Result.failure()
        val db = LocalDb(applicationContext)
        val events = db.pendingSyncEnvelopes(200)
        if (events.isEmpty()) return@withContext Result.success()
        try {
            val response = SyncHttpTransport(endpoint, settings.token()).push(db.syncDeviceId(), events)
            val accepted = response.acceptedIds.toList()
            db.acknowledgeSyncEvents(accepted)
            if (response.rejectedIds.isNotEmpty()) {
                db.recordSyncFailure(response.rejectedIds.toList(), response.message.ifBlank { "الخادم لم يؤكد استلام بعض الأحداث" })
                Result.retry()
            } else Result.success()
        } catch (e: Exception) {
            db.recordSyncFailure(events.map { it.eventId }, (e.message ?: "Network error").take(500))
            Result.retry()
        }
    }
}

object SyncWorkScheduler {
    fun enqueue(context: Context) {
        val request = OneTimeWorkRequestBuilder<SyncPushWorker>()
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork("treatment-cases-sync-push", ExistingWorkPolicy.KEEP, request)
        val pull=OneTimeWorkRequestBuilder<SyncPullWorker>()
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build()
        WorkManager.getInstance(context).enqueueUniqueWork("treatment-cases-sync-pull", ExistingWorkPolicy.KEEP, pull)
    }
}
