#!/usr/bin/env python3
"""Source and in-memory SQLite integration checks for 2.7.0 sync capture retained in 2.7.1."""
from pathlib import Path
import sqlite3, uuid
root=Path(__file__).resolve().parents[1]
src=(root/'android/app/src/main/java/com/treatmentcases/app/LocalDb.kt').read_text(encoding='utf-8')
gradle=(root/'android/app/build.gradle').read_text(encoding='utf-8')
protocol=(root/'android/app/src/main/java/com/treatmentcases/app/SyncProtocol.kt').read_text(encoding='utf-8')
main=(root/'android/app/src/main/java/com/treatmentcases/app/MainActivity.kt').read_text(encoding='utf-8')
checks=[
 ('database schema version 11', 'treatment_cases_local.db",null,11' in src),
 ('additive v5-to-v6 upgrade', 'if(oldVersion<6){ createSyncInfrastructure(db); backfillSyncIdentities(db); createSyncCaptureTriggers(db); enqueueInitialSyncSnapshot(db) }' in src),
 ('insert/update/delete capture triggers', all(f'sync_${{safe}}_{op}' in src for op in ('insert','update','delete')) and all(f'"{t}" to "{safe}"' in src for t,safe in [('cases','case'),('employees','employee'),('medicines','medicine'),('strengths','strength')])),
 ('capture suppression flag exists', 'sync_runtime_flags' in src and 'suppress_capture' in src),
 ('initial snapshot queued after migration', 'enqueueInitialSyncSnapshot(db)' in src),
 ('transport-ready pending envelope API', 'fun pendingSyncEnvelopes(limit:Int=200)' in src),
 ('ACK required before outbox marked sent', 'fun acknowledgeSyncEvents(eventIds:List<String>)' in src),
 ('failed delivery retained with retry count', 'attempt_count=attempt_count+1,last_error=?' in src),
 ('duplicate and conflict policy explicit', 'IgnoreDuplicate' in protocol and 'local version differs from remote base version' in protocol),
 ('settings screen exposes secure sync setup', 'المزامنة بين الأجهزة' in main and 'HTTPS server URL' in main and 'syncStats["pending"]' in main),
 ('2.7.3 version and isolated preview id', "versionCode 33" in gradle and "versionName '2.8.1-ui-polish'" in gradle and 'com.treatmentcases.app.preview275' in gradle),
]
for name,ok in checks: print(('PASS' if ok else 'FAIL')+': '+name)
assert all(ok for _,ok in checks)
# Exercise the same SQLite trigger design on a disposable in-memory database.
db=sqlite3.connect(':memory:')
db.executescript('''
CREATE TABLE cases(id INTEGER PRIMARY KEY,name TEXT);
CREATE TABLE employees(id INTEGER PRIMARY KEY,name TEXT);
CREATE TABLE medicines(id INTEGER PRIMARY KEY,name TEXT);
CREATE TABLE strengths(id INTEGER PRIMARY KEY,medicine TEXT,strength TEXT);
CREATE TABLE sync_entity_identity(entity_type TEXT,local_id INTEGER,entity_uuid TEXT UNIQUE,version INTEGER DEFAULT 1,updated_at TEXT DEFAULT CURRENT_TIMESTAMP,deleted_at TEXT,PRIMARY KEY(entity_type,local_id));
CREATE TABLE sync_outbox(event_uuid TEXT PRIMARY KEY,entity_type TEXT,entity_uuid TEXT,operation TEXT,base_version INTEGER,new_version INTEGER,payload_json TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,delivery_state TEXT DEFAULT 'pending',attempt_count INTEGER DEFAULT 0,last_error TEXT DEFAULT '');
CREATE TABLE sync_runtime_flags(id INTEGER PRIMARY KEY,suppress_capture INTEGER DEFAULT 0);
INSERT INTO sync_runtime_flags VALUES(1,0);
''')
for table,typ in [('cases','case'),('employees','employee'),('medicines','medicine'),('strengths','strength')]:
 db.executescript(f'''
 CREATE TRIGGER sync_{typ}_insert AFTER INSERT ON {table} WHEN COALESCE((SELECT suppress_capture FROM sync_runtime_flags WHERE id=1),0)=0 BEGIN
 INSERT OR IGNORE INTO sync_entity_identity(entity_type,local_id,entity_uuid,version,updated_at) VALUES('{typ}',NEW.id,lower(hex(randomblob(16))),1,CURRENT_TIMESTAMP);
 INSERT INTO sync_outbox(event_uuid,entity_type,entity_uuid,operation,base_version,new_version,payload_json) SELECT lower(hex(randomblob(16))),'{typ}',entity_uuid,'upsert',0,version,'{{}}' FROM sync_entity_identity WHERE entity_type='{typ}' AND local_id=NEW.id; END;
 CREATE TRIGGER sync_{typ}_update AFTER UPDATE ON {table} WHEN COALESCE((SELECT suppress_capture FROM sync_runtime_flags WHERE id=1),0)=0 BEGIN
 INSERT OR IGNORE INTO sync_entity_identity(entity_type,local_id,entity_uuid,version,updated_at) VALUES('{typ}',NEW.id,lower(hex(randomblob(16))),1,CURRENT_TIMESTAMP);
 UPDATE sync_entity_identity SET version=version+1,updated_at=CURRENT_TIMESTAMP WHERE entity_type='{typ}' AND local_id=NEW.id;
 INSERT INTO sync_outbox(event_uuid,entity_type,entity_uuid,operation,base_version,new_version,payload_json) SELECT lower(hex(randomblob(16))),'{typ}',entity_uuid,'upsert',COALESCE((SELECT MIN(base_version) FROM sync_outbox WHERE entity_uuid=sync_entity_identity.entity_uuid AND delivery_state='pending'),version-1),version,'{{}}' FROM sync_entity_identity WHERE entity_type='{typ}' AND local_id=NEW.id; UPDATE sync_outbox SET delivery_state='superseded' WHERE entity_uuid=(SELECT entity_uuid FROM sync_entity_identity WHERE entity_type='{typ}' AND local_id=NEW.id) AND delivery_state='pending' AND event_uuid<>(SELECT event_uuid FROM sync_outbox WHERE entity_uuid=(SELECT entity_uuid FROM sync_entity_identity WHERE entity_type='{typ}' AND local_id=NEW.id) ORDER BY rowid DESC LIMIT 1); END;
 CREATE TRIGGER sync_{typ}_delete BEFORE DELETE ON {table} WHEN COALESCE((SELECT suppress_capture FROM sync_runtime_flags WHERE id=1),0)=0 BEGIN
 INSERT OR IGNORE INTO sync_entity_identity(entity_type,local_id,entity_uuid,version,updated_at) VALUES('{typ}',OLD.id,lower(hex(randomblob(16))),1,CURRENT_TIMESTAMP);
 UPDATE sync_entity_identity SET version=version+1,updated_at=CURRENT_TIMESTAMP,deleted_at=CURRENT_TIMESTAMP WHERE entity_type='{typ}' AND local_id=OLD.id;
 INSERT INTO sync_outbox(event_uuid,entity_type,entity_uuid,operation,base_version,new_version,payload_json) SELECT lower(hex(randomblob(16))),'{typ}',entity_uuid,'delete',COALESCE((SELECT MIN(base_version) FROM sync_outbox WHERE entity_uuid=sync_entity_identity.entity_uuid AND delivery_state='pending'),version-1),version,'{{}}' FROM sync_entity_identity WHERE entity_type='{typ}' AND local_id=OLD.id; UPDATE sync_outbox SET delivery_state='superseded' WHERE entity_uuid=(SELECT entity_uuid FROM sync_entity_identity WHERE entity_type='{typ}' AND local_id=OLD.id) AND delivery_state='pending' AND event_uuid<>(SELECT event_uuid FROM sync_outbox WHERE entity_uuid=(SELECT entity_uuid FROM sync_entity_identity WHERE entity_type='{typ}' AND local_id=OLD.id) ORDER BY rowid DESC LIMIT 1); END;
 ''')
# Inserts are automatically queued for every synchronized entity type.
for table,values in [('cases',(1,'case row')),('employees',(2,'employee row')),('medicines',(3,'medicine row'))]: db.execute(f'INSERT INTO {table}(id,name) VALUES(?,?)',values)
db.execute("INSERT INTO strengths(id,medicine,strength) VALUES(4,'Drug','10 mg')")
assert db.execute('SELECT COUNT(*) FROM sync_outbox').fetchone()[0]==4
assert db.execute('SELECT COUNT(DISTINCT entity_uuid) FROM sync_entity_identity').fetchone()[0]==4
print('PASS: four entity types automatically create unique outbox events and identities')
# Update increments version and preserves a monotonic base/new pair.
db.execute("UPDATE cases SET name='case revised' WHERE id=1")
assert db.execute("SELECT version FROM sync_entity_identity WHERE entity_type='case' AND local_id=1").fetchone()[0]==2
assert db.execute("SELECT base_version,new_version FROM sync_outbox WHERE entity_type='case' AND delivery_state='pending' ORDER BY rowid DESC LIMIT 1").fetchone()==(0,2)
assert db.execute("SELECT COUNT(*) FROM sync_outbox WHERE entity_type='case' AND delivery_state='pending'").fetchone()[0]==1
assert db.execute("SELECT COUNT(*) FROM sync_outbox WHERE entity_type='case' AND delivery_state='superseded'").fetchone()[0]==1
print('PASS: updates increment version, coalesce pending edits and preserve the first base version')
# Delete creates a tombstone before removing the business row.
db.execute('DELETE FROM employees WHERE id=2')
assert db.execute("SELECT operation FROM sync_outbox WHERE entity_type='employee' AND delivery_state='pending' ORDER BY rowid DESC LIMIT 1").fetchone()[0]=='delete'
assert db.execute("SELECT base_version,new_version FROM sync_outbox WHERE entity_type='employee' AND delivery_state='pending' ORDER BY rowid DESC LIMIT 1").fetchone()==(0,2)
assert db.execute("SELECT deleted_at IS NOT NULL FROM sync_entity_identity WHERE entity_type='employee' AND local_id=2").fetchone()[0]==1
print('PASS: delete emits a tombstone and retains stable identity')
# Suppression allows a future inbound apply to avoid echoing its own write.
db.execute('UPDATE sync_runtime_flags SET suppress_capture=1 WHERE id=1')
count=db.execute('SELECT COUNT(*) FROM sync_outbox').fetchone()[0]
db.execute("UPDATE medicines SET name='remote-applied' WHERE id=3")
assert db.execute('SELECT COUNT(*) FROM sync_outbox').fetchone()[0]==count
assert db.execute("SELECT name FROM medicines WHERE id=3").fetchone()[0]=='remote-applied'
print('PASS: inbound-apply suppression prevents sync echo events')
# All unrelated business rows remain intact in this test database.
assert db.execute('SELECT COUNT(*) FROM cases').fetchone()[0]==1
assert db.execute('SELECT COUNT(*) FROM medicines').fetchone()[0]==1
assert db.execute('SELECT COUNT(*) FROM strengths').fetchone()[0]==1
print('PASS: capture tests preserve unrelated case, medicine and strength rows')
print('11 source assertions + 5 SQLite integration assertions passed')
