package com.treatmentcases.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper


data class SyncReviewItem(
 val eventId:String,val entityType:String,val entityUuid:String,val operation:String,
 val baseVersion:Long,val remoteVersion:Long,val sourceDevice:String,val state:String,
 val error:String,val payloadJson:String,val localPayloadJson:String
)

class LocalDb(private val appContext:Context):SQLiteOpenHelper(appContext,"treatment_cases_local.db",null,11){
 init { setActiveSession("ADMIN",setOf("view_search","add_edit","export_share","import_excel","manage_medicines","manage_users")); seedMedicineDictionary(); ensureApprovedCanonicalEntriesFromSeed(); refreshVerifiedMedicineMetadataFromSeed(); syncLegacyStrengths(); reconcileVerifiedMedicineAliases(); reconcileMedicineCatalogDuplicates(); reconcileKnownMedicineNames(); reconcileStrengthDuplicates(); setActiveSession("GUEST", emptySet()) }
 private fun seedMedicineDictionary(){
  val prefs=appContext.getSharedPreferences("local_setup",Context.MODE_PRIVATE)
  if(prefs.getBoolean("dictionary_seeded",false))return
  try{
   val json=org.json.JSONArray(appContext.assets.open("medicines_seed.json").bufferedReader(Charsets.UTF_8).use{it.readText()})
   val d=writableDatabase;d.beginTransaction()
   try{for(i in 0 until json.length()){val o=json.getJSONObject(i);val v=ContentValues().apply{put("name",o.optString("name"));put("generic_name",o.optString("generic"));put("specialty",o.optString("specialty"));put("strengths",o.optString("strengths"));put("dosage_form",o.optString("form"));put("review_status",o.optString("status"));put("aliases",o.optString("aliases"));put("medical_notes",o.optString("medical_notes",o.optString("notes")));put("indications",o.optString("indications"));put("critical_classification",o.optString("critical_classification"));put("target_conditions",o.optString("target_conditions"));put("source_reference",o.optString("source_reference"));put("last_reviewed",o.optString("last_reviewed"))};d.insertWithOnConflict("medicines",null,v,SQLiteDatabase.CONFLICT_IGNORE)};d.setTransactionSuccessful()}finally{d.endTransaction()}
   prefs.edit().putBoolean("dictionary_seeded",true).apply()
  }catch(_:Exception){}
 }
 private fun ensureApprovedCanonicalEntriesFromSeed(){
  val prefs=appContext.getSharedPreferences("local_setup",Context.MODE_PRIVATE)
  if(prefs.getBoolean("canonical_names_250_migrated",false))return
  try{
   val json=org.json.JSONArray(appContext.assets.open("medicines_seed.json").bufferedReader(Charsets.UTF_8).use{it.readText()})
   val d=writableDatabase;d.beginTransaction()
   try{
    for(i in 0 until json.length()){
     val o=json.getJSONObject(i);val name=o.optString("name").trim()
     if(name !in setOf("BARITAVA","RECORMON"))continue
     val v=ContentValues().apply{put("name",name);put("generic_name",o.optString("generic"));put("specialty",o.optString("specialty"));put("strengths",o.optString("strengths"));put("dosage_form",o.optString("form"));put("review_status",o.optString("status"));put("aliases",o.optString("aliases"));put("medical_notes",o.optString("medical_notes",o.optString("notes")));put("indications",o.optString("indications"));put("critical_classification",o.optString("critical_classification"));put("target_conditions",o.optString("target_conditions"));put("source_reference",o.optString("source_reference"));put("last_reviewed",o.optString("last_reviewed"))}
     d.insertWithOnConflict("medicines",null,v,SQLiteDatabase.CONFLICT_IGNORE)
    }
    d.setTransactionSuccessful()
   }finally{d.endTransaction()}
   prefs.edit().putBoolean("canonical_names_250_migrated",true).apply()
  }catch(_:Exception){}
 }
 private fun refreshVerifiedMedicineMetadataFromSeed(){
  // Safe catalog refresh: fill missing/placeholder fields only; never overwrite non-empty user-reviewed content.
  val seed=try{org.json.JSONArray(appContext.assets.open("medicines_seed.json").bufferedReader(Charsets.UTF_8).use{it.readText()})}catch(_:Exception){return}
  val d=writableDatabase;d.beginTransaction()
  try{
   for(i in 0 until seed.length()){
    val o=seed.getJSONObject(i);val name=o.optString("name").trim();if(name.isBlank())continue
    val current=d.rawQuery("SELECT generic_name,specialty,strengths,dosage_form,review_status,indications,critical_classification,target_conditions,medical_notes,source_reference,last_reviewed,aliases FROM medicines WHERE name=? COLLATE NOCASE",arrayOf(name)).use{c->if(c.moveToFirst())(0..11).map{c.getString(it).orEmpty()} else null} ?: continue
    fun blankOrPlaceholder(v:String)=v.isBlank()||v.contains("يُستكمل")||v.contains("يحدد")||v.contains("غير مسجل")
    fun mergeAliases(a:String,b:String)= (a.split(Regex("[;؛,،|\\n]+")).map{it.trim()}+b.split(Regex("[;؛,،|\\n]+")).map{it.trim()}).filter{it.isNotBlank()}.distinctBy{MedicineNameMatcher.key(it)}.joinToString("; ")
    val v=ContentValues()
    listOf("generic","specialty","strengths","form","status","indications","critical_classification","target_conditions","notes","source_reference","last_reviewed","aliases").forEachIndexed{idx,key->
     val seedValue=(if(key=="notes")o.optString("medical_notes",o.optString("notes","")) else o.optString(key,"")).trim();val old=current[idx]
     when(key){
      "strengths"->{val combined=MedicineStrengthNormalizer.unique(splitStrengths(old)+splitStrengths(seedValue));if(combined.joinToString("; ")!=old)v.put("strengths",combined.joinToString("; "))}
      "aliases"->{val merged=mergeAliases(old,o.optString(key,""));if(merged!=old)v.put("aliases",merged)}
      "status"->{if(seedValue.isNotBlank()&&(old.isBlank()||old.contains("مراجعة أولية")||old.contains("يحتاج مراجعة")||old.contains("مضاف يدوياً")))v.put("review_status",seedValue)}
      else->{if(blankOrPlaceholder(old)&&seedValue.isNotBlank())v.put(when(key){"generic"->"generic_name";"form"->"dosage_form";"status"->"review_status";"notes"->"medical_notes";else->key},seedValue)}
     }
    }
    if(v.size()>0)d.update("medicines",v,"name=? COLLATE NOCASE",arrayOf(name))
   }
   d.setTransactionSuccessful()
  }finally{d.endTransaction()}
 }
 override fun onCreate(db:SQLiteDatabase){
  db.execSQL("CREATE TABLE cases(id INTEGER PRIMARY KEY AUTOINCREMENT,region TEXT,sector TEXT,name TEXT NOT NULL,performance_no TEXT,medicine TEXT,strength TEXT,extra1 TEXT,extra2 TEXT,duration TEXT,dosage TEXT,condition_text TEXT,approval_date TEXT,approval_expiry TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP)")
  db.execSQL("CREATE INDEX idx_performance ON cases(performance_no)");db.execSQL("CREATE INDEX idx_medicine ON cases(medicine)")
  db.execSQL("CREATE TABLE medicines(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE COLLATE NOCASE,generic_name TEXT DEFAULT '',specialty TEXT DEFAULT '',strengths TEXT DEFAULT '',dosage_form TEXT DEFAULT '',review_status TEXT DEFAULT 'يحتاج مراجعة',indications TEXT DEFAULT '',critical_classification TEXT DEFAULT '',target_conditions TEXT DEFAULT '',medical_notes TEXT DEFAULT '',source_reference TEXT DEFAULT '',last_reviewed TEXT DEFAULT '',aliases TEXT DEFAULT '')")
  db.execSQL("CREATE TABLE strengths(id INTEGER PRIMARY KEY AUTOINCREMENT,medicine TEXT,strength TEXT,UNIQUE(medicine,strength))")
  db.execSQL("CREATE TABLE app_users(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT UNIQUE,password_hash TEXT,role TEXT,permissions TEXT NOT NULL DEFAULT '[]',active INTEGER NOT NULL DEFAULT 1,owner_user_id INTEGER)")
  db.execSQL("CREATE TABLE activation_codes(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT NOT NULL,code_salt TEXT NOT NULL,code_hash TEXT NOT NULL,permissions TEXT NOT NULL,expires_at INTEGER NOT NULL,used_at INTEGER,created_by TEXT NOT NULL,created_by_user_id INTEGER,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)")
  db.execSQL("CREATE INDEX idx_activation_username ON activation_codes(username,expires_at)")
  db.execSQL("CREATE TABLE audit_log(id INTEGER PRIMARY KEY AUTOINCREMENT,action TEXT,item_key TEXT,at TEXT DEFAULT CURRENT_TIMESTAMP)")
  db.execSQL("CREATE TABLE medicine_name_history(id INTEGER PRIMARY KEY AUTOINCREMENT,old_name TEXT NOT NULL,new_name TEXT NOT NULL,affected_cases INTEGER NOT NULL DEFAULT 0,reason TEXT DEFAULT '',approved_at TEXT DEFAULT CURRENT_TIMESTAMP)")
  createEmployeeTable(db)
  createSyncInfrastructure(db)
  createSyncCaptureTriggers(db)
  createAuthorizationInfrastructure(db)
 }
 override fun onUpgrade(db:SQLiteDatabase,oldVersion:Int,newVersion:Int){
  if(oldVersion<2) createEmployeeTable(db)
  if(oldVersion<3){
   addColumnIfMissing(db,"medicines","indications","TEXT DEFAULT ''")
   addColumnIfMissing(db,"medicines","critical_classification","TEXT DEFAULT ''")
   addColumnIfMissing(db,"medicines","target_conditions","TEXT DEFAULT ''")
   addColumnIfMissing(db,"medicines","medical_notes","TEXT DEFAULT ''")
   addColumnIfMissing(db,"medicines","source_reference","TEXT DEFAULT ''")
   addColumnIfMissing(db,"medicines","last_reviewed","TEXT DEFAULT ''")
   addColumnIfMissing(db,"medicines","aliases","TEXT DEFAULT ''")
  }
  if(oldVersion<4) db.execSQL("CREATE TABLE IF NOT EXISTS medicine_name_history(id INTEGER PRIMARY KEY AUTOINCREMENT,old_name TEXT NOT NULL,new_name TEXT NOT NULL,affected_cases INTEGER NOT NULL DEFAULT 0,reason TEXT DEFAULT '',approved_at TEXT DEFAULT CURRENT_TIMESTAMP)")
  if(oldVersion<5){ createSyncInfrastructure(db); backfillSyncIdentities(db) }
  if(oldVersion<6){ createSyncInfrastructure(db); backfillSyncIdentities(db); createSyncCaptureTriggers(db); enqueueInitialSyncSnapshot(db) }
  if(oldVersion<7){
   addColumnIfMissing(db,"sync_inbox","entity_type","TEXT DEFAULT ''")
   addColumnIfMissing(db,"sync_inbox","entity_uuid","TEXT DEFAULT ''")
   addColumnIfMissing(db,"sync_inbox","operation","TEXT DEFAULT 'upsert'")
   addColumnIfMissing(db,"sync_inbox","base_version","INTEGER NOT NULL DEFAULT 0")
   addColumnIfMissing(db,"sync_inbox","remote_version","INTEGER NOT NULL DEFAULT 0")
   addColumnIfMissing(db,"sync_inbox","payload_json","TEXT NOT NULL DEFAULT '{}'")
   addColumnIfMissing(db,"sync_conflicts","remote_event_uuid","TEXT DEFAULT ''")
  }
  if(oldVersion<8){
   addColumnIfMissing(db,"app_users","permissions","TEXT NOT NULL DEFAULT '[]'")
   addColumnIfMissing(db,"app_users","active","INTEGER NOT NULL DEFAULT 1")
   db.execSQL("CREATE TABLE IF NOT EXISTS activation_codes(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT NOT NULL,code_salt TEXT NOT NULL,code_hash TEXT NOT NULL,permissions TEXT NOT NULL,expires_at INTEGER NOT NULL,used_at INTEGER,created_by TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)")
   db.execSQL("CREATE INDEX IF NOT EXISTS idx_activation_username ON activation_codes(username,expires_at)")
  }
  if(oldVersion<9) createAuthorizationInfrastructure(db)
  if(oldVersion<10) addColumnIfMissing(db,"auth_runtime","user_id","INTEGER")
  if(oldVersion<11){ addColumnIfMissing(db,"app_users","owner_user_id","INTEGER"); addColumnIfMissing(db,"activation_codes","created_by_user_id","INTEGER") }
 }
 /** Database-level permission enforcement: UI visibility is not the security boundary. */
 private fun createAuthorizationInfrastructure(db:SQLiteDatabase){
  db.execSQL("CREATE TABLE IF NOT EXISTS auth_runtime(id INTEGER PRIMARY KEY CHECK(id=1),role TEXT NOT NULL,permissions TEXT NOT NULL DEFAULT '',user_id INTEGER)")
  db.execSQL("INSERT OR IGNORE INTO auth_runtime(id,role,permissions) VALUES(1,'ADMIN','view_search,add_edit,export_share,import_excel,manage_medicines,manage_users')")
  val rules=listOf("cases" to "add_edit","employees" to "add_edit","medicines" to "manage_medicines","strengths" to "manage_medicines")
  rules.forEach{(table,permission)->
   listOf("INSERT","UPDATE","DELETE").forEach{op->
    db.execSQL("CREATE TRIGGER IF NOT EXISTS auth_${table}_${op.lowercase()} BEFORE $op ON $table WHEN COALESCE((SELECT role FROM auth_runtime WHERE id=1),'GUEST')!='ADMIN' AND instr(','||COALESCE((SELECT permissions FROM auth_runtime WHERE id=1),'')||',',',$permission,')=0 BEGIN SELECT RAISE(ABORT,'permission_denied:$permission'); END")
   }
  }
 }
 fun setActiveSession(role:String,permissions:Set<String>,userId:Long?=null){
  val safeRole=if(role=="ADMIN")"ADMIN" else if(role=="USER")"USER" else "GUEST"
  val allowed=setOf("view_search","add_edit","export_share","import_excel","manage_medicines","manage_users")
  val packed=permissions.filter{it in allowed}.sorted().joinToString(",")
  val v=ContentValues().apply{put("role",safeRole);put("permissions",packed);if(userId==null)putNull("user_id") else put("user_id",userId)}
  writableDatabase.update("auth_runtime",v,"id=1",null)
 }
 fun isAdminSession():Boolean=readableDatabase.rawQuery("SELECT role FROM auth_runtime WHERE id=1",null).use{it.moveToFirst()&&it.getString(0)=="ADMIN"}
 fun hasActivePermission(permission:String):Boolean=isAdminSession()||readableDatabase.rawQuery("SELECT instr(','||permissions||',',?)>0 FROM auth_runtime WHERE id=1",arrayOf(",$permission,")).use{it.moveToFirst()&&it.getInt(0)==1}
 fun activePermissions():Set<String> = if(isAdminSession())setOf("view_search","add_edit","export_share","import_excel","manage_medicines","manage_users") else readableDatabase.rawQuery("SELECT permissions FROM auth_runtime WHERE id=1",null).use{c->if(c.moveToFirst())c.getString(0).split(",").filter{it.isNotBlank()}.toSet() else emptySet()}
 fun activeUserId():Long?=readableDatabase.rawQuery("SELECT user_id FROM auth_runtime WHERE id=1",null).use{if(it.moveToFirst()&&!it.isNull(0))it.getLong(0) else null}

 /** Durable local sync queue with automatic SQLite change capture; remote transport is provider-neutral. */
 private fun createSyncInfrastructure(db:SQLiteDatabase){
  db.execSQL("CREATE TABLE IF NOT EXISTS sync_device(id INTEGER PRIMARY KEY CHECK(id=1),device_uuid TEXT NOT NULL UNIQUE,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)")
  db.execSQL("CREATE TABLE IF NOT EXISTS sync_entity_identity(entity_type TEXT NOT NULL,local_id INTEGER NOT NULL,entity_uuid TEXT NOT NULL UNIQUE,version INTEGER NOT NULL DEFAULT 1,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,deleted_at TEXT,PRIMARY KEY(entity_type,local_id))")
  db.execSQL("CREATE TABLE IF NOT EXISTS sync_outbox(event_uuid TEXT PRIMARY KEY,entity_type TEXT NOT NULL,entity_uuid TEXT NOT NULL,operation TEXT NOT NULL,base_version INTEGER NOT NULL,new_version INTEGER NOT NULL,payload_json TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,delivery_state TEXT NOT NULL DEFAULT 'pending',attempt_count INTEGER NOT NULL DEFAULT 0,last_error TEXT DEFAULT '')")
  db.execSQL("CREATE INDEX IF NOT EXISTS idx_sync_outbox_state ON sync_outbox(delivery_state,created_at)")
  db.execSQL("CREATE TABLE IF NOT EXISTS sync_inbox(event_uuid TEXT PRIMARY KEY,source_device_uuid TEXT NOT NULL,received_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,applied_at TEXT,apply_state TEXT NOT NULL DEFAULT 'received',error_text TEXT DEFAULT '',entity_type TEXT DEFAULT '',entity_uuid TEXT DEFAULT '',operation TEXT DEFAULT 'upsert',base_version INTEGER NOT NULL DEFAULT 0,remote_version INTEGER NOT NULL DEFAULT 0,payload_json TEXT NOT NULL DEFAULT '{}')")
  db.execSQL("CREATE TABLE IF NOT EXISTS sync_conflicts(conflict_uuid TEXT PRIMARY KEY,entity_type TEXT NOT NULL,entity_uuid TEXT NOT NULL,local_version INTEGER NOT NULL,remote_version INTEGER NOT NULL,local_payload_json TEXT NOT NULL,remote_payload_json TEXT NOT NULL,detected_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,resolution TEXT NOT NULL DEFAULT 'pending',resolved_at TEXT,remote_event_uuid TEXT DEFAULT '')")
  db.execSQL("CREATE INDEX IF NOT EXISTS idx_sync_conflicts_state ON sync_conflicts(resolution,detected_at)")
  val device=db.rawQuery("SELECT device_uuid FROM sync_device WHERE id=1",null).use{c->if(c.moveToFirst())c.getString(0) else null}
  if(device==null){val v=ContentValues().apply{put("id",1);put("device_uuid",java.util.UUID.randomUUID().toString())};db.insertOrThrow("sync_device",null,v)}
  db.execSQL("CREATE TABLE IF NOT EXISTS sync_runtime_flags(id INTEGER PRIMARY KEY CHECK(id=1),suppress_capture INTEGER NOT NULL DEFAULT 0)")
  db.execSQL("INSERT OR IGNORE INTO sync_runtime_flags(id,suppress_capture) VALUES(1,0)")
 }
 private fun createSyncCaptureTriggers(db:SQLiteDatabase){
  val entities=listOf("cases" to "case","employees" to "employee","medicines" to "medicine","strengths" to "strength")
  entities.forEach{(table,type)->
   val safe=type
   db.execSQL("CREATE TRIGGER IF NOT EXISTS sync_${safe}_insert AFTER INSERT ON $table WHEN COALESCE((SELECT suppress_capture FROM sync_runtime_flags WHERE id=1),0)=0 BEGIN INSERT OR IGNORE INTO sync_entity_identity(entity_type,local_id,entity_uuid,version,updated_at) VALUES('$safe',NEW.id,lower(hex(randomblob(16))),1,CURRENT_TIMESTAMP); INSERT INTO sync_outbox(event_uuid,entity_type,entity_uuid,operation,base_version,new_version,payload_json) SELECT lower(hex(randomblob(16))),'$safe',entity_uuid,'upsert',0,version,'{}' FROM sync_entity_identity WHERE entity_type='$safe' AND local_id=NEW.id; END")
   db.execSQL("CREATE TRIGGER IF NOT EXISTS sync_${safe}_update AFTER UPDATE ON $table WHEN COALESCE((SELECT suppress_capture FROM sync_runtime_flags WHERE id=1),0)=0 BEGIN INSERT OR IGNORE INTO sync_entity_identity(entity_type,local_id,entity_uuid,version,updated_at) VALUES('$safe',NEW.id,lower(hex(randomblob(16))),1,CURRENT_TIMESTAMP); UPDATE sync_entity_identity SET version=version+1,updated_at=CURRENT_TIMESTAMP WHERE entity_type='$safe' AND local_id=NEW.id; INSERT INTO sync_outbox(event_uuid,entity_type,entity_uuid,operation,base_version,new_version,payload_json) SELECT lower(hex(randomblob(16))),'$safe',entity_uuid,'upsert',COALESCE((SELECT MIN(base_version) FROM sync_outbox WHERE entity_uuid=sync_entity_identity.entity_uuid AND delivery_state='pending'),version-1),version,'{}' FROM sync_entity_identity WHERE entity_type='$safe' AND local_id=NEW.id; UPDATE sync_outbox SET delivery_state='superseded' WHERE entity_uuid=(SELECT entity_uuid FROM sync_entity_identity WHERE entity_type='$safe' AND local_id=NEW.id) AND delivery_state='pending' AND event_uuid<>(SELECT event_uuid FROM sync_outbox WHERE entity_uuid=(SELECT entity_uuid FROM sync_entity_identity WHERE entity_type='$safe' AND local_id=NEW.id) ORDER BY rowid DESC LIMIT 1); END")
   db.execSQL("CREATE TRIGGER IF NOT EXISTS sync_${safe}_delete BEFORE DELETE ON $table WHEN COALESCE((SELECT suppress_capture FROM sync_runtime_flags WHERE id=1),0)=0 BEGIN INSERT OR IGNORE INTO sync_entity_identity(entity_type,local_id,entity_uuid,version,updated_at) VALUES('$safe',OLD.id,lower(hex(randomblob(16))),1,CURRENT_TIMESTAMP); UPDATE sync_entity_identity SET version=version+1,updated_at=CURRENT_TIMESTAMP,deleted_at=CURRENT_TIMESTAMP WHERE entity_type='$safe' AND local_id=OLD.id; INSERT INTO sync_outbox(event_uuid,entity_type,entity_uuid,operation,base_version,new_version,payload_json) SELECT lower(hex(randomblob(16))),'$safe',entity_uuid,'delete',COALESCE((SELECT MIN(base_version) FROM sync_outbox WHERE entity_uuid=sync_entity_identity.entity_uuid AND delivery_state='pending'),version-1),version,'{}' FROM sync_entity_identity WHERE entity_type='$safe' AND local_id=OLD.id; UPDATE sync_outbox SET delivery_state='superseded' WHERE entity_uuid=(SELECT entity_uuid FROM sync_entity_identity WHERE entity_type='$safe' AND local_id=OLD.id) AND delivery_state='pending' AND event_uuid<>(SELECT event_uuid FROM sync_outbox WHERE entity_uuid=(SELECT entity_uuid FROM sync_entity_identity WHERE entity_type='$safe' AND local_id=OLD.id) ORDER BY rowid DESC LIMIT 1); END")
  }
 }
 private fun enqueueInitialSyncSnapshot(db:SQLiteDatabase){
  db.execSQL("INSERT INTO sync_outbox(event_uuid,entity_type,entity_uuid,operation,base_version,new_version,payload_json) SELECT lower(hex(randomblob(16))),entity_type,entity_uuid,'upsert',0,version,'{}' FROM sync_entity_identity WHERE deleted_at IS NULL")
 }
 private fun backfillSyncIdentities(db:SQLiteDatabase){
  val entities=listOf("cases" to "case","employees" to "employee","medicines" to "medicine","strengths" to "strength")
  entities.forEach{(table,type)->
   db.rawQuery("SELECT id FROM $table",null).use{c->while(c.moveToNext()){
    val localId=c.getLong(0)
    val exists=db.rawQuery("SELECT 1 FROM sync_entity_identity WHERE entity_type=? AND local_id=?",arrayOf(type,localId.toString())).use{it.moveToFirst()}
    if(!exists){val v=ContentValues().apply{put("entity_type",type);put("local_id",localId);put("entity_uuid",java.util.UUID.randomUUID().toString());put("version",1)};db.insertOrThrow("sync_entity_identity",null,v)}
   }}
  }
 }
 /** Stable per-install identifier; never derived from employee or personal data. */
 fun syncDeviceId():String = readableDatabase.rawQuery("SELECT device_uuid FROM sync_device WHERE id=1",null).use{c->if(c.moveToFirst())c.getString(0) else ""}
 /** Diagnostic counts for the local sync queue and unresolved conflicts. */
 fun syncDiagnostics():Map<String,Int>{
  val d=readableDatabase
  fun count(table:String,where:String="")=d.rawQuery("SELECT COUNT(*) FROM $table $where",null).use{c->c.moveToFirst();c.getInt(0)}
  return mapOf("identities" to count("sync_entity_identity"),"pending" to count("sync_outbox","WHERE delivery_state='pending'"),"inbox" to count("sync_inbox","WHERE apply_state IN ('received','conflict')"),"conflicts" to count("sync_conflicts","WHERE resolution='pending'"))
 }
 /** Builds transport-ready envelopes from the latest local row snapshot. A server ACK is required before marking sent. */
 fun pendingSyncEnvelopes(limit:Int=200):List<SyncEnvelope>{
  val d=readableDatabase;val result=mutableListOf<SyncEnvelope>()
  d.rawQuery("SELECT o.event_uuid,o.entity_type,o.entity_uuid,o.operation,o.base_version,o.new_version,i.local_id FROM sync_outbox o JOIN sync_entity_identity i ON i.entity_type=o.entity_type AND i.entity_uuid=o.entity_uuid WHERE o.delivery_state='pending' ORDER BY o.created_at,o.rowid LIMIT ?",arrayOf(limit.coerceIn(1,1000).toString())).use{c->
   while(c.moveToNext()){
    val eventId=c.getString(0);val type=c.getString(1);val entityId=c.getString(2);val operation=c.getString(3);val localId=c.getLong(6)
    val payload=org.json.JSONObject().put("entity_uuid",entityId).put("local_id",localId)
    if(operation=="delete")payload.put("deleted",true) else {
     val table=when(type){"case"->"cases";"employee"->"employees";"medicine"->"medicines";"strength"->"strengths";else->error("Unsupported sync entity: $type")}
     d.rawQuery("SELECT * FROM $table WHERE id=?",arrayOf(localId.toString())).use{row->if(row.moveToFirst()){for(index in 0 until row.columnCount){val name=row.getColumnName(index);if(name!="id")payload.put(name,if(row.isNull(index))org.json.JSONObject.NULL else row.getString(index))}}else payload.put("deleted",true)}
    }
    result+=SyncEnvelope(eventId,syncDeviceId(),type,entityId,operation,c.getLong(4),c.getLong(5),payload.toString())
   }
  }
  return result
 }
 /** Call only after the remote endpoint confirms the event IDs. */
 fun acknowledgeSyncEvents(eventIds:List<String>):Int{
  if(eventIds.isEmpty())return 0
  val d=writableDatabase;var changed=0;d.beginTransaction()
  try{eventIds.distinct().forEach{id->val v=ContentValues().apply{put("delivery_state","sent");put("last_error","")};changed+=d.update("sync_outbox",v,"event_uuid=? AND delivery_state='pending'",arrayOf(id))};d.setTransactionSuccessful()}finally{d.endTransaction()}
  return changed
 }
 fun recordSyncFailure(eventIds:List<String>,message:String){
  val d=writableDatabase;d.beginTransaction()
  try{eventIds.distinct().forEach{id->d.execSQL("UPDATE sync_outbox SET attempt_count=attempt_count+1,last_error=? WHERE event_uuid=? AND delivery_state='pending'",arrayOf(message.take(500),id))};d.setTransactionSuccessful()}finally{d.endTransaction()}
 }
 /** Read-only review queue. Payloads are retained verbatim for a human comparison. */
 fun syncReviewItems(limit:Int=100):List<SyncReviewItem>{
  val out=mutableListOf<SyncReviewItem>()
  readableDatabase.rawQuery("SELECT i.event_uuid,i.entity_type,i.entity_uuid,i.operation,i.base_version,i.remote_version,i.source_device_uuid,i.apply_state,COALESCE(i.error_text,''),i.payload_json,COALESCE(c.local_payload_json,'{}') FROM sync_inbox i LEFT JOIN sync_conflicts c ON c.remote_event_uuid=i.event_uuid WHERE i.apply_state IN ('received','conflict','error') ORDER BY i.received_at DESC LIMIT ?",arrayOf(limit.coerceIn(1,300).toString())).use{c->while(c.moveToNext())out+=SyncReviewItem(c.getString(0),c.getString(1),c.getString(2),c.getString(3),c.getLong(4),c.getLong(5),c.getString(6),c.getString(7),c.getString(8),c.getString(9),c.getString(10))}
  return out
 }
 /** Keep the local revision and publish it as a newer event so other devices converge on the explicit choice. */
 fun keepLocalForRemoteEvent(eventId:String):Boolean{
  val d=writableDatabase;d.beginTransaction()
  return try{
   val info=d.rawQuery("SELECT entity_type,entity_uuid,apply_state,remote_version,operation FROM sync_inbox WHERE event_uuid=?",arrayOf(eventId)).use{c->if(c.moveToFirst())(0..4).map{c.getString(it)} else null}?:return false
   if(info[2] !in setOf("conflict","error") && info[4]!="delete")return false
   val identity=d.rawQuery("SELECT local_id,version FROM sync_entity_identity WHERE entity_type=? AND entity_uuid=?",arrayOf(info[0],info[1])).use{c->if(c.moveToFirst())c.getLong(0) to c.getLong(1) else null}?:return false
   val table=when(info[0]){"case"->"cases";"employee"->"employees";"medicine"->"medicines";"strength"->"strengths";else->return false}
   val exists=d.rawQuery("SELECT 1 FROM $table WHERE id=?",arrayOf(identity.first.toString())).use{it.moveToFirst()}
   if(!exists)return false
   val baseVersion=maxOf(identity.second,info[3].toLongOrNull()?:identity.second)
   val nextVersion=baseVersion+1
   d.update("sync_entity_identity",ContentValues().apply{put("version",nextVersion);put("updated_at","CURRENT_TIMESTAMP")},"entity_type=? AND entity_uuid=?",arrayOf(info[0],info[1]))
   d.update("sync_outbox",ContentValues().apply{put("delivery_state","superseded")},"entity_uuid=? AND delivery_state='pending'",arrayOf(info[1]))
   val event=ContentValues().apply{put("event_uuid",java.util.UUID.randomUUID().toString());put("entity_type",info[0]);put("entity_uuid",info[1]);put("operation","upsert");put("base_version",baseVersion);put("new_version",nextVersion);put("payload_json","{}");put("delivery_state","pending")}
   d.insertOrThrow("sync_outbox",null,event)
   d.update("sync_inbox",ContentValues().apply{put("apply_state","kept_local");put("error_text","تم الاحتفاظ بالبيانات المحلية ونشر إصدارها إلى بقية الأجهزة")},"event_uuid=?",arrayOf(eventId))
   d.update("sync_conflicts",ContentValues().apply{put("resolution","local_kept");put("resolved_at","CURRENT_TIMESTAMP")},"remote_event_uuid=? AND resolution='pending'",arrayOf(eventId))
   d.insert("audit_log",null,ContentValues().apply{put("action","مزامنة: الاحتفاظ بالبيانات المحلية");put("item_key",eventId)})
   d.setTransactionSuccessful();true
  }finally{d.endTransaction()}
 }
 /** Apply one reviewed remote upsert atomically. Deletes are deliberately blocked until archival/restore semantics exist. */
 fun applyReviewedRemoteEvent(eventId:String):String?{
  val d=writableDatabase;d.beginTransaction()
  try{
   val row=d.rawQuery("SELECT entity_type,entity_uuid,operation,base_version,remote_version,payload_json,apply_state FROM sync_inbox WHERE event_uuid=?",arrayOf(eventId)).use{c->if(c.moveToFirst())(0..6).map{c.getString(it)} else return "الحدث غير موجود في صندوق المراجعة"}
   val type=row[0];val uuid=row[1];val operation=row[2];val baseVersion=row[3].toLongOrNull()?:return "إصدار الأساس غير صالح";val remoteVersion=row[4].toLongOrNull()?:return "إصدار الحدث غير صالح";val payloadText=row[5];val state=row[6]
   if(state !in setOf("received","conflict","error"))return "تمت معالجة هذا الحدث أو لا ينتظر المراجعة"
   if(remoteVersion<=baseVersion)return "تسلسل إصدارات الحدث غير صالح"
   if(operation!="upsert")return "لا يمكن تطبيق الحذف الوارد قبل توفير الأرشفة والاسترجاع؛ يمكنك الاحتفاظ بالنسخة المحلية"
   val table=when(type){"case"->"cases";"employee"->"employees";"medicine"->"medicines";"strength"->"strengths";else->return "نوع السجل غير مدعوم"}
   require(payloadText.length<=131072){"حجم بيانات الحدث يتجاوز الحد الآمن"}
   val json=org.json.JSONObject(payloadText);if(json.has("entity_uuid")&&json.optString("entity_uuid")!=uuid)return "معرّف السجل داخل الحمولة لا يطابق معرّف الحدث"
   val localVersion=d.rawQuery("SELECT version FROM sync_entity_identity WHERE entity_type=? AND entity_uuid=?",arrayOf(type,uuid)).use{c->if(c.moveToFirst())c.getLong(0) else 0L}
   val reviewedVersion=d.rawQuery("SELECT local_version FROM sync_conflicts WHERE remote_event_uuid=?",arrayOf(eventId)).use{c->if(c.moveToFirst())c.getLong(0) else baseVersion}
   if(localVersion!=reviewedVersion)return "تغير السجل المحلي بعد فتح المراجعة؛ حدّث قائمة المزامنة وراجع التعارض من جديد"
   val mappedType=d.rawQuery("SELECT entity_type FROM sync_entity_identity WHERE entity_uuid=?",arrayOf(uuid)).use{c->if(c.moveToFirst())c.getString(0) else null}
   if(mappedType!=null&&mappedType!=type)return "معرّف السجل مستخدم لنوع بيانات مختلف"
   val allowed=mutableSetOf<String>()
   d.rawQuery("PRAGMA table_info($table)",null).use{c->while(c.moveToNext()){val name=c.getString(c.getColumnIndexOrThrow("name"));if(name!="id")allowed+=name}}
   val values=ContentValues();val keys=json.keys();while(keys.hasNext()){val key=keys.next();if(key in setOf("id","local_id","entity_uuid","deleted","_sync_version"))continue;if(key !in allowed)return "حقل غير معروف في بيانات السجل: $key";val value=json.opt(key);when(value){null,org.json.JSONObject.NULL->values.putNull(key);is Boolean->values.put(key,if(value)1 else 0);is Number->values.put(key,value.toString());else->values.put(key,value.toString())}}
   fun field(name:String)=values.getAsString(name).orEmpty()
   when(type){
    "case"->{val record=CaseRecord(region=field("region"),sector=field("sector"),name=field("name"),performanceNo=field("performance_no"),medicine=field("medicine"),strength=field("strength"),extra1=field("extra1"),extra2=field("extra2"),duration=field("duration"),dosage=field("dosage"),condition=field("condition_text"),approvalDate=field("approval_date"),approvalExpiry=field("approval_expiry"));val issues=CaseDataRules.validate(listOf(record));if(issues.isNotEmpty())return issues.joinToString(" ");val match=medicineNameMatch(record.medicine);if(match.type==MedicineNameMatchType.NEW||match.type==MedicineNameMatchType.SUGGESTION)return "اسم الدواء الوارد غير معتمد محلياً؛ راجع قاموس الأدوية أولاً"}
    "employee"->{if(field("performance_no").isBlank()||field("name").isBlank())return "رقم الأداء والاسم إلزاميان";if(field("performance_no").length>64||field("name").length>200)return "بيانات العامل تتجاوز الحدود المسموح بها"}
    "medicine"->{if(field("name").isBlank())return "اسم الدواء إلزامي";if(field("name").length>200)return "اسم الدواء أطول من الحد المسموح"}
    "strength"->{if(field("medicine").isBlank()||field("strength").isBlank())return "اسم الدواء والتركيز إلزاميان";if(field("strength").length>120)return "وصف التركيز أطول من الحد المسموح"}
   }
   val identity=d.rawQuery("SELECT local_id FROM sync_entity_identity WHERE entity_type=? AND entity_uuid=?",arrayOf(type,uuid)).use{c->if(c.moveToFirst())c.getLong(0) else null}
   if(identity==null){
    val natural=when(type){"employee"->d.rawQuery("SELECT id FROM employees WHERE performance_no=?",arrayOf(values.getAsString("performance_no"))).use{c->if(c.moveToFirst())c.getLong(0) else null};"medicine"->d.rawQuery("SELECT id FROM medicines WHERE name=? COLLATE NOCASE",arrayOf(values.getAsString("name"))).use{c->if(c.moveToFirst())c.getLong(0) else null};"strength"->d.rawQuery("SELECT id FROM strengths WHERE medicine=? COLLATE NOCASE AND strength=? COLLATE NOCASE",arrayOf(values.getAsString("medicine"),values.getAsString("strength"))).use{c->if(c.moveToFirst())c.getLong(0) else null};else->null}
    if(natural!=null)return "يوجد سجل محلي مشابه بمعرّف مختلف؛ يلزم ربطه يدوياً قبل الاستبدال"
   }
   d.update("sync_outbox",ContentValues().apply{put("delivery_state","superseded");put("last_error","تم اعتماد النسخة الواردة بقرار المستخدم")},"entity_uuid=? AND delivery_state='pending'",arrayOf(uuid))
   d.execSQL("UPDATE sync_runtime_flags SET suppress_capture=1 WHERE id=1")
   val localId=if(identity!=null){val changed=d.update(table,values,"id=?",arrayOf(identity.toString()));if(changed==0)return "السجل المحلي المرتبط غير موجود";identity}else d.insertOrThrow(table,null,values)
   val identityUpdate=ContentValues().apply{put("local_id",localId);put("version",remoteVersion);put("updated_at","CURRENT_TIMESTAMP");putNull("deleted_at")}
   val identityChanged=d.update("sync_entity_identity",identityUpdate,"entity_type=? AND entity_uuid=?",arrayOf(type,uuid))
   if(identityChanged==0){val iv=ContentValues().apply{put("entity_type",type);put("local_id",localId);put("entity_uuid",uuid);put("version",remoteVersion);put("updated_at","CURRENT_TIMESTAMP");putNull("deleted_at")};d.insertOrThrow("sync_entity_identity",null,iv)}
   d.update("sync_inbox",ContentValues().apply{put("apply_state","applied");put("applied_at","CURRENT_TIMESTAMP");put("error_text","")},"event_uuid=?",arrayOf(eventId))
   d.update("sync_conflicts",ContentValues().apply{put("resolution","remote_wins");put("resolved_at","CURRENT_TIMESTAMP")},"remote_event_uuid=? AND resolution='pending'",arrayOf(eventId))
   d.insert("audit_log",null,ContentValues().apply{put("action","مزامنة: اعتماد تحديث وارد");put("item_key",eventId)})
   d.execSQL("UPDATE sync_runtime_flags SET suppress_capture=0 WHERE id=1")
   d.setTransactionSuccessful();return null
  }catch(e:Exception){return "تعذر تطبيق التحديث: ${e.message?:"خطأ غير معروف"}"}finally{try{d.execSQL("UPDATE sync_runtime_flags SET suppress_capture=0 WHERE id=1")}catch(_:Exception){};d.endTransaction()}
 }
 /** Persist pulled events without applying them. Conflicts are recorded for explicit review; no business row is overwritten. */
 fun receiveRemoteSyncEvents(events:List<SyncPullEvent>):Int {
  if(events.isEmpty())return 0
  val d=writableDatabase;var inserted=0;d.beginTransaction()
  try {
   events.forEach { e ->
    val exists=d.rawQuery("SELECT 1 FROM sync_inbox WHERE event_uuid=?",arrayOf(e.eventId)).use{it.moveToFirst()}
    if(exists)return@forEach
    val identity=d.rawQuery("SELECT local_id,version FROM sync_entity_identity WHERE entity_type=? AND entity_uuid=?",arrayOf(e.entityType,e.entityId)).use{c->if(c.moveToFirst())c.getLong(0) to c.getLong(1) else null}
    val localVersion=identity?.second ?: 0L
    val conflict=localVersion!=e.baseVersion
    val state=if(conflict)"conflict" else "received"
    val inbox=ContentValues().apply{put("event_uuid",e.eventId);put("source_device_uuid",e.sourceDeviceId);put("apply_state",state);put("entity_type",e.entityType);put("entity_uuid",e.entityId);put("operation",e.operation);put("base_version",e.baseVersion);put("remote_version",e.newVersion);put("payload_json",e.payloadJson);if(conflict)put("error_text","الإصدار المحلي لا يطابق إصدار الأساس الوارد؛ يلزم فحص يدوي")}
    d.insertOrThrow("sync_inbox",null,inbox);inserted++
    if(conflict){
     val localPayload=if(identity==null)"{}" else {
      val table=when(e.entityType){"case"->"cases";"employee"->"employees";"medicine"->"medicines";"strength"->"strengths";else->error("Unsupported sync entity")}
      d.rawQuery("SELECT * FROM $table WHERE id=?",arrayOf(identity.first.toString())).use{row->
       if(!row.moveToFirst())"{}" else org.json.JSONObject().apply{for(index in 0 until row.columnCount){val key=row.getColumnName(index);put(key,if(row.isNull(index))org.json.JSONObject.NULL else row.getString(index))};put("_sync_version",localVersion)}.toString()
      }
     }
     val cv=ContentValues().apply{put("conflict_uuid",java.util.UUID.randomUUID().toString());put("remote_event_uuid",e.eventId);put("entity_type",e.entityType);put("entity_uuid",e.entityId);put("local_version",localVersion);put("remote_version",e.newVersion);put("local_payload_json",localPayload);put("remote_payload_json",e.payloadJson)}
     d.insertOrThrow("sync_conflicts",null,cv)
    }
   }
   d.setTransactionSuccessful()
  } finally {d.endTransaction()}
  return inserted
 }

 private fun addColumnIfMissing(db:SQLiteDatabase,table:String,column:String,definition:String){
  val exists=db.rawQuery("PRAGMA table_info($table)",null).use{c->var found=false;while(c.moveToNext())if(c.getString(c.getColumnIndexOrThrow("name")).equals(column,true))found=true;found}
  if(!exists)db.execSQL("ALTER TABLE $table ADD COLUMN $column $definition")
 }
 private fun createEmployeeTable(db:SQLiteDatabase){
  db.execSQL("CREATE TABLE IF NOT EXISTS employees(id INTEGER PRIMARY KEY AUTOINCREMENT,performance_no TEXT NOT NULL UNIQUE,name TEXT NOT NULL DEFAULT '',job TEXT DEFAULT '',entity TEXT DEFAULT '',department TEXT DEFAULT '',national_id TEXT DEFAULT '',phone1 TEXT DEFAULT '',phone2 TEXT DEFAULT '',gender TEXT DEFAULT '',notes TEXT DEFAULT '',birth_date TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP)")
  db.execSQL("CREATE INDEX IF NOT EXISTS idx_employee_name ON employees(name)")
 }
 private fun android.database.Cursor.s(k:String)=getString(getColumnIndexOrThrow(k))?:""
 private fun android.database.Cursor.toRecord()=CaseRecord(getLong(getColumnIndexOrThrow("id")),s("region"),s("sector"),s("name"),s("performance_no"),s("medicine"),s("strength"),s("extra1"),s("extra2"),s("duration"),s("dosage"),s("condition_text"),s("approval_date"),s("approval_expiry"))
 fun all():List<CaseRecord>{val a= mutableListOf<CaseRecord>();readableDatabase.rawQuery("SELECT * FROM cases ORDER BY name",null).use{c->while(c.moveToNext())a+=c.toRecord()};return a}
 fun search(q:String="",med:String=""):List<CaseRecord>{val a= mutableListOf<CaseRecord>();val l="%$q%";readableDatabase.rawQuery("SELECT * FROM cases WHERE (?='' OR name LIKE ? OR performance_no LIKE ? OR medicine LIKE ?) AND (?='' OR medicine=?) ORDER BY name",arrayOf(q,l,l,l,med,med)).use{c->while(c.moveToNext())a+=c.toRecord()};return a}
 fun save(r:CaseRecord):Long{val medicineMatch=medicineNameMatch(r.medicine);if(r.medicine.isNotBlank()&&medicineMatch.type==MedicineNameMatchType.NEW&&!hasActivePermission("manage_medicines"))throw SecurityException("الدواء غير موجود في القاموس؛ اطلب من مدير الأدوية إضافته أولاً.");require(medicineMatch.type!=MedicineNameMatchType.SUGGESTION){if(medicineMatch.similarity>0.0)"اسم الدواء «${r.medicine}» قريب من «${medicineMatch.canonicalName}». صحح الاسم لتجنب إنشاء دواء مكرر." else "اسم الدواء «${r.medicine}» يحتاج مراجعة العبوة: ${medicineMatch.canonicalName}. لم يتم الحفظ."};val v=ContentValues().apply{put("region",r.region);put("sector",r.sector);put("name",r.name);put("performance_no",r.performanceNo);put("medicine",canonicalMedicineName(r.medicine));put("strength",r.strength);put("extra1",r.extra1);put("extra2",r.extra2);put("duration",r.duration);put("dosage",r.dosage);put("condition_text",r.condition);put("approval_date",r.approvalDate);put("approval_expiry",r.approvalExpiry)};return if(r.id>0){writableDatabase.update("cases",v,"id=?",arrayOf(r.id.toString()));r.id}else writableDatabase.insertOrThrow("cases",null,v)}
 fun delete(id:Long){writableDatabase.delete("cases","id=?",arrayOf(id.toString()))}

 /** Delete only treatment rows; employee directory and medicine catalog remain intact. */
 fun clearCases(){
  require(isAdminSession()){"هذه العملية متاحة لمدير النظام فقط."}
  val d=writableDatabase;d.beginTransaction()
  try{d.delete("cases",null,null);val log=ContentValues().apply{put("action","مسح جميع الحالات العلاجية");put("item_key","تم مسح جميع سجلات الحالات")};d.insert("audit_log",null,log);d.setTransactionSuccessful()}finally{d.endTransaction()}
 }

 /** Delete only the employee directory; treatment records are intentionally preserved. */
 fun clearEmployees(){
  require(isAdminSession()){"هذه العملية متاحة لمدير النظام فقط."}
  val d=writableDatabase;d.beginTransaction()
  try{d.delete("employees",null,null);val log=ContentValues().apply{put("action","مسح دليل العاملين");put("item_key","تم مسح جميع العاملين")};d.insert("audit_log",null,log);d.setTransactionSuccessful()}finally{d.endTransaction()}
 }

 /** Full business-data reset. Keeps local administrator credentials and visual preferences. */
 fun factoryResetData(){
  require(isAdminSession()){"إعادة ضبط قاعدة البيانات متاحة لمدير النظام فقط."}
  // Load the seed before deleting anything. If it cannot be read, preserve the existing database.
  val seed=org.json.JSONArray(appContext.assets.open("medicines_seed.json").bufferedReader(Charsets.UTF_8).use{it.readText()})
  val d=writableDatabase;d.beginTransaction()
  try{
   d.delete("cases",null,null)
   d.delete("employees",null,null)
   d.delete("strengths",null,null)
   d.delete("medicines",null,null)
   d.delete("app_users",null,null)
   d.delete("activation_codes",null,null)
   d.delete("audit_log",null,null)
   for(i in 0 until seed.length()){
    val o=seed.getJSONObject(i)
    val name=o.optString("name").trim()
    if(name.isNotBlank()){
     val values=ContentValues().apply{put("name",name);put("generic_name",o.optString("generic"));put("specialty",o.optString("specialty"));put("strengths",o.optString("strengths"));put("dosage_form",o.optString("form"));put("review_status",o.optString("status"));put("aliases",o.optString("aliases"));put("medical_notes",o.optString("medical_notes",o.optString("notes")));put("indications",o.optString("indications"));put("critical_classification",o.optString("critical_classification"));put("target_conditions",o.optString("target_conditions"));put("source_reference",o.optString("source_reference"));put("last_reviewed",o.optString("last_reviewed"))}
     d.insertWithOnConflict("medicines",null,values,SQLiteDatabase.CONFLICT_IGNORE)
    }
   }
   d.rawQuery("SELECT name,strengths FROM medicines",null).use{c->while(c.moveToNext()){
    val medicine=c.getString(0).orEmpty()
    splitStrengths(c.getString(1).orEmpty()).forEach{strength->
     val v=ContentValues().apply{put("medicine",medicine);put("strength",strength)}
     d.insertWithOnConflict("strengths",null,v,SQLiteDatabase.CONFLICT_IGNORE)
    }
   }}
   check(d.rawQuery("SELECT COUNT(*) FROM medicines",null).use{it.moveToFirst();it.getInt(0)}>0){"تعذر تحميل قاموس الأدوية الأساسي؛ تم إلغاء إعادة الضبط."}
   val log=ContentValues().apply{put("action","إعادة ضبط بيانات البرنامج");put("item_key","مسح البيانات وإعادة بناء قاموس الأدوية الأساسي")}
   d.insert("audit_log",null,log)
   d.setTransactionSuccessful()
  }finally{d.endTransaction()}
  appContext.getSharedPreferences("local_setup",Context.MODE_PRIVATE).edit().putBoolean("dictionary_seeded",true).apply()
 }
 private fun reconcileVerifiedMedicineAliases(){
  val verified=linkedMapOf("CINRYSE" to "CINRYZE","Xelganz" to "XELJANZ","X-GEVA" to "XGEVA","Baraitava" to "BARITAVA","recorman" to "RECORMON")
  val d=writableDatabase;d.beginTransaction()
  try{
   verified.forEach{(oldName,canonicalName)->
    val old=medicineCatalog().firstOrNull{it.name.equals(oldName,true)} ?: return@forEach
    val canonical=medicineCatalog().firstOrNull{it.name.equals(canonicalName,true)} ?: return@forEach
    val aliases=(canonical.aliases.split(Regex("[;؛,،|\\n]+")).filter{it.isNotBlank()}+old.name+old.aliases.split(Regex("[;؛,،|\\n]+")).filter{it.isNotBlank()}).distinct()
    val affected=d.rawQuery("SELECT COUNT(*) FROM cases WHERE medicine=? COLLATE NOCASE",arrayOf(old.name)).use{c->c.moveToFirst();c.getInt(0)}
    val oldStrengthRows=mutableListOf<String>();d.rawQuery("SELECT strength FROM strengths WHERE medicine=? COLLATE NOCASE",arrayOf(old.name)).use{c->while(c.moveToNext())oldStrengthRows+=c.getString(0).orEmpty()}
    val allStrengths=(splitStrengths(canonical.strengths)+splitStrengths(old.strengths)+oldStrengthRows).filter{it.any(Char::isLetter)}.distinctBy{MedicineStrengthNormalizer.key(it)}
    val ambiguous=(splitStrengths(old.strengths)+oldStrengthRows).filter{it.isNotBlank()&&it.none(Char::isLetter)}
    val mergedNotes=listOf(canonical.medicalNotes,old.medicalNotes,if(ambiguous.isNotEmpty())"قيم غير موثقة من الاسم السابق ${old.name}: ${ambiguous.distinct().joinToString("، ")}؛ يلزم تأكيد الوحدة من العبوة." else "").filter{it.isNotBlank()}.distinct().joinToString("\n")
    val values=ContentValues().apply{
     put("generic_name",if(canonical.genericName.isNotBlank()&&!canonical.genericName.contains("يُستكمل"))canonical.genericName else old.genericName);put("specialty",if(canonical.specialty.isNotBlank()&&!canonical.specialty.contains("يُحدد"))canonical.specialty else old.specialty);put("strengths",allStrengths.joinToString("; "));put("dosage_form",if(canonical.dosageForm.isNotBlank()&&!canonical.dosageForm.contains("يُحدد"))canonical.dosageForm else old.dosageForm);put("review_status",canonical.reviewStatus);put("indications",mergeText(canonical.indications,old.indications));put("critical_classification",mergeText(canonical.criticalClassification,old.criticalClassification));put("target_conditions",mergeText(canonical.targetConditions,old.targetConditions));put("medical_notes",mergedNotes);put("source_reference",mergeText(canonical.sourceReference,old.sourceReference));put("last_reviewed",listOf(canonical.lastReviewed,old.lastReviewed).filter{it.isNotBlank()}.maxOrNull().orEmpty());put("aliases",aliases.joinToString("; "))
    }
    d.update("medicines",values,"name=? COLLATE NOCASE",arrayOf(canonical.name))
    d.execSQL("UPDATE cases SET medicine=? WHERE medicine=? COLLATE NOCASE",arrayOf(canonical.name,old.name))
    allStrengths.forEach{st->val sv=ContentValues().apply{put("medicine",canonical.name);put("strength",st)};d.insertWithOnConflict("strengths",null,sv,SQLiteDatabase.CONFLICT_IGNORE)}
    d.delete("strengths","medicine=? COLLATE NOCASE",arrayOf(old.name));d.delete("medicines","name=? COLLATE NOCASE",arrayOf(old.name))
    val history=ContentValues().apply{put("old_name",old.name);put("new_name",canonical.name);put("affected_cases",affected);put("reason","تصحيح معتمد مسبقاً في قاموس الإصدار 2.5.0")};d.insert("medicine_name_history",null,history)
    val log=ContentValues().apply{put("action","تصحيح اسم دواء ومطابقته مع القاموس");put("item_key","${old.name} ← ${canonical.name} | السجلات المتأثرة: $affected")};d.insert("audit_log",null,log)
   }
   d.setTransactionSuccessful()
  }finally{d.endTransaction()}
 }
 private fun reconcileMedicineCatalogDuplicates(){
  val d=writableDatabase;d.beginTransaction()
  try{
   val rows=mutableListOf<MedicineCatalogRecord>()
   d.rawQuery("SELECT name,generic_name,specialty,strengths,dosage_form,review_status,indications,critical_classification,target_conditions,medical_notes,source_reference,last_reviewed,aliases FROM medicines",null).use{c->while(c.moveToNext())rows+=MedicineCatalogRecord(c.getString(0).orEmpty(),c.getString(1).orEmpty(),c.getString(2).orEmpty(),c.getString(3).orEmpty(),c.getString(4).orEmpty(),c.getString(5).orEmpty(),c.getString(6).orEmpty(),c.getString(7).orEmpty(),c.getString(8).orEmpty(),c.getString(9).orEmpty(),c.getString(10).orEmpty(),c.getString(11).orEmpty(),c.getString(12).orEmpty())}
   rows.filter{it.name.isNotBlank()}.groupBy{MedicineNameMatcher.key(it.name)}.filterKeys{it.isNotBlank()}.values.filter{it.size>1}.forEach{group->
    val canonical=group.minWithOrNull(compareBy<MedicineCatalogRecord>({if(it.name.all{ch->ch.isLetterOrDigit()})0 else 1},{if(it.name==it.name.uppercase(java.util.Locale.ROOT))0 else 1},{it.name.length})) ?: return@forEach
    group.filter{it.name!=canonical.name}.forEach{old->
     val current=d.rawQuery("SELECT generic_name,specialty,strengths,dosage_form,review_status,indications,critical_classification,target_conditions,medical_notes,source_reference,last_reviewed,aliases FROM medicines WHERE name=? COLLATE NOCASE",arrayOf(canonical.name)).use{c->if(c.moveToFirst())(0..11).map{c.getString(it).orEmpty()} else emptyList()}
     val aliasList=(current.getOrNull(11).orEmpty().split(Regex("[;؛,،|\\n]+")).filter{it.isNotBlank()}+old.name+old.aliases.split(Regex("[;؛,،|\\n]+")).filter{it.isNotBlank()}).distinct()
     val mergedStrengths=(splitStrengths(current.getOrNull(2).orEmpty())+splitStrengths(old.strengths)).distinctBy{MedicineStrengthNormalizer.key(it)}
     val values=ContentValues().apply{
      put("generic_name",mergeText(current.getOrNull(0).orEmpty(),old.genericName));put("specialty",mergeText(current.getOrNull(1).orEmpty(),old.specialty));put("strengths",mergedStrengths.joinToString("; "));put("dosage_form",mergeText(current.getOrNull(3).orEmpty(),old.dosageForm));put("review_status",mergeText(current.getOrNull(4).orEmpty(),old.reviewStatus));put("indications",mergeText(current.getOrNull(5).orEmpty(),old.indications));put("critical_classification",mergeText(current.getOrNull(6).orEmpty(),old.criticalClassification));put("target_conditions",mergeText(current.getOrNull(7).orEmpty(),old.targetConditions));put("medical_notes",mergeText(current.getOrNull(8).orEmpty(),old.medicalNotes));put("source_reference",mergeText(current.getOrNull(9).orEmpty(),old.sourceReference));put("last_reviewed",listOf(current.getOrNull(10).orEmpty(),old.lastReviewed).filter{it.isNotBlank()}.maxOrNull().orEmpty());put("aliases",aliasList.joinToString("; "))
     }
     d.update("medicines",values,"name=? COLLATE NOCASE",arrayOf(canonical.name))
     d.execSQL("UPDATE cases SET medicine=? WHERE medicine=?",arrayOf(canonical.name,old.name))
     val oldStrengths=mutableListOf<String>();d.rawQuery("SELECT strength FROM strengths WHERE medicine=? COLLATE NOCASE",arrayOf(old.name)).use{c->while(c.moveToNext())oldStrengths+=c.getString(0).orEmpty()}
     (oldStrengths+splitStrengths(old.strengths)).distinctBy{MedicineStrengthNormalizer.key(it)}.forEach{st->val sv=ContentValues().apply{put("medicine",canonical.name);put("strength",st)};d.insertWithOnConflict("strengths",null,sv,SQLiteDatabase.CONFLICT_IGNORE)}
     d.delete("strengths","medicine=? COLLATE NOCASE",arrayOf(old.name));d.delete("medicines","name=? COLLATE NOCASE",arrayOf(old.name))
     val log=ContentValues().apply{put("action","توحيد اسم دواء متطابق كتابياً");put("item_key","${old.name} ← ${canonical.name}")};d.insert("audit_log",null,log)
    }
   }
   d.setTransactionSuccessful()
  }finally{d.endTransaction()}
 }
 private fun reconcileKnownMedicineNames(){
  val d=writableDatabase;d.beginTransaction()
  try{
   val existing=mutableListOf<String>()
   d.rawQuery("SELECT DISTINCT medicine FROM cases WHERE trim(medicine)<>''",null).use{c->while(c.moveToNext())existing+=c.getString(0).orEmpty()}
   existing.forEach{old->
    val match=medicineNameMatch(old)
    if((match.type==MedicineNameMatchType.NORMALIZED||match.type==MedicineNameMatchType.EXACT)&&match.canonicalName!=null&&match.canonicalName!=old){
     val canonical=match.canonicalName
     d.execSQL("UPDATE cases SET medicine=? WHERE medicine=?",arrayOf(canonical,old))
     val oldStrengths=mutableListOf<String>()
     d.rawQuery("SELECT strength FROM strengths WHERE medicine=? COLLATE NOCASE",arrayOf(old)).use{c->while(c.moveToNext())oldStrengths+=c.getString(0).orEmpty()}
     oldStrengths.forEach{st->val values=ContentValues().apply{put("medicine",canonical);put("strength",st)};d.insertWithOnConflict("strengths",null,values,SQLiteDatabase.CONFLICT_IGNORE)}
     d.delete("strengths","medicine=? COLLATE NOCASE",arrayOf(old))
    }
   }
   d.setTransactionSuccessful()
  }finally{d.endTransaction()}
 }
 fun count()=readableDatabase.rawQuery("SELECT COUNT(*) FROM cases",null).use{it.moveToFirst();it.getInt(0)}
 fun counts():Map<String,Int>{val m=linkedMapOf<String,Int>();readableDatabase.rawQuery("SELECT medicine,COUNT(*) FROM cases GROUP BY medicine ORDER BY medicine",null).use{c->while(c.moveToNext())m[c.getString(0).orEmpty()]=c.getInt(1)};return m}
 fun medicines():List<String>{val m=linkedSetOf<String>();readableDatabase.rawQuery("SELECT name FROM medicines UNION SELECT DISTINCT medicine FROM cases WHERE medicine<>'' ORDER BY 1",null).use{c->while(c.moveToNext())m+=c.getString(0)};return m.toList()}
 fun medicineCatalog():List<MedicineCatalogRecord>{
  val out=mutableListOf<MedicineCatalogRecord>()
  readableDatabase.rawQuery("SELECT name,generic_name,specialty,strengths,dosage_form,review_status,indications,critical_classification,target_conditions,medical_notes,source_reference,last_reviewed,aliases FROM medicines ORDER BY name",null).use{c->while(c.moveToNext())out+=MedicineCatalogRecord(c.getString(0).orEmpty(),c.getString(1).orEmpty(),c.getString(2).orEmpty(),c.getString(3).orEmpty(),c.getString(4).orEmpty(),c.getString(5).orEmpty(),c.getString(6).orEmpty(),c.getString(7).orEmpty(),c.getString(8).orEmpty(),c.getString(9).orEmpty(),c.getString(10).orEmpty(),c.getString(11).orEmpty(),c.getString(12).orEmpty())}
  return out
 }
 fun medicineStrengths():List<MedicineStrengthRecord>{
  val out=mutableListOf<MedicineStrengthRecord>()
  readableDatabase.rawQuery("SELECT medicine,strength FROM strengths ORDER BY medicine,strength",null).use{c->while(c.moveToNext())out+=MedicineStrengthRecord(c.getString(0).orEmpty(),c.getString(1).orEmpty())}
  return out
 }
 fun medicineNameMatch(name:String):MedicineNameMatch {
  val catalog=medicineCatalog()
  val aliases=linkedMapOf<String,String>()
  catalog.forEach{m->m.aliases.split(Regex("[;؛,،|\\n]+")).map{it.trim()}.filter{it.isNotBlank()}.forEach{aliases[it]=m.name}}
  return MedicineNameMatcher.match(name,catalog.map{it.name},aliases)
 }
 fun medicineNameNormalizationNotes(rows:List<CaseRecord>):List<String> = rows.mapNotNull{row->
  val match=medicineNameMatch(row.medicine)
  if((match.type==MedicineNameMatchType.NORMALIZED||match.type==MedicineNameMatchType.EXACT)&&match.canonicalName!=null&&match.canonicalName!=row.medicine.trim()) "${match.importedName} ← ${match.canonicalName}" else null
 }.distinct()
 fun medicineNameReviewIssues(rows:List<CaseRecord>):List<String> = rows.mapIndexedNotNull{index,row->
  val match=medicineNameMatch(row.medicine)
  if(match.type==MedicineNameMatchType.SUGGESTION) {
   if(match.similarity>0.0) "صف ${index+5}: اسم الدواء «${match.importedName}» قريب من «${match.canonicalName}» (${(match.similarity*100).toInt()}%). راجع الاسم وصححه قبل الاستيراد."
   else "صف ${index+5}: الاسم «${match.importedName}» محجوز للمراجعة اليدوية: ${match.canonicalName}. لا تنشئ دواءً جديداً قبل التحقق من العبوة."
  } else null
 }.distinct()
 fun canonicalMedicineName(name:String):String {
  val match=medicineNameMatch(name)
  return if(match.type==MedicineNameMatchType.EXACT||match.type==MedicineNameMatchType.NORMALIZED) match.canonicalName.orEmpty() else name.trim().replace(Regex("\\s+")," ")
 }
 fun upsertMedicine(n:String){if(n.isBlank())return;val clean=canonicalMedicineName(n);val exists=readableDatabase.rawQuery("SELECT 1 FROM medicines WHERE name=? COLLATE NOCASE LIMIT 1",arrayOf(clean)).use{it.moveToFirst()};if(exists)return;require(hasActivePermission("manage_medicines")){"إضافة دواء جديد تتطلب صلاحية إدارة الأدوية."};val v=ContentValues().apply{put("name",clean)};writableDatabase.insertWithOnConflict("medicines",null,v,SQLiteDatabase.CONFLICT_IGNORE)}
 /**
  * Approve a canonical medicine name from the medicine detail screen.
  * Case rows, strengths, aliases, catalog fields and audit history are changed atomically.
  * If the target already exists, merge is allowed only when known active ingredients agree.
  */
 fun approveMedicineNameCorrection(oldName:String,newName:String,reason:String="اعتماد يدوي بعد مراجعة الاسم"):Int {
  require(hasActivePermission("manage_medicines")){"تصحيح أسماء الأدوية يتطلب صلاحية إدارة الأدوية."}
  val oldClean=oldName.trim();val newClean=newName.trim().replace(Regex("\\s+")," ")
  require(oldClean.isNotBlank()&&newClean.isNotBlank()) { "يجب إدخال الاسم القديم والجديد." }
  require(!oldClean.equals(newClean,true)) { "الاسم الجديد مطابق للاسم الحالي." }
  val d=writableDatabase;d.beginTransaction()
  try {
   val old=medicineCatalog().firstOrNull{it.name.equals(oldClean,true)} ?: throw IllegalArgumentException("الدواء الأصلي غير موجود في القاموس.")
   val target=medicineCatalog().firstOrNull{it.name.equals(newClean,true)}
   val affected=d.rawQuery("SELECT COUNT(*) FROM cases WHERE medicine=? COLLATE NOCASE",arrayOf(old.name)).use{c->c.moveToFirst();c.getInt(0)}
   val other=medicineCatalog().filter{!it.name.equals(old.name,true)&&!it.name.equals(target?.name.orEmpty(),true)}
   val collision=other.firstOrNull{MedicineNameMatcher.key(it.name)==MedicineNameMatcher.key(newClean)||it.aliases.split(Regex("[;؛,،|\\n]+")).any{a->MedicineNameMatcher.key(a)==MedicineNameMatcher.key(newClean)}}
   require(collision==null) { "الاسم الجديد مستخدم بالفعل مع دواء آخر: ${collision?.name}. لا يمكن دمجه تلقائياً." }
   val mergedName=target?.name ?: newClean
   if(target!=null){
    val oldGeneric=MedicineNameMatcher.key(old.genericName);val targetGeneric=MedicineNameMatcher.key(target.genericName)
    require(oldGeneric.isBlank()||targetGeneric.isBlank()||oldGeneric==targetGeneric) { "المادة الفعالة مختلفة بين الاسمين؛ أوقفنا الدمج لحماية السجلات." }
   }
   fun merge(a:String,b:String)=listOf(a.trim(),b.trim()).filter{it.isNotBlank()}.distinct().joinToString("\n")
   val aliasList=((target?.aliases.orEmpty().split(Regex("[;؛,،|\\n]+")))+old.name+old.aliases.split(Regex("[;؛,،|\\n]+"))).map{it.trim()}.filter{it.isNotBlank()&& !it.equals(mergedName,true)}.distinctBy{MedicineNameMatcher.key(it)}
   val strengths=(splitStrengths(target?.strengths.orEmpty())+splitStrengths(old.strengths)).distinctBy{MedicineStrengthNormalizer.key(it)}
   val values=ContentValues().apply{
    put("name",mergedName);put("generic_name",if(target?.genericName.isNullOrBlank())old.genericName else target!!.genericName)
    put("specialty",merge(target?.specialty.orEmpty(),old.specialty));put("strengths",strengths.joinToString("; "))
    put("dosage_form",merge(target?.dosageForm.orEmpty(),old.dosageForm));put("review_status",if(target?.reviewStatus.isNullOrBlank()||target?.reviewStatus?.contains("يحتاج مراجعة")==true) old.reviewStatus else target!!.reviewStatus)
    put("indications",merge(target?.indications.orEmpty(),old.indications));put("critical_classification",merge(target?.criticalClassification.orEmpty(),old.criticalClassification));put("target_conditions",merge(target?.targetConditions.orEmpty(),old.targetConditions));put("medical_notes",merge(target?.medicalNotes.orEmpty(),old.medicalNotes));put("source_reference",merge(target?.sourceReference.orEmpty(),old.sourceReference));put("last_reviewed",listOf(target?.lastReviewed.orEmpty(),old.lastReviewed).filter{it.isNotBlank()}.maxOrNull().orEmpty());put("aliases",aliasList.joinToString("; "))
   }
   if(target==null){d.update("medicines",values,"name=? COLLATE NOCASE",arrayOf(old.name))}
   else {d.update("medicines",values,"name=? COLLATE NOCASE",arrayOf(target.name));d.delete("medicines","name=? COLLATE NOCASE",arrayOf(old.name))}
   d.execSQL("UPDATE cases SET medicine=? WHERE medicine=? COLLATE NOCASE",arrayOf(mergedName,old.name))
   val strengthRows=mutableListOf<String>();d.rawQuery("SELECT strength FROM strengths WHERE medicine=? COLLATE NOCASE",arrayOf(old.name)).use{c->while(c.moveToNext())strengthRows+=c.getString(0).orEmpty()}
   (strengths+strengthRows).distinctBy{MedicineStrengthNormalizer.key(it)}.forEach{st->val sv=ContentValues().apply{put("medicine",mergedName);put("strength",st)};d.insertWithOnConflict("strengths",null,sv,SQLiteDatabase.CONFLICT_IGNORE)}
   d.delete("strengths","medicine=? COLLATE NOCASE",arrayOf(old.name))
   val history=ContentValues().apply{put("old_name",old.name);put("new_name",mergedName);put("affected_cases",affected);put("reason",reason)};d.insertOrThrow("medicine_name_history",null,history)
   val log=ContentValues().apply{put("action","اعتماد تصحيح اسم دواء");put("item_key","${old.name} ← $mergedName | السجلات المتأثرة: $affected | $reason")};d.insert("audit_log",null,log)
   d.setTransactionSuccessful();return affected
  }finally{d.endTransaction()}
 }
 fun medicineNameHistoryReport():List<String>{
  val out=mutableListOf<String>();readableDatabase.rawQuery("SELECT old_name,new_name,affected_cases,reason,approved_at FROM medicine_name_history ORDER BY id DESC",null).use{c->while(c.moveToNext())out+="${c.getString(0)} ← ${c.getString(1)} | سجلات العاملين المتأثرة: ${c.getInt(2)} | ${c.getString(3)} | ${c.getString(4)}"};return out
 }

 fun updateMedicineClinicalDetails(record:MedicineCatalogRecord):Boolean {
  require(hasActivePermission("manage_medicines")){"تعديل قاموس الأدوية يتطلب صلاحية إدارة الأدوية."}
  if(record.name.isBlank())return false
  val otherCatalog=medicineCatalog().filter{!it.name.equals(record.name,true)}
  val proposedAliases=record.aliases.split(Regex("[;؛,،|\\n]+")).map{it.trim()}.filter{it.isNotBlank()}
  proposedAliases.forEach{alias->
   val key=MedicineNameMatcher.key(alias)
   val conflict=otherCatalog.firstOrNull{other->MedicineNameMatcher.key(other.name)==key||other.aliases.split(Regex("[;؛,،|\\n]+")).any{MedicineNameMatcher.key(it)==key}}
   require(conflict==null){"الاسم البديل «$alias» مستخدم بالفعل مع الدواء ${conflict?.name}؛ لم يتم الحفظ."}
  }
  val v=ContentValues().apply{put("generic_name",record.genericName);put("specialty",record.specialty);put("strengths",MedicineStrengthNormalizer.unique(splitStrengths(record.strengths)).joinToString("; "));put("dosage_form",record.dosageForm);put("review_status",record.reviewStatus);put("indications",record.indications);put("critical_classification",record.criticalClassification);put("target_conditions",record.targetConditions);put("medical_notes",record.medicalNotes);put("source_reference",record.sourceReference);put("last_reviewed",record.lastReviewed);put("aliases",proposedAliases.distinctBy{MedicineNameMatcher.key(it)}.joinToString("; "))}
  val d=writableDatabase;d.beginTransaction()
  try{
   val updated=d.update("medicines",v,"name=? COLLATE NOCASE",arrayOf(record.name.trim()))>0
   if(updated){
    d.delete("strengths","medicine=? COLLATE NOCASE",arrayOf(record.name.trim()))
    splitStrengths(record.strengths).forEach{st->val sv=ContentValues().apply{put("medicine",record.name.trim());put("strength",st)};d.insertWithOnConflict("strengths",null,sv,SQLiteDatabase.CONFLICT_IGNORE)}
   }
   d.setTransactionSuccessful();return updated
  }finally{d.endTransaction()}
 }
 private fun mergeText(first:String,second:String):String = listOf(first.trim(),second.trim()).filter{it.isNotBlank()}.distinct().joinToString("\n")
 private fun splitStrengths(value:String):List<String> = value.split(Regex("[;؛,،|\\n]+")).map{it.trim()}.filter{it.isNotBlank() && !it.contains("يُستكمل") && !it.contains("يستكمل")}.distinctBy{MedicineStrengthNormalizer.key(it)}
 private fun syncLegacyStrengths(){
  val d=writableDatabase
  d.beginTransaction()
  try{
   d.rawQuery("SELECT name,strengths FROM medicines",null).use{c->while(c.moveToNext()){
    val medicine=c.getString(0).orEmpty();splitStrengths(c.getString(1).orEmpty()).forEach{strength->
     val v=ContentValues().apply{put("medicine",medicine);put("strength",strength)}
     d.insertWithOnConflict("strengths",null,v,SQLiteDatabase.CONFLICT_IGNORE)
    }
   }}
   d.setTransactionSuccessful()
  }finally{d.endTransaction()}
 }
 private fun reconcileStrengthDuplicates(){
  val d=writableDatabase;d.beginTransaction()
  try{
   val grouped=mutableMapOf<String,MutableList<String>>()
   d.rawQuery("SELECT medicine,strength FROM strengths ORDER BY id",null).use{c->while(c.moveToNext()){
    val med=c.getString(0).orEmpty();val st=c.getString(1).orEmpty();grouped.getOrPut(med){mutableListOf()}+=st
   }}
   grouped.forEach{(med,values)->
    val unique=MedicineStrengthNormalizer.unique(values)
    d.delete("strengths","medicine=? COLLATE NOCASE",arrayOf(med))
    unique.forEach{st->val v=ContentValues().apply{put("medicine",med);put("strength",st)};d.insertWithOnConflict("strengths",null,v,SQLiteDatabase.CONFLICT_IGNORE)}
    d.update("medicines",ContentValues().apply{put("strengths",unique.joinToString("; "))},"name=? COLLATE NOCASE",arrayOf(med))
   }
   d.setTransactionSuccessful()
  }finally{d.endTransaction()}
 }
 fun strengthsForMedicine(medicine:String):List<String>{
  val out=linkedSetOf<String>()
  readableDatabase.rawQuery("SELECT strength FROM strengths WHERE medicine=? COLLATE NOCASE ORDER BY strength",arrayOf(canonicalMedicineName(medicine))).use{c->while(c.moveToNext())out+=c.getString(0).orEmpty()}
  if(out.isEmpty())readableDatabase.rawQuery("SELECT strengths FROM medicines WHERE name=? COLLATE NOCASE LIMIT 1",arrayOf(canonicalMedicineName(medicine))).use{c->if(c.moveToFirst())out+=splitStrengths(c.getString(0).orEmpty())}
  return out.toList()
 }
 fun addStrength(medicine:String,strength:String):Boolean{
  val med=canonicalMedicineName(medicine);val st=strength.trim();if(med.isBlank()||st.isBlank())return false
  val alreadyKnown=strengthsForMedicine(med).any{MedicineStrengthNormalizer.key(it)==MedicineStrengthNormalizer.key(st)}
  if(alreadyKnown)return false
  if(!hasActivePermission("manage_medicines"))return false
  val d=writableDatabase;d.beginTransaction()
  try{
   upsertMedicine(med)
   val currentStrengths=strengthsForMedicine(med)
   if(currentStrengths.any{MedicineStrengthNormalizer.key(it)==MedicineStrengthNormalizer.key(st)}){d.setTransactionSuccessful();return false}
   val values=ContentValues().apply{put("medicine",med);put("strength",st)}
   val inserted=d.insertWithOnConflict("strengths",null,values,SQLiteDatabase.CONFLICT_IGNORE)>0
   val current=d.rawQuery("SELECT strengths FROM medicines WHERE name=? COLLATE NOCASE LIMIT 1",arrayOf(med)).use{c->if(c.moveToFirst())c.getString(0).orEmpty() else ""}
   val all=MedicineStrengthNormalizer.unique(splitStrengths(current)+st)
   val update=ContentValues().apply{put("strengths",all.joinToString("; "))}
   d.update("medicines",update,"name=? COLLATE NOCASE",arrayOf(med))
   d.setTransactionSuccessful();return inserted
  }finally{d.endTransaction()}
 }
 fun removeStrength(medicine:String,strength:String):Boolean {
  require(hasActivePermission("manage_medicines")){"حذف عيار يتطلب صلاحية إدارة الأدوية."}
  val med=canonicalMedicineName(medicine);val d=writableDatabase;d.beginTransaction()
  try {
   val removed=d.delete("strengths","medicine=? COLLATE NOCASE AND strength=?",arrayOf(med,strength))>0
   val remaining=strengthsForMedicine(med)
   val values=ContentValues().apply{put("strengths",remaining.joinToString("; "))}
   d.update("medicines",values,"name=? COLLATE NOCASE",arrayOf(med))
   d.setTransactionSuccessful();return removed
  }finally{d.endTransaction()}
 }
 fun renameStrength(medicine:String,oldStrength:String,newStrength:String):Boolean {
  val med=canonicalMedicineName(medicine);val next=newStrength.trim()
  if(med.isBlank()||next.isBlank())return false
  val current=strengthsForMedicine(med)
  if(current.none{it==oldStrength})return false
  if(current.any{it!=oldStrength && MedicineStrengthNormalizer.key(it)==MedicineStrengthNormalizer.key(next)})return false
  val d=writableDatabase;d.beginTransaction()
  try {
   d.delete("strengths","medicine=? COLLATE NOCASE AND strength=?",arrayOf(med,oldStrength))
   val values=ContentValues().apply{put("medicine",med);put("strength",next)}
   d.insertOrThrow("strengths",null,values)
   val all=strengthsForMedicine(med)
   d.update("medicines",ContentValues().apply{put("strengths",all.joinToString("; "))},"name=? COLLATE NOCASE",arrayOf(med))
   d.setTransactionSuccessful();return true
  }finally{d.endTransaction()}
 }
 fun medicineCatalogReviewReport():List<String> {
  val catalog=medicineCatalog();val lines=mutableListOf<String>()
  val missingClinical=catalog.filter{it.indications.isBlank()}
  val unresolved=catalog.filter{it.reviewStatus.contains("غير محسوم")||it.genericName.isBlank()||it.genericName.contains("يُستكمل")}
  val unitless=catalog.flatMap{m->splitStrengths(m.strengths).filter{MedicineStrengthNormalizer.isUnitlessNumber(it)}.map{"${m.name}: «$it» بلا وحدة"}}
  val duplicateStrengths=catalog.flatMap{m->
   val vals=strengthsForMedicine(m.name);vals.groupBy{MedicineStrengthNormalizer.key(it)}.values.filter{it.size>1}.map{"${m.name}: ${it.joinToString(" / ")}"}
  }
  lines += "إجمالي الأدوية: ${catalog.size}"
  lines += "أدوية لها دواعي استعمال مسجلة: ${catalog.count{it.indications.isNotBlank()}}"
  lines += "أدوية لم تكتمل دواعي استعمالها: ${missingClinical.size}"
  if(missingClinical.isNotEmpty()) lines += "قائمة الأدوية التي تحتاج استكمالاً: ${missingClinical.joinToString("، "){it.name}}"
  lines += "أسماء/مواد فعالة تحتاج تأكيداً: ${unresolved.size}"
  if(unresolved.isNotEmpty()) lines += "تحتاج تأكيداً وصورة عبوة أو اسم شركة/مادة فعالة: ${unresolved.joinToString("، "){it.name}}"
  lines += "تصحيحات أسماء موثقة: CINRYSE ← CINRYZE؛ Xelganz ← XELJANZ؛ X-GEVA ← XGEVA"
  lines += "الأسماء المتشابهة غير المحسومة لم تُدمج تلقائياً حفاظاً على هوية الدواء."
  val sameActiveIngredient=catalog.filter{it.genericName.isNotBlank()&&!it.genericName.contains("يُستكمل")}.groupBy{it.genericName.trim().lowercase()}.filterValues{it.size>1}
  if(sameActiveIngredient.isNotEmpty()){
   lines += "علامات تجارية مختلفة تشترك في المادة الفعالة (تبقى منفصلة لاختلاف المنتج/التركيز/الشكل):"
   sameActiveIngredient.forEach{(generic,items)->lines += "$generic: ${items.joinToString("، "){it.name}}"}
  }
  if(unitless.isNotEmpty()) { lines += "عيارات رقمية بلا وحدة (تحتاج صورة العبوة):"; lines += unitless }
  if(duplicateStrengths.isNotEmpty()) { lines += "عيارات متكررة بصيغ كتابة مختلفة:"; lines += duplicateStrengths }
  val aliasCollisions=mutableListOf<String>()
  val aliasOwners=mutableMapOf<String,String>()
  catalog.forEach{m->m.aliases.split(Regex("[;؛,،|\\n]+")).map{it.trim()}.filter{it.isNotBlank()}.forEach{a->
   val k=MedicineNameMatcher.key(a);val prior=aliasOwners.putIfAbsent(k,m.name);if(prior!=null&&prior!=m.name)aliasCollisions+="$a: $prior / ${m.name}"
  }}
  if(aliasCollisions.isNotEmpty()){lines += "مرادفات متعارضة تحتاج مراجعة:";lines += aliasCollisions}
  return lines
 }
 fun addMedicine(n:String,generic:String="",strengths:String="",form:String=""):Boolean {
  require(hasActivePermission("manage_medicines")){"إضافة دواء تتطلب صلاحية إدارة الأدوية."}
  val clean=n.trim().replace(Regex("\\s+")," ");if(clean.isBlank())return false
  val match=medicineNameMatch(clean);if(match.type==MedicineNameMatchType.SUGGESTION||match.type==MedicineNameMatchType.NORMALIZED)return false
  val v=ContentValues().apply{put("name",clean);put("generic_name",generic.trim());put("strengths",strengths.trim());put("dosage_form",form.trim());put("review_status","مضاف يدوياً — يحتاج مراجعة")}
  val d=writableDatabase;d.beginTransaction()
  try{
   val inserted=d.insertWithOnConflict("medicines",null,v,SQLiteDatabase.CONFLICT_IGNORE)>0
   if(inserted)splitStrengths(strengths).forEach{st->val sv=ContentValues().apply{put("medicine",clean);put("strength",st)};d.insertWithOnConflict("strengths",null,sv,SQLiteDatabase.CONFLICT_IGNORE)}
   d.setTransactionSuccessful();return inserted
  }finally{d.endTransaction()}
 }
 private fun caseSignature(r:CaseRecord):String = CaseDataRules.signature(r)
 fun caseImportIssues(rows:List<CaseRecord>):List<String> = CaseDataRules.validate(rows)
 private fun existingCaseSignatures(d:SQLiteDatabase):MutableSet<String> {
  val signatures=mutableSetOf<String>()
  d.rawQuery("SELECT * FROM cases",null).use{c->while(c.moveToNext())signatures+=caseSignature(c.toRecord())}
  return signatures
 }
 fun duplicateCount(rows:List<CaseRecord>):Int {
  val known=existingCaseSignatures(readableDatabase)
  var duplicates=0
  rows.forEach{r->val n=CaseDataRules.normalizeForImport(r);val canonical=n.copy(medicine=canonicalMedicineName(n.medicine));if(!known.add(caseSignature(canonical)))duplicates++}
  return duplicates
 }
 fun importRows(rows:List<CaseRecord>):Pair<Int,Int>{
  require(hasActivePermission("import_excel")&&hasActivePermission("add_edit")){"استيراد الحالات يتطلب صلاحية استيراد Excel وصلاحية الإضافة والتعديل."}
  val canManageCatalog=hasActivePermission("manage_medicines")
  if(!canManageCatalog){
   val needsCatalogChange=rows.any{row->val match=medicineNameMatch(row.medicine);match.type==MedicineNameMatchType.NEW||(row.strength.isNotBlank()&&strengthsForMedicine(canonicalMedicineName(row.medicine)).none{MedicineStrengthNormalizer.key(it)==MedicineStrengthNormalizer.key(row.strength)})}
   require(!needsCatalogChange){"يحتوي الملف على دواء أو عيار غير مسجل؛ يلزم مدير الأدوية لمراجعته قبل الاستيراد."}
  }
  val issues=caseImportIssues(rows)+medicineNameReviewIssues(rows)
  require(issues.isEmpty()) { issues.take(10).joinToString("\n") }
  var added=0;var duplicates=0;val d=writableDatabase
  d.beginTransaction()
  try {
   val known=existingCaseSignatures(d)
   rows.forEach { source ->
    val normalized=CaseDataRules.normalizeForImport(source)
    val r=normalized.copy(medicine=canonicalMedicineName(normalized.medicine))
    if(!known.add(caseSignature(r))) duplicates++
    else {
     save(r.copy(id=0));upsertMedicine(r.medicine)
     if(r.strength.isNotBlank()) {
      if(strengthsForMedicine(r.medicine).none{MedicineStrengthNormalizer.key(it)==MedicineStrengthNormalizer.key(r.strength)}){
       val strengthValues=ContentValues().apply{put("medicine",r.medicine);put("strength",r.strength)}
       d.insertWithOnConflict("strengths",null,strengthValues,SQLiteDatabase.CONFLICT_IGNORE)
       val current=d.rawQuery("SELECT strengths FROM medicines WHERE name=? COLLATE NOCASE LIMIT 1",arrayOf(r.medicine)).use{c->if(c.moveToFirst())c.getString(0).orEmpty() else ""}
       val merged=MedicineStrengthNormalizer.unique(splitStrengths(current)+r.strength)
       d.update("medicines",ContentValues().apply{put("strengths",merged.joinToString("; "))},"name=? COLLATE NOCASE",arrayOf(r.medicine))
      }
     }
     added++
    }
   }
   val log=ContentValues().apply{put("action","استيراد قالب الحالات الحرجة");put("item_key","إضافة $added؛ تكرارات مطابقة $duplicates")}
   d.insert("audit_log",null,log)
   d.setTransactionSuccessful()
  }finally{d.endTransaction()}
  return added to duplicates
 }
 fun employeeCount():Int=readableDatabase.rawQuery("SELECT COUNT(*) FROM employees",null).use{it.moveToFirst();it.getInt(0)}
 fun employees(q:String=""):List<EmployeeRecord>{
  val out=mutableListOf<EmployeeRecord>();val like="%$q%"
  readableDatabase.rawQuery("SELECT * FROM employees WHERE (?='' OR performance_no LIKE ? OR name LIKE ?) ORDER BY name",arrayOf(q,like,like)).use{c->while(c.moveToNext()){
   val birth=c.getString(c.getColumnIndexOrThrow("birth_date")).orEmpty();val age=employeeAge(birth)
   out+=EmployeeRecord(c.getLong(c.getColumnIndexOrThrow("id")),c.getString(c.getColumnIndexOrThrow("performance_no")),c.getString(c.getColumnIndexOrThrow("name")).orEmpty(),c.getString(c.getColumnIndexOrThrow("job")).orEmpty(),c.getString(c.getColumnIndexOrThrow("entity")).orEmpty(),c.getString(c.getColumnIndexOrThrow("department")).orEmpty(),c.getString(c.getColumnIndexOrThrow("national_id")).orEmpty(),c.getString(c.getColumnIndexOrThrow("phone1")).orEmpty(),c.getString(c.getColumnIndexOrThrow("phone2")).orEmpty(),c.getString(c.getColumnIndexOrThrow("gender")).orEmpty(),c.getString(c.getColumnIndexOrThrow("notes")).orEmpty(),birth,age,if(age!=null&&age>=60)"بلغ 60 سنة (معلومة عمرية فقط)" else "")
  }};return out
 }
 fun findEmployee(performanceNo:String):EmployeeRecord?=employees(normalizePerformanceNo(performanceNo)).firstOrNull{normalizePerformanceNo(it.performanceNo)==normalizePerformanceNo(performanceNo)}
 fun planEmployeeImport(rows:List<EmployeeRecord>):EmployeeImportPlan{
  val inserts=mutableListOf<EmployeeRecord>();val updates=mutableListOf<EmployeeRecord>();val issues=mutableListOf<EmployeeImportIssue>();val changes=mutableListOf<EmployeeImportChange>();val seen=mutableSetOf<String>();var unchanged=0
  rows.forEachIndexed{index,r->
   val key=normalizePerformanceNo(r.performanceNo);val rowNo=r.sourceRow.takeIf{it>0}?:index+5
   if(key.isBlank()){issues+=EmployeeImportIssue(rowNo,key,"رقم الأداء إلزامي");return@forEachIndexed}
   if(!seen.add(key)){issues+=EmployeeImportIssue(rowNo,r.performanceNo,"رقم الأداء مكرر داخل ملف الاستيراد");return@forEachIndexed}
   if(r.name.isBlank()&&findEmployee(key)==null){issues+=EmployeeImportIssue(rowNo,key,"اسم العامل مطلوب للسجل الجديد");return@forEachIndexed}
   if(r.nationalId.isNotBlank()&&!validNationalId(r.nationalId)){issues+=EmployeeImportIssue(rowNo,key,"رقم البطاقة يجب أن يتكون من 14 رقماً صالحاً");return@forEachIndexed}
   val derivedGender=genderFromNationalId(r.nationalId);if(r.gender.isNotBlank()&&derivedGender!=null&&normalizeGender(r.gender)!=derivedGender){issues+=EmployeeImportIssue(rowNo,key,"النوع المدخل لا يتفق مع النوع المستخرج من رقم البطاقة");return@forEachIndexed}
   val existing=findEmployee(key)
   if(existing==null) inserts+=r else {
    val merged=mergeEmployee(existing,r)
    if(merged.cells()!=existing.cells()){
     updates+=merged
     val labels=EmployeeRecord.headers
     val oldCells=existing.cells();val newCells=merged.cells()
     val fieldChanges=labels.indices.mapNotNull{i->if(oldCells[i]!=newCells[i])EmployeeFieldChange(labels[i],oldCells[i],newCells[i])else null}
     changes+=EmployeeImportChange(existing.performanceNo,existing.name,fieldChanges)
    } else unchanged++
   }
  }
  return EmployeeImportPlan(inserts,updates,unchanged,issues,changes)
 }
 fun commitEmployeeImport(plan:EmployeeImportPlan):Pair<Int,Int>{
  require(hasActivePermission("import_excel")&&hasActivePermission("add_edit")){"استيراد دليل العاملين يتطلب صلاحية استيراد Excel وصلاحية الإضافة والتعديل."}
  require(plan.canCommit){"لا يمكن اعتماد ملف يحتوي على أخطاء"}
  val d=writableDatabase;d.beginTransaction();try{
   plan.inserts.forEach{upsertEmployee(d,it,false)}
   plan.updates.forEach{upsertEmployee(d,it,true)}
   val log=ContentValues().apply{put("action","استيراد دليل العاملين");put("item_key","إضافة ${plan.inserts.size} وتحديث ${plan.updates.size}")};d.insert("audit_log",null,log)
   d.setTransactionSuccessful()
  }finally{d.endTransaction()}
  return plan.inserts.size to plan.updates.size
 }
 fun saveEmployee(r:EmployeeRecord){require(hasActivePermission("add_edit")){"حفظ بيانات العاملين يتطلب صلاحية الإضافة والتعديل."};require(normalizePerformanceNo(r.performanceNo).isNotBlank());require(r.name.isNotBlank());require(r.nationalId.isBlank()||validNationalId(r.nationalId));val d=writableDatabase;upsertEmployee(d,r,findEmployee(r.performanceNo)!=null,preserveBlankFields=false)}
 private fun upsertEmployee(d:SQLiteDatabase,r:EmployeeRecord,update:Boolean,preserveBlankFields:Boolean=true){
  val existing=if(update) findEmployee(r.performanceNo) else null
  val m=if(existing!=null&&preserveBlankFields)mergeEmployee(existing,r) else if(existing!=null)r.copy(id=existing.id) else r
  val cleanNationalId=normalizeDigits(m.nationalId)
  val birth=if(cleanNationalId.isNotBlank())birthDateFromNationalId(cleanNationalId)?:"" else ""
  val inferredGender=genderFromNationalId(cleanNationalId)?:m.gender
  val v=ContentValues().apply{put("performance_no",normalizePerformanceNo(m.performanceNo));put("name",m.name);put("job",m.job);put("entity",m.entity);put("department",m.department);put("national_id",cleanNationalId);put("phone1",m.phone1);put("phone2",m.phone2);put("gender",inferredGender);put("notes",m.notes);put("birth_date",birth);put("updated_at",java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss",java.util.Locale.US).format(java.util.Date()))}
  if(existing==null)d.insertOrThrow("employees",null,v) else d.update("employees",v,"performance_no=?",arrayOf(normalizePerformanceNo(m.performanceNo)))
 }
 private fun mergeEmployee(old:EmployeeRecord,new:EmployeeRecord)=old.copy(name=new.name.ifBlank{old.name},job=new.job.ifBlank{old.job},entity=new.entity.ifBlank{old.entity},department=new.department.ifBlank{old.department},nationalId=new.nationalId.ifBlank{old.nationalId},phone1=new.phone1.ifBlank{old.phone1},phone2=new.phone2.ifBlank{old.phone2},gender=new.gender.ifBlank{old.gender},notes=new.notes.ifBlank{old.notes})
 private fun normalizePerformanceNo(value:String):String=value.trim().filterNot{it.isWhitespace()}.map{ch->when(ch){in '٠'..'٩'->'0'+(ch-'٠');in '۰'..'۹'->'0'+(ch-'۰');else->ch}}.joinToString("")
 private fun normalizeDigits(value:String):String=value.map{ch->when(ch){in '٠'..'٩'->'0'+(ch-'٠');in '۰'..'۹'->'0'+(ch-'۰');else->ch}}.joinToString("")
 private fun normalizeGender(value:String):String=when(value.trim()){"ذكر","رجل","Male","male"->"ذكر";"أنثى","انثى","امرأة","Female","female"->"أنثى";else->value.trim()}
 private fun genderFromNationalId(value:String):String?{val id=normalizeDigits(value);if(id.length!=14)return null;val serial=id[12].digitToIntOrNull()?:return null;return if(serial%2==1)"ذكر" else "أنثى"}
 private fun validNationalId(id:String):Boolean{val clean=normalizeDigits(id);if(!clean.matches(Regex("[0-9]{14}")))return false;return birthDateFromNationalId(clean)!=null}
 private fun birthDateFromNationalId(id:String):String? {
  if(id.length!=14)return null
  val century=when(id[0]){'2'->1900;'3'->2000;else->return null}
  return try{
   val year=century+id.substring(1,3).toInt();val month=id.substring(3,5).toInt();val day=id.substring(5,7).toInt()
   val cal=java.util.GregorianCalendar(year,month-1,day)
   if(cal.get(java.util.Calendar.YEAR)!=year||cal.get(java.util.Calendar.MONTH)!=month-1||cal.get(java.util.Calendar.DAY_OF_MONTH)!=day)null
   else java.text.SimpleDateFormat("yyyy-MM-dd",java.util.Locale.US).format(cal.time)
  }catch(_:Exception){null}
 }
 private fun employeeAge(birth:String):Int? {
  return try {
   val d=java.text.SimpleDateFormat("yyyy-MM-dd",java.util.Locale.US).parse(birth) ?: return null
   val born=java.util.Calendar.getInstance().apply{time=d}
   val now=java.util.Calendar.getInstance()
   var age=now.get(java.util.Calendar.YEAR)-born.get(java.util.Calendar.YEAR)
   val beforeBirthday=now.get(java.util.Calendar.MONTH)<born.get(java.util.Calendar.MONTH) ||
    (now.get(java.util.Calendar.MONTH)==born.get(java.util.Calendar.MONTH) && now.get(java.util.Calendar.DAY_OF_MONTH)<born.get(java.util.Calendar.DAY_OF_MONTH))
   if(beforeBirthday) age--
   age
  } catch(_:Exception){null}
 }


 /** Complete preflight shared by the preview screen and the final restore transaction. */
 fun restoreBundleIssues(bundle:BackupBundle):List<String>{
  val permissionIssues=mutableListOf<String>()
  if(!hasActivePermission("import_excel"))permissionIssues+="استعادة النسخة تتطلب صلاحية استيراد Excel."
  if(!hasActivePermission("add_edit"))permissionIssues+="استعادة الحالات والعاملين تتطلب صلاحية الإضافة والتعديل."
  if(!hasActivePermission("manage_medicines"))permissionIssues+="استعادة قاموس الأدوية والعيارات تتطلب صلاحية إدارة الأدوية."
  val catalogNameIssues=(bundle.medicineDetails.map{it.name}+bundle.medicines).mapNotNull{medicineName->
   val match=medicineNameMatch(medicineName)
   if(match.type==MedicineNameMatchType.SUGGESTION)"اسم دواء في القاموس «${medicineName}» قريب من «${match.canonicalName}»؛ راجع الاسم والعبوة قبل الاستعادة." else null
  }
  val employeeIssues=planEmployeeImport(bundle.employees).issues.map{"بيانات العامل ${it.performanceNo}: ${it.message}"}
  return (permissionIssues+CaseDataRules.validate(bundle.cases)+medicineNameReviewIssues(bundle.cases)+catalogNameIssues+employeeIssues).distinct()
 }

 fun restoreBundle(bundle:BackupBundle):Triple<Int,Int,Int>{
  require(hasActivePermission("import_excel")&&hasActivePermission("add_edit")&&hasActivePermission("manage_medicines")){"استعادة النسخة تتطلب صلاحيات الاستيراد والإضافة والتعديل وإدارة الأدوية."}
  val preflightIssues=restoreBundleIssues(bundle)
  require(preflightIssues.isEmpty()){"النسخة تحتوي على مشكلات تمنع الاستعادة؛ لم يتم اعتماد أي بيانات. أول مشكلة: ${preflightIssues.firstOrNull().orEmpty()}"}
  val employeePlan=planEmployeeImport(bundle.employees)
  var casesAdded=0;var employeesAdded=0;var employeesUpdated=0;var medicinesAdded=0
  val d=writableDatabase;d.beginTransaction()
  try{
   val knownCaseSignatures=existingCaseSignatures(d)
   bundle.cases.forEach{source->
    // A worker may legitimately have multiple records for the same medicine.
    // Only an identical normalized full record is skipped.
    val normalized=CaseDataRules.normalizeForImport(source)
    val r=normalized.copy(medicine=canonicalMedicineName(normalized.medicine))
    if(knownCaseSignatures.add(caseSignature(r))){
     save(r.copy(id=0));if(r.medicine.isNotBlank())upsertMedicine(r.medicine)
     if(r.medicine.isNotBlank()&&r.strength.isNotBlank()){
      if(strengthsForMedicine(r.medicine).none{MedicineStrengthNormalizer.key(it)==MedicineStrengthNormalizer.key(r.strength)}){
       val strengthValues=ContentValues().apply{put("medicine",r.medicine);put("strength",r.strength)}
       d.insertWithOnConflict("strengths",null,strengthValues,SQLiteDatabase.CONFLICT_IGNORE)
       val current=d.rawQuery("SELECT strengths FROM medicines WHERE name=? COLLATE NOCASE LIMIT 1",arrayOf(r.medicine)).use{c->if(c.moveToFirst())c.getString(0).orEmpty() else ""}
       val merged=MedicineStrengthNormalizer.unique(splitStrengths(current)+r.strength)
       d.update("medicines",ContentValues().apply{put("strengths",merged.joinToString("; "))},"name=? COLLATE NOCASE",arrayOf(r.medicine))
      }
     }
     casesAdded++
    }
   }
   employeePlan.inserts.forEach{upsertEmployee(d,it,false)}
   employeePlan.updates.forEach{upsertEmployee(d,it,true)}
   employeesAdded=employeePlan.inserts.size;employeesUpdated=employeePlan.updates.size
   bundle.medicines.forEach{n->if(n.isNotBlank()){val canonical=canonicalMedicineName(n);val before=readableDatabase.rawQuery("SELECT 1 FROM medicines WHERE name=? COLLATE NOCASE LIMIT 1",arrayOf(canonical)).use{it.moveToFirst()};upsertMedicine(n);if(!before)medicinesAdded++}}
   // Merge catalog rows without REPLACE: REPLACE deletes the old row first and
   // can discard local metadata/row identity. Incoming non-empty fields update
   // existing values; blank incoming fields never erase local information.
   bundle.medicineDetails.forEach{m->
    val rawName=m.name.trim().replace(Regex("\\s+")," ")
    val name=canonicalMedicineName(rawName)
    if(name.isNotBlank()){
     val existing=d.rawQuery("SELECT generic_name,specialty,strengths,dosage_form,review_status,indications,critical_classification,target_conditions,medical_notes,source_reference,last_reviewed,aliases FROM medicines WHERE name=? COLLATE NOCASE LIMIT 1",arrayOf(name)).use{c->
      if(c.moveToFirst()) (0..11).map{c.getString(it).orEmpty()} else null
     }
     val values=ContentValues().apply{
      put("name",name)
      put("generic_name",m.genericName.ifBlank{existing?.get(0).orEmpty()})
      put("specialty",m.specialty.ifBlank{existing?.get(1).orEmpty()})
      put("strengths",m.strengths.ifBlank{existing?.get(2).orEmpty()})
      put("dosage_form",m.dosageForm.ifBlank{existing?.get(3).orEmpty()})
      put("review_status",m.reviewStatus.ifBlank{existing?.get(4).orEmpty().ifBlank{"يحتاج مراجعة"}})
      put("indications",m.indications.ifBlank{existing?.get(5).orEmpty()})
      put("critical_classification",m.criticalClassification.ifBlank{existing?.get(6).orEmpty()})
      put("target_conditions",m.targetConditions.ifBlank{existing?.get(7).orEmpty()})
      put("medical_notes",m.medicalNotes.ifBlank{existing?.get(8).orEmpty()})
      put("source_reference",m.sourceReference.ifBlank{existing?.get(9).orEmpty()})
      put("last_reviewed",m.lastReviewed.ifBlank{existing?.get(10).orEmpty()})
      put("aliases",m.aliases.ifBlank{existing?.get(11).orEmpty()})
     }
     if(existing==null)d.insertOrThrow("medicines",null,values)
     else d.update("medicines",values,"name=? COLLATE NOCASE",arrayOf(name))
    }
   }
   bundle.strengths.forEach{st->if(st.medicine.isNotBlank()&&st.strength.isNotBlank()){
    val values=ContentValues().apply{put("medicine",canonicalMedicineName(st.medicine));put("strength",st.strength.trim())}
    d.insertWithOnConflict("strengths",null,values,SQLiteDatabase.CONFLICT_IGNORE)
   }}
   val log=ContentValues().apply{put("action","استعادة نسخة شاملة");put("item_key","حالات $casesAdded؛ عاملون +$employeesAdded / تحديث $employeesUpdated؛ أدوية +$medicinesAdded؛ عيارات ${bundle.strengths.size}")};d.insert("audit_log",null,log)
   d.setTransactionSuccessful()
  }finally{d.endTransaction()}
  return Triple(casesAdded,employeesAdded,employeesUpdated)
 }

 fun alerts():List<String>{
  val a=mutableListOf<String>();val d=readableDatabase
  fun n(sql:String)=d.rawQuery(sql,null).use{it.moveToFirst();it.getInt(0)}
  val missing=n("SELECT COUNT(*) FROM cases WHERE name='' OR performance_no='' OR medicine=''")
  val noApproval=n("SELECT COUNT(*) FROM cases WHERE approval_date=''")
  // Multiple medicines/treatment rows for one worker are valid; alert only when
  // one performance number is associated with more than one distinct name.
  val dup=n("SELECT COUNT(*) FROM (SELECT performance_no FROM cases WHERE trim(performance_no)<>'' GROUP BY trim(performance_no) HAVING COUNT(DISTINCT lower(trim(name)))>1)")
  val unknown=n("SELECT COUNT(*) FROM cases c LEFT JOIN medicines m ON c.medicine=m.name COLLATE NOCASE WHERE trim(c.medicine)<>'' AND m.id IS NULL")
  val recordedMedicineNames=mutableListOf<String>()
  d.rawQuery("SELECT DISTINCT medicine FROM cases WHERE trim(medicine)<>''",null).use{c->while(c.moveToNext())recordedMedicineNames+=c.getString(0).orEmpty()}
  recordedMedicineNames.forEach{name->val match=medicineNameMatch(name);if(match.type==MedicineNameMatchType.SUGGESTION)a+="اسم الدواء «$name» قريب من «${match.canonicalName}»؛ راجع السجلات لتوحيد الاسم."}
  val expired=n("SELECT COUNT(*) FROM cases WHERE approval_expiry<>'' AND date(approval_expiry) < date('now')")
  val soon=n("SELECT COUNT(*) FROM cases WHERE approval_expiry<>'' AND date(approval_expiry) BETWEEN date('now') AND date('now','+30 day')")
  if(missing>0)a+="بيانات أساسية ناقصة في $missing سجل"
  if(noApproval>0)a+="تاريخ موافقة غير مسجل في $noApproval سجل"
  if(dup>0)a+="أرقام أداء مكررة: $dup"
  if(unknown>0)a+="أدوية غير موجودة بالقاموس: $unknown"
  if(expired>0)a+="موافقات منتهية حسب تاريخ الانتهاء: $expired"
  if(soon>0)a+="موافقات ستنتهي خلال 30 يومًا: $soon"
  return a
 }
 fun log(a:String,k:String){val v=ContentValues().apply{put("action",a);put("item_key",k)};writableDatabase.insert("audit_log",null,v)}
}
