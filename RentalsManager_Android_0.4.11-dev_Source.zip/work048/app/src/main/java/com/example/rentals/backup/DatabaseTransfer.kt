package com.example.rentals.backup

import android.content.Context
import android.net.Uri
import android.database.sqlite.SQLiteDatabase
import com.example.rentals.data.RentalsDb
import java.io.File

/** Raw SQLite database transfer. Import validates integrity and the expected app schema before replacing live data. */
object DatabaseTransfer {
    fun export(context: Context, destination: Uri) {
        val db = context.getDatabasePath("rentals_local.db")
        RentalsDb.get(context).closeForBackup()
        try {
            require(db.exists() && db.length() > 0L) { "قاعدة البيانات غير موجودة" }
            context.contentResolver.openOutputStream(destination, "w")!!.use { out -> db.inputStream().use { it.copyTo(out) } }
        } finally { RentalsDb.reopen(context) }
    }

    fun import(context: Context, source: Uri) {
        val candidate = File(context.cacheDir, "incoming-rentals.db")
        val live = context.getDatabasePath("rentals_local.db")
        val rollback = File(context.cacheDir, "rentals-before-import.db")
        candidate.delete(); rollback.delete()
        context.contentResolver.openInputStream(source)!!.use { input -> candidate.outputStream().use { input.copyTo(it) } }
        require(candidate.length() > 0L) { "الملف فارغ" }
        val check = SQLiteDatabase.openDatabase(candidate.absolutePath, null, SQLiteDatabase.OPEN_READONLY)
        try {
            val integrity = check.rawQuery("PRAGMA integrity_check", null).use { if (it.moveToFirst()) it.getString(0) else "" }
            require(integrity == "ok") { "قاعدة البيانات غير سليمة: $integrity" }
            val required = setOf("units", "receipts", "ledger", "heirs", "expenses")
            val found = mutableSetOf<String>()
            check.rawQuery("SELECT name FROM sqlite_master WHERE type='table'", null).use { c -> while (c.moveToNext()) found += c.getString(0) }
            require(found.containsAll(required)) { "هذا الملف ليس قاعدة بيانات نظام إدارة الإيجارات أو أنه يفتقد جداول أساسية" }
        } finally { check.close() }
        RentalsDb.get(context).closeForBackup()
        try {
            if (live.exists()) live.copyTo(rollback, true)
            File(live.path + "-wal").delete(); File(live.path + "-shm").delete()
            candidate.copyTo(live, true)
        } catch (e: Exception) {
            if (rollback.exists()) rollback.copyTo(live, true)
            throw e
        } finally {
            RentalsDb.reopen(context)
            candidate.delete(); rollback.delete()
        }
    }
}
