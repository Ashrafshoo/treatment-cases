package com.example.rentals.domain.entities

import com.example.rentals.data.PropertyRecord
import com.example.rentals.data.TenantRecord

class GetEntityDirectory(private val repository: EntityRepository) {
    operator fun invoke() = EntityDirectorySnapshot(
        properties = repository.getProperties(),
        tenants = repository.getTenants()
    )
}

class SaveProperty(private val repository: EntityRepository) {
    operator fun invoke(item: PropertyRecord): Long {
        require(item.name.isNotBlank()) { "اسم العقار مطلوب" }
        return repository.saveProperty(item.copy(name = item.name.trim()))
    }
}

class SaveTenant(private val repository: EntityRepository) {
    operator fun invoke(item: TenantRecord): Long {
        require(item.name.isNotBlank()) { "اسم المستأجر مطلوب" }
        return repository.saveTenant(item.copy(name = item.name.trim()))
    }
}

class DeleteProperty(private val repository: EntityRepository) {
    operator fun invoke(id: Long) { require(id > 0); repository.deleteProperty(id) }
}

class DeleteTenant(private val repository: EntityRepository) {
    operator fun invoke(id: Long) { require(id > 0); repository.deleteTenant(id) }
}
