package com.example.rentals.domain.contracts


/** A single consistent read model for the contracts/archive screen. */
data class ContractArchiveSnapshot(
    val leases: List<ContractLease>,
    val attachments: List<ContractAttachment>,
    val reminders: List<String>
)

class GetContractArchive(private val repository: ContractRepository) {
    operator fun invoke() = ContractArchiveSnapshot(
        leases = repository.getLeases(),
        attachments = repository.getAttachments(),
        reminders = repository.getReminders()
    )
}

class SaveContract(private val repository: ContractRepository) {
    operator fun invoke(id: Long, unitId: Long, start: String, end: String, rent: Double?, status: String, notes: String) =
        repository.saveLease(id, unitId, start, end, rent, status, notes)
}

class DeleteContract(private val repository: ContractRepository) {
    operator fun invoke(id: Long) = repository.deleteLease(id)
}

class AddContractAttachment(private val repository: ContractRepository) {
    operator fun invoke(ownerType: String, ownerId: String, uri: String, name: String, mime: String) =
        repository.addAttachment(ownerType, ownerId, uri, name, mime)
}

class RemoveContractAttachment(private val repository: ContractRepository) {
    operator fun invoke(id: Long) = repository.deleteAttachment(id)
}
