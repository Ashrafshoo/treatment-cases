import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCHEMA = ROOT / 'app' / 'assets' / 'database' / '001_initial_schema.sql'


def database():
    db = sqlite3.connect(':memory:')
    db.execute('PRAGMA foreign_keys=ON')
    for statement in SCHEMA.read_text(encoding='utf-8').split(';'):
        if statement.strip():
            db.execute(statement)
    db.execute("INSERT INTO properties(id,name) VALUES('p','عقار')")
    db.execute("INSERT INTO units(id,property_id,unit_number,unit_type) VALUES('u','p','1','سكني')")
    return db


def test_unit_documents_keep_multiple_versions_and_notes():
    db = database()
    columns = {row[1] for row in db.execute('PRAGMA table_info(documents)')}
    assert {'notes', 'version_group_id', 'version_number', 'supersedes_document_id', 'document_date'} <= columns
    db.execute("INSERT INTO documents(id,entity_type,entity_id,title,relative_path,version_group_id,version_number,notes) VALUES('d1','unit','u','عقد الإيجار','property_archive/a.pdf','g1',1,'الإصدار الأصلي')")
    db.execute("INSERT INTO documents(id,entity_type,entity_id,title,relative_path,version_group_id,version_number,supersedes_document_id,notes) VALUES('d2','unit','u','عقد الإيجار','property_archive/b.pdf','g1',2,'d1','تجديد العقد')")
    rows = db.execute("SELECT version_number,supersedes_document_id,notes FROM documents WHERE entity_id='u' ORDER BY version_number").fetchall()
    assert rows == [(1, None, 'الإصدار الأصلي'), (2, 'd1', 'تجديد العقد')]
    db.close()


def test_dashboard_cards_open_their_corresponding_details():
    dashboard = (ROOT / 'app/lib/features/dashboard/presentation/dashboard_screen.dart').read_text()
    records = (ROOT / 'app/lib/features/records/presentation/records_screen.dart').read_text()
    assert "onTap:()=>_openRecords(initialTab:1)" in dashboard
    assert "onTap:()=>_openRecords(initialTab:2)" in dashboard
    assert "onTap:_openPayments" in dashboard and "onTap:_openExpenses" in dashboard
    assert 'ArchiveReviewScreen(' in records and "entityType: 'unit'" in records


def test_document_version_migration_is_registered_for_existing_databases():
    source = (ROOT / 'app/lib/core/database/app_database.dart').read_text()
    repository = (ROOT / 'app/lib/features/archive_review/data/archive_review_repository.dart').read_text()
    assert 'version: 5' in source and 'if (oldVersion < 5) await _applyStage11Documents(database);' in source
    assert "'supersedes_document_id': prior.isEmpty ? null : prior.first['id']" in repository
    assert "'version_number': version" in repository


if __name__ == '__main__':
    test_unit_documents_keep_multiple_versions_and_notes()
    test_dashboard_cards_open_their_corresponding_details()
    test_document_version_migration_is_registered_for_existing_databases()
    print('Stage 11 tests: 3/3 passed')
