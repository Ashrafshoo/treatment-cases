package com.treatmentcases.app

fun main() {
    var checks = 0
    fun expect(value: Boolean, label: String) { check(value) { "FAILED: $label" }; checks++ }
    expect(MedicineStrengthNormalizer.key("5mg") == MedicineStrengthNormalizer.key("5 mg"), "space variation is normalized")
    expect(MedicineStrengthNormalizer.key("500 IU") == MedicineStrengthNormalizer.key("500iu"), "IU spacing is normalized")
    expect(MedicineStrengthNormalizer.key("0.5 mg") == MedicineStrengthNormalizer.key("0,5mg"), "decimal separator variation is normalized")
    expect(MedicineStrengthNormalizer.key("100 μg") == MedicineStrengthNormalizer.key("100 mcg"), "microgram notation is normalized")
    expect(MedicineStrengthNormalizer.key("1 mg/mL") != MedicineStrengthNormalizer.key("1 mg"), "concentration and amount remain distinct")
    expect(MedicineStrengthNormalizer.key("1 mg") != MedicineStrengthNormalizer.key("1000 mcg"), "unit conversion is not inferred")
    expect(MedicineStrengthNormalizer.unique(listOf("5mg", "5 mg", "10 mg")) == listOf("5mg", "10 mg"), "duplicate strength display variants collapse")
    expect(MedicineStrengthNormalizer.isUnitlessNumber("120"), "unitless strength is flagged")
    expect(!MedicineStrengthNormalizer.isUnitlessNumber("120 mg"), "qualified strength is not flagged")
    println("PASS: $checks medicine-strength normalization assertions")
}
