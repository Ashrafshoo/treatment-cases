-- Phase 7: import review and explicit medicine-name aliases.
-- Additive only; does not rewrite historical treatment names or records.
CREATE TABLE IF NOT EXISTS Medicine_Name_Aliases (
  alias_id INTEGER PRIMARY KEY AUTOINCREMENT,
  raw_alias TEXT NOT NULL UNIQUE COLLATE NOCASE,
  medicine_id INTEGER NOT NULL REFERENCES Medicine_Dictionary(medicine_id),
  created_by TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS Medicine_Review_Queue (
  review_id INTEGER PRIMARY KEY AUTOINCREMENT,
  batch_id INTEGER NOT NULL,
  medicine_name_raw TEXT NOT NULL,
  first_seen_row INTEGER,
  review_status TEXT NOT NULL DEFAULT 'PENDING',
  review_note TEXT,
  UNIQUE(batch_id, medicine_name_raw)
);
