package com.medref.drugs

import android.app.Activity
import android.content.Context
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.LayerDrawable
import android.util.TypedValue
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import com.google.android.material.card.MaterialCardView
import com.google.android.material.color.DynamicColors
import com.google.android.material.color.MaterialColors
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.io.File

/** يعرض الحوار ثم يطبّق عليه الخط وحجم النص المختارين. */
fun MaterialAlertDialogBuilder.showStyled(): AlertDialog {
    val d = create()
    d.show()
    Ui.style(d.window?.decorView)
    return d
}

object Ui {

    class Accent(val id: String, val label: String, val light: Int, val dark: Int)

    val accents = listOf(
        Accent("teal", "أخضر مزرق", 0xFF176B5F.toInt(), 0xFF4DB6A8.toInt()),
        Accent("blue", "أزرق", 0xFF1565C0.toInt(), 0xFF8AB4F8.toInt()),
        Accent("indigo", "نيلي", 0xFF3949AB.toInt(), 0xFF9FA8DA.toInt()),
        Accent("purple", "بنفسجي", 0xFF7B1FA2.toInt(), 0xFFCE93D8.toInt()),
        Accent("pink", "وردي", 0xFFC2185B.toInt(), 0xFFF48FB1.toInt()),
        Accent("red", "أحمر", 0xFFC62828.toInt(), 0xFFEF9A9A.toInt()),
        Accent("orange", "برتقالي", 0xFFE65100.toInt(), 0xFFFFB74D.toInt()),
        Accent("green", "أخضر", 0xFF2E7D32.toInt(), 0xFF81C784.toInt()),
        Accent("brown", "بني", 0xFF6D4C41.toInt(), 0xFFBCAAA4.toInt()),
        Accent("slate", "رمادي مزرق", 0xFF455A64.toInt(), 0xFF90A4AE.toInt())
    )

    private fun accentStyle(id: String): Int = when (id) {
        "blue" -> R.style.Accent_blue
        "indigo" -> R.style.Accent_indigo
        "purple" -> R.style.Accent_purple
        "pink" -> R.style.Accent_pink
        "red" -> R.style.Accent_red
        "orange" -> R.style.Accent_orange
        "green" -> R.style.Accent_green
        "brown" -> R.style.Accent_brown
        "slate" -> R.style.Accent_slate
        else -> R.style.Accent_teal
    }

    fun isNight(ctx: Context): Boolean =
        (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    fun primary(ctx: Context): Int =
        MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorPrimary, 0xFF176B5F.toInt())

    /** يُستدعى قبل super.onCreate(). */
    fun applyTheme(a: Activity) {
        if (Prefs.accent == "dynamic" && DynamicColors.isDynamicColorAvailable()) {
            DynamicColors.applyToActivityIfAvailable(a)
        } else {
            val id = if (Prefs.accent == "dynamic") "teal" else Prefs.accent
            a.theme.applyStyle(accentStyle(id), true)
        }
    }

    // ---------- الخلفية ----------
    fun applyBackground(a: Activity) {
        val night = isNight(a)
        fun pick(l: Long, d: Long): Drawable = ColorDrawable((if (night) d else l).toInt())
        val d: Drawable = when (Prefs.background) {
            "white" -> pick(0xFFFFFFFF, 0xFF000000)
            "cream" -> pick(0xFFFFF8E7, 0xFF1F1B13)
            "gray" -> pick(0xFFF1F3F4, 0xFF1A1C1E)
            "blue" -> pick(0xFFEAF2FB, 0xFF0F1923)
            "green" -> pick(0xFFEAF6EE, 0xFF0F1A14)
            "image" -> imageBackground(a, night) ?: defaultBg(a, night)
            else -> defaultBg(a, night)
        }
        a.window.setBackgroundDrawable(d)
    }

    private fun defaultBg(a: Activity, night: Boolean): Drawable =
        ColorDrawable(MaterialColors.getColor(a, android.R.attr.colorBackground, if (night) Color.BLACK else Color.WHITE))

    private fun imageBackground(a: Activity, night: Boolean): Drawable? {
        val f = File(a.filesDir, "bg.jpg")
        if (!f.exists()) return null
        val bmp = BitmapFactory.decodeFile(f.path) ?: return null
        val dm = a.resources.displayMetrics
        val cover = cover(bmp, dm.widthPixels, dm.heightPixels)
        val base = if (night) 0 else 255
        val dim = ColorDrawable(Color.argb(255 * Prefs.bgDim / 100, base, base, base))
        return LayerDrawable(arrayOf(BitmapDrawable(a.resources, cover), dim))
    }

    private fun cover(src: Bitmap, w: Int, h: Int): Bitmap {
        val scale = maxOf(w.toFloat() / src.width, h.toFloat() / src.height)
        val sw = (src.width * scale).toInt().coerceAtLeast(w)
        val sh = (src.height * scale).toInt().coerceAtLeast(h)
        val scaled = Bitmap.createScaledBitmap(src, sw, sh, true)
        val x = ((sw - w) / 2).coerceAtLeast(0)
        val y = ((sh - h) / 2).coerceAtLeast(0)
        return Bitmap.createBitmap(scaled, x, y, w, h)
    }

    // ---------- الخطوط ----------
    private var cachedId = ""
    private var cachedTf: Typeface? = null

    /** (المعرّف، الاسم) — الخطوط المضافة في assets/fonts تظهر هنا تلقائيًا. */
    fun fontChoices(ctx: Context): List<Pair<String, String>> {
        val out = arrayListOf(
            "system" to "افتراضي (النظام)",
            "fam:sans-serif" to "Sans",
            "fam:sans-serif-light" to "Sans خفيف",
            "fam:sans-serif-medium" to "Sans متوسط",
            "fam:serif" to "Serif",
            "fam:monospace" to "Monospace",
            "fam:casual" to "Casual",
            "fam:cursive" to "Cursive"
        )
        try {
            ctx.assets.list("fonts")?.sorted()?.forEach { n ->
                val l = n.lowercase()
                if (l.endsWith(".ttf") || l.endsWith(".otf") || l.endsWith(".ttc")) {
                    out += "asset:fonts/$n" to n.substringBeforeLast('.').replace('-', ' ').replace('_', ' ')
                }
            }
        } catch (e: Exception) { /* لا خطوط إضافية */ }
        return out
    }

    private fun typeface(ctx: Context): Typeface? {
        val id = Prefs.font
        if (id == "system") return null
        if (id == cachedId) return cachedTf
        val tf: Typeface? = try {
            when {
                id.startsWith("fam:") -> Typeface.create(id.removePrefix("fam:"), Typeface.NORMAL)
                id.startsWith("asset:") -> Typeface.createFromAsset(ctx.assets, id.removePrefix("asset:"))
                else -> null
            }
        } catch (e: Exception) { null }
        cachedId = id
        cachedTf = tf
        return tf
    }

    /** يطبّق الخط وحجم النص على كل النصوص داخل الشجرة (آمن للتكرار). */
    fun style(root: View?) {
        if (root == null) return
        walk(root, typeface(root.context), Prefs.textScale / 100f)
    }

    private fun walk(v: View, tf: Typeface?, scale: Float) {
        if (v is TextView) {
            if (v.getTag(R.id.tag_base_size) == null) {
                v.setTag(R.id.tag_base_size, v.textSize)
                v.setTag(R.id.tag_base_tf, v.typeface)
            }
            val base = v.getTag(R.id.tag_base_size) as Float
            v.setTextSize(TypedValue.COMPLEX_UNIT_PX, base * scale)
            val orig = v.getTag(R.id.tag_base_tf) as? Typeface
            if (tf != null) {
                v.setTypeface(tf, orig?.style ?: Typeface.NORMAL)
            } else if (orig != null) {
                v.typeface = orig
            }
        }
        if (v is ViewGroup) for (i in 0 until v.childCount) walk(v.getChildAt(i), tf, scale)
    }

    // ---------- البطاقات ----------
    fun styleCard(c: MaterialCardView) {
        val d = c.resources.displayMetrics.density
        c.radius = Prefs.cardRadius * d
        val ctx = c.context
        when (Prefs.cardStyle) {
            "elevated" -> {
                c.strokeWidth = 0
                c.cardElevation = 4 * d
                c.setCardBackgroundColor(MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorSurface, Color.WHITE))
            }
            "flat" -> {
                c.strokeWidth = 0
                c.cardElevation = 0f
                c.setCardBackgroundColor(MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorSurfaceVariant, 0x22808080))
            }
            else -> {
                c.strokeWidth = (1 * d).toInt().coerceAtLeast(1)
                c.cardElevation = 0f
                c.strokeColor = MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorOutlineVariant, 0x33808080)
                c.setCardBackgroundColor(MaterialColors.getColor(ctx, com.google.android.material.R.attr.colorSurface, Color.WHITE))
            }
        }
    }
}
