#!/usr/bin/env python3
"""Ensure every distinct positive monthly template amount is covered by a runtime Kotlin harness."""
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
catalog = json.loads((ROOT / 'app/src/main/assets/receipt_templates/receipt_template_catalog_v1.json').read_text(encoding='utf-8'))
harness = (ROOT / 'verification/VbaMonitizeCatalogHarness.kt').read_text(encoding='utf-8')
values = sorted({float(t['amount_source']) for t in catalog['templates'] if t.get('monthlyEligible', True) and t.get('amount_source') is not None and float(t['amount_source']) > 0})
assert len(values) == 45
assert 'VbaMonitize.amountWords(value)' in harness
assert 'values.size' in harness and 'unique positive monthly template amounts' in harness
print('PASS: all 45 distinct positive monthly template source amounts are included in the Kotlin runtime harness')
