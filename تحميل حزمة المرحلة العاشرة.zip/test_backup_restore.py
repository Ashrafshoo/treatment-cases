import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import backup_restore as br

class BackupRestoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.med = self.root / 'private' / 'med.db'
        self.auth = self.root / 'private' / 'auth.db'
        self.backups = self.root / 'backups'
        for path, table, value in [(self.med, 'people', 'old-med'), (self.auth, 'users', 'old-auth')]:
            path.parent.mkdir(parents=True, exist_ok=True)
            with sqlite3.connect(path) as c:
                c.execute(f'CREATE TABLE {table}(value TEXT)')
                c.execute(f'INSERT INTO {table} VALUES(?)', (value,))
        self.patches = [
            patch.object(br, 'MED_DB', self.med),
            patch.object(br, 'AUTH_DB', self.auth),
            patch.object(br, 'BACKUP_DIR', self.backups),
        ]
        for p in self.patches: p.start()

    def tearDown(self):
        for p in reversed(self.patches): p.stop()
        self.tmp.cleanup()

    def test_backup_contains_both_databases_and_manifest(self):
        result = br.create_backup()
        self.assertEqual(set(result['files']), {'medication', 'authentication'})
        manifest = json.loads(Path(result['manifest']).read_text())
        self.assertEqual(set(manifest['files']), {'medication', 'authentication'})
        for info in manifest['files'].values():
            self.assertTrue((self.backups / info['name']).exists())

    def test_restore_reverts_both_databases_and_makes_safety_backup(self):
        original = br.create_backup()['timestamp']
        with sqlite3.connect(self.med) as c: c.execute("UPDATE people SET value='new-med'")
        with sqlite3.connect(self.auth) as c: c.execute("UPDATE users SET value='new-auth'")
        result = br.restore(original)
        self.assertNotEqual(result['safety_backup'], original)
        with sqlite3.connect(self.med) as c: self.assertEqual(c.execute('SELECT value FROM people').fetchone()[0], 'old-med')
        with sqlite3.connect(self.auth) as c: self.assertEqual(c.execute('SELECT value FROM users').fetchone()[0], 'old-auth')

    def test_tampered_backup_is_rejected(self):
        result = br.create_backup()
        med_file = self.backups / result['files']['medication']['name']
        med_file.write_bytes(med_file.read_bytes() + b'tamper')
        with self.assertRaises(ValueError): br.verify_manifest(result['timestamp'])

    def test_corrupt_database_is_rejected(self):
        self.med.write_bytes(b'not sqlite')
        with self.assertRaises(Exception): br.create_backup()

if __name__ == '__main__': unittest.main()
