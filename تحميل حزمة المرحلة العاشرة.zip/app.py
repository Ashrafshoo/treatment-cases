#!/usr/bin/env python3
"""واجهة ويب محلية للقراءة فقط لمشروع علاج الحالات حاجة (Python stdlib)."""
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs, quote
from pathlib import Path
import sqlite3, json, html, os, mimetypes, tempfile
from http.cookies import SimpleCookie
from urllib.parse import urlencode
from email.parser import BytesParser
from email.policy import default as email_policy
import security
from export_center import beneficiary_profile, export_excel, export_pdf
import analytics_center

BASE=Path(__file__).resolve().parent
DB=Path(os.environ.get('MED_DB', BASE/'medication_management_development_v2.db')).resolve()
HOST=os.environ.get('MED_HOST','127.0.0.1'); PORT=int(os.environ.get('MED_PORT','8765'))
AUTH_DB=Path(os.environ.get('MED_AUTH_DB', BASE/'auth.sqlite3')).resolve()
security.initialize(AUTH_DB)
COOKIE_SECURE=os.environ.get('MED_COOKIE_SECURE','0')=='1'

def db():
    c=sqlite3.connect(f'file:{DB}?mode=ro',uri=True); c.row_factory=sqlite3.Row; c.execute('PRAGMA query_only=ON'); return c

def esc(x): return html.escape('' if x is None else str(x))

def dashboard():
    c=db()
    try:
        people=c.execute('select count(*) from Personnel').fetchone()[0]
        cases=c.execute('select count(*) from Beneficiaries').fetchone()[0]
        entries=c.execute('select count(*) from Treatment_Entries').fetchone()[0]
        try:
            meds=c.execute("""select coalesce(d.medicine_name,v.medicine_name_raw,'غير محدد') name,count(*) n
              from v_Treatment_Export v left join Medicine_Name_Aliases a on lower(trim(a.raw_alias))=lower(trim(v.medicine_name_raw))
              left join Medicine_Dictionary d on d.medicine_id=a.medicine_id
              group by coalesce(d.medicine_name,v.medicine_name_raw,'غير محدد') order by n desc,name collate nocase""").fetchall()
        except sqlite3.OperationalError:
            meds=c.execute("select coalesce(medicine_name_raw,'غير محدد') name,count(*) n from v_Treatment_Export group by coalesce(medicine_name_raw,'غير محدد') order by n desc,name collate nocase").fetchall()
        return {'people':people,'cases':cases,'entries':entries,'medicines':[dict(x) for x in meds]}
    finally:c.close()

def search_people(term):
    term=term.strip()
    if not term:return []
    c=db()
    try:
        rows=c.execute('''select p.performance_number,p.full_name,p.job_title,p.region,p.department,
          (select count(*) from Beneficiaries b join Treatment_Entries te on te.beneficiary_id=b.beneficiary_id where b.performance_number=p.performance_number) treatment_count
          from Personnel p where p.performance_number like ? or p.full_name like ? order by p.full_name limit 50''',(f'%{term}%',f'%{term}%')).fetchall()
        return [dict(r) for r in rows]
    finally:c.close()

CSS='''
:root{--navy:#123b4a;--teal:#167d82;--mint:#e7f3f1;--paper:#f5f8f8;--ink:#18313a;--muted:#6d8187;--line:#dce7e8;--white:#fff;--gold:#d9a441}*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink);font-family:Tahoma,Arial,sans-serif;direction:rtl}.shell{max-width:1240px;margin:auto;padding:22px}.top{display:flex;align-items:center;gap:14px;margin-bottom:24px}.logo{width:58px;height:58px;flex:none}.brand h1{font-size:23px;margin:0;color:var(--navy)}.brand p{margin:5px 0 0;color:var(--muted);font-size:13px}.status{margin-right:auto;background:#eaf4ed;color:#326a48;padding:8px 13px;border-radius:30px;font-size:12px}.hero{background:linear-gradient(120deg,#123b4a,#167d82);color:white;border-radius:22px;padding:26px 28px;margin-bottom:20px;box-shadow:0 10px 25px #123b4a18}.hero h2{margin:0 0 8px;font-size:23px}.hero p{margin:0;color:#e0f1ef;line-height:1.8}.stats{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin:18px 0 26px}.stat,.panel,.med{background:var(--white);border:1px solid var(--line);border-radius:17px;box-shadow:0 4px 14px #173c4a08}.stat{padding:18px}.stat span{color:var(--muted);font-size:13px}.stat strong{display:block;font-size:30px;color:var(--navy);margin-top:8px}.layout{display:grid;grid-template-columns:1.05fr 1.4fr;gap:18px}.panel{padding:20px}.panel h3{margin:0 0 15px;color:var(--navy);font-size:18px}.search{display:flex;gap:9px}.search input{min-width:0;flex:1;border:1px solid var(--line);border-radius:12px;padding:13px;font-size:15px;outline:none}.search input:focus{border-color:var(--teal);box-shadow:0 0 0 3px #167d8218}.search button,.action{border:0;background:var(--teal);color:white;border-radius:12px;padding:0 18px;font-weight:bold;cursor:pointer}.hint{color:var(--muted);font-size:12px;margin-top:10px}.results{margin-top:14px}.person{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:12px 0;border-top:1px solid var(--line)}.person b{display:block;font-size:14px}.person small{color:var(--muted);display:block;margin-top:5px}.person a,.med a{color:inherit;text-decoration:none}.pill{font-size:12px;color:var(--teal);background:var(--mint);padding:7px 10px;border-radius:20px;white-space:nowrap}.medgrid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}.med{padding:14px;min-width:0}.med a{display:block}.med b{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:var(--navy);font-size:14px}.med strong{display:block;color:var(--teal);font-size:24px;margin-top:10px}.med small{color:var(--muted)}.footer{margin-top:20px;color:var(--muted);font-size:12px;text-align:center}.profile{margin-top:18px}.fields{display:grid;grid-template-columns:repeat(2,1fr);gap:10px}.field{background:#f7fafa;border-radius:10px;padding:12px}.field small{display:block;color:var(--muted);margin-bottom:6px}.tablewrap{overflow:auto}table{border-collapse:collapse;width:100%;font-size:13px}th,td{padding:11px;border-bottom:1px solid var(--line);text-align:right;white-space:nowrap}th{color:var(--navy);background:#f1f7f7}.notice{background:#fff7e8;color:#76541a;padding:12px;border-radius:12px;font-size:12px;line-height:1.7;margin-top:14px}.back{display:inline-block;color:var(--teal);margin-bottom:12px;text-decoration:none}@media(max-width:800px){.shell{padding:14px}.layout{grid-template-columns:1fr}.medgrid{grid-template-columns:repeat(2,minmax(0,1fr))}.stats{gap:8px}.stat{padding:13px}.stat strong{font-size:24px}.status{display:none}}@media(max-width:420px){.brand h1{font-size:19px}.hero{padding:20px}.medgrid{grid-template-columns:1fr 1fr}.fields{grid-template-columns:1fr}.search button{padding:0 12px}}
'''

ICON='''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#123b4a"/><stop offset="1" stop-color="#16878a"/></linearGradient></defs><rect x="4" y="4" width="120" height="120" rx="29" fill="url(#g)"/><path d="M56 24h16v30h30v16H72v30H56V70H26V54h30z" fill="#fff"/><circle cx="91" cy="34" r="8" fill="#e3b85e"/><path d="M25 91c11-8 21-8 31 0s20 8 31 0" fill="none" stroke="#bce8df" stroke-width="5" stroke-linecap="round"/></svg>'''

def page(body,title='علاج الحالات حاجة'):
    return f'''<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#123b4a"><title>{esc(title)}</title><link rel="icon" href="/icon.svg" type="image/svg+xml"><style>{CSS}</style></head><body><main class="shell">{body}</main></body></html>'''

def header():
    return f'<header class="top"><img class="logo" src="/icon.svg" alt="شعار البرنامج"><div class="brand"><h1>علاج الحالات حاجة</h1><p>منظومة متابعة وإدارة الحالات والعلاجات الحرجة</p></div><span class="status">● جلسة محمية</span><a class="pill" href="/analytics">التقارير</a><a class="pill" href="/alerts">التنبيهات</a><a class="pill" href="/manage">الإدارة</a><a class="pill" href="/logout">خروج</a></header>'

def home(q='', medicine=''):
    d=dashboard(); found=search_people(q) if q else []
    selected=next((m for m in d['medicines'] if str(m['name']).casefold()==medicine.casefold()),None) if medicine else None
    result=''
    if q:
        result='<div class="results">'+( ''.join(f'''<div class="person"><div><b>{esc(x['full_name'])}</b><small>رقم الأداء: {esc(x['performance_number'])} · {esc(x['region'])} · {esc(x['department'])}</small></div><a class="pill" href="/person/{quote(str(x['performance_number']))}">فتح الملف ←</a></div>''' for x in found) if found else '<p class="hint">لا توجد نتائج مطابقة.</p>')+'</div>'
    meds=''.join(f'<div class="med"><a href="/?medicine={quote(str(x["name"]))}"><b>{esc(x["name"])}</b><strong>{x["n"]}</strong><small>سجل علاج</small></a></div>' for x in d['medicines'])
    selected_box=(f'<div class="notice"><b>الدواء المحدد: {esc(medicine)}</b> — عدد السجلات: {selected["n"] if selected else 0}<br><a href="/export.xlsx?medicine={quote(medicine)}">تصدير Excel</a> · <a href="/export.pdf?medicine={quote(medicine)}">تصدير PDF</a> · <a href="/">إلغاء التحديد</a></div>' if medicine else '')
    return page(header()+f'''<section class="hero"><h2>لوحة متابعة الحالات الحرجة</h2><p>نظرة سريعة على قاعدة البيانات، مع البحث الفوري برقم الأداء أو اسم المستفيد والوصول إلى ملفه الشخصي.</p></section><section class="stats"><div class="stat"><span>العاملون المسجلون</span><strong>{d['people']}</strong></div><div class="stat"><span>ملفات المستفيدين</span><strong>{d['cases']}</strong></div><div class="stat"><span>سجلات العلاجات الحالية</span><strong>{d['entries']}</strong></div></section><div class="layout"><section class="panel"><h3>البحث عن مستفيد</h3><form class="search" method="get" action="/"><input name="q" value="{esc(q)}" placeholder="رقم الأداء أو الاسم" autofocus><button>بحث</button></form><p class="hint">اكتب جزءاً من الاسم أو رقم الأداء لعرض النتائج.</p>{result}</section><section class="panel"><h3>الأدوية حسب عدد السجلات</h3><div class="medgrid">{meds or '<p>لا توجد بيانات.</p>'}</div>{selected_box}<div class="hint"><a href="/export.xlsx">تصدير كل العلاجات Excel</a> · <a href="/export.pdf">تصدير كل العلاجات PDF</a></div></section></div><div class="footer">التعديلات متاحة للحسابات المصرح لها فقط · جميع التغييرات تسجل في سجل التدقيق</div>''')

def person_page(perf):
    p=beneficiary_profile(DB,perf)
    if not p:
        c=sqlite3.connect(f'file:{DB}?mode=ro',uri=True); c.row_factory=sqlite3.Row
        try: row=c.execute('SELECT * FROM Personnel WHERE performance_number=?',(perf,)).fetchone()
        finally: c.close()
        if not row:return page(header()+'<section class="panel"><h3>لم يتم العثور على المستفيد</h3><a class="back" href="/">العودة للرئيسية</a></section>')
        x=dict(row)
        safe=[('رقم الأداء',x.get('performance_number')),('الاسم',x.get('full_name')),('الوظيفة',x.get('job_title')),('المنطقة',x.get('region')),('الإدارة',x.get('department')),('النوع',x.get('gender')),('تاريخ الميلاد',x.get('birth_date'))]
        fields=''.join(f'<div class="field"><small>{esc(k)}</small><b>{esc(v) or "—"}</b></div>' for k,v in safe)
        return page(header()+f'<section class="panel"><h3>ملف العامل</h3><div class="fields">{fields}</div><div class="notice">لا توجد علاجات مرتبطة بهذا العامل حتى الآن.</div><a class="pill" href="/person/edit/{quote(perf)}">تعديل البيانات</a> <a class="pill" href="/treatment/new?performance_number={quote(perf)}">إضافة علاج</a></section>','ملف العامل')
    x=p['person']; safe=[('رقم الأداء',x.get('performance_number')),('الاسم',x.get('full_name')),('الوظيفة',x.get('job_title')),('المنطقة',x.get('region')),('الإدارة',x.get('department')),('النوع',x.get('gender')),('تاريخ الميلاد',x.get('birth_date')),('العمر',x.get('age_years')),('الرقم القومي (مخفي)',x.get('national_id_masked'))]
    fields=''.join(f'<div class="field"><small>{esc(k)}</small><b>{esc(v) or "—"}</b></div>' for k,v in safe)
    rows=''.join(f'<tr><td>{esc(t.get("treatment_order"))}</td><td>{esc(t.get("medicine_name_raw"))}</td><td>{esc(t.get("strength_raw"))}</td></tr>' for t in p['current_treatments']) or '<tr><td colspan="3">لا توجد علاجات حالية مسجلة.</td></tr>'
    hist=''.join(f'<tr><td>{esc(t.get("medicine_name_raw"))}</td><td>{esc(t.get("strength_raw"))}</td><td>{esc(t.get("approval_date"))}</td><td>{esc(t.get("treatment_status"))}</td></tr>' for t in p['treatment_history']) or '<tr><td colspan="4">لا توجد سجلات أرشيفية.</td></tr>'
    return page(header()+f'''<a class="back" href="/">← العودة إلى لوحة التحكم</a><div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px"><a class="pill" href="/person/edit/{quote(str(x.get('performance_number') or perf))}">تعديل بيانات المستفيد</a><a class="pill" href="/treatment/new?performance_number={quote(str(x.get('performance_number') or perf))}">إضافة علاج</a></div><section class="panel"><h3>الملف الشخصي للمستفيد</h3><div class="fields">{fields}</div><div class="notice">حماية الخصوصية: لا تعرض هذه الشاشة رقم الهاتف أو الرقم القومي كاملاً. تُتاح التعديلات من خلال الصلاحيات المناسبة، مع تسجيلها في سجل التدقيق.</div></section><section class="panel profile"><h3>العلاجات الحالية</h3><div class="tablewrap"><table><thead><tr><th>الترتيب</th><th>العلاج</th><th>التركيز</th></tr></thead><tbody>{rows}</tbody></table></div></section><section class="panel profile"><h3>السجل التاريخي</h3><div class="tablewrap"><table><thead><tr><th>العلاج</th><th>التركيز</th><th>تاريخ الموافقة</th><th>الحالة</th></tr></thead><tbody>{hist}</tbody></table></div></section>''',f'ملف {x.get("full_name") or perf}')

def login_page(message=''):
    warning = f'<div class="notice">{esc(message)}</div>' if message else ''
    return page(header()+f'''<section class="panel" style="max-width:480px;margin:35px auto"><h3>تسجيل الدخول</h3>{warning}<form method="post" action="/login" style="display:grid;gap:12px"><label>اسم المستخدم<input name="username" required autocomplete="username" style="width:100%;padding:13px;border:1px solid #dce7e8;border-radius:10px"></label><label>كلمة المرور<input type="password" name="password" required autocomplete="current-password" style="width:100%;padding:13px;border:1px solid #dce7e8;border-radius:10px"></label><button class="action" style="padding:13px">دخول آمن</button></form><p class="hint">إذا كانت هذه أول مرة، أنشئ حساب المدير من سطر الأوامر وفق دليل GitHub والتشغيل.</p></section>''', 'تسجيل الدخول — علاج الحالات حاجة')

def request_user(handler):
    jar=SimpleCookie()
    try: jar.load(handler.headers.get('Cookie',''))
    except Exception: return None, None
    morsel=jar.get('med_session')
    token=morsel.value if morsel else None
    return security.validate_session(AUTH_DB,token), token

class Handler(BaseHTTPRequestHandler):
    def send(self,body,status=200,ctype='text/html; charset=utf-8'):
        data=body.encode('utf-8') if isinstance(body,str) else body
        self.send_response(status); self.send_header('Content-Type',ctype); self.send_header('Content-Length',str(len(data))); self.send_header('X-Content-Type-Options','nosniff'); self.send_header('Cache-Control','no-store'); self.end_headers(); self.wfile.write(data)
    def redirect(self, location, cookie=None):
        self.send_response(303)
        self.send_header('Location', location)
        self.send_header('Cache-Control', 'no-store')
        if cookie: self.send_header('Set-Cookie', cookie)
        self.end_headers()
    def send_download(self, data, filename, ctype):
        self.send_response(200)
        self.send_header('Content-Type',ctype)
        self.send_header('Content-Length',str(len(data)))
        self.send_header('Content-Disposition',"attachment; filename*=UTF-8''"+quote(filename))
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Cache-Control','no-store')
        self.end_headers(); self.wfile.write(data)

    def do_GET(self):
        u=urlparse(self.path); path=u.path; qs=parse_qs(u.query)
        user, token=request_user(self)
        try:
            if path=='/icon.svg': self.send(ICON,ctype='image/svg+xml; charset=utf-8'); return
            if path=='/health': self.send(json.dumps({'status':'ok'},ensure_ascii=False),200,'application/json; charset=utf-8'); return
            if path=='/login': self.send(login_page()); return
            if path=='/logout':
                security.revoke_session(AUTH_DB,token)
                self.redirect('/login','med_session=; Max-Age=0; Path=/; HttpOnly; SameSite=Strict')
                return
            if not user:
                self.redirect('/login')
                return
            if path=='/': self.send(home(qs.get('q',[''])[0],qs.get('medicine',[''])[0])); return
            if path=='/analytics':
                if not can(user,'view_search'): self.send('غير مصرح',403,'text/plain; charset=utf-8'); return
                self.send(analytics_page()); return
            if path=='/alerts':
                if not can(user,'view_search'): self.send('غير مصرح',403,'text/plain; charset=utf-8'); return
                self.send(alerts_page()); return
            if path=='/analytics.xlsx':
                if not can(user,'export_share'): self.send('ليس لديك صلاحية التصدير',403,'text/plain; charset=utf-8'); return
                fd,out=tempfile.mkstemp(suffix='.xlsx'); os.close(fd)
                try:
                    analytics_center.export_analytics_excel(DB,out)
                    data=Path(out).read_bytes()
                finally:
                    if os.path.exists(out): os.unlink(out)
                self.send_download(data,'تقرير_الإحصائيات_والتنبيهات.xlsx','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); return
            if path=='/manage': self.send(management_home(user,token)); return
            if path=='/imports':
                if not can(user,'import_excel'): self.send('غير مصرح',403,'text/plain; charset=utf-8'); return
                self.send(imports_page(token, can(user,'manage_medicines'))); return
            if path=='/imports/template':
                if not can(user,'import_excel'): self.send('غير مصرح',403,'text/plain; charset=utf-8'); return
                template=BASE/'templates'/'قالب_الاستيراد_الفارغ.xlsx'
                if not template.exists(): self.send('قالب الاستيراد غير متاح في هذه النسخة.',404,'text/plain; charset=utf-8'); return
                self.send_download(template.read_bytes(),'قالب_الاستيراد_الفارغ.xlsx','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'); return
            if path=='/medicine-review':
                if not can(user,'manage_medicines'): self.send('غير مصرح',403,'text/plain; charset=utf-8'); return
                self.send(medicine_review_page(token)); return
            if path.startswith('/imports/batch/'):
                if not can(user,'import_excel'): self.send('غير مصرح',403,'text/plain; charset=utf-8'); return
                try: batch_id=int(path.rsplit('/',1)[1])
                except ValueError: self.send('رقم دفعة غير صحيح',400,'text/plain; charset=utf-8'); return
                self.send(import_batch_page(batch_id,token)); return
            if path=='/person/new':
                if not can(user,'add_edit'): self.send('غير مصرح',403,'text/plain; charset=utf-8'); return
                self.send(person_form(token)); return
            if path.startswith('/person/edit/'):
                if not can(user,'add_edit'): self.send('غير مصرح',403,'text/plain; charset=utf-8'); return
                c=sqlite3.connect(f'file:{DB}?mode=ro',uri=True); c.row_factory=sqlite3.Row
                try: row=c.execute('SELECT * FROM Personnel WHERE performance_number=?',(path.split('/',3)[3],)).fetchone()
                finally: c.close()
                if not row: self.send('المستفيد غير موجود',404,'text/plain; charset=utf-8'); return
                self.send(person_form(token,dict(row),row['performance_number'])); return
            if path=='/treatment/new':
                if not can(user,'add_edit'): self.send('غير مصرح',403,'text/plain; charset=utf-8'); return
                self.send(treatment_form(token,qs.get('performance_number',[''])[0])); return
            if path=='/medicines':
                if not can(user,'manage_medicines'): self.send('غير مصرح',403,'text/plain; charset=utf-8'); return
                self.send(medicines_page(token)); return
            if path=='/users':
                if not can(user,'manage_users'): self.send('غير مصرح',403,'text/plain; charset=utf-8'); return
                self.send(users_page(token)); return
            if path=='/audit':
                if not can(user,'manage_users'): self.send('غير مصرح',403,'text/plain; charset=utf-8'); return
                c=sqlite3.connect(f'file:{DB}?mode=ro',uri=True); c.row_factory=sqlite3.Row
                try: logs=c.execute('SELECT entity_type,entity_key,action,actor,action_at FROM Data_Audit_Log ORDER BY audit_id DESC LIMIT 100').fetchall()
                finally: c.close()
                rows=''.join(f'<tr><td>{esc(r["action_at"])}</td><td>{esc(r["actor"])}</td><td>{esc(r["entity_type"])}</td><td>{esc(r["entity_key"])}</td><td>{esc(r["action"])}</td></tr>' for r in logs)
                self.send(page(header()+f'<section class="panel"><h3>سجل آخر 100 عملية</h3><div class="tablewrap"><table><thead><tr><th>التاريخ</th><th>المنفذ</th><th>نوع السجل</th><th>المفتاح</th><th>العملية</th></tr></thead><tbody>{rows or "<tr><td colspan=5>لا توجد عمليات مسجلة.</td></tr>"}</tbody></table></div></section>','سجل التدقيق')); return
            if path.startswith('/person/'):
                if not security.has_permission(user,'view_search'):
                    self.send('غير مصرح',403,'text/plain; charset=utf-8'); return
                self.send(person_page(path.split('/',2)[2])); return
            if path in ('/export.xlsx','/export.pdf'):
                if not security.has_permission(user,'export_share'):
                    self.send('ليس لديك صلاحية التصدير',403,'text/plain; charset=utf-8'); return
                med=qs.get('medicine',[]); include_archive=qs.get('archive',['0'])[0]=='1'
                suffix='.xlsx' if path.endswith('xlsx') else '.pdf'
                fd,out=tempfile.mkstemp(suffix=suffix); os.close(fd)
                try:
                    if suffix=='.xlsx': export_excel(DB,out,med or None,include_archive)
                    else: export_pdf(DB,out,med or None,include_archive)
                    data=Path(out).read_bytes()
                finally:
                    if os.path.exists(out): os.unlink(out)
                self.send(data,ctype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' if suffix=='.xlsx' else 'application/pdf'); return
            self.send('غير موجود',404)
        except Exception as e:
            self.send(page(header()+f'<section class="panel"><h3>تعذر عرض الصفحة</h3><p>{esc(e)}</p></section>'),500)
    def do_POST(self):
        u=urlparse(self.path)
        try:
            size=int(self.headers.get('Content-Length','0'))
            if size<0 or size>12*1024*1024:
                self.send('حجم الطلب يتجاوز الحد المسموح (10 ميجابايت للملف).',413,'text/plain; charset=utf-8'); return
            raw_bytes=self.rfile.read(size)
            content_type=self.headers.get('Content-Type','')
            uploads={}
            if content_type.lower().startswith('multipart/form-data'):
                form,uploads=parse_multipart(content_type,raw_bytes)
            else:
                raw=raw_bytes.decode('utf-8','replace')
                form={k:v[-1] for k,v in parse_qs(raw,keep_blank_values=True).items()}
            if u.path == '/login':
                user=security.authenticate(AUTH_DB,form.get('username',''),form.get('password',''))
                if not user:
                    self.send(login_page('اسم المستخدم أو كلمة المرور غير صحيحة.'),401); return
                token=security.create_session(AUTH_DB,user['user_id'])
                cookie=f'med_session={token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=28800'
                if COOKIE_SECURE: cookie += '; Secure'
                self.redirect('/',cookie); return
            user,token=request_user(self)
            if not user: self.send('انتهت الجلسة، سجل الدخول مجدداً.',401,'text/plain; charset=utf-8'); return
            if not hmac_compare(form.get('csrf',''),csrf_value(token)):
                self.send('طلب غير صالح (CSRF). أعد تحميل الصفحة وحاول مجدداً.',403,'text/plain; charset=utf-8'); return
            if u.path=='/medicine-alias':
                if not can(user,'manage_medicines'): self.send('غير مصرح',403,'text/plain; charset=utf-8'); return
                ensure_write_backup()
                canonical=management.save_medicine_alias(DB,form.get('alias',''),int(form.get('medicine_id','0')),user['username'])
                self.send(medicine_review_page(token,'تم ربط الاسم بالدواء المعتمد: '+canonical)); return
            if u.path=='/imports/upload':
                if not can(user,'import_excel'): self.send('غير مصرح',403,'text/plain; charset=utf-8'); return
                upload=uploads.get('workbook')
                if not upload or not upload['content']: raise ValueError('اختر ملف Excel أولاً.')
                filename=upload['filename']; suffix=Path(filename).suffix.lower()
                if suffix not in ('.xlsx','.xlsm'): raise ValueError('الامتداد المدعوم هو .xlsx أو .xlsm فقط؛ ملفات .xls القديمة تحتاج حفظها بصيغة حديثة أولاً.')
                if len(upload['content'])>10*1024*1024: self.send('حجم الملف أكبر من 10 ميجابايت.',413,'text/plain; charset=utf-8'); return
                import import_update_engine
                typ=form.get('import_type','personnel')
                mode=form.get('mode','PARTIAL_UPDATE') if typ=='cases' else 'PARTIAL_UPDATE'
                if typ not in ('personnel','cases'): raise ValueError('نوع الاستيراد غير صحيح.')
                ensure_write_backup()
                temp_path=None
                try:
                    with tempfile.NamedTemporaryFile(prefix='med_import_',suffix=suffix,delete=False) as tmp:
                        tmp.write(upload['content']); temp_path=tmp.name
                    if typ=='personnel': batch_id,summary=import_update_engine.preview_personnel(DB,temp_path,user['username'])
                    else: batch_id,summary=import_update_engine.preview_cases(DB,temp_path,mode,user['username'])
                finally:
                    if temp_path and os.path.exists(temp_path): os.unlink(temp_path)
                self.redirect(f'/imports/batch/{batch_id}'); return
            if u.path=='/imports/approve':
                if not can(user,'import_excel'): self.send('غير مصرح',403,'text/plain; charset=utf-8'); return
                batch_id=int(form.get('batch_id','0'))
                import import_update_engine
                ensure_write_backup()
                counts=import_update_engine.approve(DB,batch_id,user['username'],include_archive=form.get('include_archive')=='1')
                self.send(import_batch_page(batch_id,token,'تم اعتماد الدفعة. ملخص التطبيق: '+json.dumps(counts,ensure_ascii=False))); return
            if u.path=='/person/save':
                if not can(user,'add_edit'): self.send('غير مصرح',403,'text/plain; charset=utf-8'); return
                ensure_write_backup(); perf=management.save_person(DB,form,user['username'],form.get('original_number') or None)
                self.redirect('/person/'+quote(perf)); return
            if u.path=='/treatment/save':
                if not can(user,'add_edit'): self.send('غير مصرح',403,'text/plain; charset=utf-8'); return
                ensure_write_backup(); perf=management.add_treatment(DB,form,user['username'])
                self.redirect('/person/'+quote(perf)); return
            if u.path=='/medicine/save':
                if not can(user,'manage_medicines'): self.send('غير مصرح',403,'text/plain; charset=utf-8'); return
                ensure_write_backup(); management.save_medicine(DB,form.get('medicine_name'),form.get('active_ingredient',''),form.get('dosage_form',''),form.get('specialty',''),form.get('strengths',''),user['username'])
                self.redirect('/medicines'); return
            if u.path=='/users/create':
                if not can(user,'manage_users'): self.send('غير مصرح',403,'text/plain; charset=utf-8'); return
                security.create_user(AUTH_DB,form.get('username'),form.get('display_name'),form.get('password'),form.get('role','viewer'))
                self.redirect('/users'); return
            if u.path=='/user/toggle':
                if not can(user,'manage_users'): self.send('غير مصرح',403,'text/plain; charset=utf-8'); return
                management.set_user_active(AUTH_DB,int(form.get('user_id','0')),form.get('active')=='1',user['username'])
                self.redirect('/users'); return
            self.send('غير مسموح',405,'text/plain; charset=utf-8')
        except sqlite3.IntegrityError:
            self.send(page(header()+'<section class="panel"><h3>تعذر الحفظ</h3><p>يوجد رقم أداء أو اسم دواء أو تركيز مكرر. راجع البيانات وحاول مجدداً.</p><a href="/manage">العودة للإدارة</a></section>'),409)
        except Exception as e:
            self.send(page(header()+f'<section class="panel"><h3>تعذر تنفيذ العملية</h3><p>{esc(e)}</p><a href="/manage">العودة للإدارة</a></section>'),400)
    def log_message(self,*args): pass


# Phase 6 management views and helpers
import management
management.initialize(DB)
_BACKUP_CREATED=False

def ensure_write_backup():
    global _BACKUP_CREATED
    if not _BACKUP_CREATED:
        management.backup_once(DB)
        _BACKUP_CREATED=True

def csrf_value(token):
    import hashlib
    return hashlib.sha256(('csrf:'+str(token)).encode()).hexdigest()

def csrf_field(token):
    return f'<input type="hidden" name="csrf" value="{csrf_value(token)}">'

def hmac_compare(a,b):
    import hmac
    return hmac.compare_digest(str(a),str(b))

def can(user, permission):
    return security.has_permission(user, permission)

def management_home(user, token, message=''):
    links=[]
    if can(user,'add_edit'): links.append('<a class="pill" href="/person/new">إضافة مستفيد</a> <a class="pill" href="/treatment/new">إضافة علاج</a>')
    if can(user,'manage_medicines'): links.append('<a class="pill" href="/medicines">قاموس الأدوية</a> <a class="pill" href="/medicine-review">مراجعة أسماء الأدوية</a>')
    if can(user,'import_excel'): links.append('<a class="pill" href="/imports">مركز الاستيراد الذكي</a>')
    if can(user,'manage_users'): links.append('<a class="pill" href="/users">إدارة المستخدمين</a> <a class="pill" href="/audit">سجل التدقيق</a>')
    note=f'<div class="notice">{esc(message)}</div>' if message else ''
    return page(header()+f'<section class="hero"><h2>مركز الإدارة</h2><p>إدارة البيانات والأدوية والمستخدمين وفق الصلاحيات الممنوحة لحسابك.</p></section><section class="panel">{note}<div style="display:flex;gap:10px;flex-wrap:wrap">{"".join(links) or "لا توجد صلاحيات إدارية مخصصة لهذا الحساب."}</div><p class="hint"><a href="/">العودة للوحة التحكم</a></p></section>','مركز الإدارة')

def person_form(token, person=None, original=''):
    p=person or {}
    fields=[('performance_number','رقم الأداء'),('full_name','الاسم'),('job_title','الوظيفة'),('region','المنطقة'),('department','الإدارة'),('mobile1','المحمول الأول'),('mobile2','المحمول الثاني'),('national_id','الرقم القومي'),('gender','النوع'),('birth_date','تاريخ الميلاد YYYY-MM-DD')]
    controls=''.join(f'<label>{label}<input name="{key}" value="{esc(p.get(key))}" {"required" if key in ("performance_number","full_name") else ""}></label>' for key,label in fields)
    action='تحديث البيانات' if original else 'حفظ المستفيد'
    return page(header()+f'''<section class="panel"><h3>{action}</h3><form method="post" action="/person/save" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px">{csrf_field(token)}<input type="hidden" name="original_number" value="{esc(original)}">{controls}<button class="action" style="padding:13px">{action}</button></form><p class="hint">تُسجل العملية في سجل التدقيق، وتُنشأ نسخة احتياطية قبل أول تعديل.</p></section>''','بيانات المستفيد')

def treatment_form(token, perf=''):
    medicine_options=''.join(f'<option value="{esc(m["medicine_name"])}">' for m in management.list_medicines(DB) if m['is_active'])
    return page(header()+f'''<section class="panel"><h3>إضافة أو تحديث علاج</h3><form method="post" action="/treatment/save" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px">{csrf_field(token)}<label>رقم الأداء<input name="performance_number" required value="{esc(perf)}"></label><label>ترتيب العلاج<select name="treatment_order"><option>1</option><option>2</option><option>3</option></select></label><label>اسم الدواء<input name="medicine_name_raw" list="medicine_names" required><datalist id="medicine_names">{medicine_options}</datalist></label><label>التركيز<input name="strength_raw"></label><label>مدة الصرف<input name="dispensing_duration"></label><label>الجرعة<input name="dosage_text"></label><label>الحالة المرضية<input name="medical_condition"></label><label>تاريخ الموافقة<input name="approval_date" placeholder="YYYY-MM-DD"></label><button class="action" style="padding:13px">حفظ العلاج</button></form><p class="hint">إذا كان ترتيب العلاج موجوداً فسيتم تحديثه بدلاً من إنشاء تكرار.</p></section>''','إدارة العلاج')

def medicines_page(token, message=''):
    rows=management.list_medicines(DB)
    body=''.join(f'<tr><td>{esc(r["medicine_name"])}</td><td>{esc(r["active_ingredient"])}</td><td>{esc(r["strengths"])}</td></tr>' for r in rows)
    note=f'<div class="notice">{esc(message)}</div>' if message else ''
    return page(header()+f'''<section class="panel"><h3>إضافة دواء إلى القاموس</h3>{note}<form method="post" action="/medicine/save" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px">{csrf_field(token)}<label>اسم الدواء<input name="medicine_name" required></label><label>المادة الفعالة<input name="active_ingredient"></label><label>الشكل الدوائي<input name="dosage_form"></label><label>التخصص<input name="specialty"></label><label>التركيزات (افصل بينها بفاصلة)<input name="strengths"></label><button class="action" style="padding:12px">إضافة للقاموس</button></form></section><section class="panel profile"><h3>قاموس الأدوية ({len(rows)})</h3><div class="tablewrap"><table><thead><tr><th>الدواء</th><th>المادة الفعالة</th><th>التركيزات</th></tr></thead><tbody>{body or "<tr><td colspan=3>لم تتم إضافة أدوية للقاموس بعد.</td></tr>"}</tbody></table></div></section>''','قاموس الأدوية')

def imports_page(token, can_review=False, message=''):
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row
    try:
        batches=c.execute('SELECT batch_id,batch_type,source_file,import_mode,imported_at,submitted_by,approval_status,summary_json FROM Import_Batches_Ext ORDER BY batch_id DESC LIMIT 30').fetchall()
    except sqlite3.OperationalError:
        batches=[]
    finally: c.close()
    rows=''.join(f'''<tr><td><a href="/imports/batch/{r['batch_id']}">#{r['batch_id']}</a></td><td>{'العاملون' if r['batch_type']=='PERSONNEL' else 'الحالات الحرجة'}</td><td>{esc(r['source_file'])}</td><td>{'كشف شامل' if r['import_mode']=='FULL_SNAPSHOT' else 'تحديث جزئي'}</td><td>{esc(r['imported_at'])}</td><td>{'معتمدة' if r['approval_status']=='APPROVED' else 'بانتظار الاعتماد'}</td></tr>''' for r in batches)
    note=f'<div class="notice">{esc(message)}</div>' if message else ''
    review_link='<a href="/medicine-review">مراجعة أسماء الأدوية غير المعروفة</a> · ' if can_review else ''
    return page(header()+f'''<section class="hero"><h2>مركز الاستيراد الذكي</h2><p>ارفع ملف Excel، راجع المعاينة والتغييرات، ثم اعتمدها يدويًا. لا يتم تطبيق بيانات الملف أثناء المعاينة.</p></section>{note}<section class="panel"><h3>استيراد دفعة جديدة</h3><p class="hint"><a href="/imports/template">تنزيل قالب Excel الفارغ</a></p><form method="post" action="/imports/upload" enctype="multipart/form-data" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:12px">{csrf_field(token)}<label>نوع البيانات<select name="import_type"><option value="personnel">بيانات العاملين</option><option value="cases">الحالات الحرجة والعلاجات</option></select></label><label>طريقة التعامل مع الملف<select name="mode"><option value="PARTIAL_UPDATE">إضافة / تحديث جزئي — آمن افتراضيًا</option><option value="FULL_SNAPSHOT">كشف شامل محدث — يقترح الأرشفة</option></select></label><label>ملف Excel (.xlsx أو .xlsm)<input type="file" name="workbook" accept=".xlsx,.xlsm" required></label><button class="action" style="padding:13px">رفع الملف وإنشاء المعاينة</button></form><p class="hint">{review_link}الحد الأقصى 10 ميجابايت. لا تستخدم «كشف شامل» إلا إذا كان الملف يحتوي كل العلاجات الحالية للمجموعة المقصودة. لن تتم الأرشفة إلا بموافقة مستقلة صريحة.</p></section><section class="panel profile"><h3>آخر دفعات الاستيراد</h3><div class="tablewrap"><table><thead><tr><th>الدفعة</th><th>النوع</th><th>الملف</th><th>الوضع</th><th>التاريخ</th><th>الحالة</th></tr></thead><tbody>{rows or '<tr><td colspan="6">لا توجد دفعات استيراد حتى الآن.</td></tr>'}</tbody></table></div></section>''','مركز الاستيراد الذكي')


def import_batch_page(batch_id, token, message=''):
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row
    try:
        b=c.execute('SELECT * FROM Import_Batches_Ext WHERE batch_id=?',(batch_id,)).fetchone()
        if not b: return page(header()+'<section class="panel">دفعة الاستيراد غير موجودة.</section>','معاينة الاستيراد')
        summary=json.loads(b['summary_json'] or '{}')
        if b['batch_type']=='PERSONNEL':
            data=c.execute('SELECT row_number,performance_number,full_name,region,department,validation_status,validation_message FROM Personnel_Import_Staging WHERE batch_id=? ORDER BY row_number LIMIT 150',(batch_id,)).fetchall()
            headers='<th>الصف</th><th>رقم الأداء</th><th>الاسم</th><th>المنطقة</th><th>الإدارة</th><th>نتيجة الفحص</th>'
            body=''.join(f'<tr><td>{r["row_number"]}</td><td>{esc(r["performance_number"])}</td><td>{esc(r["full_name"])}</td><td>{esc(r["region"])}</td><td>{esc(r["department"])}</td><td>{esc(r["validation_status"])}</td></tr>' for r in data)
        else:
            data=c.execute('SELECT row_number,performance_number,medicine_name_raw,strength_raw,approval_date,validation_status,validation_message FROM Case_Import_Staging WHERE batch_id=? ORDER BY row_number LIMIT 150',(batch_id,)).fetchall()
            headers='<th>الصف</th><th>رقم الأداء</th><th>العلاج</th><th>التركيز</th><th>تاريخ الموافقة</th><th>نتيجة الفحص</th>'
            body=''.join(f'<tr><td>{r["row_number"]}</td><td>{esc(r["performance_number"])}</td><td>{esc(r["medicine_name_raw"])}</td><td>{esc(r["strength_raw"])}</td><td>{esc(r["approval_date"])}</td><td>{esc(r["validation_status"])}</td></tr>' for r in data)
        status='معتمدة' if b['approval_status']=='APPROVED' else 'بانتظار الاعتماد'
        stats=''.join(f'<div class="stat"><span>{esc(k)}</span><strong>{esc(v)}</strong></div>' for k,v in [
          ('عدد الصفوف',summary.get('rows',0)),('جديد',summary.get('new',0)),('مطابق',summary.get('matched',0)),('متغير',summary.get('changed',0)),('غير صالح',summary.get('invalid',0)),('مكرر',summary.get('duplicates',summary.get('duplicate_rows',0))),('شخص غير معروف',summary.get('unknown_person',0)),('أدوية تحتاج مراجعة',summary.get('unlisted_medicines',0)),('مرشحات أرشفة',summary.get('archive_candidates',0))] if v or k=='عدد الصفوف')
        note=f'<div class="notice">{esc(message)}</div>' if message else ''
        approve_form=''
        if b['approval_status']!='APPROVED':
            archive_control='''<label style="display:flex;gap:8px;align-items:center"><input type="checkbox" name="include_archive" value="1"> أوافق صراحةً على أرشفة العلاجات المرشحة أعلاه</label>''' if b['import_mode']=='FULL_SNAPSHOT' and summary.get('archive_candidates',0) else ''
            approve_form=f'''<section class="panel"><h3>اعتماد التغييرات</h3><p class="hint">راجع الأرقام والصفوف قبل الاعتماد. الصفوف غير الصالحة أو المكررة لا تُطبّق. الأرشفة غير مفعلة افتراضيًا.</p><form method="post" action="/imports/approve" style="display:grid;gap:12px">{csrf_field(token)}<input type="hidden" name="batch_id" value="{batch_id}">{archive_control}<button class="action" style="padding:13px">اعتماد التغييرات المقبولة</button></form></section>'''
        return page(header()+f'''<a class="back" href="/imports">← العودة إلى مركز الاستيراد</a>{note}<section class="hero"><h2>معاينة الدفعة #{batch_id}</h2><p>{esc(b['source_file'])} · {'بيانات العاملين' if b['batch_type']=='PERSONNEL' else 'الحالات الحرجة'} · {status}</p></section><section class="stats">{stats}</section><section class="panel"><h3>تفاصيل الصفوف (أول 150 صفًا)</h3><div class="tablewrap"><table><thead><tr>{headers}</tr></thead><tbody>{body or '<tr><td colspan="7">لا توجد صفوف للعرض.</td></tr>'}</tbody></table></div><p class="hint">المعاينة لا تعرض أرقام الهواتف أو الرقم القومي لحماية الخصوصية.</p></section>{approve_form}''',f'معاينة الدفعة {batch_id}')
    finally: c.close()


def analytics_page():
    d=analytics_center.analytics(DB)
    a=analytics_center.alerts(DB)
    def bars(rows):
        maxv=max([r['value'] for r in rows] or [1])
        return ''.join(f'''<div style="display:grid;grid-template-columns:minmax(90px,1fr) 2fr 42px;gap:9px;align-items:center;margin:11px 0"><span style="font-size:12px">{esc(r['label'])}</span><div style="height:12px;background:#edf3f3;border-radius:20px;overflow:hidden"><div style="height:100%;width:{max(2,100*r['value']/maxv)}%;background:linear-gradient(90deg,#167d82,#57aaa1);border-radius:20px"></div></div><b>{r['value']}</b></div>''' for r in rows) or '<p class="hint">لا توجد بيانات كافية.</p>'
    totals=d['totals']
    return page(header()+f'''<section class="hero"><h2>مركز الإحصائيات والتقارير</h2><p>مؤشرات تشغيلية مستخرجة مباشرة من قاعدة البيانات للقراءة فقط، مع تقسيمات حسب الدواء والمنطقة والإدارة.</p></section><section class="stats"><div class="stat"><span>العاملون</span><strong>{totals['personnel']}</strong></div><div class="stat"><span>ملفات المستفيدين</span><strong>{totals['beneficiaries']}</strong></div><div class="stat"><span>العلاجات الحالية</span><strong>{totals['current_treatments']}</strong></div></section><section class="stats"><div class="stat"><span>العلاجات المؤرشفة</span><strong>{totals['archived_treatments']}</strong></div><div class="stat"><span>التنبيهات</span><strong>{a['total']}</strong></div><div class="stat"><span>تنبيهات تحتاج تحركًا</span><strong>{a['counts'].get('critical',0)+a['counts'].get('warning',0)}</strong></div></section><section class="layout"><div class="panel"><h3>سجلات العلاج حسب الدواء</h3>{bars(d['medicines'])}</div><div class="panel"><h3>المستفيدون حسب المنطقة</h3>{bars(d['regions'])}</div><div class="panel"><h3>المستفيدون حسب الإدارة</h3>{bars(d['departments'])}</div><div class="panel"><h3>الموافقات حسب الشهر</h3>{bars(d['approvals_by_month'])}</div></section><section class="panel profile"><a class="action" style="display:inline-block;padding:12px;text-decoration:none" href="/analytics.xlsx">تنزيل تقرير Excel الشامل</a> <a class="pill" href="/alerts">فتح مركز التنبيهات ({a['total']})</a><p class="hint">التقرير لا يعرض أرقام الهواتف أو الرقم القومي. الأعداد تمثل السجلات وفق مصدرها ولا تعني بالضرورة عدد الأشخاص الفريدين إلا حيث ذُكر ذلك.</p></section>''','التقارير والإحصائيات')


def alerts_page():
    d=analytics_center.alerts(DB)
    labels={'critical':'حرج','warning':'تحذير','info':'معلومة'}
    cards=[]
    for x in d['items']:
        perf=x.get('performance_number')
        link=f'''<a class="pill" href="/person/{quote(str(perf))}">فتح الملف</a>''' if perf else ''
        cards.append(f'''<div class="person" style="display:block"><div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap"><span class="pill">{labels.get(x['severity'],x['severity'])}</span><b>{esc(x.get('title'))}</b><span class="hint">{esc(x.get('code'))}</span></div><p class="hint">{esc(x.get('name') or '')} {('· رقم الأداء: '+esc(perf)) if perf else ''}</p><p>{esc(x.get('detail'))}</p>{link}</div>''')
    expiry_note='يوجد حقل انتهاء صريح ويمكن حساب الانتهاء.' if d['expiry_supported'] else 'لا يوجد تاريخ انتهاء مستقل في قاعدة البيانات الحالية؛ لذلك لا يتم استنتاج الانتهاء من تاريخ الموافقة أو مدة الصرف.'
    return page(header()+f'''<section class="hero"><h2>مركز التنبيهات ومراجعة جودة البيانات</h2><p>تم إنشاء الفحص بتاريخ {esc(d['generated_on'])}. التنبيهات إشارات للمراجعة وليست قرارات طبية أو إدارية تلقائية.</p></section><section class="stats"><div class="stat"><span>إجمالي التنبيهات</span><strong>{d['total']}</strong></div><div class="stat"><span>حرجة</span><strong>{d['counts'].get('critical',0)}</strong></div><div class="stat"><span>تحذيرات</span><strong>{d['counts'].get('warning',0)}</strong></div></section><section class="panel"><div class="notice">{esc(expiry_note)}</div>{''.join(cards) or '<p class="hint">لا توجد تنبيهات وفق قواعد الفحص الحالية.</p>'}<p class="hint"><a href="/analytics">العودة إلى التقارير</a></p></section>''','مركز التنبيهات')


def parse_multipart(content_type, raw):
    message=BytesParser(policy=email_policy).parsebytes((f'Content-Type: {content_type}\r\nMIME-Version: 1.0\r\n\r\n').encode('ascii')+raw)
    fields={}; files={}
    for part in message.iter_parts():
        name=part.get_param('name',header='content-disposition')
        if not name: continue
        payload=part.get_payload(decode=True) or b''
        filename=part.get_filename()
        if filename is not None:
            files[name]={'filename':Path(filename.replace('\\','/')).name,'content':payload,'content_type':part.get_content_type()}
        else:
            charset=part.get_content_charset() or 'utf-8'
            fields[name]=payload.decode(charset,'replace')
    return fields,files


def medicine_review_page(token, message=''):
    queue=management.list_medicine_review(DB)
    medicines=management.list_medicines(DB)
    options=''.join(f'<option value="{m["medicine_id"]}">{esc(m["medicine_name"])}</option>' for m in medicines)
    cards=[]
    for r in queue:
        status='بانتظار المراجعة' if r['review_status']=='PENDING' else 'تمت المراجعة'
        action=''
        if r['review_status']=='PENDING':
            action=f'''<form method="post" action="/medicine-alias" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">{csrf_field(token)}<input type="hidden" name="alias" value="{esc(r['medicine_name_raw'])}"><select name="medicine_id" required><option value="">اختر الاسم المعتمد</option>{options}</select><button class="action">اعتماد الربط</button></form>'''
        cards.append(f'''<div class="person" style="display:block"><div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap"><b>{esc(r['medicine_name_raw'])}</b><small>{status} · دفعة #{r['batch_id']} · صف {r['first_seen_row'] or '—'}</small></div><p class="hint">{esc(r['review_note'] or 'اسم دواء غير موجود في القاموس؛ راجعه قبل اعتماد الاسم الموحد.')}</p>{action}</div>''')
    note=f'<div class="notice">{esc(message)}</div>' if message else ''
    return page(header()+f'''<section class="hero"><h2>مراجعة أسماء الأدوية</h2><p>اربط الاسم الوارد في ملف الاستيراد باسم معتمد في القاموس. الربط لا يعيد كتابة الاسم الأصلي داخل السجلات القديمة.</p></section>{note}<section class="panel"><h3>الأسماء الواردة ({len(queue)})</h3>{''.join(cards) or '<p class="hint">لا توجد أسماء تحتاج مراجعة.</p>'}</section><p class="hint"><a href="/imports">العودة إلى مركز الاستيراد</a> · <a href="/medicines">إدارة قاموس الأدوية</a></p>''','مراجعة أسماء الأدوية')


def users_page(token, message=''):
    rows=management.list_users(AUTH_DB)
    body=''.join(f'''<tr><td>{esc(r['username'])}</td><td>{esc(r['display_name'])}</td><td>{esc(r['role'])}</td><td>{'نشط' if r['active'] else 'معطل'}</td><td><form method="post" action="/user/toggle">{csrf_field(token)}<input type="hidden" name="user_id" value="{r['user_id']}"><input type="hidden" name="active" value="{0 if r['active'] else 1}"><button class="pill">{'تعطيل' if r['active'] else 'تفعيل'}</button></form></td></tr>''' for r in rows)
    note=f'<div class="notice">{esc(message)}</div>' if message else ''
    return page(header()+f'''<section class="panel"><h3>إنشاء حساب مستخدم</h3>{note}<form method="post" action="/users/create" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px">{csrf_field(token)}<label>اسم المستخدم<input name="username" required minlength="3"></label><label>الاسم الظاهر<input name="display_name" required></label><label>كلمة المرور (12 حرفاً على الأقل)<input name="password" type="password" required minlength="12"></label><label>الدور<select name="role"><option value="viewer">مشاهد</option><option value="editor">محرر</option><option value="exporter">تصدير</option><option value="data_entry">إدخال بيانات</option><option value="medicine_admin">مسؤول أدوية</option><option value="manager">مدير</option></select></label><button class="action" style="padding:12px">إنشاء الحساب</button></form></section><section class="panel profile"><h3>حسابات المستخدمين</h3><div class="tablewrap"><table><thead><tr><th>المستخدم</th><th>الاسم</th><th>الدور</th><th>الحالة</th><th>إجراء</th></tr></thead><tbody>{body}</tbody></table></div></section>''','إدارة المستخدمين')

if __name__=='__main__':
    print(f'علاج الحالات حاجة يعمل على http://{HOST}:{PORT} — قاعدة البيانات: {DB}')
    ThreadingHTTPServer((HOST,PORT),Handler).serve_forever()
