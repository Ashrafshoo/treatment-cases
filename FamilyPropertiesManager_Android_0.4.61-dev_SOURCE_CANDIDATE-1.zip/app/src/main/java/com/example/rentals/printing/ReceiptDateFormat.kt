package com.example.rentals.printing

import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Keeps ISO dates in storage while displaying dates in the exact source-sheet order: yyyy/MM/dd. */
object ReceiptDateFormat {
    private val iso = DateTimeFormatter.ISO_LOCAL_DATE
    private val sheet = DateTimeFormatter.ofPattern("yyyy/MM/dd", Locale.ROOT)
    private const val westernDigits = "0123456789"
    private const val arabicDigits = "٠١٢٣٤٥٦٧٨٩"

    fun toArabicDigits(value: String): String = buildString(value.length) {
        value.forEach { ch ->
            val index = westernDigits.indexOf(ch)
            append(if (index >= 0) arabicDigits[index] else ch)
        }
    }

    private fun toWesternDigits(value: String): String = buildString(value.length) {
        value.forEach { ch ->
            val index = arabicDigits.indexOf(ch)
            append(if (index >= 0) westernDigits[index] else ch)
        }
    }

    fun toStorage(value: String): String {
        val normalized = toWesternDigits(value.trim()).replace('/', '-')
        return try { LocalDate.parse(normalized, iso).format(iso) }
        catch (_: Exception) { throw IllegalArgumentException("التاريخ يجب أن يكون بنفس ترتيب الشيت: سنة/شهر/يوم") }
    }

    fun toSheet(value: String): String {
        val trimmed = value.trim()
        if (trimmed.isEmpty()) return ""
        val normalized = trimmed.replace('/', '-')
        val formatted = try { LocalDate.parse(normalized, iso).format(sheet) }
        catch (_: Exception) { return trimmed }
        return toArabicDigits(formatted)
    }
}
