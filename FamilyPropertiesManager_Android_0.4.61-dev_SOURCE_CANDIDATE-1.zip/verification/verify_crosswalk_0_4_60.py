#!/usr/bin/env python3
"""Backward-compatible entry point for the 0.4.61 historical crosswalk validator."""
import runpy, pathlib, sys
script = pathlib.Path(__file__).with_name("verify_crosswalk_0_4_61.py")
sys.argv = [str(script)] + sys.argv[1:]
runpy.run_path(str(script), run_name="__main__")
