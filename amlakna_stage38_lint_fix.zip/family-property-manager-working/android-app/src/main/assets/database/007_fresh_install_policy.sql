-- Fresh schema already includes law_164_residential_rules; classify linked residential leases.
UPDATE leases
SET law_164_residential_rules = CASE
  WHEN law_164_2025_applies = 1 AND EXISTS (
    SELECT 1 FROM units u WHERE u.id = leases.unit_id AND lower(COALESCE(u.unit_type,'')) = 'residential'
  ) THEN 1 ELSE 0 END;
INSERT OR IGNORE INTO schema_migrations(version,name)
VALUES (7,'stage23_law164_policy_separation');
