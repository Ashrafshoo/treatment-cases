from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / 'android-app/src/main'


def test_backup_uses_authenticated_encryption_and_strong_password_derivation():
    source = (APP / 'java/com/familyproperties/app/security/BackupCipher.kt').read_text()
    assert 'AES/GCM/NoPadding' in source
    assert 'PBKDF2WithHmacSHA256' in source
    assert '310_000' in source
    assert 'updateAAD' in source
    assert 'password.fill' in source
    assert '.restore.tmp' in source and '.before-restore-' in source
    assert 'isPlaintextSqlite(temp)' in source and '.previous-' in source
    assert 'canonicalFile != destination.canonicalFile' in source
    assert 'canonicalFile != databaseFile.canonicalFile' in source


def test_biometric_prompt_uses_system_authenticator_without_template_access():
    source = (APP / 'java/com/familyproperties/app/security/BiometricLogin.kt').read_text()
    assert 'BiometricPrompt' in source
    assert 'BIOMETRIC_STRONG' in source
    assert 'استخدم كلمة المرور' in source


def test_due_notifications_are_periodically_scheduled_and_permission_declared():
    worker = (APP / 'java/com/familyproperties/app/notifications/DueNotificationWorker.kt').read_text()
    scheduler = (APP / 'java/com/familyproperties/app/notifications/ReminderScheduler.kt').read_text()
    manifest = (APP / 'AndroidManifest.xml').read_text()
    activity = (APP / 'java/com/familyproperties/app/MainActivity.kt').read_text()
    assert "status='pending'" in worker and "status='shown'" in worker
    assert 'date(due_at) <= date(?)' in worker
    assert 'PeriodicWorkRequestBuilder<DueNotificationWorker>' in scheduler
    assert 'POST_NOTIFICATIONS' in manifest
    assert 'ReminderScheduler.schedule' in activity


def test_android_dependencies_and_version_are_updated():
    gradle = (ROOT / 'android-app/build.gradle.kts').read_text()
    assert 'work-runtime-ktx:2.10.0' in gradle
    assert 'fragment-ktx:1.8.5' in gradle
    assert 'versionCode = 36' in gradle and 'versionName = "0.36.0"' in gradle
