package com.treatmentcases.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.util.Base64
import org.json.JSONArray
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** Local authentication foundation. Delegated accounts are device-local until a real server is deployed. */
data class UserSession(val userId:Long?, val username:String, val role:String, val permissions:Set<String>) {
    val isAdmin:Boolean get() = role == "ADMIN"
    fun can(permission:String):Boolean = isAdmin || permission in permissions
}

data class ManagedUser(val id:Long, val username:String, val active:Boolean, val permissions:Set<String>)

class AuthManager(private val context:Context, private val db:LocalDb) {
    private val prefs = context.getSharedPreferences("local_auth", Context.MODE_PRIVATE)
    private val random = SecureRandom()
    val permissionKeys = linkedSetOf("view_search", "add_edit", "export_share", "import_excel", "manage_medicines", "manage_users")
    /** Permissions the current authenticated session may delegate. */
    fun activePermissions():Set<String> = db.activePermissions()

    fun isConfigured():Boolean = prefs.contains("salt") && prefs.contains("hash")
    fun createAdmin(password:String):Boolean {
        if(password.length < 8) return false
        val salt=ByteArray(16).also{random.nextBytes(it)}
        val hash=derive(password,salt)
        prefs.edit().putString("salt",Base64.encodeToString(salt,Base64.NO_WRAP))
            .putString("hash",Base64.encodeToString(hash,Base64.NO_WRAP)).putString("role","ADMIN").apply()
        db.setActiveSession("ADMIN",permissionKeys)
        db.log("إنشاء/تغيير كلمة مرور المدير","local-admin")
        return true
    }
    fun verify(password:String):Boolean {
        val salt=prefs.getString("salt",null)?:return false
        val expected=prefs.getString("hash",null)?:return false
        return try { MessageDigest.isEqual(derive(password,Base64.decode(salt,Base64.NO_WRAP)),Base64.decode(expected,Base64.NO_WRAP)) } catch(_:Exception){false}
    }
    fun authenticate(username:String,password:String):UserSession? {
        if(username.equals("admin",true) && verify(password)) return UserSession(null,"admin","ADMIN",permissionKeys)
        val d=db.readableDatabase
        return d.rawQuery("SELECT id,username,password_hash,role,permissions,active FROM app_users WHERE username=? COLLATE NOCASE LIMIT 1",arrayOf(username.trim())).use{c->
            if(!c.moveToFirst() || c.getInt(5)!=1) return@use null
            val encoded=c.getString(2).orEmpty().split(":",limit=2)
            if(encoded.size!=2) return@use null
            val ok=try{MessageDigest.isEqual(derive(password,Base64.decode(encoded[0],Base64.NO_WRAP)),Base64.decode(encoded[1],Base64.NO_WRAP))}catch(_:Exception){false}
            if(!ok)return@use null
            val perms=parsePermissions(c.getString(4))
            UserSession(c.getLong(0),c.getString(1),c.getString(3),perms)
        }
    }
    /** Returns a one-time plaintext code. Only its salted hash is persisted. */
    fun createActivationCode(username:String,permissions:Set<String>,validHours:Int=72):String? {
        if(!db.hasActivePermission("manage_users")) return null
        val clean=username.trim()
        if(clean.length !in 3..40 || clean.equals("admin",true) || !clean.matches(Regex("[A-Za-z0-9_.-]+"))) return null
        if(permissions.isEmpty() || permissions.any{it !in permissionKeys || it !in db.activePermissions()} || validHours !in 1..720) return null
        val d=db.writableDatabase
        if(d.rawQuery("SELECT 1 FROM app_users WHERE username=? COLLATE NOCASE",arrayOf(clean)).use{it.moveToFirst()}) return null
        val code=buildString{repeat(12){append("ABCDEFGHJKLMNPQRSTUVWXYZ23456789"[random.nextInt(32)])}}
        val salt=ByteArray(16).also{random.nextBytes(it)}
        val hash=derive(code,salt)
        val v=ContentValues().apply{put("username",clean);put("code_salt",Base64.encodeToString(salt,Base64.NO_WRAP));put("code_hash",Base64.encodeToString(hash,Base64.NO_WRAP));put("permissions",JSONArray(permissions.toList()).toString());put("expires_at",System.currentTimeMillis()+validHours*3600_000L);put("created_by","${if(db.isAdminSession())"admin" else "delegated"}");db.activeUserId()?.let{put("created_by_user_id",it)}}
        return try{d.insertOrThrow("activation_codes",null,v);db.log("إنشاء رمز تفعيل لمرة واحدة",clean);code}catch(_:Exception){null}
    }
    /** First-use activation consumes the code atomically and creates the delegated account. */
    fun activate(username:String,code:String,password:String):Boolean {
        val clean=username.trim();if(password.length<8 || code.length !in 8..24)return false
        val d=db.writableDatabase;d.beginTransaction()
        try{
            val row=d.rawQuery("SELECT id,code_salt,code_hash,permissions,expires_at,used_at,created_by_user_id FROM activation_codes WHERE username=? COLLATE NOCASE ORDER BY id DESC LIMIT 1",arrayOf(clean)).use{c->if(c.moveToFirst()) arrayOf(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getLong(4),c.getString(5),if(c.isNull(6))null else c.getLong(6)) else null}?:return false
            if(row[5]!=null || (row[4] as Long)<System.currentTimeMillis())return false
            val salt=Base64.decode(row[1] as String,Base64.NO_WRAP)
            if(!MessageDigest.isEqual(derive(code.trim().uppercase(),salt),Base64.decode(row[2] as String,Base64.NO_WRAP)))return false
            if(d.rawQuery("SELECT 1 FROM app_users WHERE username=? COLLATE NOCASE",arrayOf(clean)).use{it.moveToFirst()})return false
            val passSalt=ByteArray(16).also{random.nextBytes(it)}
            val hash=Base64.encodeToString(passSalt,Base64.NO_WRAP)+":"+Base64.encodeToString(derive(password,passSalt),Base64.NO_WRAP)
            val u=ContentValues().apply{put("username",clean);put("password_hash",hash);put("role","USER");put("permissions",row[3] as String);put("active",1);if(row[6]!=null)put("owner_user_id",row[6] as Long)}
            d.insertOrThrow("app_users",null,u)
            val used=ContentValues().apply{put("used_at",System.currentTimeMillis())}
            if(d.update("activation_codes",used,"id=? AND used_at IS NULL",arrayOf((row[0] as Long).toString()))!=1)return false
            val audit=ContentValues().apply{put("action","تفعيل حساب مستخدم مفوض");put("item_key",clean)};d.insert("audit_log",null,audit)
            d.setTransactionSuccessful();return true
        }catch(_:Exception){return false}finally{d.endTransaction()}
    }
    fun users():List<ManagedUser> {
        if(!db.hasActivePermission("manage_users")) return emptyList()
        val sql=if(db.isAdminSession())"SELECT id,username,active,permissions FROM app_users ORDER BY username COLLATE NOCASE" else "SELECT id,username,active,permissions FROM app_users WHERE owner_user_id=? ORDER BY username COLLATE NOCASE"
        val args=if(db.isAdminSession())null else arrayOf(db.activeUserId()?.toString()?:"-1")
        return db.readableDatabase.rawQuery(sql,args).use{c->buildList{while(c.moveToNext())add(ManagedUser(c.getLong(0),c.getString(1),c.getInt(2)==1,parsePermissions(c.getString(3))))}}
    }
    fun setUserActive(id:Long,active:Boolean):Boolean {
        if(!db.hasActivePermission("manage_users") || db.activeUserId()==id) return false
        val v=ContentValues().apply{put("active",if(active)1 else 0)}
        val where=if(db.isAdminSession())"id=?" else "id=? AND owner_user_id=?"
        val args=if(db.isAdminSession())arrayOf(id.toString()) else arrayOf(id.toString(),db.activeUserId()?.toString()?:"-1")
        val changed=db.writableDatabase.update("app_users",v,where,args)==1
        if(changed)db.log(if(active)"إعادة تفعيل حساب" else "تعطيل حساب",id.toString())
        return changed
    }
    fun updatePermissions(id:Long,permissions:Set<String>):Boolean {
        if(!db.hasActivePermission("manage_users") || db.activeUserId()==id)return false
        if(permissions.isEmpty() || permissions.any{it !in permissionKeys || it !in db.activePermissions()})return false
        val v=ContentValues().apply{put("permissions",JSONArray(permissions.toList()).toString())}
        val where=if(db.isAdminSession())"id=?" else "id=? AND owner_user_id=?"
        val args=if(db.isAdminSession())arrayOf(id.toString()) else arrayOf(id.toString(),db.activeUserId()?.toString()?:"-1")
        val changed=db.writableDatabase.update("app_users",v,where,args)==1
        if(changed)db.log("تعديل صلاحيات حساب",id.toString())
        return changed
    }
    private fun parsePermissions(raw:String?):Set<String> = try{val a=JSONArray(raw?:"[]");buildSet{for(i in 0 until a.length())a.optString(i).takeIf{it in permissionKeys}?.let{add(it)}}}catch(_:Exception){emptySet()}
    private fun derive(password:String,salt:ByteArray):ByteArray {
        val spec=PBEKeySpec(password.toCharArray(),salt,160_000,256)
        return try{SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded}finally{spec.clearPassword()}
    }
}
