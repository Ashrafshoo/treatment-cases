#!/usr/bin/env python3
"""Pre-release consistency checks for 2.8.1; source-level only, not Android instrumentation."""
from pathlib import Path
from collections import defaultdict

root = Path(__file__).resolve().parents[1]
ui = (root / 'android/app/src/main/java/com/treatmentcases/app/MainActivity.kt').read_text()
manifest = (root / 'android/app/src/main/AndroidManifest.xml').read_text()
gradle = (root / 'android/app/build.gradle').read_text()
workflow = (root / '.github/workflows/android-apk.yml').read_text()
auth = (root / 'android/app/src/main/java/com/treatmentcases/app/AuthManager.kt').read_text()
sync = (root / 'android/app/src/main/java/com/treatmentcases/app/SyncTransport.kt').read_text()
localdb = (root / 'android/app/src/main/java/com/treatmentcases/app/LocalDb.kt').read_text()
checks = []
def ok(name, condition):
    if not condition:
        raise AssertionError(name)
    checks.append(name)

ok('release version is 2.8.1 / code 33', "versionName '2.8.1-ui-polish'" in gradle and 'versionCode 33' in gradle)
ok('application id remains isolated preview package', "applicationId 'com.treatmentcases.app.preview275'" in gradle)
ok('Android SDK and Java target remain aligned', 'compileSdk 35' in gradle and "sourceCompatibility JavaVersion.VERSION_17" in gradle and "jvmTarget = '17'" in gradle)
ok('internet permission exists for opt-in sync', 'android.permission.INTERNET' in manifest)
ok('offline-first disclosure no longer falsely claims no server transfer', 'لا تبدأ مشاركة البيانات بين الأجهزة إلا بعد إعداد خادم HTTPS' in ui)
gate = ui[ui.index('@Composable fun AppGate'):ui.index('@Composable private fun UserManagementCard')]
ok('login screen uses a branded rounded card and responsive scroll layout', 'RoundedCornerShape(26.dp)' in gate and 'verticalScroll(rememberScrollState())' in gate and 'ic_medical_brand' in gate)
ok('login screen has localized user, password and activation fields', all(x in gate for x in ['Icons.Default.Person','Icons.Default.Lock','Icons.Default.VpnKey']))
ok('security notes disclose HTTPS sync and local per-device database', 'خادم مزامنة فعلي ومهيأ' in ui and 'HTTPS' in ui)
ok('delegated accounts accurately disclose device-local limitation', 'device-local until a real server is deployed' in auth)
ok('sync transport requires HTTPS and bearer token', 'endpoint.startsWith("https://")' in sync and 'bearerToken.isNotBlank()' in sync)
ok('sync remains explicitly manual from the settings action', 'SyncWorkScheduler.enqueue(ctx)' in ui)
counts = localdb[localdb.index('fun counts()'):localdb.index('fun medicines()')]
ok('medicine beneficiary counts deduplicate normalized employee performance numbers', 'CaseDataRules.normalizePerformanceNo' in counts and 'MutableSet<String>' in counts)
ok('report medicine availability is based on case presence, not beneficiary count', 'fun medicinesWithCases()' in localdb and 'medicinesWithCases){meds.filter{it in medicinesWithCases}}' in ui)
reports = ui[ui.index('\n \"التقارير\"->{'):ui.index('\n \"استيراد\"->')]
ok('report medicine list labels counts as beneficiaries', 'مستفيد' in reports)
ok('CI runs every Python source check', 'for test_file in verification/check_*.py' in workflow)
ok('CI runs every Kotlin/JVM regression suite', 'for test_file in verification/run_*_tests.sh' in workflow)
ok('CI compiles and assembles the debug APK', ':app:compileDebugKotlin' in workflow and ':app:assembleDebug' in workflow)
ok('CI artifact is named for the current release', 'treatment-cases-2.8.1-debug-apk' in workflow)
ok('CI reacts to verification changes', "- 'verification/**'" in workflow)

# Mirror the Kotlin normalization rule for repeated Latin/Arabic employee numbers.
def normalize(value):
    out = []
    for ch in value:
        if '٠' <= ch <= '٩': out.append(str(ord(ch) - 0x0660))
        elif '۰' <= ch <= '۹': out.append(str(ord(ch) - 0x06F0))
        else: out.append(ch)
    return ''.join(out).strip().replace(' ', '')
people = defaultdict(set)
for med, performance in [('دواء أ', '001'), ('دواء أ', '001'), ('دواء أ', ' ٠٠١ '), ('دواء أ', '002'), ('دواء أ', '')]:
    key = normalize(performance)
    if med.strip() and key:
        people[med.strip()].add(key)
assert len(people['دواء أ']) == 2
checks.append('beneficiary count simulation deduplicates repeated employee IDs and Arabic/Latin digits')
case_medicines = {'دواء ب'}
beneficiary_counts = {'دواء ب': 0}
assert 'دواء ب' in case_medicines and beneficiary_counts['دواء ب'] == 0
checks.append('report simulation retains a medicine with legacy cases even if beneficiary IDs are missing')

print('\n'.join('PASS: ' + item for item in checks))
print(f'{len(checks)} pre-release consistency assertions passed (static + local logic simulation).')
