package com.treatmentcases.app

import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient.FileChooserParams
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import java.net.URI

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView
    private val prefs by lazy { getSharedPreferences("treatment_app", Context.MODE_PRIVATE) }
    private var serverUrl: String = ""
    private var filePathCallback: ValueCallback<Array<Uri>>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(18, 59, 74)
        window.navigationBarColor = android.graphics.Color.rgb(18, 59, 74)
        serverUrl = prefs.getString(KEY_SERVER, "") ?: ""
        buildLayout()
        configureWebView()
        if (serverUrl.isBlank()) showServerDialog() else loadHome()
    }

    private fun buildLayout() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(android.graphics.Color.rgb(247, 250, 250)) }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(8), dp(10), dp(8)); setBackgroundColor(android.graphics.Color.rgb(18, 59, 74))
        }
        val title = TextView(this).apply {
            text = "علاج الحالات حاجة"; textSize = 18f; setTextColor(android.graphics.Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, dp(48), 1f); gravity = Gravity.CENTER_VERTICAL
        }
        val settings = Button(this).apply { text = "الإعدادات"; textSize = 12f; setOnClickListener { showServerDialog() } }
        bar.addView(title); bar.addView(settings, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(42)))
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { isIndeterminate = true; visibility = View.GONE }
        status = TextView(this).apply {
            text = "أدخل عنوان الخادم الآمن لبدء الاستخدام."; textSize = 15f
            setTextColor(android.graphics.Color.rgb(45, 65, 72)); gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
        }
        webView = WebView(this).apply { layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f) }
        root.addView(bar); root.addView(progress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)))
        root.addView(status); root.addView(webView); setContentView(root)
    }

    @Suppress("SetJavaScriptEnabled")
    private fun configureWebView() {
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, false)
        webView.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true; allowFileAccess = false; allowContentAccess = false
            javaScriptCanOpenWindowsAutomatically = false; setSupportMultipleWindows(false)
            mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
            if (android.os.Build.VERSION.SDK_INT >= 26) safeBrowsingEnabled = true
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
                progress.progress = newProgress
            }
            override fun onShowFileChooser(
                webView: WebView?,
                callback: ValueCallback<Array<Uri>>?,
                params: FileChooserParams?
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                return try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST)
                    true
                } catch (_: Exception) {
                    filePathCallback?.onReceiveValue(null)
                    filePathCallback = null
                    false
                }
            }
        }
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                if (uri.scheme?.lowercase() != "https") {
                    Toast.makeText(this@MainActivity, "الاتصال غير الآمن غير مسموح به", Toast.LENGTH_LONG).show()
                    return true
                }
                val configuredOrigin = runCatching { URI(serverUrl) }.getOrNull()
                val sameOrigin = configuredOrigin != null &&
                    uri.host.equals(configuredOrigin.host, ignoreCase = true) &&
                    (if (uri.port == -1) 443 else uri.port) == (if (configuredOrigin.port == -1) 443 else configuredOrigin.port)
                if (sameOrigin) return false
                runCatching { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
                return true
            }
            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) {
                    status.visibility = View.VISIBLE
                    status.text = "تعذر الاتصال بالخادم. تحقق من الإنترنت وعنوان الخادم ثم أعد المحاولة من الإعدادات."
                }
            }
        }
        webView.setDownloadListener(DownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            if (!url.startsWith("https://")) {
                Toast.makeText(this, "تم رفض تنزيل غير آمن", Toast.LENGTH_LONG).show(); return@DownloadListener
            }
            try {
                val request = DownloadManager.Request(Uri.parse(url)).setMimeType(mimeType)
                    .addRequestHeader("User-Agent", userAgent)
                    .addRequestHeader("Cookie", CookieManager.getInstance().getCookie(url) ?: "")
                    .setTitle("تنزيل من علاج الحالات حاجة").setDescription("جارٍ تنزيل الملف")
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, safeFilename(contentDisposition))
                (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
                Toast.makeText(this, "بدأ التنزيل؛ ستجد الملف في مجلد التنزيلات", Toast.LENGTH_LONG).show()
            } catch (_: Exception) { Toast.makeText(this, "تعذر بدء التنزيل", Toast.LENGTH_LONG).show() }
        })
    }

    private fun showServerDialog() {
        val input = EditText(this).apply { setSingleLine(true); textSize = 15f; hint = "https://your-secure-server.example"; setText(serverUrl); setSelection(text.length) }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(8), dp(22), 0)
            addView(TextView(this@MainActivity).apply {
                text = "أدخل رابط الخادم الذي يستضيف برنامج علاج الحالات حاجة. يجب أن يبدأ الرابط بـ https://"
                textSize = 14f; setTextColor(android.graphics.Color.DKGRAY)
            })
            addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)))
        }
        val dialog = AlertDialog.Builder(this).setTitle("إعداد الاتصال").setView(container)
            .setCancelable(serverUrl.isNotBlank()).setPositiveButton("حفظ والاتصال", null)
            .setNegativeButton(if (serverUrl.isBlank()) "إلغاء" else "إغلاق", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val candidate = input.text.toString().trim().trimEnd('/')
                val valid = runCatching { val uri = URI(candidate); uri.scheme == "https" && !uri.host.isNullOrBlank() && uri.userInfo == null }.getOrDefault(false)
                if (!valid) { input.error = "أدخل رابط HTTPS صحيحًا، مثل https://example.com"; return@setOnClickListener }
                serverUrl = candidate; prefs.edit().putString(KEY_SERVER, serverUrl).apply()
                dialog.dismiss(); loadHome()
            }
        }
        dialog.show()
    }

    private fun loadHome() {
        if (serverUrl.isBlank()) return
        status.visibility = View.GONE; webView.visibility = View.VISIBLE; webView.loadUrl(serverUrl)
    }

    private fun safeFilename(contentDisposition: String?): String {
        val raw = Regex("filename\\*=UTF-8''([^;]+)|filename=\\\"?([^;\\\"]+)", RegexOption.IGNORE_CASE)
            .find(contentDisposition.orEmpty())?.let { it.groups[1]?.value ?: it.groups[2]?.value }
        val decoded = runCatching { java.net.URLDecoder.decode(raw ?: "report.xlsx", "UTF-8") }.getOrDefault("report.xlsx")
        return decoded.substringAfterLast('/').substringAfterLast('\\').filter { it.isLetterOrDigit() || it in "._- " }.ifBlank { "download.bin" }
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == FILE_CHOOSER_REQUEST) {
            val result = if (resultCode == RESULT_OK && data?.data != null) arrayOf(data.data!!) else null
            filePathCallback?.onReceiveValue(result)
            filePathCallback = null
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() { if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed() }
    override fun onDestroy() { if (::webView.isInitialized) webView.destroy(); super.onDestroy() }
    companion object { private const val KEY_SERVER = "server_url"; private const val FILE_CHOOSER_REQUEST = 4102 }
}
