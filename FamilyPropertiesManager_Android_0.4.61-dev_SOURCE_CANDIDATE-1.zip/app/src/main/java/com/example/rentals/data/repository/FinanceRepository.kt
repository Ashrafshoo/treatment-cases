package com.example.rentals.data.repository

import com.example.rentals.domain.finance.FinanceSummary
import com.example.rentals.domain.finance.HeirPayout
import com.example.rentals.domain.finance.HeirShare

interface FinanceRepository {
    fun getSummary(): FinanceSummary
    fun getActiveHeirs(): List<HeirShare>
    fun addLedger(unitCode: String, tenant: String, date: String, period: String, type: String, debit: Double, credit: Double, method: String, notes: String)
    fun addExpense(title: String, amount: Double, date: String, period: String, category: String, notes: String)
    fun addCollectorReceivable(collector: String, period: String, date: String, amount: Double, notes: String)
    fun handoverCollector(collector: String, date: String, amount: Double, method: String, expenses: Double, distributed: Double, period: String, notes: String)
    fun payHeirs(payouts: List<HeirPayout>, date: String, period: String)
}
