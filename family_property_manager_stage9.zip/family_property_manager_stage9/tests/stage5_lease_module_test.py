import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCHEMA = ROOT / 'app' / 'assets' / 'database' / '001_initial_schema.sql'


def test_lease_and_rent_history_are_linked():
    db = sqlite3.connect(':memory:')
    db.execute('PRAGMA foreign_keys=ON')
    for statement in SCHEMA.read_text(encoding='utf-8').split(';'):
        if statement.strip():
            db.execute(statement)
    db.execute("INSERT INTO properties(id,name) VALUES('p1','بيت تجريبي')")
    db.execute("INSERT INTO tenants(id,full_name) VALUES('t1','مستأجر تجريبي')")
    db.execute("INSERT INTO units(id,property_id,unit_number,unit_type) VALUES('u1','p1','1','residential')")
    db.execute("""INSERT INTO leases(id,unit_id,tenant_id,start_date,duration_value,duration_unit,
        calculated_end_date,initial_rent_minor,annual_increase_percent,law_164_2025_applies)
        VALUES('l1','u1','t1','2026-01-31',1,'years','2027-01-31',25000,15,1)""")
    db.execute("""INSERT INTO rent_history(id,lease_id,amount_minor,valid_from,source_type,approval_status)
        VALUES('rh1','l1',25000,'2026-01-31','manual','approved')""")
    row = db.execute("SELECT l.id, t.full_name, rh.amount_minor FROM leases l JOIN tenants t ON t.id=l.tenant_id JOIN rent_history rh ON rh.lease_id=l.id").fetchone()
    assert row == ('l1', 'مستأجر تجريبي', 25000)
    assert db.execute('PRAGMA foreign_key_check').fetchall() == []
    db.close()


def test_lease_end_date_month_clamping_rule():
    # Mirrors the Dart date rule: Jan 31 + one month => Feb 28 (non-leap year).
    import calendar
    year, month, day = 2027, 2, 31
    last_day = calendar.monthrange(year, month)[1]
    assert min(day, last_day) == 28


def test_lease_status_and_duration_constraints():
    db = sqlite3.connect(':memory:')
    db.execute('PRAGMA foreign_keys=ON')
    for statement in SCHEMA.read_text(encoding='utf-8').split(';'):
        if statement.strip():
            db.execute(statement)
    db.execute("INSERT INTO properties(id,name) VALUES('p','P')")
    db.execute("INSERT INTO tenants(id,full_name) VALUES('t','T')")
    db.execute("INSERT INTO units(id,property_id) VALUES('u','p')")
    try:
        db.execute("INSERT INTO leases(id,unit_id,tenant_id,start_date,duration_value,duration_unit) VALUES('bad','u','t','2026-01-01',0,'years')")
        raise AssertionError('Expected duration CHECK constraint to reject zero')
    except sqlite3.IntegrityError:
        pass
    db.close()


if __name__ == '__main__':
    test_lease_and_rent_history_are_linked()
    test_lease_end_date_month_clamping_rule()
    test_lease_status_and_duration_constraints()
    print('Stage 5 lease tests: 3/3 passed')
