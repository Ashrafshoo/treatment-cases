"""Synthetic, non-personal SQLite fixture shared by the test suite."""
import sqlite3
from pathlib import Path


def create_test_db(path):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    c=sqlite3.connect(path)
    c.executescript('''
    PRAGMA foreign_keys=ON;
    CREATE TABLE Personnel(
      personnel_id INTEGER PRIMARY KEY AUTOINCREMENT,
      performance_number TEXT NOT NULL UNIQUE,
      full_name TEXT,job_title TEXT,region TEXT,department TEXT,mobile1 TEXT,mobile2 TEXT,
      national_id TEXT,gender TEXT,birth_date TEXT,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,updated_at TEXT DEFAULT CURRENT_TIMESTAMP,source_batch_id INTEGER,
      national_id_validation_status TEXT
    );
    CREATE TABLE Beneficiaries(
      beneficiary_id INTEGER PRIMARY KEY AUTOINCREMENT,source_batch_id INTEGER,source_sheet TEXT,source_row INTEGER,
      source_serial TEXT,region TEXT,department TEXT,full_name TEXT,performance_number TEXT,
      dispensing_duration TEXT,dosage_text TEXT,medical_condition TEXT,approval_date TEXT,
      original_row_json TEXT NOT NULL DEFAULT '{}'
    );
    CREATE TABLE Treatment_Entries(
      treatment_entry_id INTEGER PRIMARY KEY AUTOINCREMENT,
      beneficiary_id INTEGER NOT NULL REFERENCES Beneficiaries(beneficiary_id),
      treatment_order INTEGER NOT NULL,medicine_name_raw TEXT,strength_raw TEXT,source_field TEXT NOT NULL DEFAULT 'FIXTURE',
      UNIQUE(beneficiary_id,treatment_order)
    );
    CREATE TABLE Treatment_History(
      history_id INTEGER PRIMARY KEY AUTOINCREMENT,beneficiary_id INTEGER NOT NULL,treatment_order INTEGER,
      medicine_name_raw TEXT,strength_raw TEXT,dispensing_duration TEXT,dosage_text TEXT,medical_condition TEXT,
      approval_date TEXT,treatment_status TEXT DEFAULT 'STOPPED',status_note TEXT,
      started_or_imported_at TEXT DEFAULT CURRENT_TIMESTAMP,stopped_at TEXT,source_batch_id INTEGER,source_row_json TEXT
    );
    CREATE TABLE Import_Batches(
      batch_id INTEGER PRIMARY KEY,batch_name TEXT NOT NULL,source_file TEXT NOT NULL,source_sha256 TEXT NOT NULL,
      imported_at TEXT NOT NULL,source_note TEXT
    );
    CREATE TABLE Import_Batches_Ext(
      batch_id INTEGER PRIMARY KEY AUTOINCREMENT,
      batch_type TEXT NOT NULL CHECK(batch_type IN ('PERSONNEL','CRITICAL_CASES')),
      source_file TEXT NOT NULL,import_mode TEXT NOT NULL CHECK(import_mode IN ('FULL_SNAPSHOT','PARTIAL_UPDATE')),
      imported_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,submitted_by TEXT,preview_status TEXT NOT NULL DEFAULT 'PREVIEW',
      approval_status TEXT NOT NULL DEFAULT 'PENDING',approved_by TEXT,approved_at TEXT,summary_json TEXT,source_sha256 TEXT
    );
    CREATE TABLE Personnel_Import_Staging(
      staging_id INTEGER PRIMARY KEY AUTOINCREMENT,batch_id INTEGER NOT NULL,row_number INTEGER NOT NULL,
      performance_number TEXT,full_name TEXT,job_title TEXT,region TEXT,department TEXT,mobile1 TEXT,mobile2 TEXT,
      national_id TEXT,gender TEXT,validation_status TEXT NOT NULL DEFAULT 'PENDING',validation_message TEXT,row_json TEXT NOT NULL
    );
    CREATE TABLE Case_Import_Staging(
      staging_id INTEGER PRIMARY KEY AUTOINCREMENT,batch_id INTEGER NOT NULL,row_number INTEGER NOT NULL,
      performance_number TEXT,medicine_name_raw TEXT,strength_raw TEXT,dispensing_duration TEXT,dosage_text TEXT,
      medical_condition TEXT,approval_date TEXT,notes TEXT,validation_status TEXT NOT NULL DEFAULT 'PENDING',
      validation_message TEXT,row_json TEXT NOT NULL
    );
    CREATE TABLE Data_Audit_Log(
      audit_id INTEGER PRIMARY KEY AUTOINCREMENT,batch_id INTEGER,entity_type TEXT NOT NULL,entity_key TEXT NOT NULL,
      action TEXT NOT NULL,before_json TEXT,after_json TEXT,actor TEXT,action_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE Medicine_Dictionary_Source(medicine_name_raw TEXT);
    INSERT INTO Personnel(performance_number,full_name,job_title,region,department,national_id,gender,birth_date)
      VALUES('TEST-001','مستفيد تجريبي أول','موظف','القاهرة','إدارة تجريبية','29901011234567','ذكر','1999-01-01'),
            ('TEST-002','مستفيد تجريبي ثان','موظف','الجيزة','إدارة تجريبية',NULL,'أنثى','2000-02-02');
    INSERT INTO Beneficiaries(source_batch_id,source_sheet,source_row,region,department,full_name,performance_number,
      dispensing_duration,dosage_text,medical_condition,approval_date,original_row_json)
      VALUES(1,'FIXTURE',2,'القاهرة','إدارة تجريبية','مستفيد تجريبي أول','TEST-001','شهر','مرة يومياً','حالة تجريبية','2026-01-01','{}'),
            (1,'FIXTURE',3,'الجيزة','إدارة تجريبية','مستفيد تجريبي ثان','TEST-002',NULL,NULL,NULL,NULL,'{}');
    INSERT INTO Treatment_Entries(beneficiary_id,treatment_order,medicine_name_raw,strength_raw)
      VALUES(1,1,'دواء تجريبي','10 mg'),(1,2,'دواء ثان','20 mg');
    INSERT INTO Medicine_Dictionary_Source VALUES('دواء تجريبي'),('دواء ثان');
    INSERT INTO Treatment_History(beneficiary_id,treatment_order,medicine_name_raw,strength_raw,treatment_status,status_note)
      VALUES(1,3,'دواء قديم','5 mg','STOPPED','توقف سابقاً');
    CREATE VIEW v_Treatment_Export AS
      SELECT p.performance_number,p.full_name,p.job_title,p.region,p.department,p.mobile1,
        te.medicine_name_raw,te.strength_raw,te.treatment_order,b.dosage_text,b.dispensing_duration,
        b.medical_condition,b.approval_date,'ACTIVE' record_status
      FROM Treatment_Entries te JOIN Beneficiaries b USING(beneficiary_id)
      LEFT JOIN Personnel p ON p.performance_number=b.performance_number;
    CREATE VIEW v_Treatment_History_Export AS
      SELECT p.performance_number,p.full_name,p.job_title,p.region,p.department,p.mobile1,
        h.medicine_name_raw,h.strength_raw,h.treatment_order,h.dosage_text,h.dispensing_duration,
        h.medical_condition,h.approval_date,h.treatment_status record_status
      FROM Treatment_History h JOIN Beneficiaries b USING(beneficiary_id)
      LEFT JOIN Personnel p ON p.performance_number=b.performance_number;
    ''')
    c.commit(); c.close()
    return path
