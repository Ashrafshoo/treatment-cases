package com.familyproperties.app

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import net.zetetic.database.sqlcipher.SQLiteDatabase
import java.io.File
import java.util.UUID

/** Private app-internal document archive. The database stores metadata, never external file paths. */
class DocumentArchiveRepository(
    context: Context,
    private val database: FamilyDatabase,
    private val session: () -> AuthSession?
) {
    private val appContext = context.applicationContext
    private val archiveRoot = File(appContext.filesDir, "family_archive")

    data class ArchivedDocument(
        val id: String, val entityType: String, val entityId: String,
        val documentType: String?, val title: String, val mimeType: String?, val createdAt: String
    )

    fun importDocument(uri: Uri, entityType: String, entityId: String, title: String, documentType: String?): String {
        val actor = requireAdmin()
        require(entityType in ENTITY_TABLES) { "نوع السجل غير مدعوم" }
        require(entityId.isNotBlank() && title.isNotBlank()) { "يجب تحديد السجل وعنوان المستند" }
        val db = database.writableDatabase
        require(entityExists(db, entityType, entityId)) { "السجل المرتبط بالمستند غير موجود" }
        val id = UUID.randomUUID().toString()
        val mime = appContext.contentResolver.getType(uri) ?: "application/octet-stream"
        val extension = safeExtension(mime, appContext.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        })
        val targetDir = File(archiveRoot, id).apply { check(mkdirs() || isDirectory) }
        val target = File(targetDir, "document$extension")
        try {
            appContext.contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "تعذر قراءة الملف المحدد" }
                target.outputStream().use { output -> input.copyTo(output) }
            }
            require(target.length() > 0L) { "الملف فارغ" }
            db.beginTransaction()
            try {
                val values = ContentValues().apply {
                    put("id", id); put("entity_type", entityType); put("entity_id", entityId)
                    put("document_type", documentType); put("title", title.trim())
                    put("relative_path", "family_archive/$id/document$extension")
                    put("mime_type", mime); put("source_type", "manual")
                }
                db.insertOrThrow("documents", null, values)
                audit(db, actor.userId, id, "create", title.trim())
                db.setTransactionSuccessful()
            } finally { db.endTransaction() }
            return id
        } catch (error: Throwable) {
            targetDir.deleteRecursively()
            throw error
        }
    }

    fun list(entityType: String? = null, entityId: String? = null): List<ArchivedDocument> {
        val result = mutableListOf<ArchivedDocument>()
        val where = mutableListOf("archived_at IS NULL")
        val args = mutableListOf<String>()
        if (entityType != null) { where += "entity_type=?"; args += entityType }
        if (entityId != null) { where += "entity_id=?"; args += entityId }
        database.readableDatabase.rawQuery(
            "SELECT id,entity_type,entity_id,document_type,title,mime_type,created_at FROM documents WHERE ${where.joinToString(" AND ")} ORDER BY created_at DESC",
            args.toTypedArray()
        ).use { c -> while (c.moveToNext()) result += ArchivedDocument(c.getString(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getString(5),c.getString(6)) }
        return result
    }

    fun fileFor(documentId: String): File? {
        val relative = database.readableDatabase.rawQuery(
            "SELECT relative_path FROM documents WHERE id=? AND archived_at IS NULL", arrayOf(documentId)
        ).use { if (it.moveToFirst()) it.getString(0) else null } ?: return null
        val root = archiveRoot.canonicalFile
        val file = File(appContext.filesDir, relative).canonicalFile
        return file.takeIf { it.path.startsWith(root.path + File.separator) && it.isFile }
    }

    fun archive(documentId: String) {
        val actor = requireAdmin(); val db = database.writableDatabase
        db.beginTransaction()
        try {
            val title = db.rawQuery("SELECT title FROM documents WHERE id=? AND archived_at IS NULL", arrayOf(documentId)).use {
                if (it.moveToFirst()) it.getString(0) else throw IllegalArgumentException("المستند غير موجود")
            }
            db.execSQL("UPDATE documents SET archived_at=CURRENT_TIMESTAMP WHERE id=?", arrayOf(documentId))
            audit(db, actor.userId, documentId, "archive", title)
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    private fun requireAdmin() = session()?.takeIf { it.isAdministrator }
        ?: throw SecurityException("هذه العملية متاحة للمدير فقط")

    private fun entityExists(db: SQLiteDatabase, type: String, id: String): Boolean =
        db.rawQuery("SELECT 1 FROM ${ENTITY_TABLES.getValue(type)} WHERE id=? AND archived_at IS NULL", arrayOf(id)).use { it.moveToFirst() }

    private fun audit(db: SQLiteDatabase, userId: String, id: String, action: String, title: String) {
        val values = ContentValues().apply {
            put("id", UUID.randomUUID().toString()); put("user_id", userId)
            put("entity_type", "document"); put("entity_id", id); put("action", action)
            put("after_json", "{\"title\":\"${title.replace("\\", "\\\\").replace("\"", "\\\"")}\"}")
        }
        db.insertOrThrow("audit_log", null, values)
    }

    private fun safeExtension(mime: String, displayName: String?): String {
        val candidate = displayName?.substringAfterLast('.', "")?.lowercase()?.takeIf { it.matches(Regex("[a-z0-9]{1,8}")) }
        if (candidate != null) return ".$candidate"
        return when (mime) { "application/pdf" -> ".pdf"; "image/jpeg" -> ".jpg"; "image/png" -> ".png"; else -> ".bin" }
    }

    companion object {
        private val ENTITY_TABLES = mapOf("property" to "properties", "unit" to "units", "tenant" to "tenants", "lease" to "leases", "receipt" to "receipts", "owner" to "owners")
    }
}
