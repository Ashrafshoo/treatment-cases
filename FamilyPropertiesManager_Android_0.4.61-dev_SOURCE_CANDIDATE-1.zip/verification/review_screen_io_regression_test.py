from pathlib import Path
root = Path(__file__).resolve().parents[1]
s = (root / 'app/src/main/java/com/example/rentals/features/review/ReviewScreen.kt').read_text(encoding='utf-8')
checks = {
    'review screen uses coroutine IO dispatcher': 'withContext(Dispatchers.IO)' in s,
    'review loading is lifecycle-bound': 'LaunchedEffect(refresh,search,statusFilter,typeFilter,units)' in s,
    'loading state is visible': 'if(loading) LinearProgressIndicator' in s,
    'load errors are shown instead of crashing silently': 'تعذر تحميل مركز المراجعة:' in s,
    'heavy source analyzers run in background load': 'LegacyReceiptMatchAnalyzer.analyze(allRecords)' in s and 'LegacyUnitReviewAnalyzer.analyze' in s,
}
for name, ok in checks.items(): print(('PASS' if ok else 'FAIL') + ' - ' + name)
assert all(checks.values()), 'Review screen IO regression'
print(f'{len(checks)}/{len(checks)} checks passed')
