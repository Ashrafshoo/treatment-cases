import http.client, tempfile, threading, unittest
from pathlib import Path
from http.server import ThreadingHTTPServer
from urllib.parse import urlencode
import app, security, management

class AuthRouteTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(); self.old=app.AUTH_DB; self.old_db=app.DB
  app.AUTH_DB=Path(self.tmp.name)/'auth.sqlite3'; app.DB=Path(self.tmp.name)/'med.db'
  import sqlite3
  c=sqlite3.connect(app.DB)
  c.executescript("""
  CREATE TABLE Personnel(personnel_id INTEGER PRIMARY KEY,performance_number TEXT NOT NULL UNIQUE,full_name TEXT,job_title TEXT,region TEXT,department TEXT,mobile1 TEXT,mobile2 TEXT,national_id TEXT,gender TEXT,birth_date TEXT,updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
  CREATE TABLE Beneficiaries(beneficiary_id INTEGER PRIMARY KEY,performance_number TEXT,full_name TEXT,region TEXT,department TEXT);
  CREATE TABLE Treatment_Entries(treatment_entry_id INTEGER PRIMARY KEY);
  CREATE TABLE Import_Batches(batch_id INTEGER PRIMARY KEY,batch_name TEXT,source_file TEXT,source_sha256 TEXT,imported_at TEXT,source_note TEXT);
  CREATE TABLE Data_Audit_Log(audit_id INTEGER PRIMARY KEY,entity_type TEXT,entity_key TEXT,action TEXT,before_json TEXT,after_json TEXT,actor TEXT,action_at TEXT DEFAULT CURRENT_TIMESTAMP);
  CREATE VIEW v_Treatment_Export AS SELECT 'TestMed' AS medicine_name_raw, 1 AS n;
  """)
  c.close()
  security.initialize(app.AUTH_DB); management.initialize(app.DB)
  uid=security.create_user(app.AUTH_DB,'viewer','قارئ','Strong-Viewer-Password-2026','viewer')
  self.server=ThreadingHTTPServer(('127.0.0.1',0),app.Handler)
  self.thread=threading.Thread(target=self.server.serve_forever,daemon=True); self.thread.start()
  self.conn=http.client.HTTPConnection('127.0.0.1',self.server.server_port)
 def tearDown(self):
  self.conn.close(); self.server.shutdown(); self.server.server_close(); self.thread.join(timeout=2)
  app.AUTH_DB=self.old; app.DB=self.old_db; self.tmp.cleanup()
 def test_requires_login_and_allows_authenticated_dashboard(self):
  self.conn.request('GET','/')
  r=self.conn.getresponse(); self.assertEqual(r.status,303); self.assertEqual(r.getheader('Location'),'/login'); r.read()
  body=urlencode({'username':'viewer','password':'Strong-Viewer-Password-2026'})
  self.conn.request('POST','/login',body,{'Content-Type':'application/x-www-form-urlencoded'})
  r=self.conn.getresponse(); self.assertEqual(r.status,303); cookie=r.getheader('Set-Cookie'); self.assertIn('HttpOnly',cookie); r.read()
  self.conn.request('GET','/',headers={'Cookie':cookie.split(';',1)[0]})
  r=self.conn.getresponse(); self.assertEqual(r.status,200); self.assertIn('لوحة متابعة'.encode(),r.read())
 def test_viewer_cannot_export(self):
  body=urlencode({'username':'viewer','password':'Strong-Viewer-Password-2026'})
  self.conn.request('POST','/login',body,{'Content-Type':'application/x-www-form-urlencoded'})
  r=self.conn.getresponse(); cookie=r.getheader('Set-Cookie').split(';',1)[0]; r.read()
  self.conn.request('GET','/export.xlsx',headers={'Cookie':cookie})
  r=self.conn.getresponse(); self.assertEqual(r.status,403); r.read()


 def test_manager_can_add_person_with_csrf_and_audit(self):
  security.create_user(app.AUTH_DB,'admin','مدير','Strong-Admin-Password-2026','manager')
  body=urlencode({'username':'admin','password':'Strong-Admin-Password-2026'})
  self.conn.request('POST','/login',body,{'Content-Type':'application/x-www-form-urlencoded'})
  r=self.conn.getresponse(); cookie=r.getheader('Set-Cookie').split(';',1)[0]; r.read()
  token=cookie.split('=',1)[1]
  import hashlib
  csrf=hashlib.sha256(('csrf:'+token).encode()).hexdigest()
  payload=urlencode({'csrf':csrf,'performance_number':'ROUTE-TEST-1','full_name':'اختبار واجهة','region':'اختبار'})
  self.conn.request('POST','/person/save',payload,{'Content-Type':'application/x-www-form-urlencoded','Cookie':cookie})
  r=self.conn.getresponse(); self.assertEqual(r.status,303); self.assertIn('/person/ROUTE-TEST-1',r.getheader('Location')); r.read()
  import sqlite3
  c=sqlite3.connect(app.DB)
  self.assertEqual(c.execute("select full_name from Personnel where performance_number='ROUTE-TEST-1'").fetchone()[0],'اختبار واجهة')
  self.assertEqual(c.execute("select count(*) from Data_Audit_Log where entity_key='ROUTE-TEST-1'").fetchone()[0],1)
  c.close()

 def test_post_without_csrf_is_rejected(self):
  security.create_user(app.AUTH_DB,'admin','مدير','Strong-Admin-Password-2026','manager')
  body=urlencode({'username':'admin','password':'Strong-Admin-Password-2026'})
  self.conn.request('POST','/login',body,{'Content-Type':'application/x-www-form-urlencoded'})
  r=self.conn.getresponse(); cookie=r.getheader('Set-Cookie').split(';',1)[0]; r.read()
  payload=urlencode({'performance_number':'NO-CSRF','full_name':'غير مسموح'})
  self.conn.request('POST','/person/save',payload,{'Content-Type':'application/x-www-form-urlencoded','Cookie':cookie})
  r=self.conn.getresponse(); self.assertEqual(r.status,403); r.read()

if __name__=='__main__': unittest.main()
