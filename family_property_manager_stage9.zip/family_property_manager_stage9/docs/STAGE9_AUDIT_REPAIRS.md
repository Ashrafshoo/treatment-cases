# Stage 9 – Audit repair notes

## Changes in this repair

1. `ReportsRepository.monthlyRentStatement`
   - The monthly due amount now comes from the latest approved rent-history row valid for the selected month, falling back to the lease's initial rent.
   - Pending `under_review` rent-history rows are exposed separately as `has_pending_rent_review`; they no longer force the due amount to zero.
   - Historical visibility is based on the lease start/end dates. Leases currently marked `ended` or `terminated` remain reportable for months that overlap their contractual dates. `suspended` leases remain excluded because the current schema does not store suspension/resumption effective dates.

2. `LeaseScheduleService.refresh`
   - The generic `none` / `manual_dates` rule now blocks only generic annual increases.
   - Residential Law 164 schedules use the configured 15% September rule independently of that generic setting.
   - The Law 164 automatic branch remains residential-only; commercial units do not receive the residential 15% automatic rule or the residential minimum-rent rule through this branch.

## Verification

- Python/SQLite test suite: **35 passed**.
- Added regression tests for pending rent review, historical ended/terminated leases, and Law 164 residential schedule gating.
- These tests exercise SQLite behavior and inspect the Dart source condition. They are not a substitute for Dart/Flutter tests or an Android device test.
- Flutter/Dart toolchains are not available in the current execution environment; `flutter pub get`, `dart format`, `flutter analyze`, `flutter test`, and APK build/signing were not run.

## Remaining limitations

This repair does not complete the production-readiness items identified in the audit: SQLCipher/live database encryption, Android Keystore key protection, biometric login, scheduled Android notifications, device-to-device merge/synchronization, legacy XLS import, remaining reports/charts, final navy-and-gold visual identity, and real-device PDF/printing tests.
