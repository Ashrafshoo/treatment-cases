package com.medref.drugs

import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.google.android.material.card.MaterialCardView
import com.google.android.material.chip.Chip
import com.google.android.material.color.MaterialColors

/**
 * الدواء ← التركيز: اسم الدواء في الأعلى، ومربع بحث مستقل لاختيار التركيز/الشكل/العبوة،
 * وعند الاختيار تُفتح بياناته كاملة وما ارتبط به (المحذوف القديم، التكرار، المتشابه).
 */
class FamilyActivity : BaseActivity() {

    private lateinit var db: Db
    private lateinit var list: LinearLayout
    private lateinit var info: TextView
    private lateinit var showRemoved: Chip
    private lateinit var search: EditText
    private var family = ""
    private var scope = Scope.CURATED
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        family = intent.getStringExtra("family") ?: ""
        scope = try { Scope.valueOf(intent.getStringExtra("scope") ?: "CURATED") } catch (e: Exception) { Scope.CURATED }
        db = Db.get(this)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = "الدواء ← التركيز"

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        box.addView(TextView(this).apply {
            text = family
            textSize = 22f
            setTypeface(typeface, Typeface.BOLD)
            textDirection = View.TEXT_DIRECTION_LTR
            textAlignment = View.TEXT_ALIGNMENT_VIEW_START
            setTextIsSelectable(true)
        })
        info = TextView(this).apply { textSize = 12f; alpha = 0.75f; setPadding(0, dp(2), 0, dp(8)) }
        box.addView(info)

        val strengths = db.strengths(family)
        if (strengths.isNotEmpty()) {
            val hs = android.widget.HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (st in listOf("") + strengths) {
                val c = layoutInflater.inflate(R.layout.chip_filter, row, false) as Chip
                c.text = if (st.isEmpty()) "كل القوى" else st
                c.setOnClickListener { search.setText(st) }
                row.addView(c)
            }
            hs.addView(row)
            box.addView(hs)
        }

        search = EditText(this).apply {
            hint = "ابحث في التراكيز والعبوات: 500 / شراب / 10 أقراص…"
            maxLines = 1
            inputType = android.text.InputType.TYPE_CLASS_TEXT
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) { query = s?.toString() ?: ""; render() }
            })
        }
        box.addView(search, LinearLayout.LayoutParams(MATCH, WRAP))

        showRemoved = (layoutInflater.inflate(R.layout.chip_filter, null, false) as Chip).apply {
            text = "إظهار المحذوف والمتشابه أيضًا"
            setOnCheckedChangeListener { _, _ -> render() }
        }
        box.addView(showRemoved)

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(list, LinearLayout.LayoutParams(MATCH, WRAP))
        setContentView(ScrollView(this).apply { addView(box) })
        render()
    }

    private var query = ""

    override fun onResume() {
        super.onResume()
        if (::list.isInitialized) render()
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    private fun render() {
        list.removeAllViews()
        // «الأصلية» هنا تعني «بلا قيد قسم» (جدول القائمة العاملة كاملًا) لإظهار المحذوف أيضًا.
        val items = db.variants(family, if (showRemoved.isChecked) Scope.ORIGINAL else scope, query)
        info.text = "${items.size} تركيز/عبوة" + if (query.isNotBlank()) " (بعد البحث)" else ""
        val primary = Ui.primary(this)
        for (item in items) {
            val c = MaterialCardView(this).apply {
                layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6) }
            }
            Ui.styleCard(c)
            val inner = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(10), dp(12), dp(10))
            }
            inner.addView(TextView(this).apply {
                text = "${item.code} · ${item.nameEn.ifBlank { item.nameAr }}"
                textSize = 15f
                setTypeface(typeface, Typeface.BOLD)
                textDirection = View.TEXT_DIRECTION_LTR
                textAlignment = View.TEXT_ALIGNMENT_VIEW_START
            })
            inner.addView(TextView(this).apply {
                text = item.nameAr
                textSize = 13f
                alpha = 0.85f
                textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            })
            val parts = ArrayList<String>()
            parts += Labels.status[item.status] ?: item.status
            if (item.decision == "remove") parts += "محذوف من المحدّثة"
            if (item.concentration.isNotBlank()) parts += item.concentration
            if (item.dosageForm.isNotBlank()) parts += item.dosageForm
            if (item.therapeuticClass.isNotBlank() && item.therapeuticClass != "غير محدد") parts += item.therapeuticClass
            if (item.rel > 0) parts += "🔗 ${item.rel} مرتبط"
            inner.addView(TextView(this).apply {
                text = parts.joinToString(" • ")
                textSize = 12f
                alpha = 0.75f
                setPadding(0, dp(4), 0, 0)
                if (item.decision == "remove") setTextColor(0xFFC62828.toInt())
                else if (item.rel > 0) setTextColor(primary)
            })
            c.addView(inner)
            val code = item.code
            c.isClickable = true
            c.setOnClickListener {
                startActivity(Intent(this, DetailActivity::class.java).putExtra("code", code))
            }
            list.addView(c)
        }
        Ui.style(window.decorView)
        finishUi()
    }
}
