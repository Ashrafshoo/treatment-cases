-- Stage 27: indexes for safe document archive browsing and entity lookups.
CREATE INDEX IF NOT EXISTS idx_documents_entity_active
  ON documents(entity_type, entity_id, archived_at, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_documents_type_active
  ON documents(document_type, archived_at);
INSERT OR IGNORE INTO schema_migrations(version,name)
VALUES (8,'stage27_archive_indexes');
