from pathlib import Path

source = Path(__file__).resolve().parents[1] / "app/src/main/java/com/example/rentals/MainActivity.kt"
text = source.read_text(encoding="utf-8")

assert 'IconButton(onClick={editingProperty=p}){Icon(Icons.Default.Edit,"تعديل العقار")}' in text
assert 'IconButton(onClick={editingTenant=t}){Icon(Icons.Default.Edit,"تعديل بيانات المستأجر")}' in text
assert 'IconButton(onClick={editingProperty=p){' not in text
assert 'IconButton(onClick={editingTenant=t){' not in text

# Lightweight lexical delimiter check. Strings/comments are skipped; this is a
# regression guard for the exact missing-brace class, not a Kotlin compiler.
stack = []
i = 0
line = 1
state = "code"
while i < len(text):
    c = text[i]
    n = text[i + 1] if i + 1 < len(text) else ""
    if c == "\n":
        line += 1
    if state == "code":
        if c == "/" and n == "/":
            state = "line"; i += 2; continue
        if c == "/" and n == "*":
            state = "block"; i += 2; continue
        if c == '"':
            state = "string"; i += 1; continue
        if c == "'":
            state = "char"; i += 1; continue
        if c == "{":
            stack.append(line)
        elif c == "}":
            assert stack, f"Extra closing brace at line {line}"
            stack.pop()
    elif state == "line":
        if c == "\n": state = "code"
    elif state == "block":
        if c == "*" and n == "/": state = "code"; i += 2; continue
    elif state == "string":
        if c == "\\": i += 2; continue
        if c == '"': state = "code"
    elif state == "char":
        if c == "\\": i += 2; continue
        if c == "'": state = "code"
    i += 1

assert not stack, f"Unclosed braces at lines {stack}"
print("PASS: entity edit click lambdas are closed correctly and MainActivity braces are balanced.")
