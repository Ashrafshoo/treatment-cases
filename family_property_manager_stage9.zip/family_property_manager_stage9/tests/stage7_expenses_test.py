import sqlite3
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SCHEMA=ROOT/'app'/'assets'/'database'/'001_initial_schema.sql'

def test_general_expenses_and_archive():
    db=sqlite3.connect(':memory:')
    for statement in SCHEMA.read_text(encoding='utf-8').split(';'):
        if statement.strip(): db.execute(statement)
    db.execute("INSERT INTO expenses(id,name,amount_minor,expense_date,notes) VALUES('e1','فاتورة كهرباء',125000,'2026-11-01','فاتورة عامة')")
    assert db.execute("SELECT name,amount_minor FROM expenses WHERE archived_at IS NULL").fetchone()==('فاتورة كهرباء',125000)
    db.execute("UPDATE expenses SET archived_at='2026-11-09' WHERE id='e1'")
    assert db.execute("SELECT COUNT(*) FROM expenses WHERE archived_at IS NULL").fetchone()[0]==0
    assert db.execute("SELECT COUNT(*) FROM expenses WHERE id='e1'").fetchone()[0]==1
    db.close()

if __name__=='__main__':
    test_general_expenses_and_archive()
    print('Stage 7 expense tests: 1/1 passed')
