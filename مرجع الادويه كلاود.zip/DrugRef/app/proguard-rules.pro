# لا قواعد خاصة: المشروع لا يستخدم الانعكاس (reflection)، ومكتبات AndroidX/Material تضيف قواعدها تلقائيًا.
-dontwarn org.jetbrains.annotations.**
