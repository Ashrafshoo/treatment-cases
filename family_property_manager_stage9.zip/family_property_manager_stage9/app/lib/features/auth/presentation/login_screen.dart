import 'package:flutter/material.dart';
import '../data/auth_repository.dart';
import '../data/biometric_auth_service.dart';
import '../../dashboard/presentation/dashboard_screen.dart';

class LoginScreen extends StatefulWidget {const LoginScreen({super.key});@override State<LoginScreen> createState()=>_LoginScreenState();}
class _LoginScreenState extends State<LoginScreen>{
  final _repo=AuthRepository();final _username=TextEditingController(text:'Ashrafshoo');final _password=TextEditingController();final _confirm=TextEditingController();
  bool _loading=true,_setup=false,_obscure=true;
  @override void initState(){super.initState();_check();}
  @override void dispose(){_username.dispose();_password.dispose();_confirm.dispose();super.dispose();}
  Future<void> _check() async {try{final has=await _repo.hasUsers();if(mounted)setState(()=>_setup=!has);}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تعذر فتح قاعدة البيانات: $e')));}finally{if(mounted)setState(()=>_loading=false);}}
  Future<void> _biometricLogin() async {
    setState(() => _loading = true);
    try {
      final username = await BiometricAuthService.instance.authenticate();
      if (username == null) return;
      final ok = await _repo.signInWithBiometric(username);
      if (!ok) throw StateError('الحساب المرتبط بالبصمة غير متاح؛ استخدم كلمة المرور');
      if (mounted) {
        await Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => const DashboardScreen()));
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر الدخول بالبصمة: $e')));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _submit() async {if(_password.text.isEmpty)return;setState(()=>_loading=true);try{if(_setup){await _repo.createInitialAdmin(password:_password.text,confirm:_confirm.text);final ok=await _repo.signIn('Ashrafshoo',_password.text);if(!ok)throw StateError('تعذر بدء جلسة المدير');}else{final ok=await _repo.signIn(_username.text,_password.text);if(!ok)throw StateError('اسم المستخدم أو كلمة المرور غير صحيحة');}if(mounted){_password.clear();_confirm.clear();await Navigator.of(context).push(MaterialPageRoute<void>(builder:(_)=>const DashboardScreen()));}}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تعذر المتابعة: $e')));}finally{if(mounted)setState(()=>_loading=false);}}
  @override Widget build(BuildContext context){final colors=Theme.of(context).colorScheme;return Scaffold(body:SafeArea(child:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(24),child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:440),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[Container(height:88,width:88,alignment:Alignment.center,decoration:BoxDecoration(color:colors.primary,borderRadius:BorderRadius.circular(26)),child:const Icon(Icons.apartment_rounded,color:Colors.white,size:46)),const SizedBox(height:26),Text('إدارة أملاك العائلة',style:Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight:FontWeight.bold)),const SizedBox(height:8),Text(_setup?'إنشاء كلمة مرور المدير لأول مرة':'تسجيل الدخول إلى حسابك',style:Theme.of(context).textTheme.bodyLarge),const SizedBox(height:30),if(!_setup)TextField(controller:_username,decoration:const InputDecoration(labelText:'اسم المستخدم',prefixIcon:Icon(Icons.person_outline))),if(!_setup)const SizedBox(height:14),TextField(controller:_password,obscureText:_obscure,decoration:InputDecoration(labelText:_setup?'كلمة مرور المدير الجديدة':'كلمة المرور',prefixIcon:const Icon(Icons.lock_outline),suffixIcon:IconButton(onPressed:()=>setState(()=>_obscure=!_obscure),icon:Icon(_obscure?Icons.visibility_outlined:Icons.visibility_off_outlined)))),if(_setup)const SizedBox(height:14),if(_setup)TextField(controller:_confirm,obscureText:true,decoration:const InputDecoration(labelText:'تأكيد كلمة المرور',prefixIcon:Icon(Icons.verified_user_outlined))),if(_setup)const Padding(padding:EdgeInsets.only(top:8),child:Text('اسم المدير الأول ثابت: Ashrafshoo. اختر كلمة مرور قوية لا تقل عن 10 أحرف.',style:TextStyle(fontSize:12))),const SizedBox(height:24),FilledButton(onPressed:_loading?null:_submit,style:FilledButton.styleFrom(padding:const EdgeInsets.symmetric(vertical:16)),child:_loading?const SizedBox(height:20,width:20,child:CircularProgressIndicator(strokeWidth:2)):Text(_setup?'إنشاء حساب المدير والدخول':'تسجيل الدخول')),if(!_setup)FutureBuilder<bool>(future:BiometricAuthService.instance.isEnabled,builder:(context,snapshot)=>snapshot.data==true?Padding(padding:const EdgeInsets.only(top:10),child:OutlinedButton.icon(onPressed:_loading?null:_biometricLogin,icon:const Icon(Icons.fingerprint),label:const Text('الدخول بالبصمة'))):const SizedBox.shrink()),const SizedBox(height:18),const Text('كلمات المرور تُحفظ بصيغة مشتقة PBKDF2، وقاعدة البيانات محمية بتشفير SQLCipher ومفتاح محفوظ في التخزين الآمن للجهاز.',textAlign:TextAlign.center,style:TextStyle(fontSize:12))]))))));}
}
