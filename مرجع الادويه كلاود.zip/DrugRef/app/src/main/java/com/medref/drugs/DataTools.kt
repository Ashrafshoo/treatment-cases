package com.medref.drugs

import android.net.Uri
import android.widget.Toast
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.io.File

object Csv {
    fun parse(text: String, delim: Char): List<List<String>> {
        val rows = ArrayList<List<String>>()
        var row = ArrayList<String>()
        val sb = StringBuilder()
        var inQ = false
        var i = 0
        while (i < text.length) {
            val c = text[i]
            if (inQ) {
                if (c == '"') {
                    if (i + 1 < text.length && text[i + 1] == '"') { sb.append('"'); i++ } else inQ = false
                } else sb.append(c)
            } else if (c == '"') {
                inQ = true
            } else if (c == delim) {
                row.add(sb.toString()); sb.setLength(0)
            } else if (c == '\n') {
                row.add(sb.toString()); sb.setLength(0)
                rows.add(row); row = ArrayList()
            } else if (c != '\r') {
                sb.append(c)
            }
            i++
        }
        if (sb.isNotEmpty() || row.isNotEmpty()) { row.add(sb.toString()); rows.add(row) }
        return rows
    }
}

object DataTools {

    fun showMenu(a: BaseActivity) {
        val items = arrayOf(
            "تصدير الكل — CSV قابل للتعديل ثم الاستيراد",
            "تصدير الكل — Excel (.xlsx)",
            "تصدير المحدّثة فقط (CSV)",
            "تصدير الأجهزة التعويضية (CSV)",
            "تصدير المحذوفة (CSV)",
            "تصدير الأصلية — للمقارنة فقط (CSV)",
            "تصدير سجل التعديلات (CSV)",
            "تقرير PDF بالتقدم وآخر التعديلات",
            "تصدير الأكواد الناقصة من التسلسل",
            "نسخة احتياطية كاملة (.db)",
            "استيراد تعديلات من ملف CSV",
            "استعادة نسخة احتياطية (.db)"
        )
        val xlsx = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        MaterialAlertDialogBuilder(a)
            .setTitle("تصدير واستيراد")
            .setItems(items) { _, i ->
                val db = Db.get(a)
                when (i) {
                    0 -> export(a, "text/csv") { Share.exportAll(a, db) }
                    1 -> export(a, xlsx) { Share.exportAllXlsx(a, db) }
                    2 -> export(a, "text/csv") { Share.exportItems(a, db, Scope.CURATED) }
                    3 -> export(a, "text/csv") { Share.exportItems(a, db, Scope.DEVICES) }
                    4 -> export(a, "text/csv") { Share.exportItems(a, db, Scope.REMOVED) }
                    5 -> export(a, "text/csv") { Share.exportItems(a, db, Scope.ORIGINAL) }
                    6 -> export(a, "text/csv") { Share.exportLog(a, db) }
                    7 -> export(a, "application/pdf") { Share.exportPdf(a, db) }
                    8 -> export(a, "text/csv") { Share.exportMissing(a, db) }
                    9 -> export(a, "application/octet-stream") { Share.backup(a) }
                    10 -> explainImport(a)
                    11 -> a.openDbPicker()
                }
            }
            .showStyled()
    }

    private fun export(a: BaseActivity, mime: String, make: () -> File) {
        Thread {
            try {
                val f = make()
                a.runOnUiThread { Share.file(a, f, mime, "تصدير") }
            } catch (e: Exception) {
                a.runOnUiThread { Toast.makeText(a, "تعذر التصدير: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private fun explainImport(a: BaseActivity) {
        MaterialAlertDialogBuilder(a)
            .setTitle("استيراد تعديلات")
            .setMessage(
                "1) صدّر «الكل» وعدّله في Excel.\n" +
                    "2) لا تغيّر عمودي item_code و name_en: الكود ملتصق باسمه الأجنبي، وأي صف لا يتطابق فيه الاثنان يُرفض.\n" +
                    "3) احفظ بصيغة CSV UTF-8 ثم اخترها هنا.\n\n" +
                    "تُطبَّق التعديلات على الأعمدة الموجودة فقط، وكل تغيير يُسجَّل في سجل الصنف."
            )
            .setPositiveButton("اختيار الملف") { _, _ -> a.openCsvPicker() }
            .setNegativeButton("إلغاء", null)
            .showStyled()
    }

    fun importCsv(a: BaseActivity, uri: Uri) {
        val db = Db.get(a)
        Thread {
            try {
                val bytes = a.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    ?: throw IllegalStateException("تعذر فتح الملف")
                var text = bytes.toString(Charsets.UTF_8).removePrefix("\uFEFF")
                if (text.count { it == '\uFFFD' } > 5) {
                    throw IllegalStateException("ترميز الملف غير UTF-8 — احفظه بصيغة CSV UTF-8")
                }
                val first = text.lineSequence().firstOrNull() ?: ""
                val delim = listOf(',', ';', '\t').maxByOrNull { d -> first.count { it == d } } ?: ','
                val table = Csv.parse(text, delim)
                if (table.size < 2) throw IllegalStateException("الملف فارغ")
                val header = table[0].map { it.trim().lowercase() }
                if (!header.contains("item_code")) throw IllegalStateException("لا يوجد عمود item_code")
                val rows = table.drop(1).filter { r -> r.any { it.isNotBlank() } }.map { r ->
                    header.indices.associate { i -> header[i] to (r.getOrNull(i) ?: "") }
                }
                text = ""
                val res = db.importRows(rows)
                a.runOnUiThread {
                    a.onDataChanged()
                    showImportResult(a, res)
                }
            } catch (e: Exception) {
                a.runOnUiThread { Toast.makeText(a, "تعذر الاستيراد: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    private fun showImportResult(a: BaseActivity, r: ImportResult) {
        val sb = StringBuilder()
        sb.append("تم تعديل: ${r.updated}\n")
        sb.append("بلا تغيير: ${r.unchanged}\n")
        if (r.rejected > 0) {
            sb.append("مرفوض (الاسم الأجنبي لا يطابق الكود): ${r.rejected}\n")
            sb.append("أمثلة: ${r.rejectedCodes.joinToString("، ")}\n")
        }
        if (r.unknown > 0) sb.append("أكواد غير موجودة: ${r.unknown}\n")
        if (r.invalid > 0) sb.append("قيم غير صالحة: ${r.invalid}\n")
        MaterialAlertDialogBuilder(a)
            .setTitle("نتيجة الاستيراد")
            .setMessage(sb.toString().trim())
            .setPositiveButton("حسنًا", null)
            .showStyled()
    }

    fun restoreBackup(a: BaseActivity, uri: Uri) {
        MaterialAlertDialogBuilder(a)
            .setTitle("استعادة نسخة احتياطية؟")
            .setMessage("ستُستبدل كل بياناتك الحالية (التعديلات والسجل) بمحتوى النسخة. يُنصح بتصدير نسخة احتياطية أولًا.")
            .setPositiveButton("استعادة") { _, _ ->
                Thread {
                    val ok = try {
                        val tmp = File(a.cacheDir, "restore.db")
                        a.contentResolver.openInputStream(uri)?.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                        Db.replaceWith(a, tmp).also { tmp.delete() }
                    } catch (e: Exception) { false }
                    a.runOnUiThread {
                        if (ok) {
                            Toast.makeText(a, "تمت الاستعادة", Toast.LENGTH_SHORT).show()
                            a.onDataChanged()
                        } else {
                            Toast.makeText(a, "الملف ليس نسخة احتياطية صالحة لهذا الإصدار", Toast.LENGTH_LONG).show()
                        }
                    }
                }.start()
            }
            .setNegativeButton("إلغاء", null)
            .showStyled()
    }
}
