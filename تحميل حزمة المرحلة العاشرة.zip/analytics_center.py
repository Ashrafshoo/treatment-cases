"""Read-only alerts and management analytics for the medication database."""
from __future__ import annotations
import sqlite3
from pathlib import Path
from datetime import date, datetime, timedelta
from collections import Counter


def connect(db_path):
    c=sqlite3.connect(f'file:{Path(db_path).resolve()}?mode=ro', uri=True)
    c.row_factory=sqlite3.Row
    c.execute('PRAGMA query_only=ON')
    return c


def _columns(c, table):
    return {r['name'] for r in c.execute(f'PRAGMA table_info("{table}")')}


def _parse_date(value):
    if value is None or not str(value).strip():
        return None
    s=str(value).strip()
    for fmt in ('%Y-%m-%d','%Y/%m/%d','%d/%m/%Y','%d-%m-%Y','%Y-%m-%d %H:%M:%S','%d-%m-%y'):
        try: return datetime.strptime(s,fmt).date()
        except ValueError: pass
    try: return datetime.fromisoformat(s.replace('Z','+00:00')).date()
    except ValueError: return None


def alerts(db_path, today=None, near_days=30):
    today=today or date.today()
    c=connect(db_path); items=[]
    try:
        pcols=_columns(c,'Personnel'); bcols=_columns(c,'Beneficiaries')
        tcols=_columns(c,'Treatment_Entries')
        people=c.execute('SELECT performance_number,full_name FROM Personnel').fetchall()
        beneficiaries=c.execute('SELECT * FROM Beneficiaries').fetchall()
        personnel={str(r['performance_number']).strip():r for r in people if r['performance_number']}
        by_perf={str(r['performance_number']).strip():r for r in beneficiaries if r['performance_number']}
        for perf,p in personnel.items():
            b=by_perf.get(perf)
            if not b:
                items.append({'severity':'info','code':'NO_TREATMENT_FILE','title':'عامل بلا ملف علاج','performance_number':perf,'name':p['full_name'],'detail':'لا يوجد ملف مستفيد مرتبط به في جدول الحالات.'})
                continue
            treatments=c.execute('SELECT medicine_name_raw,strength_raw FROM Treatment_Entries WHERE beneficiary_id=?',(b['beneficiary_id'],)).fetchall()
            if not treatments:
                items.append({'severity':'warning','code':'NO_ACTIVE_TREATMENT','performance_number':perf,'name':p['full_name'],'title':'ملف بلا علاج حالي','detail':'يوجد ملف مستفيد لكن لا توجد سجلات علاج حالية.'})
            approval=b['approval_date'] if 'approval_date' in bcols else None
            if not approval or not str(approval).strip():
                items.append({'severity':'warning','code':'MISSING_APPROVAL_DATE','performance_number':perf,'name':p['full_name'],'title':'تاريخ الموافقة مفقود','detail':'يجب مراجعة مستند الموافقة وإدخال التاريخ الصحيح.'})
            elif _parse_date(approval) is None:
                items.append({'severity':'warning','code':'INVALID_APPROVAL_DATE','performance_number':perf,'name':p['full_name'],'title':'تاريخ الموافقة غير مفهوم','detail':f'القيمة المسجلة: {approval}'})
            if not (b['full_name'] or p['full_name']):
                items.append({'severity':'warning','code':'MISSING_NAME','performance_number':perf,'name':'','title':'الاسم مفقود','detail':'سجل المستفيد لا يحتوي اسمًا.'})
            for t in treatments:
                if not (t['medicine_name_raw'] or '').strip():
                    items.append({'severity':'warning','code':'MISSING_MEDICINE','performance_number':perf,'name':p['full_name'],'title':'اسم العلاج مفقود','detail':'يوجد موضع علاج دون اسم دواء.'})
                if not (t['strength_raw'] or '').strip():
                    items.append({'severity':'info','code':'MISSING_STRENGTH','performance_number':perf,'name':p['full_name'],'title':'تركيز العلاج غير مسجل','detail':str(t['medicine_name_raw'] or 'علاج غير محدد')})
        for perf,b in by_perf.items():
            if perf not in personnel:
                items.append({'severity':'warning','code':'ORPHAN_BENEFICIARY','performance_number':perf,'name':b['full_name'],'title':'ملف دون سجل عامل مطابق','detail':'رقم الأداء غير موجود في جدول العاملين.'})
        # Duplicate treatment entries are checked after whitespace/case normalization.
        dup=c.execute('''SELECT b.performance_number, b.full_name, lower(trim(coalesce(te.medicine_name_raw,''))) med,
                         lower(trim(coalesce(te.strength_raw,''))) strength, count(*) n
                         FROM Treatment_Entries te JOIN Beneficiaries b USING(beneficiary_id)
                         GROUP BY b.performance_number,med,strength HAVING count(*)>1''').fetchall()
        for r in dup:
            items.append({'severity':'warning','code':'DUPLICATE_TREATMENT','performance_number':r['performance_number'],'name':r['full_name'],'title':'احتمال تكرار علاج','detail':f"{r['med']} — {r['strength']} ({r['n']} سجلات)"})
        # Missing dictionary mapping is a review alert, never an automatic rename.
        try:
            unknown=c.execute('''SELECT DISTINCT trim(te.medicine_name_raw) medicine FROM Treatment_Entries te
                WHERE coalesce(trim(te.medicine_name_raw),'')<>'' AND NOT EXISTS
                (SELECT 1 FROM Medicine_Dictionary d WHERE lower(trim(d.medicine_name))=lower(trim(te.medicine_name_raw)))
                AND NOT EXISTS (SELECT 1 FROM Medicine_Name_Aliases a WHERE lower(trim(a.raw_alias))=lower(trim(te.medicine_name_raw)))''').fetchall()
            for r in unknown:
                items.append({'severity':'info','code':'MEDICINE_NOT_MAPPED','title':'اسم دواء يحتاج مراجعة القاموس','name':r['medicine'],'detail':'الاسم غير مرتبط باسم معتمد؛ لا يتم تغييره تلقائيًا.'})
        except sqlite3.OperationalError:
            pass
        # Expiry is only calculated when an explicit expiry date column exists.
        expiry_col=next((x for x in ('approval_expiry_date','expiry_date','approval_end_date') if x in bcols),None)
        if expiry_col:
            for b in beneficiaries:
                raw=b[expiry_col]
                if not raw: continue
                dt=_parse_date(raw)
                if not dt:
                    items.append({'severity':'warning','code':'INVALID_EXPIRY_DATE','performance_number':b['performance_number'],'title':'تاريخ انتهاء غير صالح','detail':str(raw)})
                elif dt < today:
                    items.append({'severity':'critical','code':'APPROVAL_EXPIRED','performance_number':b['performance_number'],'title':'الموافقة منتهية','detail':f'انتهت في {dt.isoformat()}'})
                elif dt <= today+timedelta(days=near_days):
                    items.append({'severity':'warning','code':'APPROVAL_EXPIRING','performance_number':b['performance_number'],'title':'الموافقة قاربت على الانتهاء','detail':f'تنتهي في {dt.isoformat()}'})
        else:
            items.append({'severity':'info','code':'EXPIRY_DATE_NOT_AVAILABLE','title':'تعذر حساب انتهاء الموافقات','detail':'قاعدة البيانات الحالية لا تحتوي حقلًا مستقلًا لتاريخ انتهاء الموافقة؛ لم نفترض تاريخ انتهاء من مدة الصرف أو تاريخ الموافقة.'})
        order={'critical':0,'warning':1,'info':2}
        items.sort(key=lambda x:(order.get(x['severity'],9),x.get('title',''),x.get('performance_number','')))
        return {'items':items,'counts':dict(Counter(x['severity'] for x in items)),'total':len(items),'generated_on':today.isoformat(),'expiry_supported':bool(expiry_col)}
    finally: c.close()


def analytics(db_path, today=None):
    c=connect(db_path)
    try:
        people=c.execute('SELECT count(*) FROM Personnel').fetchone()[0]
        beneficiary_count=c.execute('SELECT count(*) FROM Beneficiaries').fetchone()[0]
        current_entries=c.execute('SELECT count(*) FROM Treatment_Entries').fetchone()[0]
        archived=c.execute('SELECT count(*) FROM Treatment_History').fetchone()[0]
        def grouped(sql): return [dict(r) for r in c.execute(sql)]
        meds=grouped('''SELECT coalesce(nullif(trim(medicine_name_raw),''),'غير محدد') label,count(*) value
                        FROM Treatment_Entries GROUP BY label ORDER BY value DESC,label LIMIT 30''')
        regions=grouped('''SELECT coalesce(nullif(trim(coalesce(p.region,b.region)),''),'غير محددة') label,count(DISTINCT b.performance_number) value
                           FROM Beneficiaries b LEFT JOIN Personnel p ON p.performance_number=b.performance_number
                           GROUP BY label ORDER BY value DESC,label LIMIT 30''')
        departments=grouped('''SELECT coalesce(nullif(trim(coalesce(p.department,b.department)),''),'غير محددة') label,count(DISTINCT b.performance_number) value
                               FROM Beneficiaries b LEFT JOIN Personnel p ON p.performance_number=b.performance_number
                               GROUP BY label ORDER BY value DESC,label LIMIT 30''')
        approvals=grouped('''SELECT substr(approval_date,1,7) label,count(*) value FROM Beneficiaries
                             WHERE approval_date IS NOT NULL AND trim(approval_date)<>'' AND substr(approval_date,1,4) GLOB '[0-9][0-9][0-9][0-9]'
                             GROUP BY substr(approval_date,1,7) ORDER BY label DESC LIMIT 24''')
        return {'totals':{'personnel':people,'beneficiaries':beneficiary_count,'current_treatments':current_entries,'archived_treatments':archived},
                'medicines':meds,'regions':regions,'departments':departments,'approvals_by_month':list(reversed(approvals))}
    finally:c.close()


def export_analytics_excel(db_path, output):
    from openpyxl import Workbook
    from openpyxl.styles import Font,PatternFill,Alignment
    data=analytics(db_path); alert_data=alerts(db_path)
    wb=Workbook(); ws=wb.active; ws.title='ملخص'; ws.sheet_view.rightToLeft=True
    ws.append(['المؤشر','القيمة'])
    for k,label in [('personnel','العاملون'),('beneficiaries','ملفات المستفيدين'),('current_treatments','العلاجات الحالية'),('archived_treatments','العلاجات المؤرشفة')]: ws.append([label,data['totals'][k]])
    for name,key in [('الأدوية','medicines'),('المناطق','regions'),('الإدارات','departments'),('الموافقات الشهرية','approvals_by_month')]:
        sh=wb.create_sheet(name); sh.sheet_view.rightToLeft=True; sh.append(['التصنيف','العدد'])
        for r in data[key]: sh.append([r['label'],r['value']])
    sh=wb.create_sheet('التنبيهات'); sh.sheet_view.rightToLeft=True; sh.append(['الخطورة','التنبيه','رقم الأداء','الاسم / البيان','التفاصيل'])
    for r in alert_data['items']: sh.append([r['severity'],r.get('title'),r.get('performance_number'),r.get('name'),r.get('detail')])
    for sh in wb.worksheets:
        sh.freeze_panes='A2'; sh.auto_filter.ref=sh.dimensions; sh.sheet_properties.pageSetUpPr.fitToPage=True
        sh.page_setup.orientation='landscape'; sh.page_setup.paperSize=sh.PAPERSIZE_A4; sh.page_setup.fitToWidth=1; sh.page_setup.fitToHeight=0; sh.print_title_rows='1:1'
        for cell in sh[1]: cell.font=Font(name='Arial',bold=True,color='FFFFFF'); cell.fill=PatternFill('solid',fgColor='174A5B'); cell.alignment=Alignment(horizontal='center')
        for col in sh.columns:
            letter=col[0].column_letter; sh.column_dimensions[letter].width=min(42,max(16,max(len(str(x.value or '')) for x in col)+2))
    Path(output).parent.mkdir(parents=True,exist_ok=True); wb.save(output)
    return {'file':str(output),'alerts':alert_data['total'],'sheets':len(wb.sheetnames)}
