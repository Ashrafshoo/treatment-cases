package com.familyproperties.app

import android.content.ContentValues
import net.zetetic.database.sqlcipher.SQLiteDatabase
import java.util.UUID

/** Local repository. All write paths require a verified administrator session and append an audit row atomically. */
class PropertyRepository(
    private val helper: FamilyDatabase,
    private val currentSession: () -> AuthSession? = { null }
) {
    data class DashboardStats(val properties: Int, val units: Int, val tenants: Int, val collected: String, val expenses: String)
    data class PropertyRow(
        val id: String, val name: String, val address: String?, val notes: String?, val reviewStatus: String,
        val modifiedUnreviewed: Boolean, val highlighted: Boolean
    )
    data class UnitRow(
        val id: String, val propertyId: String, val propertyName: String, val number: String,
        val type: String, val occupancy: String, val tenantName: String?, val reviewStatus: String,
        val law164Applies: Boolean, val modifiedUnreviewed: Boolean
    )
    data class TenantRow(val id: String, val name: String, val phone: String?, val notes: String?)
    data class ExpenseRow(val id: String, val name: String, val amountMinor: Long, val expenseDate: String, val notes: String?)
    data class LeaseRow(
        val id: String, val propertyName: String, val unitNumber: String, val tenantName: String,
        val startDate: String, val calculatedEndDate: String?, val manualEndDate: String?,
        val rentMinor: Long?, val status: String, val law164Applies: Boolean
    )
    data class PaymentRow(
        val id: String, val receiptId: String?, val receiptNumber: String?, val propertyName: String,
        val unitNumber: String, val tenantName: String, val paidAt: String, val amountMinor: Long,
        val period: String?, val remainingMinor: Long?, val receiptApproved: Boolean
    )
    data class ReceiptPrintRow(
        val receiptNumber: String, val issuedAt: String, val landlord: String?, val tenant: String,
        val property: String, val unit: String, val amountMinor: Long, val amountWords: String?,
        val period: String?, val paymentMethod: String?, val remainingMinor: Long?, val law164: Boolean
    )
    data class MonthlyStatementRow(
        val leaseId: String, val propertyName: String, val unitNumber: String, val tenantName: String,
        val dueMinor: Long, val paidMinor: Long, val remainingMinor: Long, val law164: Boolean
    )

    /** Only approved, immutable receipt snapshots are eligible for final PDF output. */
    /** Monthly rent statement based on the approved rent history effective on month start. */
    fun monthlyStatement(monthText: String): List<MonthlyStatementRow> {
        val month = java.time.YearMonth.parse(monthText.trim())
        val start = month.atDay(1).toString()
        val end = month.atEndOfMonth().toString()
        val rows = mutableListOf<MonthlyStatementRow>()
        helper.readableDatabase.rawQuery(
            "SELECT l.id, p.name, COALESCE(u.unit_number,''), t.full_name, " +
                "COALESCE((SELECT rh.amount_minor FROM rent_history rh WHERE rh.lease_id=l.id " +
                "AND rh.approval_status='approved' AND rh.valid_from<=? " +
                "AND (rh.valid_to IS NULL OR rh.valid_to>=?) ORDER BY rh.valid_from DESC LIMIT 1), l.initial_rent_minor, 0), " +
                "COALESCE((SELECT SUM(pay.amount_minor) FROM payments pay WHERE pay.lease_id=l.id " +
                "AND substr(COALESCE(pay.period_start,pay.paid_at),1,7)=?),0), l.law_164_2025_applies " +
                "FROM leases l JOIN units u ON u.id=l.unit_id JOIN properties p ON p.id=u.property_id " +
                "JOIN tenants t ON t.id=l.tenant_id WHERE l.archived_at IS NULL AND u.archived_at IS NULL " +
                "AND p.archived_at IS NULL AND l.start_date<=? " +
                "AND COALESCE(l.manual_end_date,l.calculated_end_date,'9999-12-31')>=? " +
                "ORDER BY p.name COLLATE NOCASE, u.unit_number, t.full_name COLLATE NOCASE",
            arrayOf(start, start, month.toString(), end, start)
        ).use { cursor ->
            while (cursor.moveToNext()) {
                val due = cursor.getLong(4)
                val paid = cursor.getLong(5)
                rows += MonthlyStatementRow(cursor.getString(0), cursor.getString(1), cursor.getString(2),
                    cursor.getString(3), due, paid, (due - paid).coerceAtLeast(0), cursor.getInt(6) == 1)
            }
        }
        return rows
    }

    fun listApprovedReceiptsForPrint(): List<ReceiptPrintRow> {
        requireAdministrator()
        val rows = mutableListOf<ReceiptPrintRow>()
        helper.readableDatabase.rawQuery(
            "SELECT receipt_number, issued_at, landlord_snapshot, COALESCE(tenant_snapshot,''), " +
                "COALESCE(property_snapshot,''), COALESCE(unit_snapshot,''), amount_minor, amount_words_snapshot, " +
                "period_snapshot, payment_method_snapshot, remaining_minor, law_164_2025_snapshot " +
                "FROM receipts WHERE approved=1 ORDER BY issued_at DESC, receipt_number DESC", null
        ).use { cursor ->
            while (cursor.moveToNext()) rows += ReceiptPrintRow(
                cursor.getString(0), cursor.getString(1), cursor.getString(2), cursor.getString(3),
                cursor.getString(4), cursor.getString(5), cursor.getLong(6), cursor.getString(7),
                cursor.getString(8), cursor.getString(9), if (cursor.isNull(10)) null else cursor.getLong(10),
                cursor.getInt(11) == 1
            )
        }
        return rows
    }


    /**
     * Applies a reviewed Excel batch atomically. Import is insert-only: an existing ID is a
     * conflict, never an implicit update. All relationships must resolve before the first write.
     */
    fun applyExcelImport(previews: List<ExcelInterchange.Preview>): Map<String, Int> {
        val session = requireAdministrator()
        require(previews.isNotEmpty()) { "لا توجد بيانات للاستيراد." }
        require(previews.all { it.headersValid && it.issues.isEmpty() }) {
            "لا يمكن الاستيراد: أصلح عناوين الأعمدة وملاحظات التحقق أولاً."
        }
        val allowedSheets = ExcelInterchange.schemas.keys
        require(previews.all { it.sheet in allowedSheets }) { "يحتوي الملف على ورقة غير معتمدة." }
        val rowsBySheet = previews.associate { it.sheet to it.rows }
        val orderedSheets = listOf("العقارات", "الملاك", "المستأجرون", "الوحدات", "حصص_الملكية", "العقود", "التحصيلات", "المصروفات")
        val allRows = orderedSheets.flatMap { sheet -> rowsBySheet[sheet].orEmpty().map { sheet to it } }
        require(allRows.isNotEmpty()) { "ملف Excel لا يحتوي على صفوف بيانات للاستيراد." }
        val ids = mutableSetOf<String>()
        allRows.forEach { (sheet, row) ->
            val id = row[ExcelInterchange.schemas.getValue(sheet).first()].orEmpty().trim()
            require(id.isNotEmpty()) { "المعرف مطلوب في ورقة $sheet؛ لا يتم توليد معرفات للعلاقات تلقائياً." }
            require(ids.add("$sheet|$id")) { "المعرف $id مكرر داخل ورقة $sheet." }
        }

        val db = helper.writableDatabase
        val result = linkedMapOf<String, Int>()
        db.beginTransaction()
        try {
            // Preflight all conflicts and foreign keys before any insert.
            allRows.forEach { (sheet, row) ->
                val id = row[ExcelInterchange.schemas.getValue(sheet).first()]!!.trim()
                val table = when (sheet) {
                    "العقارات" -> "properties"; "الملاك" -> "owners"; "المستأجرون" -> "tenants"
                    "الوحدات" -> "units"; "حصص_الملكية" -> "ownership_shares"; "العقود" -> "leases"
                    "التحصيلات" -> "payments"; else -> "expenses"
                }
                val exists = db.rawQuery("SELECT 1 FROM $table WHERE id=? LIMIT 1", arrayOf(id)).use { it.moveToFirst() }
                check(!exists) { "المعرف $id موجود مسبقاً في قاعدة البيانات ($sheet). لن يتم تحديثه." }
            }
            fun requireRef(sheet: String, key: String, table: String, targetSheet: String) {
                rowsBySheet[sheet].orEmpty().forEach { row ->
                    val ref = row[key].orEmpty().trim()
                    require(ref.isNotEmpty()) { "الحقل $key مطلوب في ورقة $sheet." }
                    val inBatch = rowsBySheet[targetSheet].orEmpty().any { r -> r[ExcelInterchange.schemas.getValue(targetSheet).first()]?.trim() == ref }
                    val inDb = db.rawQuery("SELECT 1 FROM $table WHERE id=? AND archived_at IS NULL LIMIT 1", arrayOf(ref)).use { it.moveToFirst() }
                    check(inBatch || inDb) { "تعذر العثور على المرجع $ref في $table؛ أوقفنا الاستيراد دون تغيير." }
                }
            }
            requireRef("الوحدات", "property_id", "properties", "العقارات")
            requireRef("حصص_الملكية", "property_id", "properties", "العقارات")
            requireRef("حصص_الملكية", "owner_id", "owners", "الملاك")
            requireRef("العقود", "unit_id", "units", "الوحدات")
            requireRef("العقود", "tenant_id", "tenants", "المستأجرون")
            requireRef("التحصيلات", "lease_id", "leases", "العقود")
            rowsBySheet["العقود"].orEmpty().filter { it["law_164_residential_rules"]?.trim()?.lowercase() in setOf("1", "true") }.forEach { row ->
                val unitId = row["unit_id"]!!.trim()
                val importedType = rowsBySheet["الوحدات"].orEmpty().firstOrNull { it["unit_id"]?.trim() == unitId }?.get("unit_type")?.trim()
                val existingType = if (importedType == null) db.rawQuery("SELECT unit_type FROM units WHERE id=? AND archived_at IS NULL", arrayOf(unitId)).use { c -> if (c.moveToFirst()) c.getString(0) else null } else importedType
                check(existingType == "residential") { "قواعد قانون 164 السكنية لا يمكن تفعيلها لعقد وحدته ليست سكنية مؤكدة." }
            }

            rowsBySheet["العقود"].orEmpty().forEach { row ->
                val start = java.time.LocalDate.parse(row["start_date"]!!.trim())
                val manualEnd = row["manual_end_date"]?.trim()?.takeIf { it.isNotEmpty() }?.let(java.time.LocalDate::parse)
                check(manualEnd == null || !manualEnd.isBefore(start)) { "تاريخ نهاية العقد اليدوي يسبق بدايته." }
            }
            rowsBySheet["التحصيلات"].orEmpty().forEach { row ->
                val start = row["period_start"]?.trim()?.takeIf { it.isNotEmpty() }?.let(java.time.LocalDate::parse)
                val end = row["period_end"]?.trim()?.takeIf { it.isNotEmpty() }?.let(java.time.LocalDate::parse)
                check(start == null || end == null || !end.isBefore(start)) { "نهاية فترة التحصيل تسبق بدايتها." }
            }

            // Refuse ambiguous natural-key duplicates rather than guessing that two records match.
            val unitKeys = mutableSetOf<String>()
            rowsBySheet["الوحدات"].orEmpty().forEach { row ->
                val key = "${row["property_id"]?.trim()}|${row["unit_number"]?.trim()}"
                check(unitKeys.add(key)) { "رقم الوحدة مكرر داخل العقار نفسه: $key" }
                val found = db.rawQuery("SELECT 1 FROM units WHERE property_id=? AND unit_number=? AND archived_at IS NULL LIMIT 1", arrayOf(row["property_id"]?.trim(), row["unit_number"]?.trim())).use { it.moveToFirst() }
                check(!found) { "توجد وحدة قائمة بنفس العقار ورقم الوحدة (${row["unit_number"]}). راجع المطابقة يدوياً." }
            }
            val propertyNames = mutableSetOf<String>()
            rowsBySheet["العقارات"].orEmpty().forEach { row ->
                val key = row["name"].orEmpty().trim().lowercase()
                check(propertyNames.add(key)) { "اسم عقار مكرر داخل الملف: ${row["name"]}" }
                val found = db.rawQuery("SELECT 1 FROM properties WHERE lower(trim(name))=? AND archived_at IS NULL LIMIT 1", arrayOf(key)).use { it.moveToFirst() }
                check(!found) { "يوجد عقار بالاسم نفسه (${row["name"]}). لا ندمج السجلات تلقائياً." }
            }

            fun value(row: Map<String, String>, key: String): String? = row[key]?.trim()?.takeIf { it.isNotEmpty() }
            fun date(row: Map<String, String>, key: String): String? = value(row, key)?.let { java.time.LocalDate.parse(it).toString() }
            fun money(row: Map<String, String>, key: String): Long? = value(row, key)?.let { LeaseRules.egpToMinorUnits(it) }
            fun insert(sheet: String, row: Map<String, String>, values: ContentValues, entity: String) {
                val id = row[ExcelInterchange.schemas.getValue(sheet).first()]!!.trim()
                values.put("id", id)
                db.insertOrThrow(when (sheet) {
                    "العقارات" -> "properties"; "الملاك" -> "owners"; "المستأجرون" -> "tenants"
                    "الوحدات" -> "units"; "حصص_الملكية" -> "ownership_shares"; "العقود" -> "leases"
                    "التحصيلات" -> "payments"; else -> "expenses"
                }, null, values)
                val audit = ContentValues().apply {
                    put("id", UUID.randomUUID().toString()); put("user_id", session.userId)
                    put("entity_type", entity); put("entity_id", id); put("action", "import")
                    put("after_json", "{\"source\":\"Excel\",\"sheet\":\"$sheet\"}")
                }
                db.insertOrThrow("audit_log", null, audit)
                result[sheet] = (result[sheet] ?: 0) + 1
            }

            orderedSheets.forEach { sheet -> rowsBySheet[sheet].orEmpty().forEach { row ->
                when (sheet) {
                    "العقارات" -> insert(sheet,row,ContentValues().apply { put("name",value(row,"name")); put("address_text",value(row,"address_text")); put("city",value(row,"city")); put("district",value(row,"district")); put("property_type",value(row,"property_type")); put("notes",value(row,"notes")); put("review_status","needs_review"); put("source_status","excel") },"property")
                    "الملاك" -> insert(sheet,row,ContentValues().apply { put("full_name",value(row,"full_name")); put("phone",value(row,"phone")); put("notes",value(row,"notes")) },"owner")
                    "المستأجرون" -> insert(sheet,row,ContentValues().apply { put("full_name",value(row,"full_name")); put("phone",value(row,"phone")); put("national_id_last4",value(row,"national_id_last4")); put("notes",value(row,"notes")) },"tenant")
                    "الوحدات" -> insert(sheet,row,ContentValues().apply { put("property_id",value(row,"property_id")); put("unit_number",value(row,"unit_number")); put("floor_label",value(row,"floor_label")); put("unit_type",value(row,"unit_type")); put("area",value(row,"area")?.toDouble()); put("occupancy_status",value(row,"occupancy_status") ?: "unknown"); put("old_law_164_2025",if(value(row,"old_law_164_2025") in setOf("1","true")) 1 else 0); put("address_details",value(row,"address_details")); put("notes",value(row,"notes")); put("review_status","needs_review"); put("source_status","excel") },"unit")
                    "حصص_الملكية" -> insert(sheet,row,ContentValues().apply { put("property_id",value(row,"property_id")); put("owner_id",value(row,"owner_id")); put("share_percent",value(row,"share_percent")!!.toDouble()); put("valid_from",date(row,"valid_from")); put("valid_to",date(row,"valid_to")); put("notes",value(row,"notes")) },"ownership_share")
                    "العقود" -> {
                        insert(sheet,row,ContentValues().apply {
                        val start = date(row,"start_date")!!; val duration = value(row,"duration_value")?.toInt(); val unit = value(row,"duration_unit")
                        put("unit_id",value(row,"unit_id")); put("tenant_id",value(row,"tenant_id")); put("start_date",start); if(duration!=null) put("duration_value",duration); put("duration_unit",unit)
                        if(duration!=null && unit!=null) put("calculated_end_date",LeaseRules.calculateEndDate(java.time.LocalDate.parse(start),duration,unit).toString())
                        put("manual_end_date",date(row,"manual_end_date")); put("initial_rent_minor",money(row,"initial_rent_egp")); put("annual_increase_percent",value(row,"annual_increase_percent")?.toDouble())
                        put("increase_rule",value(row,"increase_rule") ?: "anniversary"); put("increase_month",value(row,"increase_month")?.toInt()); put("increase_day",value(row,"increase_day")?.toInt())
                        put("status",value(row,"status") ?: "active"); put("notes",value(row,"notes"))
                        put("law_164_2025_applies",if(value(row,"law_164_2025_applies") in setOf("1","true")) 1 else 0)
                        put("law_164_residential_rules",if(value(row,"law_164_residential_rules") in setOf("1","true")) 1 else 0)
                        },"lease")
                        // Preserve the imported starting rent as an approved historical rent period.
                        val rent = money(row,"initial_rent_egp")
                        if (rent != null) {
                            val history = ContentValues().apply {
                                put("id",UUID.randomUUID().toString()); put("lease_id",row["lease_id"]!!.trim())
                                put("amount_minor",rent); put("valid_from",date(row,"start_date"))
                                put("source_type","import"); put("approval_status","approved")
                            }
                            db.insertOrThrow("rent_history",null,history)
                        }
                    }
                    "التحصيلات" -> insert(sheet,row,ContentValues().apply { put("lease_id",value(row,"lease_id")); put("paid_at",date(row,"paid_at")); put("amount_minor",money(row,"amount_egp") ?: 0L); put("period_start",date(row,"period_start")); put("period_end",date(row,"period_end")); put("payment_method",value(row,"payment_method")); put("reference_text",value(row,"reference_text")); put("notes",value(row,"notes")) },"payment")
                    "المصروفات" -> insert(sheet,row,ContentValues().apply { put("name",value(row,"name")); put("amount_minor",money(row,"amount_egp") ?: 0L); put("expense_date",date(row,"expense_date")); put("notes",value(row,"notes")) },"expense")
                }
            } }
            // Database overlap triggers enforce the 100% ownership ceiling for intersecting validity periods.
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        return result
    }

    /** Admin-only export of active master data and complete payment history. */
    fun exportExcelData(): Map<String, List<Map<String, String>>> {
        requireAdministrator()
        val db = helper.readableDatabase
        fun rows(sql: String, columns: List<String>): List<Map<String, String>> {
            val result = mutableListOf<Map<String, String>>()
            db.rawQuery(sql, null).use { cursor ->
                while (cursor.moveToNext()) {
                    result += columns.mapIndexed { index, key ->
                        key to if (cursor.isNull(index)) "" else cursor.getString(index)
                    }.toMap()
                }
            }
            return result
        }
        return linkedMapOf(
            "العقارات" to rows(
                "SELECT id,name,COALESCE(address_text,''),COALESCE(city,''),COALESCE(district,''),COALESCE(property_type,''),COALESCE(notes,'') FROM properties WHERE archived_at IS NULL ORDER BY name COLLATE NOCASE",
                listOf("property_id","name","address_text","city","district","property_type","notes")),
            "الوحدات" to rows(
                "SELECT u.id,u.property_id,COALESCE(u.unit_number,''),COALESCE(u.floor_label,''),COALESCE(u.unit_type,''),COALESCE(CAST(u.area AS TEXT),''),u.occupancy_status,CAST(u.old_law_164_2025 AS TEXT),COALESCE(u.address_details,''),COALESCE(u.notes,'') FROM units u JOIN properties p ON p.id=u.property_id WHERE u.archived_at IS NULL AND p.archived_at IS NULL ORDER BY u.property_id,u.unit_number",
                listOf("unit_id","property_id","unit_number","floor_label","unit_type","area","occupancy_status","old_law_164_2025","address_details","notes")),
            "الملاك" to rows(
                "SELECT id,full_name,COALESCE(phone,''),COALESCE(notes,'') FROM owners WHERE archived_at IS NULL ORDER BY full_name COLLATE NOCASE",
                listOf("owner_id","full_name","phone","notes")),
            "حصص_الملكية" to rows(
                "SELECT s.id,s.property_id,s.owner_id,CAST(s.share_percent AS TEXT),COALESCE(s.valid_from,''),COALESCE(s.valid_to,''),COALESCE(s.notes,'') FROM ownership_shares s JOIN properties p ON p.id=s.property_id JOIN owners o ON o.id=s.owner_id WHERE p.archived_at IS NULL AND o.archived_at IS NULL ORDER BY s.property_id,s.owner_id",
                listOf("share_id","property_id","owner_id","share_percent","valid_from","valid_to","notes")),
            "المستأجرون" to rows(
                "SELECT id,full_name,COALESCE(phone,''),COALESCE(national_id_last4,''),COALESCE(notes,'') FROM tenants WHERE archived_at IS NULL ORDER BY full_name COLLATE NOCASE",
                listOf("tenant_id","full_name","phone","national_id_last4","notes")),
            "العقود" to rows(
                "SELECT l.id,l.unit_id,l.tenant_id,l.start_date,COALESCE(CAST(l.duration_value AS TEXT),''),COALESCE(l.duration_unit,''),COALESCE(l.manual_end_date,''),COALESCE(printf('%.2f',l.initial_rent_minor/100.0),''),COALESCE(CAST(l.annual_increase_percent AS TEXT),''),l.increase_rule,COALESCE(CAST(l.increase_month AS TEXT),''),COALESCE(CAST(l.increase_day AS TEXT),''),CAST(l.law_164_2025_applies AS TEXT),CAST(l.law_164_residential_rules AS TEXT),l.status,COALESCE(l.notes,'') FROM leases l JOIN units u ON u.id=l.unit_id JOIN properties p ON p.id=u.property_id JOIN tenants t ON t.id=l.tenant_id WHERE l.archived_at IS NULL AND u.archived_at IS NULL AND p.archived_at IS NULL AND t.archived_at IS NULL ORDER BY l.start_date",
                listOf("lease_id","unit_id","tenant_id","start_date","duration_value","duration_unit","manual_end_date","initial_rent_egp","annual_increase_percent","increase_rule","increase_month","increase_day","law_164_2025_applies","law_164_residential_rules","status","notes")),
            "التحصيلات" to rows(
                "SELECT pay.id,pay.lease_id,pay.paid_at,printf('%.2f',pay.amount_minor/100.0),COALESCE(pay.period_start,''),COALESCE(pay.period_end,''),COALESCE(pay.payment_method,''),COALESCE(pay.reference_text,''),COALESCE(pay.notes,'') FROM payments pay JOIN leases l ON l.id=pay.lease_id JOIN units u ON u.id=l.unit_id JOIN properties p ON p.id=u.property_id JOIN tenants t ON t.id=l.tenant_id WHERE l.archived_at IS NULL AND u.archived_at IS NULL AND p.archived_at IS NULL AND t.archived_at IS NULL ORDER BY pay.paid_at,pay.created_at",
                listOf("payment_id","lease_id","paid_at","amount_egp","period_start","period_end","payment_method","reference_text","notes")),
            "المصروفات" to rows(
                "SELECT id,name,printf('%.2f',amount_minor/100.0),expense_date,COALESCE(notes,'') FROM expenses WHERE archived_at IS NULL ORDER BY expense_date,created_at",
                listOf("expense_id","name","amount_egp","expense_date","notes"))
        )
    }

    fun dashboardStats(): DashboardStats = helper.readableDatabase.let { db ->
        DashboardStats(
            count(db, "properties"), count(db, "units"), count(db, "tenants"),
            sum(db, "payments", "amount_minor"), sumActiveExpenses(db)
        )
    }

    fun listProperties(): List<PropertyRow> {
        val result = mutableListOf<PropertyRow>()
        helper.readableDatabase.query(
            "properties", arrayOf("id", "name", "address_text", "notes", "review_status", "modified_unreviewed", "is_highlighted"),
            "archived_at IS NULL", null, null, null, "name COLLATE NOCASE"
        ).use { cursor ->
            while (cursor.moveToNext()) {
                result += PropertyRow(cursor.getString(0), cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4),
                    cursor.getInt(5) == 1, cursor.getInt(6) == 1)
            }
        }
        return result
    }

    fun listUnits(): List<UnitRow> {
        val rows = mutableListOf<UnitRow>()
        helper.readableDatabase.rawQuery(
            "SELECT u.id, u.property_id, p.name, COALESCE(u.unit_number,''), COALESCE(u.unit_type,''), " +
                "u.occupancy_status, t.full_name, u.review_status, u.old_law_164_2025, u.modified_unreviewed " +
                "FROM units u JOIN properties p ON p.id = u.property_id " +
                "LEFT JOIN tenants t ON t.id = u.current_tenant_id " +
                "WHERE u.archived_at IS NULL AND p.archived_at IS NULL ORDER BY p.name COLLATE NOCASE, u.unit_number",
            null
        ).use { cursor ->
            while (cursor.moveToNext()) {
                rows += UnitRow(cursor.getString(0), cursor.getString(1), cursor.getString(2), cursor.getString(3),
                    cursor.getString(4), cursor.getString(5), cursor.getString(6), cursor.getString(7),
                    cursor.getInt(8) == 1, cursor.getInt(9) == 1)
            }
        }
        return rows
    }

    fun listTenants(): List<TenantRow> {
        val rows = mutableListOf<TenantRow>()
        helper.readableDatabase.query(
            "tenants", arrayOf("id", "full_name", "phone", "notes"),
            "archived_at IS NULL", null, null, null, "full_name COLLATE NOCASE"
        ).use { cursor ->
            while (cursor.moveToNext()) rows += TenantRow(cursor.getString(0), cursor.getString(1), cursor.getString(2), cursor.getString(3))
        }
        return rows
    }

    fun listExpenses(): List<ExpenseRow> {
        val rows = mutableListOf<ExpenseRow>()
        helper.readableDatabase.query(
            "expenses", arrayOf("id", "name", "amount_minor", "expense_date", "notes"),
            "archived_at IS NULL", null, null, null, "expense_date DESC, created_at DESC"
        ).use { cursor ->
            while (cursor.moveToNext()) rows += ExpenseRow(
                cursor.getString(0), cursor.getString(1), cursor.getLong(2), cursor.getString(3), cursor.getString(4)
            )
        }
        return rows
    }

    fun listLeases(): List<LeaseRow> {
        val rows = mutableListOf<LeaseRow>()
        helper.readableDatabase.rawQuery(
            "SELECT l.id, p.name, COALESCE(u.unit_number,''), t.full_name, l.start_date, " +
                "l.calculated_end_date, l.manual_end_date, l.initial_rent_minor, l.status, l.law_164_2025_applies " +
                "FROM leases l JOIN units u ON u.id=l.unit_id JOIN properties p ON p.id=u.property_id " +
                "JOIN tenants t ON t.id=l.tenant_id WHERE l.archived_at IS NULL " +
                "ORDER BY COALESCE(l.manual_end_date,l.calculated_end_date,'9999-12-31'), p.name COLLATE NOCASE, u.unit_number",
            null
        ).use { cursor ->
            while (cursor.moveToNext()) rows += LeaseRow(
                cursor.getString(0), cursor.getString(1), cursor.getString(2), cursor.getString(3),
                cursor.getString(4), cursor.getString(5), cursor.getString(6),
                if (cursor.isNull(7)) null else cursor.getLong(7), cursor.getString(8), cursor.getInt(9) == 1
            )
        }
        return rows
    }

    fun listPayments(): List<PaymentRow> {
        val rows = mutableListOf<PaymentRow>()
        helper.readableDatabase.rawQuery(
            "SELECT pay.id, r.id, r.receipt_number, COALESCE(r.property_snapshot,p.name), " +
                "COALESCE(r.unit_snapshot,COALESCE(u.unit_number,'')), COALESCE(r.tenant_snapshot,t.full_name), " +
                "pay.paid_at, pay.amount_minor, COALESCE(r.period_snapshot,substr(pay.period_start,1,7)), " +
                "r.remaining_minor, COALESCE(r.approved,0) " +
                "FROM payments pay JOIN leases l ON l.id=pay.lease_id JOIN units u ON u.id=l.unit_id " +
                "JOIN properties p ON p.id=u.property_id JOIN tenants t ON t.id=l.tenant_id " +
                "LEFT JOIN receipts r ON r.payment_id=pay.id " +
                "ORDER BY pay.paid_at DESC, pay.created_at DESC",
            null
        ).use { cursor ->
            while (cursor.moveToNext()) rows += PaymentRow(
                cursor.getString(0), cursor.getString(1), cursor.getString(2), cursor.getString(3),
                cursor.getString(4), cursor.getString(5), cursor.getString(6), cursor.getLong(7),
                cursor.getString(8), if (cursor.isNull(9)) null else cursor.getLong(9), cursor.getInt(10) == 1
            )
        }
        return rows
    }

    /** Records a payment and creates its immutable-name draft receipt snapshot in one transaction. */
    fun recordPayment(
        leaseId: String,
        paidAt: String,
        amountEgp: String,
        periodMonth: String,
        paymentMethod: String,
        notes: String = ""
    ): String {
        val session = requireAdministrator()
        val paidDate = java.time.LocalDate.parse(paidAt.trim())
        val month = java.time.YearMonth.parse(periodMonth.trim())
        val periodStart = month.atDay(1)
        val periodEnd = month.atEndOfMonth()
        val amountMinor = LeaseRules.egpToMinorUnits(amountEgp)
        require(amountMinor > 0) { "قيمة التحصيل يجب أن تكون أكبر من صفر" }
        val db = helper.writableDatabase
        val paymentId = UUID.randomUUID().toString()
        val receiptId = UUID.randomUUID().toString()
        val receiptNumber = "RCP-${paidDate.toString().replace("-", "")}-${UUID.randomUUID().toString().take(8).uppercase()}"
        db.beginTransaction()
        try {
            val snapshot = db.rawQuery(
                "SELECT p.name, COALESCE(u.unit_number,''), t.full_name, l.law_164_2025_applies, " +
                    "l.start_date, COALESCE(l.manual_end_date,l.calculated_end_date,'') " +
                    "FROM leases l JOIN units u ON u.id=l.unit_id JOIN properties p ON p.id=u.property_id " +
                    "JOIN tenants t ON t.id=l.tenant_id WHERE l.id=? AND l.archived_at IS NULL AND l.status IN ('active','ending_soon','open_ended')",
                arrayOf(leaseId)
            ).use { cursor ->
                check(cursor.moveToFirst()) { "العقد غير موجود أو غير نشط." }
                arrayOf(cursor.getString(0), cursor.getString(1), cursor.getString(2), cursor.getInt(3).toString(), cursor.getString(4), cursor.getString(5))
            }
            check(!periodStart.isBefore(java.time.LocalDate.parse(snapshot[4]))) { "شهر التحصيل يسبق تاريخ بداية العقد." }
            if (snapshot[5].isNotBlank()) check(!periodStart.isAfter(java.time.LocalDate.parse(snapshot[5]))) { "شهر التحصيل يلي نهاية العقد." }
            val rentDue = db.rawQuery(
                "SELECT amount_minor FROM rent_history WHERE lease_id=? AND approval_status='approved' " +
                    "AND valid_from<=? AND (valid_to IS NULL OR valid_to>=?) ORDER BY valid_from DESC LIMIT 1",
                arrayOf(leaseId, periodStart.toString(), periodStart.toString())
            ).use { cursor ->
                if (cursor.moveToFirst()) cursor.getLong(0) else db.rawQuery(
                    "SELECT initial_rent_minor FROM leases WHERE id=?", arrayOf(leaseId)
                ).use { fallback -> check(fallback.moveToFirst() && !fallback.isNull(0)) { "لا يوجد إيجار معتمد لهذا العقد في شهر التحصيل." }; fallback.getLong(0) }
            }
            val previouslyPaid = db.rawQuery(
                "SELECT COALESCE(SUM(amount_minor),0) FROM payments WHERE lease_id=? AND period_start=? AND period_end=?",
                arrayOf(leaseId, periodStart.toString(), periodEnd.toString())
            ).use { if (it.moveToFirst()) it.getLong(0) else 0L }
            val remaining = (rentDue - previouslyPaid - amountMinor).coerceAtLeast(0L)

            val payment = ContentValues().apply {
                put("id", paymentId); put("lease_id", leaseId); put("paid_at", paidDate.toString())
                put("amount_minor", amountMinor); put("period_start", periodStart.toString()); put("period_end", periodEnd.toString())
                put("payment_method", paymentMethod.trim().takeIf(String::isNotEmpty)); put("notes", notes.trim())
            }
            db.insertOrThrow("payments", null, payment)
            val receipt = ContentValues().apply {
                put("id", receiptId); put("payment_id", paymentId); put("lease_id", leaseId)
                put("receipt_number", receiptNumber); put("issued_at", paidDate.toString())
                put("landlord_snapshot", "إدارة أملاك العائلة"); put("tenant_snapshot", snapshot[2])
                put("property_snapshot", snapshot[0]); put("unit_snapshot", snapshot[1])
                put("amount_minor", amountMinor); put("amount_words_snapshot", ArabicAmountWords.forEgpMinorUnits(amountMinor)); put("currency_code", "EGP")
                put("period_snapshot", periodMonth.trim()); put("payment_method_snapshot", paymentMethod.trim())
                put("remaining_minor", remaining); put("law_164_2025_snapshot", snapshot[3].toInt())
                put("approved", 0)
            }
            db.insertOrThrow("receipts", null, receipt)
            appendAudit(db, session, "create", "payment", paymentId,
                "{\"lease_id\":\"${jsonEscape(leaseId)}\",\"amount_minor\":$amountMinor,\"period\":\"$periodMonth\"}")
            appendAudit(db, session, "create", "receipt", receiptId,
                "{\"receipt_number\":\"$receiptNumber\",\"approved\":false}")
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        return receiptId
    }

    fun approveReceipt(receiptId: String) {
        val session = requireAdministrator()
        val db = helper.writableDatabase
        db.beginTransaction()
        try {
            val values = ContentValues().apply { put("approved", 1) }
            check(db.update("receipts", values, "id=? AND approved=0", arrayOf(receiptId)) == 1) {
                "الإيصال غير موجود أو تم اعتماده من قبل."
            }
            appendAudit(db, session, "approve", "receipt", receiptId, "{\"approved\":true}")
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    /** Applies all scheduled increases due through the supplied date, preserving every prior rent period. */
    fun applyDueRentIncreases(today: java.time.LocalDate = java.time.LocalDate.now()): Int {
        val session = requireAdministrator()
        val db = helper.writableDatabase
        var applied = 0
        db.beginTransaction()
        try {
            data class Candidate(
                val id: String, val start: java.time.LocalDate, val percentage: java.math.BigDecimal?,
                val rule: String, val month: Int?, val day: Int?, val residentialLaw164Rules: Boolean
            )
            val candidates = mutableListOf<Candidate>()
            db.rawQuery(
                "SELECT l.id,l.start_date,l.annual_increase_percent,l.increase_rule,l.increase_month,l.increase_day,l.law_164_residential_rules " +
                    "FROM leases l JOIN units u ON u.id=l.unit_id WHERE l.archived_at IS NULL " +
                    "AND l.status IN ('active','ending_soon','open_ended') AND u.archived_at IS NULL",
                null
            ).use { cursor ->
                while (cursor.moveToNext()) candidates += Candidate(
                    cursor.getString(0), java.time.LocalDate.parse(cursor.getString(1)),
                    if (cursor.isNull(2)) null else cursor.getString(2).toBigDecimal(), cursor.getString(3),
                    if (cursor.isNull(4)) null else cursor.getInt(4), if (cursor.isNull(5)) null else cursor.getInt(5),
                    cursor.getInt(6) == 1
                )
            }
            candidates.forEach { lease ->
                val percent = if (lease.residentialLaw164Rules) java.math.BigDecimal("15") else lease.percentage
                if (percent == null || percent.compareTo(java.math.BigDecimal.ZERO) <= 0 || lease.rule in setOf("none", "manual_dates")) return@forEach
                var rent = db.rawQuery(
                    "SELECT id,amount_minor,valid_from FROM rent_history WHERE lease_id=? AND approval_status='approved' ORDER BY valid_from DESC LIMIT 1",
                    arrayOf(lease.id)
                ).use { cursor ->
                    if (cursor.moveToFirst()) Triple(cursor.getString(0), cursor.getLong(1), java.time.LocalDate.parse(cursor.getString(2)))
                    else null
                } ?: return@forEach
                // The latest approved rent-history row is the schedule anchor. Do not replace it
                // with today's date: doing so skips every increase that became due after that row.
                // Imported opening rents that already include an earlier increase must be reviewed
                // with valid_from set to that effective date before scheduled increases are applied.
                var nextDate = LeaseRules.nextIncreaseDate(lease.start, rent.third, lease.rule, lease.month, lease.day)
                while (nextDate != null && !nextDate.isAfter(today)) {
                    val newRent = LeaseRules.increasedRentMinor(rent.second, percent)
                    val previousValues = ContentValues().apply { put("valid_to", nextDate.minusDays(1).toString()) }
                    check(db.update("rent_history", previousValues, "id=? AND approval_status='approved'", arrayOf(rent.first)) == 1) {
                        "تعذر إغلاق فترة الإيجار السابقة للعقد ${lease.id}"
                    }
                    val newHistoryId = UUID.randomUUID().toString()
                    val history = ContentValues().apply {
                        put("id", newHistoryId); put("lease_id", lease.id); put("amount_minor", newRent)
                        put("currency_code", "EGP"); put("valid_from", nextDate.toString())
                        put("source_type", "increase"); put("source_id", newHistoryId); put("approval_status", "approved")
                    }
                    db.insertOrThrow("rent_history", null, history)
                    val increase = ContentValues().apply {
                        put("id", UUID.randomUUID().toString()); put("lease_id", lease.id)
                        put("effective_date", nextDate.toString()); put("percentage", percent.toDouble())
                        put("previous_rent_minor", rent.second); put("new_rent_minor", newRent)
                        put("calculation_method", "percentage"); put("status", "applied")
                    }
                    db.insertOrThrow("rent_increases", null, increase)
                    appendAudit(db, session, "apply_scheduled_increase", "lease", lease.id,
                        "{\"effective_date\":\"$nextDate\",\"previous_rent_minor\":${rent.second},\"new_rent_minor\":$newRent,\"percentage\":${percent.toPlainString()}}")
                    rent = Triple(newHistoryId, newRent, nextDate)
                    applied++
                    nextDate = LeaseRules.nextIncreaseDate(lease.start, rent.third, lease.rule, lease.month, lease.day)
                }
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        return applied
    }

    /** Creates a lease and its opening rent-history row atomically. */
    fun addLease(
        unitId: String,
        tenantId: String,
        startDate: String,
        durationValue: Int?,
        durationUnit: String?,
        initialRentEgp: String?,
        annualIncreasePercent: String?,
        law164Applies: Boolean,
        notes: String = ""
    ): String {
        val session = requireAdministrator()
        val parsedStart = java.time.LocalDate.parse(startDate.trim())
        val calculatedEnd = LeaseRules.calculateEndDate(parsedStart, durationValue, durationUnit)
        val rentMinor = initialRentEgp?.trim()?.takeIf(String::isNotEmpty)?.let(LeaseRules::egpToMinorUnits)
            ?: throw IllegalArgumentException("الإيجار الشهري للعقد مطلوب")
        val increaseText = annualIncreasePercent?.trim()?.takeIf(String::isNotEmpty)
        val increasePercent = increaseText?.toBigDecimalOrNull()
            ?: if (increaseText == null) null else throw IllegalArgumentException("نسبة الزيادة غير صحيحة")
        require(increasePercent == null || increasePercent >= java.math.BigDecimal.ZERO) { "نسبة الزيادة لا يمكن أن تكون سالبة" }
        val id = UUID.randomUUID().toString()
        val db = helper.writableDatabase
        db.beginTransaction()
        try {
            val unit = db.rawQuery(
                "SELECT u.unit_type, u.archived_at, p.archived_at FROM units u JOIN properties p ON p.id=u.property_id WHERE u.id=?",
                arrayOf(unitId)
            ).use { cursor ->
                check(cursor.moveToFirst() && cursor.isNull(1) && cursor.isNull(2)) { "الوحدة أو العقار غير موجود أو مؤرشف." }
                cursor.getString(0) ?: "residential"
            }
            val tenantExists = db.rawQuery(
                "SELECT COUNT(*) FROM tenants WHERE id=? AND archived_at IS NULL", arrayOf(tenantId)
            ).use { it.moveToFirst() && it.getInt(0) == 1 }
            check(tenantExists) { "المستأجر غير موجود أو مؤرشف." }
            val activeLeaseExists = db.rawQuery(
                "SELECT COUNT(*) FROM leases WHERE unit_id=? AND archived_at IS NULL AND status IN ('active','ending_soon','open_ended')",
                arrayOf(unitId)
            ).use { it.moveToFirst() && it.getInt(0) > 0 }
            check(!activeLeaseExists) { "توجد وحدة تعاقد نشطة بالفعل لهذه الوحدة؛ راجع العقد الحالي أولاً." }

            val residentialLaw164 = law164Applies && unit.equals("residential", ignoreCase = true)
            if (residentialLaw164 && rentMinor != null) {
                require(rentMinor >= 25_000L) { "الحد الأدنى المسجل للوحدة السكنية الخاضعة للقانون هو 250 جنيهاً." }
            }
            val effectiveIncrease = if (residentialLaw164) java.math.BigDecimal("15") else increasePercent
            val values = ContentValues().apply {
                put("id", id); put("unit_id", unitId); put("tenant_id", tenantId)
                put("start_date", parsedStart.toString())
                if (durationValue == null) putNull("duration_value") else put("duration_value", durationValue)
                if (durationUnit == null) putNull("duration_unit") else put("duration_unit", durationUnit)
                if (calculatedEnd == null) putNull("calculated_end_date") else put("calculated_end_date", calculatedEnd.toString())
                if (rentMinor == null) putNull("initial_rent_minor") else put("initial_rent_minor", rentMinor)
                if (effectiveIncrease == null) putNull("annual_increase_percent") else put("annual_increase_percent", effectiveIncrease.toDouble())
                put("increase_rule", if (residentialLaw164) "fixed_month_day" else if (effectiveIncrease != null) "anniversary" else "none")
                if (residentialLaw164) { put("increase_month", 9); put("increase_day", 1) }
                put("law_164_2025_applies", if (law164Applies) 1 else 0)
                // Persist the residential calculation policy separately from legal applicability/receipt wording.
                put("law_164_residential_rules", if (residentialLaw164) 1 else 0)
                put("status", if (calculatedEnd == null) "open_ended" else "active")
                put("notes", notes.trim())
            }
            db.insertOrThrow("leases", null, values)
            if (rentMinor != null) {
                val history = ContentValues().apply {
                    put("id", UUID.randomUUID().toString()); put("lease_id", id); put("amount_minor", rentMinor)
                    put("valid_from", parsedStart.toString()); put("source_type", "manual"); put("approval_status", "approved")
                }
                db.insertOrThrow("rent_history", null, history)
            }
            db.update("units", ContentValues().apply {
                put("current_tenant_id", tenantId); put("occupancy_status", "occupied")
                put("old_law_164_2025", if (law164Applies) 1 else 0)
                put("modified_unreviewed", 1)
            }, "id=?", arrayOf(unitId))
            appendAudit(db, session, "create", "lease", id,
                "{\"unit_id\":\"${jsonEscape(unitId)}\",\"tenant_id\":\"${jsonEscape(tenantId)}\",\"start_date\":\"$parsedStart\",\"calculated_end_date\":${calculatedEnd?.let { "\"$it\"" } ?: "null"},\"initial_rent_minor\":${rentMinor ?: "null"}}")
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        return id
    }

    /** Updates the calculated contract term without changing its original start date or rent history. */
    fun extendLease(leaseId: String, newDurationValue: Int, durationUnit: String, reason: String) {
        val session = requireAdministrator()
        require(reason.isNotBlank()) { "سبب تمديد العقد مطلوب." }
        val db = helper.writableDatabase
        db.beginTransaction()
        try {
            val start = db.rawQuery("SELECT start_date,status FROM leases WHERE id=? AND archived_at IS NULL", arrayOf(leaseId)).use {
                check(it.moveToFirst()) { "العقد غير موجود." }
                check(it.getString(1) in setOf("active", "ending_soon", "open_ended")) { "لا يمكن تمديد عقد غير نشط." }
                java.time.LocalDate.parse(it.getString(0))
            }
            val end = LeaseRules.calculateEndDate(start, newDurationValue, durationUnit)
                ?: throw IllegalArgumentException("مدة العقد غير صالحة.")
            val values = ContentValues().apply {
                put("duration_value", newDurationValue); put("duration_unit", durationUnit)
                put("calculated_end_date", end.toString()); put("manual_end_date", null as String?)
                put("end_date_override_reason", null as String?)
                put("status", "active"); put("modified_unreviewed", 1); put("updated_at", java.time.Instant.now().toString())
            }
            check(db.update("leases", values, "id=?", arrayOf(leaseId)) == 1) { "تعذر تحديث مدة العقد." }
            appendAudit(db, session, "extend_term", "lease", leaseId,
                "{\"duration_value\":$newDurationValue,\"duration_unit\":\"${jsonEscape(durationUnit)}\",\"calculated_end_date\":\"$end\",\"reason\":\"${jsonEscape(reason.trim())}\"}")
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    /** Sets or clears a manual end-date override; original start and calculated term remain intact. */
    fun setLeaseEndOverride(leaseId: String, manualEndDate: String?, reason: String?) {
        val session = requireAdministrator()
        val parsed = manualEndDate?.trim()?.takeIf(String::isNotEmpty)?.let(java.time.LocalDate::parse)
        val cleanReason = reason?.trim().orEmpty()
        require(parsed == null || cleanReason.isNotBlank()) { "سبب تعديل تاريخ النهاية مطلوب." }
        val db = helper.writableDatabase
        db.beginTransaction()
        try {
            val start = db.rawQuery("SELECT start_date FROM leases WHERE id=? AND archived_at IS NULL", arrayOf(leaseId)).use {
                check(it.moveToFirst()) { "العقد غير موجود." }; java.time.LocalDate.parse(it.getString(0))
            }
            require(parsed == null || !parsed.isBefore(start)) { "تاريخ نهاية العقد لا يمكن أن يسبق بدايته." }
            val values = ContentValues().apply {
                if (parsed == null) { putNull("manual_end_date"); putNull("end_date_override_reason") }
                else { put("manual_end_date", parsed.toString()); put("end_date_override_reason", cleanReason) }
                put("modified_unreviewed", 1); put("updated_at", java.time.Instant.now().toString())
            }
            check(db.update("leases", values, "id=?", arrayOf(leaseId)) == 1) { "تعذر تعديل تاريخ النهاية." }
            appendAudit(db, session, if (parsed == null) "clear_end_override" else "set_end_override", "lease", leaseId,
                "{\"manual_end_date\":${parsed?.let { "\"$it\"" } ?: "null"},\"reason\":\"${jsonEscape(cleanReason)}\"}")
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    /** Terminates a contract on a chosen date while preserving its rent and receipt history. */
    fun terminateLease(leaseId: String, terminationDate: String, reason: String) {
        val session = requireAdministrator()
        val date = java.time.LocalDate.parse(terminationDate.trim())
        require(reason.isNotBlank()) { "سبب إنهاء العقد مطلوب." }
        val db = helper.writableDatabase
        db.beginTransaction()
        try {
            val details = db.rawQuery("SELECT unit_id,start_date,status FROM leases WHERE id=? AND archived_at IS NULL", arrayOf(leaseId)).use {
                check(it.moveToFirst()) { "العقد غير موجود." }
                Triple(it.getString(0), java.time.LocalDate.parse(it.getString(1)), it.getString(2))
            }
            require(details.third in setOf("active", "ending_soon", "open_ended")) { "العقد ليس نشطاً." }
            require(!date.isBefore(details.second)) { "تاريخ الإنهاء يسبق بداية العقد." }
            val values = ContentValues().apply {
                put("status", "terminated"); put("manual_end_date", date.toString())
                put("end_date_override_reason", reason.trim()); put("modified_unreviewed", 1)
                put("updated_at", java.time.Instant.now().toString())
            }
            check(db.update("leases", values, "id=?", arrayOf(leaseId)) == 1) { "تعذر إنهاء العقد." }
            val nextActive = db.rawQuery(
                "SELECT COUNT(*) FROM leases WHERE unit_id=? AND id<>? AND archived_at IS NULL AND status IN ('active','ending_soon','open_ended')",
                arrayOf(details.first, leaseId)
            ).use { it.moveToFirst() && it.getInt(0) > 0 }
            if (!nextActive) db.update("units", ContentValues().apply {
                put("current_tenant_id", null as String?); put("occupancy_status", "vacant"); put("modified_unreviewed", 1)
            }, "id=?", arrayOf(details.first))
            appendAudit(db, session, "terminate", "lease", leaseId,
                "{\"termination_date\":\"$date\",\"reason\":\"${jsonEscape(reason.trim())}\"}")
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    /** Changes the annual increase policy without rewriting any previously approved rent-history row. */
    fun updateLeaseIncreasePolicy(leaseId: String, percentage: String?, rule: String, month: Int?, day: Int?) {
        val session = requireAdministrator()
        require(rule in setOf("anniversary", "fixed_month_day", "manual_dates", "none")) { "قاعدة الزيادة غير صحيحة." }
        val percent = percentage?.trim()?.takeIf(String::isNotEmpty)?.toBigDecimalOrNull()
        require(percentage.isNullOrBlank() || percent != null) { "نسبة الزيادة غير صحيحة." }
        require(percent == null || percent >= java.math.BigDecimal.ZERO) { "نسبة الزيادة لا يمكن أن تكون سالبة." }
        if (rule == "fixed_month_day") require(month != null && month in 1..12 && day != null && day in 1..31) { "حدد شهر ويوم الزيادة." }
        val db = helper.writableDatabase
        db.beginTransaction()
        try {
            val law164Residential = db.rawQuery(
                "SELECT law_164_residential_rules FROM leases WHERE id=? AND archived_at IS NULL", arrayOf(leaseId)
            ).use { check(it.moveToFirst()) { "العقد غير موجود." }; it.getInt(0) == 1 }
            if (law164Residential) {
                require(percent?.compareTo(java.math.BigDecimal("15")) == 0 && rule == "fixed_month_day" && month == 9 && day == 1) {
                    "زيادة الوحدات السكنية الخاضعة لقواعد قانون 164 مثبتة على 15% في 1 سبتمبر."
                }
            }
            val values = ContentValues().apply {
                if (percent == null) putNull("annual_increase_percent") else put("annual_increase_percent", percent.toDouble())
                put("increase_rule", rule)
                if (rule == "fixed_month_day") { put("increase_month", month!!); put("increase_day", day!!) }
                else { putNull("increase_month"); putNull("increase_day") }
                put("modified_unreviewed", 1); put("updated_at", java.time.Instant.now().toString())
            }
            check(db.update("leases", values, "id=? AND archived_at IS NULL", arrayOf(leaseId)) == 1) { "العقد غير موجود." }
            appendAudit(db, session, "update_increase_policy", "lease", leaseId,
                "{\"percentage\":${percent?.toPlainString() ?: "null"},\"rule\":\"$rule\",\"month\":${month ?: "null"},\"day\":${day ?: "null"}}")
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    /** Renews by closing the previous contract state and creating a new contract identity atomically. */
    fun renewLease(
        oldLeaseId: String, startDate: String, durationValue: Int?, durationUnit: String?,
        initialRentEgp: String, annualIncreasePercent: String?, notes: String = ""
    ): String {
        val session = requireAdministrator()
        val start = java.time.LocalDate.parse(startDate.trim())
        val end = LeaseRules.calculateEndDate(start, durationValue, durationUnit)
        val rent = LeaseRules.egpToMinorUnits(initialRentEgp)
        val percent = annualIncreasePercent?.trim()?.takeIf(String::isNotEmpty)?.toBigDecimalOrNull()
            ?: if (annualIncreasePercent.isNullOrBlank()) null else throw IllegalArgumentException("نسبة الزيادة غير صحيحة.")
        require(percent == null || percent >= java.math.BigDecimal.ZERO) { "نسبة الزيادة غير صحيحة." }
        val db = helper.writableDatabase
        val newId = UUID.randomUUID().toString()
        db.beginTransaction()
        try {
            val old = db.rawQuery(
                "SELECT unit_id,tenant_id,law_164_2025_applies,law_164_residential_rules,unit_type FROM leases l JOIN units u ON u.id=l.unit_id WHERE l.id=? AND l.archived_at IS NULL",
                arrayOf(oldLeaseId)
            ).use {
                check(it.moveToFirst()) { "العقد السابق غير موجود." }
                arrayOf(it.getString(0), it.getString(1), it.getInt(2).toString(), it.getInt(3).toString(), it.getString(4) ?: "residential")
            }
            val lawApplies = old[2] == "1"
            val residentialLaw = old[3] == "1"
            require(!residentialLaw || rent >= 25_000L) { "الحد الأدنى المسجل للوحدة السكنية الخاضعة للقانون هو 250 جنيهاً." }
            val oldStatus = db.rawQuery("SELECT status FROM leases WHERE id=?", arrayOf(oldLeaseId)).use { it.moveToFirst() && it.getString(0) in setOf("active", "ending_soon", "open_ended") }
            check(oldStatus) { "لا يمكن تجديد عقد غير نشط." }
            require(start.isAfter(java.time.LocalDate.parse(db.rawQuery("SELECT COALESCE(manual_end_date,calculated_end_date,'9999-12-31') FROM leases WHERE id=?", arrayOf(oldLeaseId)).use { it.moveToFirst(); it.getString(0) }))) {
                "بداية العقد الجديد يجب أن تكون بعد نهاية العقد السابق."
            }
            db.update("leases", ContentValues().apply { put("status", "renewed"); put("modified_unreviewed", 1) }, "id=?", arrayOf(oldLeaseId))
            val effectivePercent = if (residentialLaw) java.math.BigDecimal("15") else percent
            val leaseValues = ContentValues().apply {
                put("id", newId); put("unit_id", old[0]); put("tenant_id", old[1]); put("start_date", start.toString())
                if (durationValue == null) putNull("duration_value") else put("duration_value", durationValue)
                if (durationUnit == null) putNull("duration_unit") else put("duration_unit", durationUnit)
                if (end == null) putNull("calculated_end_date") else put("calculated_end_date", end.toString())
                put("initial_rent_minor", rent)
                if (effectivePercent == null) putNull("annual_increase_percent") else put("annual_increase_percent", effectivePercent.toDouble())
                put("increase_rule", if (residentialLaw) "fixed_month_day" else if (effectivePercent == null) "none" else "anniversary")
                if (residentialLaw) { put("increase_month", 9); put("increase_day", 1) }
                put("law_164_2025_applies", if (lawApplies) 1 else 0); put("law_164_residential_rules", if (residentialLaw) 1 else 0)
                put("status", if (end == null) "open_ended" else "active"); put("notes", notes.trim())
                put("modified_unreviewed", 1)
            }
            db.insertOrThrow("leases", null, leaseValues)
            db.insertOrThrow("rent_history", null, ContentValues().apply {
                put("id", UUID.randomUUID().toString()); put("lease_id", newId); put("amount_minor", rent)
                put("valid_from", start.toString()); put("source_type", "manual"); put("approval_status", "approved")
            })
            db.update("units", ContentValues().apply { put("current_tenant_id", old[1]); put("occupancy_status", "occupied"); put("modified_unreviewed", 1) }, "id=?", arrayOf(old[0]))
            appendAudit(db, session, "renew", "lease", oldLeaseId, "{\"new_lease_id\":\"$newId\",\"new_start_date\":\"$start\"}")
            appendAudit(db, session, "create_renewal", "lease", newId, "{\"previous_lease_id\":\"$oldLeaseId\",\"initial_rent_minor\":$rent}")
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
        return newId
    }

    fun addExpense(name: String, amountEgp: String, expenseDate: String, notes: String = ""): String {
        val cleanName = name.trim()
        require(cleanName.isNotEmpty()) { "اسم المصروف مطلوب" }
        val amountMinor = LeaseRules.egpToMinorUnits(amountEgp)
        require(amountMinor >= 0) { "قيمة المصروف لا يمكن أن تكون سالبة" }
        val parsedDate = java.time.LocalDate.parse(expenseDate.trim())
        val id = UUID.randomUUID().toString()
        val values = ContentValues().apply {
            put("id", id)
            put("name", cleanName)
            put("amount_minor", amountMinor)
            put("expense_date", parsedDate.toString())
            put("notes", notes.trim())
        }
        insertChecked("expenses", values, "expense", id,
            "{\"name\":\"${jsonEscape(cleanName)}\",\"amount_minor\":$amountMinor,\"expense_date\":\"$parsedDate\"}")
        return id
    }

    fun addProperty(name: String, address: String? = null): String {
        val cleanName = name.trim()
        require(cleanName.isNotEmpty()) { "اسم العقار مطلوب" }
        val id = UUID.randomUUID().toString()
        val values = ContentValues().apply {
            put("id", id)
            put("name", cleanName)
            put("address_text", address?.trim()?.takeIf(String::isNotEmpty))
            put("review_status", "needs_review")
            put("source_status", "manual")
        }
        insertChecked("properties", values, "property", id,
            "{\"name\":\"${jsonEscape(cleanName)}\"}")
        return id
    }

    fun addTenant(fullName: String, phone: String? = null): String {
        val name = fullName.trim()
        require(name.isNotEmpty()) { "اسم المستأجر مطلوب" }
        val id = UUID.randomUUID().toString()
        val values = ContentValues().apply {
            put("id", id)
            put("full_name", name)
            put("phone", phone?.trim()?.takeIf(String::isNotEmpty))
        }
        insertChecked("tenants", values, "tenant", id,
            "{\"full_name\":\"${jsonEscape(name)}\"}")
        return id
    }

    fun addUnit(propertyId: String, number: String, type: String): String {
        require(propertyId.isNotBlank()) { "العقار مطلوب" }
        require(number.trim().isNotEmpty()) { "رقم الوحدة مطلوب" }
        require(type in setOf("residential", "commercial")) { "نوع الوحدة غير صحيح" }
        val id = UUID.randomUUID().toString()
        val cleanNumber = number.trim()
        val values = ContentValues().apply {
            put("id", id)
            put("property_id", propertyId)
            put("unit_number", cleanNumber)
            put("unit_type", type)
            put("review_status", "needs_review")
            put("source_status", "manual")
        }
        insertChecked("units", values, "unit", id,
            "{\"property_id\":\"${jsonEscape(propertyId)}\",\"unit_number\":\"${jsonEscape(cleanNumber)}\"}")
        return id
    }

    fun updateProperty(id: String, name: String, address: String?, notes: String, reviewStatus: String) {
        val session = requireAdministrator()
        val cleanName = name.trim()
        require(cleanName.isNotEmpty()) { "اسم العقار مطلوب" }
        require(reviewStatus in setOf("sound", "needs_review", "incorrect")) { "حالة المراجعة غير صحيحة" }
        val db = helper.writableDatabase
        db.beginTransaction()
        try {
            val before = db.rawQuery("SELECT name, address_text, notes, review_status FROM properties WHERE id = ? AND archived_at IS NULL", arrayOf(id)).use { cursor ->
                if (!cursor.moveToFirst()) null else "{\"name\":\"${jsonEscape(cursor.getString(0))}\",\"address\":\"${jsonEscape(cursor.getString(1) ?: "")}\",\"notes\":\"${jsonEscape(cursor.getString(2) ?: "")}\",\"review_status\":\"${jsonEscape(cursor.getString(3))}\"}"
            } ?: error("العقار غير موجود أو مؤرشف.")
            val values = ContentValues().apply {
                put("name", cleanName)
                put("address_text", address?.trim()?.takeIf(String::isNotEmpty))
                put("notes", notes.trim())
                put("review_status", reviewStatus)
                put("modified_unreviewed", 1)
            }
            check(db.update("properties", values, "id = ? AND archived_at IS NULL", arrayOf(id)) == 1) { "تعذر تحديث العقار." }
            db.execSQL("UPDATE properties SET updated_at = CURRENT_TIMESTAMP WHERE id = ?", arrayOf<Any>(id))
            val after = "{\"name\":\"${jsonEscape(cleanName)}\",\"address\":\"${jsonEscape(address ?: "")}\",\"notes\":\"${jsonEscape(notes)}\",\"review_status\":\"$reviewStatus\"}"
            appendAudit(db, session, "update", "property", id, after, before)
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun setPropertyHighlighted(propertyId: String, highlighted: Boolean) {
        val session = requireAdministrator()
        val db = helper.writableDatabase
        db.beginTransaction()
        try {
            val values = ContentValues().apply { put("is_highlighted", if (highlighted) 1 else 0) }
            check(db.update("properties", values, "id = ? AND archived_at IS NULL", arrayOf(propertyId)) == 1) {
                "العقار غير موجود."
            }
            appendAudit(db, session, "update", "property", propertyId,
                "{\"is_highlighted\":$highlighted}")
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun clearModifiedMarker(propertyId: String) {
        val session = requireAdministrator()
        val db = helper.writableDatabase
        db.beginTransaction()
        try {
            check(db.update("properties", ContentValues().apply { put("modified_unreviewed", 0) },
                "id = ? AND archived_at IS NULL", arrayOf(propertyId)) == 1) { "العقار غير موجود." }
            appendAudit(db, session, "update", "property", propertyId, "{\"modified_unreviewed\":false}")
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun archiveUnit(unitId: String) {
        val session = requireAdministrator()
        val db = helper.writableDatabase
        db.beginTransaction()
        try {
            val activeLease = db.rawQuery(
                "SELECT COUNT(*) FROM leases WHERE unit_id=? AND archived_at IS NULL AND status IN ('active','ending_soon','open_ended')",
                arrayOf(unitId)
            ).use { it.moveToFirst() && it.getInt(0) > 0 }
            check(!activeLease) { "لا يمكن أرشفة وحدة لها عقد نشط؛ أنهِ العقد أو عالجه أولاً." }
            val values = ContentValues().apply {
                put("archived_at", java.time.LocalDateTime.now().toString())
                put("occupancy_status", "closed")
                putNull("current_tenant_id")
                put("updated_at", java.time.LocalDateTime.now().toString())
            }
            check(db.update("units", values, "id=? AND archived_at IS NULL", arrayOf(unitId)) == 1) {
                "الوحدة غير موجودة أو مؤرشفة بالفعل."
            }
            appendAudit(db, session, "archive", "unit", unitId, "{\"archived\":true}")
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun archiveProperty(propertyId: String) {
        val session = requireAdministrator()
        val db = helper.writableDatabase
        db.beginTransaction()
        try {
            val propertyExists = db.rawQuery(
                "SELECT COUNT(*) FROM properties WHERE id = ? AND archived_at IS NULL",
                arrayOf(propertyId)
            ).use { it.moveToFirst() && it.getInt(0) == 1 }
            check(propertyExists) { "العقار غير موجود أو مؤرشف بالفعل." }
            val activeUnits = db.rawQuery(
                "SELECT COUNT(*) FROM units WHERE property_id = ? AND archived_at IS NULL",
                arrayOf(propertyId)
            ).use { it.moveToFirst() && it.getInt(0) > 0 }
            check(!activeUnits) { "يجب مراجعة وأرشفة الوحدات النشطة أولاً." }
            // Use SQL for the timestamp expression rather than storing its literal text.
            db.execSQL("UPDATE properties SET archived_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP WHERE id = ?", arrayOf<Any>(propertyId))
            appendAudit(db, session, "archive", "property", propertyId, "{\"archived\":true}")
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    private fun insertChecked(table: String, values: ContentValues, entityType: String, entityId: String, afterJson: String) {
        val session = requireAdministrator()
        val db = helper.writableDatabase
        db.beginTransaction()
        try {
            val row = db.insertOrThrow(table, null, values)
            check(row != -1L) { "تعذر حفظ السجل" }
            appendAudit(db, session, "create", entityType, entityId, afterJson)
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    private fun requireAdministrator(): AuthSession {
        val session = currentSession() ?: error("يجب تسجيل الدخول أولاً.")
        check(session.isAdministrator) { "هذه العملية متاحة للمدير فقط." }
        return session
    }

    private fun appendAudit(db: SQLiteDatabase, session: AuthSession, action: String, entityType: String, entityId: String, afterJson: String, beforeJson: String? = null) {
        val values = ContentValues().apply {
            put("id", UUID.randomUUID().toString())
            put("user_id", session.userId)
            put("entity_type", entityType)
            put("entity_id", entityId)
            put("action", action)
            put("before_json", beforeJson)
            put("after_json", afterJson)
        }
        db.insertOrThrow("audit_log", null, values)
    }

    private fun jsonEscape(value: String): String = value.replace("\\", "\\\\").replace("\"", "\\\"")

    private fun count(db: SQLiteDatabase, table: String): Int = db.rawQuery(
        "SELECT COUNT(*) FROM $table WHERE archived_at IS NULL", null
    ).use { if (it.moveToFirst()) it.getInt(0) else 0 }

    private fun sum(db: SQLiteDatabase, table: String, column: String): String = db.rawQuery(
        "SELECT COALESCE(SUM($column),0) FROM $table", null
    ).use { if (it.moveToFirst()) it.getString(0) ?: "0" else "0" }

    /** Dashboard expenses exclude soft-archived rows, matching the active expense list. */
    private fun sumActiveExpenses(db: SQLiteDatabase): String = db.rawQuery(
        "SELECT COALESCE(SUM(amount_minor),0) FROM expenses WHERE archived_at IS NULL", null
    ).use { if (it.moveToFirst()) it.getString(0) ?: "0" else "0" }
}
