package com.example.rentals.domain.collection

/** Single source of truth for monthly collector-batch eligibility, shared by UI and SQLite validation. */
fun collectionIneligibilityReason(status: String): String? {
    val value = status.trim().lowercase()
    return when {
        value.contains("متوقف") -> "الوحدة متوقفة عن الدفع"
        value.contains("مباع") -> "الوحدة مباعة ومحفوظة للأرشيف"
        value.contains("مغلق") -> "الوحدة مغلقة ومحفوظة للأرشيف"
        value.contains("مستبعد") -> "السجل مستبعد من كشف التحصيل"
        value.contains("مكرر") -> "السجل مكرر ويحتاج مراجعة"
        value.contains("غير محسومة") -> "حالة الوحدة غير محسومة وتحتاج اعتمادًا من المراجعة"
        value.contains("تغيير مستأجر") -> "بيانات المستأجر الجديد لم تُعتمد بعد"
        else -> null
    }
}

fun isCollectionEligible(status: String): Boolean = collectionIneligibilityReason(status) == null
