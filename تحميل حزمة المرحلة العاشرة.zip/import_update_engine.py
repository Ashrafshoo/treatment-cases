"""Arabic medication database import engine. Preview first; changes only after explicit approval."""
from __future__ import annotations
import argparse, hashlib, json, re, shutil, sqlite3
from datetime import datetime, date
from pathlib import Path
from openpyxl import load_workbook

PERSONNEL_HEADERS = ['رقم الأداء','الاســـم','الوظيفة','المنطقة','الإدارة','المحمول','المحمول2','الرقم القومى','النوع']
CASE_HEADERS = ['رقم الأداء','العلاج','التركيز','مدة الصرف','الجرعة','الحالة المرضية','تاريخ الموافقة','ملاحظات']
P_FIELDS = {'الاســـم':'full_name','الاسم':'full_name','الوظيفة':'job_title','المنطقة':'region','الإدارة':'department','المحمول':'mobile1','المحمول2':'mobile2','الرقم القومى':'national_id','الرقم القومي':'national_id','النوع':'gender'}
C_FIELDS = {'العلاج':'medicine_name','التركيز':'strength','مدة الصرف':'dispensing_duration','الجرعة':'dosage_text','الحالة المرضية':'medical_condition','تاريخ الموافقة':'approval_date','ملاحظات':'notes'}

def norm(v): return '' if v is None else str(v).strip()
def jsondump(x): return json.dumps(x, ensure_ascii=False, default=str)
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def connect(db):
    c=sqlite3.connect(db); c.row_factory=sqlite3.Row; c.execute('PRAGMA foreign_keys=ON'); return c

def migrate(db):
    c=connect(db)
    c.executescript('''
    CREATE TABLE IF NOT EXISTS Treatments(
      treatment_id INTEGER PRIMARY KEY AUTOINCREMENT,
      beneficiary_id INTEGER NOT NULL REFERENCES Beneficiaries(beneficiary_id),
      medicine_name_raw TEXT NOT NULL, strength_raw TEXT, dispensing_duration TEXT,
      dosage_text TEXT, medical_condition TEXT, approval_date TEXT, notes TEXT,
      status TEXT NOT NULL DEFAULT 'ACTIVE', started_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      stopped_at TEXT, status_note TEXT, source_batch_id INTEGER,
      UNIQUE(beneficiary_id, medicine_name_raw, strength_raw, status)
    );
    CREATE TABLE IF NOT EXISTS Import_Run_Details(
      detail_id INTEGER PRIMARY KEY AUTOINCREMENT, batch_id INTEGER NOT NULL,
      row_number INTEGER NOT NULL, entity_type TEXT NOT NULL, entity_key TEXT,
      action TEXT NOT NULL, old_json TEXT, new_json TEXT, decision TEXT NOT NULL DEFAULT 'PENDING'
    );
    CREATE INDEX IF NOT EXISTS idx_treatments_beneficiary ON Treatments(beneficiary_id,status);
    CREATE TABLE IF NOT EXISTS Medicine_Review_Queue(
      review_id INTEGER PRIMARY KEY AUTOINCREMENT, batch_id INTEGER NOT NULL,
      medicine_name_raw TEXT NOT NULL, first_seen_row INTEGER, review_status TEXT NOT NULL DEFAULT 'PENDING',
      review_note TEXT, UNIQUE(batch_id,medicine_name_raw)
    );
    ''')
    columns={r['name'] for r in c.execute('PRAGMA table_info(Import_Batches_Ext)')}
    if 'source_sha256' not in columns:
        c.execute('ALTER TABLE Import_Batches_Ext ADD COLUMN source_sha256 TEXT')
    # One-time, non-destructive copy of existing 1/2/3 treatment slots.
    for r in c.execute('''SELECT b.beneficiary_id,b.dispensing_duration,b.dosage_text,b.medical_condition,b.approval_date,
                          te.medicine_name_raw,te.strength_raw FROM Beneficiaries b JOIN Treatment_Entries te USING(beneficiary_id)''').fetchall():
        c.execute('''INSERT OR IGNORE INTO Treatments(beneficiary_id,medicine_name_raw,strength_raw,dispensing_duration,dosage_text,medical_condition,approval_date)
                     VALUES(?,?,?,?,?,?,?)''',(r['beneficiary_id'],norm(r['medicine_name_raw']),norm(r['strength_raw']),r['dispensing_duration'],r['dosage_text'],r['medical_condition'],r['approval_date']))
    c.commit(); c.close()

def read_sheet(path, wanted):
    wb=load_workbook(path,read_only=True,data_only=True)
    ws=next((s for s in wb.worksheets if (('عامل' in s.title or 'بيانات' in s.title) if wanted=='personnel' else ('حرج' in s.title or 'حالات' in s.title))),None)
    if ws is None: ws=wb.active
    rows=ws.iter_rows(values_only=True); headers=[norm(x) for x in next(rows,())]
    # old wide data layout support: employee base fields + medicine 1/2/3 columns
    records=[]
    for n,row in enumerate(rows,2):
        d={headers[i]:row[i] if i<len(row) else None for i in range(len(headers)) if headers[i]}
        if any(norm(v) for v in d.values()): records.append((n,d))
    wb.close(); return headers,records

def make_batch(c, typ, path, mode, actor):
    cur=c.execute('INSERT INTO Import_Batches_Ext(batch_type,source_file,import_mode,submitted_by,source_sha256) VALUES(?,?,?,?,?)',(typ,Path(path).name,mode,actor,sha(path)))
    return cur.lastrowid

def preview_personnel(db, path, actor='admin'):
    migrate(db); headers, rows=read_sheet(path,'personnel')
    if 'رقم الأداء' not in headers: raise ValueError('عمود رقم الأداء غير موجود')
    c=connect(db); batch=make_batch(c,'PERSONNEL',path,'PARTIAL_UPDATE',actor); seen=set(); summary={'rows':len(rows),'new':0,'matched':0,'changed':0,'invalid':0,'duplicates':0,'field_changes':0}
    for rn,d in rows:
        perf=norm(d.get('رقم الأداء')); new={P_FIELDS[k]:norm(v) for k,v in d.items() if k in P_FIELDS}
        status='NEW'; old={}
        if not perf: status='INVALID'; summary['invalid']+=1
        elif perf in seen: status='DUPLICATE'; summary['duplicates']+=1
        else:
            seen.add(perf); r=c.execute('SELECT * FROM Personnel WHERE performance_number=?',(perf,)).fetchone()
            if r:
                old={k:r[k] for k in new}; diffs={k:(old.get(k),v) for k,v in new.items() if v!='' and norm(old.get(k))!=v}
                status='CHANGED' if diffs else 'MATCHED'; summary['changed' if diffs else 'matched']+=1; summary['field_changes']+=len(diffs)
            else: summary['new']+=1
        payload={'performance_number':perf,**new}
        c.execute('INSERT INTO Personnel_Import_Staging(batch_id,row_number,performance_number,full_name,job_title,region,department,mobile1,mobile2,national_id,gender,validation_status,validation_message,row_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
          (batch,rn,perf,new.get('full_name'),new.get('job_title'),new.get('region'),new.get('department'),new.get('mobile1'),new.get('mobile2'),new.get('national_id'),new.get('gender'),status,'رقم أداء مكرر' if status=='DUPLICATE' else ('رقم الأداء مطلوب' if status=='INVALID' else ''),jsondump(payload)))
        if status in ('NEW','CHANGED'):
            c.execute('INSERT INTO Import_Run_Details(batch_id,row_number,entity_type,entity_key,action,old_json,new_json) VALUES(?,?,?,?,?,?,?)',(batch,rn,'PERSONNEL',perf,status,jsondump(old),jsondump(payload)))
    c.execute('UPDATE Import_Batches_Ext SET summary_json=? WHERE batch_id=?',(jsondump(summary),batch)); c.commit(); c.close(); return batch,summary

def preview_cases(db,path,mode='PARTIAL_UPDATE',actor='admin'):
    if mode not in ('PARTIAL_UPDATE','FULL_SNAPSHOT'): raise ValueError('وضع الاستيراد غير صحيح')
    migrate(db); headers,rows=read_sheet(path,'cases')
    if 'رقم الأداء' not in headers or 'العلاج' not in headers: raise ValueError('أعمدة رقم الأداء والعلاج مطلوبة')
    c=connect(db); batch=make_batch(c,'CRITICAL_CASES',path,mode,actor); seen=set(); incoming=set(); summary={'rows':len(rows),'new':0,'matched':0,'changed':0,'invalid':0,'unknown_person':0,'duplicate_rows':0,'archive_candidates':0,'unlisted_medicines':0}
    for rn,d in rows:
        perf=norm(d.get('رقم الأداء')); med=norm(d.get('العلاج')); strength=norm(d.get('التركيز')); key=(perf,med,strength)
        new={C_FIELDS[k]:norm(v) for k,v in d.items() if k in C_FIELDS}
        if not perf or not med: status='INVALID'; summary['invalid']+=1
        elif key in seen: status='DUPLICATE'; summary['duplicate_rows']+=1
        elif not c.execute('SELECT 1 FROM Personnel WHERE performance_number=?',(perf,)).fetchone() and not c.execute('SELECT 1 FROM Beneficiaries WHERE performance_number=?',(perf,)).fetchone(): status='UNKNOWN_PERSON'; summary['unknown_person']+=1
        else:
            seen.add(key); incoming.add(key)
            b=c.execute('SELECT beneficiary_id FROM Beneficiaries WHERE performance_number=?',(perf,)).fetchone()
            if not b:
                # Personnel-only person gets a minimal beneficiary record after approval; mark new treatment proposal now.
                old=None
            else: old=c.execute("SELECT * FROM Treatments WHERE beneficiary_id=? AND medicine_name_raw=? AND COALESCE(strength_raw,'')=? AND status='ACTIVE'",(b['beneficiary_id'],med,strength)).fetchone()
            if old:
                oldd={k:old[k] for k in ['dispensing_duration','dosage_text','medical_condition','approval_date','notes']}
                diffs={k:(norm(oldd.get(k)),v) for k,v in new.items() if v!='' and norm(oldd.get(k))!=v}
                status='CHANGED' if diffs else 'MATCHED'; summary['changed' if diffs else 'matched']+=1
            else: oldd={}; status='NEW'; summary['new']+=1
        c.execute('INSERT INTO Case_Import_Staging(batch_id,row_number,performance_number,medicine_name_raw,strength_raw,dispensing_duration,dosage_text,medical_condition,approval_date,notes,validation_status,validation_message,row_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',
          (batch,rn,perf,med,strength,new.get('dispensing_duration'),new.get('dosage_text'),new.get('medical_condition'),new.get('approval_date'),new.get('notes'),status,'',jsondump({'performance_number':perf,'medicine_name_raw':med,'strength_raw':strength,**new})))
        if med and status in ('NEW','CHANGED'):
            known=c.execute('SELECT 1 FROM Medicine_Dictionary_Source WHERE UPPER(TRIM(medicine_name_raw))=UPPER(TRIM(?)) LIMIT 1',(med,)).fetchone()
            try:
                alias_known=c.execute('SELECT 1 FROM Medicine_Name_Aliases WHERE raw_alias=? COLLATE NOCASE LIMIT 1',(med,)).fetchone()
            except sqlite3.OperationalError:
                alias_known=None
            if not known and not alias_known:
                summary['unlisted_medicines']+=1
                c.execute("INSERT OR IGNORE INTO Medicine_Review_Queue(batch_id,medicine_name_raw,first_seen_row,review_note) VALUES(?,?,?,'اسم جديد يحتاج مراجعة القاموس قبل توحيده')",(batch,med,rn))
        if status in ('NEW','CHANGED'):
            c.execute('INSERT INTO Import_Run_Details(batch_id,row_number,entity_type,entity_key,action,old_json,new_json) VALUES(?,?,?,?,?,?,?)',(batch,rn,'TREATMENT','|'.join(key),status,jsondump(oldd),jsondump({'performance_number':perf,'medicine_name_raw':med,'strength_raw':strength,**new})))
    if mode=='FULL_SNAPSHOT':
        active=c.execute("SELECT t.*,b.performance_number FROM Treatments t JOIN Beneficiaries b USING(beneficiary_id) WHERE t.status='ACTIVE'").fetchall()
        for t in active:
            if (norm(t['performance_number']),norm(t['medicine_name_raw']),norm(t['strength_raw'])) not in incoming:
                summary['archive_candidates']+=1
                old={k:t[k] for k in t.keys()}
                c.execute('INSERT INTO Import_Run_Details(batch_id,row_number,entity_type,entity_key,action,old_json,new_json) VALUES(?,?,?,?,?,?,?)',(batch,0,'TREATMENT',f"{t['performance_number']}|{t['medicine_name_raw']}|{t['strength_raw']}",'ARCHIVE_CANDIDATE',jsondump(old),jsondump({'status':'STOPPED','status_note':'توقف عن هذا العلاج'})))
    c.execute('UPDATE Import_Batches_Ext SET summary_json=? WHERE batch_id=?',(jsondump(summary),batch)); c.commit(); c.close(); return batch,summary

def egyptian_nid_birthdate(nid):
    s=norm(nid)
    if not re.fullmatch(r'\d{14}',s): return None,'NEEDS_REVIEW'
    century={'2':1900,'3':2000}.get(s[0])
    if not century: return None,'NEEDS_REVIEW'
    try: d=date(century+int(s[1:3]),int(s[3:5]),int(s[5:7]))
    except ValueError: return None,'NEEDS_REVIEW'
    return d.isoformat(),'VALID'

def approve(db,batch_id,approved_by='admin',include_archive=False):
    c=connect(db); batch=c.execute('SELECT * FROM Import_Batches_Ext WHERE batch_id=?',(batch_id,)).fetchone()
    if not batch: raise ValueError('دفعة غير موجودة')
    if batch['approval_status']=='APPROVED': raise ValueError('تم اعتماد هذه الدفعة مسبقاً')
    c.execute('SAVEPOINT apply_batch')
    try:
        details=c.execute("SELECT * FROM Import_Run_Details WHERE batch_id=? AND decision='PENDING' ORDER BY detail_id",(batch_id,)).fetchall(); counts={'personnel_added':0,'personnel_updated':0,'treatments_added':0,'treatments_updated':0,'treatments_archived':0}
        for p in details:
            old=json.loads(p['old_json'] or '{}'); new=json.loads(p['new_json'] or '{}'); action=p['action']
            if p['entity_type']=='PERSONNEL':
                perf=new['performance_number']; current=c.execute('SELECT * FROM Personnel WHERE performance_number=?',(perf,)).fetchone()
                if not current:
                    nid=new.get('national_id',''); bd,vs=egyptian_nid_birthdate(nid)
                    c.execute('''INSERT INTO Personnel(performance_number,full_name,job_title,region,department,mobile1,mobile2,national_id,gender,birth_date,national_id_validation_status,source_batch_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)''',(perf,new.get('full_name'),new.get('job_title'),new.get('region'),new.get('department'),new.get('mobile1'),new.get('mobile2'),nid,new.get('gender'),bd,vs,batch_id)); counts['personnel_added']+=1
                else:
                    updates={k:v for k,v in new.items() if k!='performance_number' and v!=''}
                    if updates:
                        sets=','.join(f'{k}=?' for k in updates); vals=list(updates.values())
                        if 'national_id' in updates:
                            bd,vs=egyptian_nid_birthdate(updates['national_id']); sets+=',birth_date=?,national_id_validation_status=?'; vals += [bd,vs]
                        sets+=",updated_at=CURRENT_TIMESTAMP,source_batch_id=?"; vals += [batch_id,perf]
                        c.execute(f'UPDATE Personnel SET {sets} WHERE performance_number=?',vals); counts['personnel_updated']+=1
                c.execute('INSERT INTO Data_Audit_Log(batch_id,entity_type,entity_key,action,before_json,after_json,actor) VALUES(?,?,?,?,?,?,?)',(batch_id,'PERSONNEL',perf,action,jsondump(old),jsondump(new),approved_by))
            elif p['entity_type']=='TREATMENT':
                if action=='ARCHIVE_CANDIDATE':
                    if not include_archive:
                        c.execute("UPDATE Import_Run_Details SET decision='SKIPPED' WHERE detail_id=?",(p['detail_id'],))
                        continue
                    perf,med,strength=p['entity_key'].split('|',2)
                    b=c.execute('SELECT beneficiary_id FROM Beneficiaries WHERE performance_number=?',(perf,)).fetchone()
                    if not b: continue
                    t=c.execute("SELECT * FROM Treatments WHERE beneficiary_id=? AND medicine_name_raw=? AND COALESCE(strength_raw,'')=? AND status='ACTIVE'",(b['beneficiary_id'],med,strength)).fetchone()
                    if t:
                        c.execute("UPDATE Treatments SET status='STOPPED',status_note='توقف عن هذا العلاج',stopped_at=CURRENT_TIMESTAMP WHERE treatment_id=?",(t['treatment_id'],))
                        c.execute('INSERT INTO Treatment_History(beneficiary_id,treatment_order,medicine_name_raw,strength_raw,dispensing_duration,dosage_text,medical_condition,approval_date,treatment_status,status_note,stopped_at,source_batch_id,source_row_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',(b['beneficiary_id'],None,t['medicine_name_raw'],t['strength_raw'],t['dispensing_duration'],t['dosage_text'],t['medical_condition'],t['approval_date'],'STOPPED','توقف عن هذا العلاج',datetime.now().isoformat(timespec='seconds'),batch_id,jsondump(old))); counts['treatments_archived']+=1
                        c.execute('INSERT INTO Data_Audit_Log(batch_id,entity_type,entity_key,action,before_json,after_json,actor) VALUES(?,?,?,?,?,?,?)',(batch_id,'TREATMENT',p['entity_key'],'ARCHIVED',jsondump(old),jsondump({'status':'STOPPED'}),approved_by))
                    continue
                perf=new['performance_number']; med=new['medicine_name_raw']; strength=new.get('strength_raw','')
                b=c.execute('SELECT beneficiary_id FROM Beneficiaries WHERE performance_number=?',(perf,)).fetchone()
                if not b:
                    pr=c.execute('SELECT * FROM Personnel WHERE performance_number=?',(perf,)).fetchone()
                    if not pr: raise ValueError(f'رقم أداء غير موجود: {perf}')
                    cur=c.execute('INSERT INTO Beneficiaries(source_batch_id,source_sheet,source_row,full_name,performance_number,region,department,original_row_json) VALUES(?,?,?,?,?,?,?,?)',(batch_id,'CRITICAL_CASES',p['row_number'],pr['full_name'],perf,pr['region'],pr['department'],jsondump(new))); bid=cur.lastrowid
                else: bid=b['beneficiary_id']
                t=c.execute("SELECT treatment_id FROM Treatments WHERE beneficiary_id=? AND medicine_name_raw=? AND COALESCE(strength_raw,'')=? AND status='ACTIVE'",(bid,med,strength)).fetchone()
                vals=(new.get('dispensing_duration'),new.get('dosage_text'),new.get('medical_condition'),new.get('approval_date'),new.get('notes'),batch_id)
                if t:
                    c.execute('UPDATE Treatments SET dispensing_duration=?,dosage_text=?,medical_condition=?,approval_date=?,notes=?,source_batch_id=? WHERE treatment_id=?',(*vals,t['treatment_id'])); counts['treatments_updated']+=1
                else:
                    c.execute('INSERT INTO Treatments(beneficiary_id,medicine_name_raw,strength_raw,dispensing_duration,dosage_text,medical_condition,approval_date,notes,source_batch_id) VALUES(?,?,?,?,?,?,?,?,?)',(bid,med,strength,*vals)); counts['treatments_added']+=1
                c.execute('INSERT INTO Data_Audit_Log(batch_id,entity_type,entity_key,action,before_json,after_json,actor) VALUES(?,?,?,?,?,?,?)',(batch_id,'TREATMENT',p['entity_key'],action,jsondump(old),jsondump(new),approved_by))
            c.execute("UPDATE Import_Run_Details SET decision='APPROVED' WHERE detail_id=?",(p['detail_id'],))
        c.execute("UPDATE Import_Batches_Ext SET approval_status='APPROVED',approved_by=?,approved_at=CURRENT_TIMESTAMP,preview_status='APPLIED' WHERE batch_id=?",(approved_by,batch_id))
        c.execute('RELEASE apply_batch'); c.commit(); return counts
    except Exception:
        c.execute('ROLLBACK TO apply_batch'); c.execute('RELEASE apply_batch'); c.rollback(); raise
    finally: c.close()

def main():
    ap=argparse.ArgumentParser(description='استيراد آمن لقاعدة علاج الحالات حاجة')
    ap.add_argument('--db',required=True); ap.add_argument('--file',required=True); ap.add_argument('--type',choices=['personnel','cases'],required=True); ap.add_argument('--mode',choices=['PARTIAL_UPDATE','FULL_SNAPSHOT'],default='PARTIAL_UPDATE'); ap.add_argument('--approve',type=int); ap.add_argument('--actor',default='admin')
    a=ap.parse_args();
    if a.approve:
        print(jsondump(approve(a.db,a.approve,a.actor))); return
    result=preview_personnel(a.db,a.file,a.actor) if a.type=='personnel' else preview_cases(a.db,a.file,a.mode,a.actor)
    print(jsondump({'batch_id':result[0],'summary':result[1],'message':'معاينة فقط؛ لم تتغير البيانات. استخدم --approve مع رقم الدفعة بعد المراجعة.'}))
if __name__=='__main__': main()
