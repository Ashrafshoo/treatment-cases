package com.treatmentcases.app

import android.content.ContentResolver
import android.net.Uri
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** XLSX interchange dedicated to the company-wide employee directory. */
object EmployeeXlsx {
    private const val MAX_FILE_BYTES = 32 * 1024 * 1024
    private const val MAX_EXPANDED_BYTES = 64 * 1024 * 1024

    fun read(cr: ContentResolver, uri: Uri): List<EmployeeRecord> {
        val raw = cr.openInputStream(uri)?.use { readBounded(it, MAX_FILE_BYTES) } ?: error("تعذر فتح ملف Excel")
        require(raw.size >= 4 && raw[0] == 'P'.code.toByte() && raw[1] == 'K'.code.toByte()) { "الملف ليس XLSX صالحاً. استخدم القالب الرسمي بصيغة XLSX." }
        val parts = mutableMapOf<String, ByteArray>()
        var expanded = 0L
        ZipInputStream(ByteArrayInputStream(raw)).use { z ->
            var entries = 0
            while (true) {
                val e = z.nextEntry ?: break
                entries++
                require(entries <= 1000) { "ملف Excel يحتوي على عدد غير طبيعي من المكونات." }
                require(!e.name.startsWith("/") && !e.name.contains("../") && !e.name.contains("\\")) { "يحتوي الملف على مسار داخلي غير آمن." }
                val bytes = readBounded(z, (MAX_EXPANDED_BYTES - expanded).coerceAtLeast(0).toInt())
                expanded += bytes.size
                parts[e.name] = bytes
            }
        }
        val strings = parts["xl/sharedStrings.xml"]?.let(::sharedStrings) ?: emptyList()
        val sheet = parts["xl/worksheets/sheet1.xml"] ?: error("ورقة البيانات غير موجودة في الملف")
        val rows = parseSheet(sheet, strings)
        require(rows.isNotEmpty()) { "الملف فارغ أو لا يحتوي على صف عناوين" }
        require(rows.firstOrNull()?.firstOrNull()?.startsWith("دليل العاملين بالشركة") == true || rows.firstOrNull()?.firstOrNull()?.startsWith("قالب دليل العاملين بالشركة") == true) { "هذا ليس ملف دليل العاملين الصادر من البرنامج. استخرج القالب الرسمي أولاً." }
        val headerRow = rows.indexOfFirst { row -> row.any { it.trim() == "رقم الأداء" } }
        require(headerRow >= 0) { "قالب غير متوافق: لم يتم العثور على عمود رقم الأداء" }
        val headers = rows[headerRow].map { it.trim() }
        val required = EmployeeRecord.headers
        val positions = required.map { expected -> headers.indexOf(expected) }
        require(positions.all { it >= 0 }) { "عناوين الأعمدة لا تطابق قالب دليل العاملين الرسمي. أعد استخراج القالب من التطبيق." }
        val parsed = rows.drop(headerRow + 1).mapIndexedNotNull { index, row ->
            val cells = positions.map { row.getOrElse(it) { "" }.trim() }
            if (cells.all { it.isBlank() }) null else EmployeeRecord(
                performanceNo = cells[0], name = cells[1], job = cells[2], entity = cells[3], department = cells[4],
                nationalId = cells[5], phone1 = cells[6], phone2 = cells[7], gender = cells[8], notes = cells[9], sourceRow = headerRow + index + 2
            )
        }
        require(parsed.size <= 10000) { "عدد السجلات يتجاوز الحد الآمن للدفعة الواحدة (10000). قسّم الملف إلى دفعات." }
        return parsed
    }

    private fun readBounded(input: java.io.InputStream, limit: Int): ByteArray {
        val output = ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        var total = 0
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            if (count == 0) continue
            total += count
            require(total <= limit) { "حجم الملف أو محتوياته أكبر من الحد المسموح." }
            output.write(buffer, 0, count)
        }
        return output.toByteArray()
    }

    fun writeTemplate(cr: ContentResolver, uri: Uri) = write(cr, uri, listOf(
        listOf("قالب دليل العاملين بالشركة", "إصدار 1"),
        listOf("تعليمات", "املأ الصفوف أسفل العناوين فقط. رقم الأداء إلزامي وفريد."),
        listOf("ملاحظة", "لا تغير أسماء الأعمدة. الخانة الفارغة لا تمسح البيانات الحالية عند تحديث موظف موجود."),
        EmployeeRecord.headers
    ) + List(500) { List(10) { "" } })

    fun writeDirectory(cr: ContentResolver, uri: Uri, employees: List<EmployeeRecord>) = write(cr, uri,
        listOf(listOf("دليل العاملين بالشركة", "تصدير بيانات العاملين"), EmployeeRecord.headers) + employees.map { it.cells() })

    private fun write(cr: ContentResolver, uri: Uri, matrix: List<List<String>>) {
        val headerRowIndex = if (matrix.firstOrNull()?.firstOrNull()?.startsWith("قالب دليل العاملين") == true) 3 else 1
        val xml = buildString {
            append("<?xml version=\"1.0\" encoding=\"UTF-8\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><cols><col min=\"1\" max=\"1\" width=\"18\" customWidth=\"1\"/><col min=\"2\" max=\"5\" width=\"22\" customWidth=\"1\"/><col min=\"6\" max=\"6\" width=\"20\" customWidth=\"1\"/><col min=\"7\" max=\"10\" width=\"22\" customWidth=\"1\"/></cols><sheetData>")
            matrix.forEachIndexed { ri, row ->
                append("<row r=\"${ri + 1}\">")
                row.forEachIndexed { ci, value ->
                    val style = when { ri == headerRowIndex -> 2; ci == 0 || ci == 5 || ci == 6 || ci == 7 -> 1; else -> 0 }
                    append("<c r=\"${col(ci)}${ri + 1}\" s=\"$style\" t=\"inlineStr\"><is><t xml:space=\"preserve\">${esc(value)}</t></is></c>")
                }
                append("</row>")
            }
            append("</sheetData></worksheet>")
        }
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { z ->
            fun put(path: String, content: String) { z.putNextEntry(ZipEntry(path)); z.write(content.toByteArray(Charsets.UTF_8)); z.closeEntry() }
            put("[Content_Types].xml", "<?xml version=\"1.0\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/><Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/></Types>")
            put("_rels/.rels", "<?xml version=\"1.0\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>")
            put("xl/workbook.xml", "<?xml version=\"1.0\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\"دليل العاملين\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>")
            put("xl/_rels/workbook.xml.rels", "<?xml version=\"1.0\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/><Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/></Relationships>")
            put("xl/styles.xml", "<?xml version=\"1.0\"?><styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><numFmts count=\"1\"><numFmt numFmtId=\"164\" formatCode=\"@\"/></numFmts><fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font><font><b/><color rgb=\"FFFFFFFF\"/><sz val=\"11\"/><name val=\"Calibri\"/></font></fonts><fills count=\"2\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"solid\"><fgColor rgb=\"FF0759C7\"/><bgColor indexed=\"64\"/></patternFill></fill></fills><borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs><cellXfs count=\"3\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/><xf numFmtId=\"164\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyNumberFormat=\"1\"/><xf numFmtId=\"0\" fontId=\"1\" fillId=\"1\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\"/></cellXfs></styleSheet>")
            put("xl/worksheets/sheet1.xml", xml)
        }
        cr.openOutputStream(uri)?.use { it.write(out.toByteArray()) } ?: error("تعذر حفظ ملف Excel")
    }

    private fun sharedStrings(bytes: ByteArray): List<String> {
        val p = Xml.newPullParser(); p.setInput(ByteArrayInputStream(bytes), "UTF-8")
        val result = mutableListOf<String>(); var inSi = false; var value = ""
        while (p.eventType != XmlPullParser.END_DOCUMENT) { if (p.eventType == XmlPullParser.START_TAG && p.name == "si") { inSi = true; value = "" } else if (inSi && p.eventType == XmlPullParser.TEXT) value += p.text else if (p.eventType == XmlPullParser.END_TAG && p.name == "si") { result += value; inSi = false }; p.next() }
        return result
    }
    private fun parseSheet(bytes: ByteArray, shared: List<String>): List<List<String>> {
        val p = Xml.newPullParser(); p.setInput(ByteArrayInputStream(bytes), "UTF-8")
        val result = mutableListOf<List<String>>(); var row = mutableListOf<String>(); var ref = "A1"; var type = ""; var value = ""; var active = false
        fun col(s: String): Int { var n = 0; s.takeWhile { it.isLetter() }.forEach { n = n * 26 + (it.uppercaseChar() - 'A' + 1) }; return (n - 1).coerceAtLeast(0) }
        while (p.eventType != XmlPullParser.END_DOCUMENT) { when (p.eventType) {
            XmlPullParser.START_TAG -> when (p.name) { "row" -> row = mutableListOf(); "c" -> { ref = p.getAttributeValue(null, "r") ?: "A1"; type = p.getAttributeValue(null, "t") ?: ""; value = "" }; "v", "t" -> active = true }
            XmlPullParser.TEXT -> if (active) value += p.text
            XmlPullParser.END_TAG -> when (p.name) { "v", "t" -> active = false; "c" -> { val i = col(ref); while (row.size <= i) row.add(""); row[i] = if (type == "s") shared.getOrElse(value.toIntOrNull() ?: -1) { "" } else value }; "row" -> result += row.toList() }
        }; p.next() }
        return result
    }
    private fun col(index: Int): String { var n = index + 1; var s = ""; while (n > 0) { s = ('A' + (n - 1) % 26) + s; n = (n - 1) / 26 }; return s }
    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&apos;")
}
