#!/usr/bin/env python3
"""Saved aggregate PDFs are reopened and checked before success is reported."""
from pathlib import Path
R=Path(__file__).resolve().parents[1]
S=(R/'app/src/main/java/com/example/rentals/printing/AggregateReceiptPdfExporter.kt').read_text(encoding='utf-8')
assert 'resolver.openInputStream(uri)' in S
assert 'String(header, Charsets.US_ASCII) == "%PDF-"' in S
assert 'total >= 512L' in S
print('PASS: aggregate PDF output is reopened and validated for PDF signature and non-empty payload')
