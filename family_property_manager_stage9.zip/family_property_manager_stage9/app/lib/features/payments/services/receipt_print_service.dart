import 'package:flutter/services.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import '../data/payments_repository.dart';
import '../../../core/database/app_database.dart';
import '../../auth/data/app_session.dart';

class ReceiptPrintService {
  Future<int> printApprovedReceipts() async {
    AppSession.instance.requireAdmin();
    final db=await AppDatabase.instance.database;
    final rows=await db.query('receipts',where:'approved=1',orderBy:'issued_at DESC, receipt_number DESC');
    if(rows.isEmpty)throw StateError('لا توجد إيصالات معتمدة للطباعة');
    final font=pw.Font.ttf(await rootBundle.load('assets/fonts/NotoSansArabic-Regular.ttf'));
    final document=pw.Document();
    for(var start=0;start<rows.length;start+=3){
      final batch=rows.skip(start).take(3).toList();
      document.addPage(pw.Page(pageFormat:PdfPageFormat.a4,margin:const pw.EdgeInsets.all(20),build:(context)=>pw.Directionality(textDirection:pw.TextDirection.rtl,child:pw.Column(children:[
        for(var i=0;i<3;i++)...[
          if(i<batch.length)_receipt(batch[i],font),
          if(i<2&&i<batch.length-1)pw.SizedBox(height:8),
        ],
      ]))));
    }
    await Printing.layoutPdf(onLayout:(format)async=>document.save(),name:'family_rent_receipts.pdf');
    return rows.length;
  }

  pw.Widget _receipt(Map<String,Object?> r,pw.Font font){
    final amount=(r['amount_minor'] as num).toInt();
    final amountText=(amount/100).toStringAsFixed(2);
    final remaining=r['remaining_minor']==null?null:((r['remaining_minor'] as num)/100).toStringAsFixed(2);
    final law=(r['law_164_2025_snapshot'] as num?)?.toInt()==1;
    pw.Widget line(String label,Object? value)=>pw.Padding(padding:const pw.EdgeInsets.symmetric(vertical:3),child:pw.Row(children:[pw.Expanded(flex:2,child:pw.Text(label,style:pw.TextStyle(font:font,fontSize:10,fontWeight:pw.FontWeight.bold))),pw.Expanded(flex:5,child:pw.Text(value?.toString()??'—',style:pw.TextStyle(font:font,fontSize:10),textAlign:pw.TextAlign.right))]));
    return pw.Container(height:245,width:double.infinity,padding:const pw.EdgeInsets.all(12),decoration:pw.BoxDecoration(border:pw.Border.all(color:PdfColors.grey700,width:0.8)),child:pw.Column(crossAxisAlignment:pw.CrossAxisAlignment.stretch,children:[
      pw.Row(mainAxisAlignment:pw.MainAxisAlignment.spaceBetween,children:[pw.Text('إيصال إيجار',style:pw.TextStyle(font:font,fontSize:16,fontWeight:pw.FontWeight.bold)),pw.Text('رقم: ${r['receipt_number']}',style:pw.TextStyle(font:font,fontSize:10))]),
      pw.Divider(),line('المستلم من:',r['tenant_snapshot']),line('العقار:',r['property_snapshot']),line('الوحدة:',r['unit_snapshot']),line('تاريخ الإيصال:',r['issued_at']),line('عن الفترة:',r['period_snapshot']),
      pw.SizedBox(height:4),pw.Container(padding:const pw.EdgeInsets.all(8),color:PdfColors.grey200,child:pw.Column(crossAxisAlignment:pw.CrossAxisAlignment.stretch,children:[pw.Text('المبلغ: $amountText جنيه مصري',style:pw.TextStyle(font:font,fontSize:13,fontWeight:pw.FontWeight.bold)),pw.Text('فقط ${r['amount_words_snapshot']??PaymentsRepository.amountInArabicWords(amount)}',style:pw.TextStyle(font:font,fontSize:9))])),
      if(remaining!=null)line('المتبقي عن الفترة:', '$remaining جنيه'),line('طريقة الدفع:',_method(r['payment_method_snapshot'])),
      if(law)pw.Text('إيجار قديم – قانون 164 لسنة 2025',style:pw.TextStyle(font:font,fontSize:9,fontWeight:pw.FontWeight.bold)),
      pw.Spacer(),pw.Row(mainAxisAlignment:pw.MainAxisAlignment.spaceBetween,children:[pw.Text('توقيع المستلم: ______________',style:pw.TextStyle(font:font,fontSize:9)),pw.Text('ختم / توقيع الإدارة: __________',style:pw.TextStyle(font:font,fontSize:9))]),
    ]));
  }
  String _method(Object? value)=>switch(value){'cash'=>'نقداً','bank_transfer'=>'تحويل بنكي','wallet'=>'محفظة إلكترونية','cheque'=>'شيك',_=>'أخرى'};
}
