package com.familyproperties.app

import android.content.ContentValues
import android.util.Base64
import net.zetetic.database.sqlcipher.SQLiteDatabase
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.UUID
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

data class AuthSession(
    val userId: String,
    val username: String,
    val role: String
) {
    val isAdministrator: Boolean get() = role == ROLE_ADMINISTRATOR
    val isFamilyViewer: Boolean get() = role == ROLE_FAMILY_VIEWER

    companion object {
        const val ROLE_ADMINISTRATOR = "administrator"
        const val ROLE_FAMILY_VIEWER = "family_viewer"
    }
}

/** Authentication records are local to this device; only salted password hashes are stored. */
class AuthRepository(private val helper: FamilyDatabase) {
    fun hasAccounts(): Boolean = helper.readableDatabase.rawQuery(
        "SELECT COUNT(*) FROM users", null
    ).use { it.moveToFirst() && it.getInt(0) > 0 }

    fun createInitialAdministrator(password: CharArray): AuthSession {
        try {
            validatePassword(password)
            val db = helper.writableDatabase
            val userId = UUID.randomUUID().toString()
            val passwordHash = PasswordHash.create(password)
            db.beginTransaction()
            try {
                val existing = db.rawQuery("SELECT COUNT(*) FROM users", null)
                    .use { it.moveToFirst() && it.getInt(0) > 0 }
                check(!existing) { "The initial administrator has already been created." }
                val values = ContentValues().apply {
                    put("id", userId)
                    put("username", ADMIN_USERNAME)
                    put("display_name", "مدير النظام")
                    put("role", AuthSession.ROLE_ADMINISTRATOR)
                    put("password_hash", passwordHash)
                    put("is_active", 1)
                }
                db.insertOrThrow("users", null, values)
                appendAudit(db, userId, "create", "user", userId,
                    "{\"username\":\"$ADMIN_USERNAME\",\"role\":\"administrator\"}")
                db.setTransactionSuccessful()
            } finally {
                db.endTransaction()
            }
            return AuthSession(userId, ADMIN_USERNAME, AuthSession.ROLE_ADMINISTRATOR)
        } finally {
            password.fill('\u0000')
        }
    }

    /** Restores only the locally enrolled account after Android BiometricPrompt succeeds. */
    fun loginWithBiometric(userId: String): AuthSession? = helper.readableDatabase.rawQuery(
        "SELECT id, username, role, is_active FROM users WHERE id=? LIMIT 1", arrayOf(userId)
    ).use { cursor ->
        if (!cursor.moveToFirst() || cursor.getInt(3) != 1) null
        else AuthSession(cursor.getString(0), cursor.getString(1), cursor.getString(2))
    }

    fun login(username: String, password: CharArray): AuthSession? {
        val cleanUsername = username.trim()
        if (cleanUsername.isEmpty() || password.isEmpty()) {
            password.fill('\u0000')
            return null
        }
        return try {
            helper.readableDatabase.rawQuery(
                "SELECT id, username, password_hash, role, is_active FROM users WHERE username = ? COLLATE NOCASE LIMIT 1",
                arrayOf(cleanUsername)
            ).use { cursor ->
                if (!cursor.moveToFirst() || cursor.getInt(4) != 1) return@use null
                val encodedHash = cursor.getString(2) ?: return@use null
                if (!PasswordHash.verify(password, encodedHash)) return@use null
                AuthSession(cursor.getString(0), cursor.getString(1), cursor.getString(3))
            }
        } finally {
            password.fill('\u0000')
        }
    }

    fun createFamilyViewer(
        administrator: AuthSession,
        username: String,
        displayName: String,
        password: CharArray
    ): String {
        try {
            requireAdministrator(administrator)
            val cleanUsername = username.trim()
            val cleanDisplayName = displayName.trim()
            require(cleanUsername.isNotEmpty()) { "اسم المستخدم مطلوب" }
            require(cleanDisplayName.isNotEmpty()) { "اسم العرض مطلوب" }
            validatePassword(password)
            val userId = UUID.randomUUID().toString()
            val values = ContentValues().apply {
                put("id", userId)
                put("username", cleanUsername)
                put("display_name", cleanDisplayName)
                put("role", AuthSession.ROLE_FAMILY_VIEWER)
                put("password_hash", PasswordHash.create(password))
                put("is_active", 1)
            }
            val db = helper.writableDatabase
            db.beginTransaction()
            try {
                db.insertOrThrow("users", null, values)
                appendAudit(db, administrator.userId, "create", "user", userId,
                    "{\"username\":\"${jsonEscape(cleanUsername)}\",\"role\":\"family_viewer\"}")
                db.setTransactionSuccessful()
            } finally {
                db.endTransaction()
            }
            return userId
        } finally {
            password.fill('\u0000')
        }
    }

    fun changePassword(session: AuthSession, newPassword: CharArray) {
        try {
            validatePassword(newPassword)
            val db = helper.writableDatabase
            db.beginTransaction()
            try {
                val values = ContentValues().apply { put("password_hash", PasswordHash.create(newPassword)) }
                check(db.update("users", values, "id = ? AND is_active = 1", arrayOf(session.userId)) == 1) {
                    "The user account could not be updated."
                }
                appendAudit(db, session.userId, "update", "user", session.userId, "{\"password\":\"changed\"}")
                db.setTransactionSuccessful()
            } finally {
                db.endTransaction()
            }
        } finally {
            newPassword.fill('\u0000')
        }
    }

    private fun validatePassword(password: CharArray) {
        require(password.size >= MIN_PASSWORD_LENGTH) { "كلمة المرور يجب ألا تقل عن 10 أحرف" }
        require(password.any { it.isLetter() } && password.any { it.isDigit() }) {
            "يجب أن تحتوي كلمة المرور على حرف واحد ورقم واحد على الأقل"
        }
    }

    private fun requireAdministrator(session: AuthSession) {
        check(session.isAdministrator) { "هذه العملية متاحة للمدير فقط." }
    }

    private fun appendAudit(db: SQLiteDatabase, actorId: String, action: String, entityType: String, entityId: String, afterJson: String) {
        val audit = ContentValues().apply {
            put("id", UUID.randomUUID().toString())
            put("user_id", actorId)
            put("entity_type", entityType)
            put("entity_id", entityId)
            put("action", action)
            put("after_json", afterJson)
        }
        db.insertOrThrow("audit_log", null, audit)
    }

    private fun jsonEscape(value: String): String = value.replace("\\", "\\\\").replace("\"", "\\\"")

    companion object {
        const val ADMIN_USERNAME = "Ashrafshoo"
        private const val MIN_PASSWORD_LENGTH = 10
    }
}

private object PasswordHash {
    private const val ALGORITHM = "PBKDF2WithHmacSHA256"
    private const val ITERATIONS = 310_000
    private const val KEY_BITS = 256
    private const val SALT_BYTES = 16

    fun create(password: CharArray): String {
        val salt = ByteArray(SALT_BYTES).also { SecureRandom().nextBytes(it) }
        val derived = derive(password, salt, ITERATIONS)
        return listOf(
            "pbkdf2_sha256_v1",
            ITERATIONS.toString(),
            Base64.encodeToString(salt, Base64.NO_WRAP),
            Base64.encodeToString(derived, Base64.NO_WRAP)
        ).joinToString("\$")
    }

    fun verify(password: CharArray, encoded: String): Boolean {
        val parts = encoded.split('$')
        if (parts.size != 4 || parts[0] != "pbkdf2_sha256_v1") return false
        val iterations = parts[1].toIntOrNull() ?: return false
        if (iterations !in 100_000..1_000_000) return false
        return try {
            val salt = Base64.decode(parts[2], Base64.NO_WRAP)
            val expected = Base64.decode(parts[3], Base64.NO_WRAP)
            val actual = derive(password, salt, iterations)
            MessageDigest.isEqual(expected, actual)
        } catch (_: IllegalArgumentException) {
            false
        }
    }

    private fun derive(password: CharArray, salt: ByteArray, iterations: Int): ByteArray {
        val spec = PBEKeySpec(password, salt, iterations, KEY_BITS)
        return try {
            SecretKeyFactory.getInstance(ALGORITHM).generateSecret(spec).encoded
        } finally {
            spec.clearPassword()
        }
    }
}
